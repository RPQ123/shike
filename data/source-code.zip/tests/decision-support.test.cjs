const test = require('node:test');
const assert = require('node:assert/strict');
const R = require('../dist/research.js');
const D = require('../dist/decision-support.js');

function round(totals = [20, 30, 40]) {
  return { meanTotal: totals.reduce((a, b) => a + b, 0) / 3, meanWait: 10,
    seatWait: 1, onTime: 0.8, ...Object.fromEntries(totals.flatMap((value, id) => [
      [`grade${id}Total`, value], [`grade${id}Count`, 120], [`grade${id}OnTime`, 0.8]
    ])) };
}
const copies = (value) => [R.clone(value), R.clone(value), R.clone(value)];

test('identical paired scenarios have zero differences and pass the explicit threshold', () => {
  const a = R.example(), rows = copies(round());
  const result = D.assess(a, a, rows, rows, 0.5);
  assert.deepEqual([result.total.mean, result.total.low, result.total.high], [0, 0, 0]);
  assert.equal(result.guard, 'within');
  assert.ok(result.grades.every(g => g.change === 'same'));
});

test('a lower overall mean does not conceal a one-minute loss for the last grade', () => {
  const a = R.example();
  const result = D.assess(a, a, copies(round()), copies(round([19.4, 29, 41])), 0.5);
  assert.ok(Math.abs(result.total.mean + 0.2) < 1e-10);
  assert.equal(result.guard, 'exceeded');
  assert.equal(result.mostAffected.id, 2);
  assert.equal(result.mostAffected.delta.mean, 1);
  assert.equal(result.grades[2].change, 'increase');
});

test('individual paired intervals, not only the mean, determine an uncertain threshold check', () => {
  const a = R.example(), rows = copies(round()), b = [round([20,30,40]), round([20,30,41]), round([20,30,40])];
  const result = D.assess(a, a, rows, b, 0.5);
  assert.ok(result.grades[2].delta.mean < 0.5);
  assert.ok(result.grades[2].delta.high > 0.5);
  assert.equal(result.guard, 'uncertain');
});

test('changing the time origin or endpoint prevents a misleading grade-fairness verdict', () => {
  const a = R.example(), b = R.clone(a);
  b.grades[0].readyTime -= 1;
  const result = D.assess(a, b, copies(round()), copies(round()), 0.5);
  assert.equal(result.comparability.comparable, false);
  assert.equal(result.guard, 'not-comparable');
  assert.ok(result.comparability.reasons.some(reason => reason.code === 'ready-time'));
  b.grades[0].readyTime = a.grades[0].readyTime;
  b.returnDestination = 'gate';
  assert.ok(D.comparability(a,b).reasons.some(reason => reason.code === 'endpoint'));
});

test('changing grade composition is detected even when total population is unchanged', () => {
  const a = R.example(), b = R.clone(a);
  b.grades[0].students -= 10; b.grades[1].students += 10;
  assert.equal(D.comparability(a,b).comparable, false);
  assert.ok(D.comparability(a,b).reasons.some(reason => reason.code === 'population'));
});

test('resource changes are identified while counter reassignment remains an arrangement change', () => {
  const a = R.example(), b = R.clone(a);
  b.windowZones = [0,0,0,0,1,1];
  assert.equal(D.comparability(a,b).fixedResources, true);
  b.windowMeans[0] = 15;
  assert.equal(D.comparability(a,b).fixedResources, false);
});

test('absent grades are excluded, and empty groups do not invent fairness benefits', () => {
  const a = R.example(); a.grades[0].students = 0; a.students = 240;
  const r = round(); r.grade0Count = 0; r.grade0Total = 0;
  const result = D.assess(a, a, copies(r), copies(r), 0);
  assert.deepEqual(result.grades.map(g => g.id), [1,2]);
  assert.equal(result.guard, 'within');
});

test('invalid paired samples and threshold inputs are rejected', () => {
  const a = R.example();
  assert.throws(() => D.assess(a,a,[round()],[round()],0.5));
  assert.throws(() => D.assess(a,a,copies(round()),copies(round()),-1));
  assert.throws(() => D.assess(a,a,copies(round()),copies(round()),NaN));
});

test('nine interaction scenarios preserve each policy and never mutate either input', () => {
  const a = R.example(), b = R.clone(a); b.windowZones = [0,0,0,0,1,1];
  const saved = JSON.stringify({a,b}), plan = D.planScenarios(a,b,{repeats:10});
  assert.equal(plan.accepted.length,9); assert.equal(plan.rejected.length,0);
  assert.equal(plan.workUnits,64800); assert.equal(plan.executable,true);
  assert.equal(JSON.stringify({a,b}),saved);
  for (const cell of plan.accepted) {
    assert.equal(cell.configA.windows,6); assert.equal(cell.configB.seats,120);
    assert.deepEqual(cell.configB.windowZones,b.windowZones);
    assert.deepEqual(cell.configA.grades.map(g=>g.releaseTime),a.grades.map(g=>g.releaseTime));
    assert.equal(cell.configA.sourceProfile.observedSchoolData,false);
  }
  const low = plan.accepted.find(cell => cell.serviceFactor===0.8 && cell.preferenceShift===-0.1);
  assert.equal(low.configA.windowMeans[0],16);
  assert.ok(Math.abs(low.configA.gradeZoneWeights[0][0]-0.65)<1e-10);
});

test('invalid edge-of-range scenarios are reported instead of silently clipped', () => {
  const a = R.example(); a.gradeZoneWeights = [[0.95,0.05],[0.95,0.05],[0.95,0.05]];
  const plan=D.planScenarios(a,a,{repeats:10});
  assert.equal(plan.accepted.length,6); assert.equal(plan.rejected.length,3);
  assert.ok(plan.rejected.every(x=>x.reason));
});

test('large cohorts face an explicit computation budget, while unzoned cases keep meal choice unchanged', () => {
  const a=R.example();a.students=4500;a.grades.forEach(g=>g.students=1500);
  assert.equal(D.planScenarios(a,a,{repeats:30}).executable,false);
  const c=R.example();c.serviceZones=null;c.windowZones=null;c.gradeZoneWeights=null;c.seatPoolByZone=null;
  const plan=D.planScenarios(c,c,{repeats:10});
  assert.equal(plan.accepted.length,3);
  assert.ok(plan.accepted.every(x=>x.preferenceShift===0));
});

test('scenario summary counts mean and interval-supported improvements separately without assigning probabilities', () => {
  const a=R.example(), rows=copies(round());
  const x=D.assess(a,a,rows,copies(round([19,29,39])),0.5);
  const y=D.assess(a,a,rows,copies(round([21,31,41])),0.5);
  const summary=D.summarizeScenarios([{id:'a',assessment:x},{id:'b',assessment:y}]);
  assert.equal(summary.scenarios,2); assert.equal(summary.meanImproved,1);
  assert.equal(summary.supportedImprovement,1); assert.equal(summary.guardWithin,1);
  assert.deepEqual(summary.totalDeltaRange,[-1,1]);
  assert.equal('probability' in summary,false);
});
