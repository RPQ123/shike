#!/usr/bin/env node
'use strict';

/*
 * v1.2 synthetic robustness and held-out validation study.
 * Run: node tests/robustness.cjs [output-directory]
 * Standard library only. Outputs v12-model-results.json/.csv and summary.md.
 * Requiring this file exports the seed/validation helpers without running
 * the study, so their validation rules can be reused by other consumers.
 */
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const Sim = require('../dist/engine.js');

const SEED = 20261017;
const VALIDATION_OFFSET = 1000003;
const T = { 5: 2.7764451051977987, 10: 2.2621571628540993, 30: 2.045229642132703 };
const METRICS = [
  'meanWait', 'p95Wait', 'peakQueue', 'within5min', 'utilization',
  'utilizationScheduled', 'lastDeparture', 'clearanceTime',
  'staggerParticipants', 'staggerParticipationRate', 'shiftedStudents',
  'shiftedStudentRate', 'windowLoadCV'
];
let auditedRuns = 0, auditChecks = 0, maximumAbsoluteResidual = 0;

function check(value, message) {
  auditChecks += 1;
  assert.ok(value, message);
}
function close(actual, expected, message, tolerance = 1e-9) {
  const residual = Math.abs(actual - expected);
  maximumAbsoluteResidual = Math.max(maximumAbsoluteResidual, residual);
  check(residual <= tolerance * Math.max(1, Math.abs(actual), Math.abs(expected)), `${message}: ${actual} versus ${expected}`);
}
function summarize(values) {
  assert.ok(T[values.length], 'This study supports n=5, 10 or 30 with explicit Student-t critical values.');
  const n = values.length, mean = values.reduce((a, b) => a + b, 0) / n;
  const sd = Math.sqrt(values.reduce((a, b) => a + (b - mean) ** 2, 0) / (n - 1));
  const se = sd / Math.sqrt(n), tCritical = T[n];
  return { n, mean, sd, se, ci95: [mean - tCritical * se, mean + tCritical * se], tCritical, degreesOfFreedom: n - 1 };
}
function pairedComparison(baseline, scenario) {
  assert.deepEqual(baseline.seeds, scenario.seeds, 'Paired comparisons must use the same ordered seeds.');
  const differences = baseline.repetitions.map((run, i) => run.metrics.meanWait - scenario.repetitions[i].metrics.meanWait);
  return {
    ...summarize(differences), baselineId: baseline.id,
    direction: 'baseline mean wait minus scenario mean wait; positive means improvement',
    percentOfBaselineMean: baseline.summary.meanWait.mean ? 100 * (baseline.summary.meanWait.mean - scenario.summary.meanWait.mean) / baseline.summary.meanWait.mean : 0,
    rawDifferences: differences
  };
}
function auditRun(result) {
  auditedRuns += 1;
  const { students, config, metrics: m } = result;
  let waitSum = 0, serviceSum = 0, participants = 0, shifted = 0;
  const changes = new Map(), windows = Array.from({ length: config.windows }, () => []);
  for (const s of students) {
    check(s.id >= 0 && students[s.id] === s && s.cohort === s.id % 3, 'stable student identity and cohort');
    check(s.start >= s.arrival && s.end > s.start && s.arrival >= 0 && s.arrival <= config.horizon, 'causal event order');
    close(s.wait, s.start - s.arrival, 'individual waiting identity');
    close(s.service, s.end - s.start, 'individual service identity');
    check(s.appliedArrivalOffset === (s.staggerParticipant ? s.plannedArrivalOffset : 0), 'participation controls offset');
    close(s.targetArrival, config.arrivalPeak + s.appliedArrivalOffset, 'individual target center');
    waitSum += s.wait; serviceSum += s.service;
    participants += Number(s.staggerParticipant); shifted += Number(s.appliedArrivalOffset !== 0);
    changes.set(s.arrival, (changes.get(s.arrival) || 0) + 1);
    changes.set(s.start, (changes.get(s.start) || 0) - 1);
    windows[s.window].push(s);
  }
  let area = 0, count = 0, previous = 0, peak = 0;
  for (const [time, delta] of [...changes.entries()].sort((a, b) => a[0] - b[0])) {
    area += count * (time - previous);
    count += delta; peak = Math.max(peak, count); previous = time;
    check(count >= 0, 'nonnegative waiting count');
  }
  check(count === 0, 'all queues clear');
  close(area, waitSum, 'independent event integral');
  close(m.queueIntegral, waitSum, 'engine queue integral');
  close(m.busyIntegral, serviceSum, 'engine busy integral');
  check(m.peakQueue === peak, 'exact event peak');
  check(m.staggerParticipants === participants && m.shiftedStudents === shifted, 'distinct participation/shift counts');
  close(m.staggerParticipationRate, students.length ? participants / students.length : 0, 'observed participation rate');
  close(m.shiftedStudentRate, students.length ? shifted / students.length : 0, 'observed shifted rate');
  for (const records of windows) {
    records.sort((a, b) => a.start - b.start || a.id - b.id);
    for (let i = 1; i < records.length; i += 1) check(records[i].start >= records[i - 1].end - 1e-10, 'no overlapping service');
  }
  const final = Sim.snapshot(result, m.observationEnd);
  check(final.completed === students.length && final.waiting === 0 && final.inService === 0, 'final population conservation');
}
function auditPair(reference, result) {
  check(reference.students.length === result.students.length, 'paired population');
  for (let i = 0; i < reference.students.length; i += 1) {
    const a = reference.students[i], b = result.students[i];
    close(a.rawArrival - a.targetArrival, b.rawArrival - b.targetArrival, 'paired arrival residual');
    close(a.service / reference.windows[a.window].meanService, b.service / result.windows[b.window].meanService, 'paired latent service factor');
    if (reference.config.staggerParticipation === result.config.staggerParticipation) {
      check(a.staggerParticipant === b.staggerParticipant, 'same participation membership across strategies');
    }
  }
}
function runSet(definitions, seeds) {
  const series = definitions.map(d => ({
    id: d.id, label: d.label, config: Sim.normalizeConfig(d.config), seeds: seeds.slice(), repetitions: []
  }));
  for (const seed of seeds) {
    let reference;
    for (const s of series) {
      const result = Sim.simulate({ ...s.config, seed });
      auditRun(result);
      if (reference) auditPair(reference, result); else reference = result;
      const metrics = Object.fromEntries(METRICS.map(key => [key, result.metrics[key]]));
      metrics.clippedArrivalRate = result.students.length ? result.clampedArrivals.total / result.students.length : 0;
      s.repetitions.push({ seed, metrics, clampedArrivals: result.clampedArrivals });
      s.effectiveWindowMeans = result.effectiveWindowMeans;
    }
  }
  for (const s of series) {
    s.summary = Object.fromEntries([...METRICS, 'clippedArrivalRate'].map(key => [key, summarize(s.repetitions.map(r => r.metrics[key]))]));
  }
  return series;
}
function consecutiveSeeds(first, count) {
  return Array.from({ length: count }, (_, i) => (first + i) >>> 0);
}
function createFreshSeeds(trainingSeeds, count = 30) {
  assert.ok(Array.isArray(trainingSeeds) && trainingSeeds.length > 0, 'Training seeds are required.');
  for (const seed of trainingSeeds) assert.ok(Number.isInteger(seed) && seed >= 0 && seed <= 4294967295, 'Seeds must be uint32.');
  assert.ok(Number.isInteger(count) && count > 0 && count <= 1000, 'Validation count must be 1..1000.');
  const excluded = new Set(trainingSeeds), seeds = [];
  let next = (trainingSeeds[0] + VALIDATION_OFFSET) >>> 0;
  while (seeds.length < count) {
    if (!excluded.has(next)) { seeds.push(next); excluded.add(next); }
    next = (next + 1) >>> 0;
  }
  return seeds;
}
function validateCandidate(candidateConfig, options) {
  const { trainingSeeds, baselineConfig, repetitions = 30, targetMeanWait = 5 } = options;
  const seeds = createFreshSeeds(trainingSeeds, repetitions);
  const [baseline, candidate] = runSet([
    { id: 'validation_baseline', label: '新种子基准', config: baselineConfig },
    { id: 'validation_candidate', label: '锁定候选的新种子复核', config: candidateConfig }
  ], seeds);
  return {
    trainingSeeds: trainingSeeds.slice(), seeds, candidate, baseline,
    pairedMeanWaitReduction: pairedComparison(baseline, candidate),
    target: {
      meanWaitMinutes: targetMeanWait,
      meanPass: candidate.summary.meanWait.mean <= targetMeanWait,
      upper95CIPass: candidate.summary.meanWait.ci95[1] <= targetMeanWait,
      passedRuns: candidate.repetitions.filter(r => r.metrics.meanWait <= targetMeanWait).length,
      totalRuns: repetitions,
      interpretation: 'Mean waiting objective under this synthetic model. The t interval concerns the seed-level expected mean, not a guarantee for 95% of students or future scenarios.'
    },
    lockedBeforeValidation: true, rerankedAfterValidation: false
  };
}

function runStudy(outputDir) {
  auditedRuns = 0; auditChecks = 0; maximumAbsoluteResidual = 0;
  const strategies = ['shortest', 'workload', 'pooled'];
  const participationDefinitions = [];
  for (const rate of [0, 0.5, 0.8, 1]) {
    for (const strategy of strategies) participationDefinitions.push({
      id: `participation_${rate}_${strategy}`, label: `参与概率${rate * 100}% / ${Sim.strategyNames[strategy]}`,
      config: { ...Sim.DEFAULT_CONFIG, stagger: 12, staggerParticipation: rate, strategy }
    });
  }
  const participation = runSet(participationDefinitions, consecutiveSeeds(SEED, 30));
  for (const s of participation) {
    s.pairedVsBaseline = pairedComparison(participation[0], s);
    s.pairedRouting = pairedComparison(participation.find(x => x.config.staggerParticipation === s.config.staggerParticipation && x.config.strategy === 'shortest'), s);
    s.pairedStagger = pairedComparison(participation.find(x => x.config.staggerParticipation === 0 && x.config.strategy === s.config.strategy), s);
  }

  // Match total expected service capacity sum(60/meanSeconds), so changing
  // heterogeneity does not silently add or remove expected capacity.
  const defaultMeans = Sim.DEFAULT_WINDOW_MULTIPLIERS.map(x => 30 * x);
  const capacity = defaultMeans.reduce((sum, x) => sum + 60 / x, 0);
  const rawStrong = [12, 18, 24, 30, 42, 54, 66, 84];
  const strongScale = rawStrong.reduce((sum, x) => sum + 60 / x, 0) / capacity;
  const profiles = [
    { id: 'homogeneous', label: '同质窗口', means: Array(8).fill(8 * 60 / capacity) },
    { id: 'default', label: '默认异质窗口', means: defaultMeans },
    { id: 'strong', label: '强异质窗口', means: rawStrong.map(x => x * strongScale) }
  ];
  const routing = [];
  for (const profile of profiles) {
    close(profile.means.reduce((sum, x) => sum + 60 / x, 0), capacity, 'capacity-normalized window profile', 1e-12);
    for (const cv of [0, 0.35, 0.8]) for (const students of [480, 960, 1440]) {
      const id = `routing_${profile.id}_cv${cv}_n${students}`;
      const series = runSet(strategies.map(strategy => ({
        id: `${id}_${strategy}`, label: Sim.strategyNames[strategy],
        config: { ...Sim.DEFAULT_CONFIG, students, windowMeans: profile.means, serviceCV: cv, stagger: 0, strategy }
      })), consecutiveSeeds(SEED, 10));
      routing.push({
        id, label: `${profile.label} / CV=${cv} / ${students}人`, windowProfile: profile.id,
        windowProfileLabel: profile.label, serviceCV: cv, students,
        effectiveCapacityPerMinute: capacity, effectiveWindowMeans: profile.means,
        series, workloadReduction: pairedComparison(series[0], series[1]), pooledReduction: pairedComparison(series[0], series[2])
      });
    }
  }

  // A concrete finite search at 80% participation, with three selected
  // configs locked in training order before any fresh-seed evaluation.
  const searchBase = Sim.normalizeConfig({ ...Sim.DEFAULT_CONFIG, staggerParticipation: 0.8 });
  const trainingSeeds = consecutiveSeeds(SEED, 5), definitions = [];
  for (const windows of [8, 9, 10]) for (const stagger of [0, 6, 12, 18]) for (const strategy of strategies) {
    definitions.push({ id: `candidate_${windows}_${stagger}_${strategy}`, label: `${windows}窗口 / ${stagger}分钟 / ${Sim.strategyNames[strategy]}`, config: { ...searchBase, windows, stagger, strategy } });
  }
  const candidates = runSet(definitions, trainingSeeds);
  const feasible = candidates.filter(s => s.summary.meanWait.mean <= 5);
  const ordered = (feasible.length ? feasible : candidates).slice().sort((a, b) => feasible.length ?
    a.config.windows - b.config.windows || a.config.stagger - b.config.stagger || a.summary.meanWait.mean - b.summary.meanWait.mean :
    a.summary.meanWait.mean - b.summary.meanWait.mean);
  const validation = {
    searchBase, trainingSeeds, candidateCount: candidates.length, feasibleTrainingCount: feasible.length,
    selectionRule: 'Among candidates with training mean wait <= 5: windows, stagger gap, then training mean wait, all ascending. If none passes, rank by training mean wait. This is a finite lexicographic preference, not a global optimum or a measured cost objective.',
    targetMeanWait: 5, candidates,
    selected: ordered.slice(0, 3).map((training, index) => ({
      trainingRank: index + 1, training,
      validation: validateCandidate(training.config, { trainingSeeds, baselineConfig: { ...searchBase, stagger: 0, strategy: 'shortest' } })
    }))
  };

  const result = {
    meta: {
      title: '校园食堂仿真 v1.2：参与率、纯路由稳健性与新种子复核',
      synthetic: true, generatedAtUTC: new Date().toISOString(), engineVersion: Sim.VERSION,
      engineSha256: crypto.createHash('sha256').update(fs.readFileSync(path.resolve(__dirname, '../dist/engine.js'))).digest('hex'),
      seed: SEED, participationRepetitions: 30, routingRepetitions: 10,
      trainingRepetitions: 5, validationRepetitions: 30, validationSeedOffset: VALIDATION_OFFSET,
      units: { times: 'minutes', configuredServiceMeans: 'seconds', rates: 'fractions' },
      participationModel: 'U(seed,student,stream5)<p. Nonparticipants keep the baseline arrival center; the middle cohort can participate without a nonzero shift. The participant count is stochastic, not a fixed quota. Original streams 0..4 are unchanged.',
      capacityMatching: 'All heterogeneity profiles have identical sum(60 / window service mean seconds). Homogeneous mean uses the default harmonic mean; strong profile [12,18,24,30,42,54,66,84] seconds is multiplied by one factor to match capacity.',
      routingDesign: 'Full 3 x 3 x 3 factorial: window heterogeneity x service CV x student count. Arrival center/spread and other parameters fixed; stagger=0. Each condition compares shortest, expected-workload and shared FCFS using 10 paired seeds.',
      poolingQualification: 'Shared FCFS changes the physical queue organization. It is a structural reference requiring all windows to be substitutable and a feasible common queue, not merely a different dedicated-window selector.',
      confidenceIntervals: 'Unadjusted two-sided Student t across seed-level outcomes. Paired intervals use seed-matched baseline minus scenario mean waits; t criticals are explicit. Descriptive parameter sweep, no multiple-comparison correction.',
      p95Interpretation: 'The summary p95Wait is the mean of per-run nearest-rank p95 waits, not a pooled-student percentile.',
      statisticalScope: 'Monte Carlo variability inside this synthetic model; no real school measurements, timetable compliance evidence, collision/seat constraints, estimated real-world costs or campus outcome guarantees.'
    },
    participation, routing, validation,
    audit: {
      passed: true, auditedRuns, scalarChecks: auditChecks, maximumAbsoluteResidual,
      note: 'Checks include individual time/participation identities, event queue area and peak, service nonoverlap, final conservation, same-seed arrival residuals and service factors. Audited run count includes repeated validation baseline runs for each locked candidate; scalarChecks is not a test-case count.'
    }
  };

  fs.mkdirSync(outputDir, { recursive: true });
  fs.writeFileSync(path.join(outputDir, 'v12-model-results.json'), JSON.stringify(result, null, 2) + '\n');
  const columns = ['study', 'condition', 'strategy', 'students', 'service_cv', 'participation_probability', 'stagger_min', 'n', 'mean_wait_min', 'ci95_low', 'ci95_high', 'mean_run_p95_min', 'mean_peak_queue', 'mean_within5_fraction', 'observed_participation_fraction', 'shifted_fraction', 'paired_mean_reduction_min', 'paired_ci95_low', 'paired_ci95_high', 'reduction_percent_of_baseline_mean'];
  const rows = [];
  function addRow(study, condition, s, p) {
    const c = s.config, u = s.summary;
    rows.push([study, condition, c.strategy, c.students, c.serviceCV, c.staggerParticipation, c.stagger, s.seeds.length,
      u.meanWait.mean, ...u.meanWait.ci95, u.p95Wait.mean, u.peakQueue.mean, u.within5min.mean,
      u.staggerParticipationRate.mean, u.shiftedStudentRate.mean, p.mean, ...p.ci95, p.percentOfBaselineMean]);
  }
  for (const s of participation) addRow('participation_vs_0pct_shortest', s.id, s, s.pairedVsBaseline);
  for (const c of routing) for (const s of c.series) addRow('routing_only', c.id, s, pairedComparison(c.series[0], s));
  for (const s of validation.selected) addRow('held_out_validation', `training_rank_${s.trainingRank}`, s.validation.candidate, s.validation.pairedMeanWaitReduction);
  const csv = '\uFEFF' + [columns, ...rows].map(row => row.map(value => `"${String(value).replaceAll('"', '""')}"`).join(',')).join('\r\n') + '\r\n';
  fs.writeFileSync(path.join(outputDir, 'v12-model-results.csv'), csv);
  fs.writeFileSync(path.join(outputDir, 'v12-model-summary.md'), makeSummary(result));
  return result;
}

function makeSummary(r) {
  const f = x => x.toFixed(3), pct = x => (100 * x).toFixed(2) + '%';
  let text = '# v1.2 模型与实验说明\n\n';
  text += `本补充全部为合成情境。引擎 ${r.meta.engineVersion}；主随机种子 ${SEED}。参与率实验每项30种子，纯路由全因子情境每项10种子，候选训练5种子、锁定后复核30新种子。\n\n`;
  text += '## 参与率的定义与旧版兼容\n\n';
  text += '每学生按 U(seed, studentId, stream5) < staggerParticipation 决定是否参与。未参与者保持原到达中心，参与者的三组计划偏移分别为 −stagger、0、+stagger 分钟；到达噪声照旧，最后裁剪至观察区间。参与率是概率，本次实际人数不强制等于 N×p。中间组参与者没有非零中心偏移，故同时报告参与人数和 shiftedStudents。计划偏移是到达分布中心的变化，裁剪边界附近的实际到达时间差可能小于计划值。\n\n';
  text += '缺失新参数的旧 JSON 自动补100%参与。旧随机流0..4及其计算次序保持不变；四组旧引擎完整数值输出经SHA-256金样本逐字节核对，默认、错峰工作量、错峰共享队列及带裁剪的随机分配结果均相同。新元数据和记录字段使整体文件结构变化，不能把新旧整个JSON文件哈希相同作为兼容要求。\n\n';
  text += '## 错峰12分钟：参与率与分配的贡献\n\n';
  text += '|参与概率|策略|平均等待/分钟|均值95%区间|每次P95的均值/分钟|平均实参与率|对同参与率最短队伍的等待减少/分钟|对同策略0%参与的等待减少/分钟|\n|---|---|---:|---|---:|---:|---:|---:|\n';
  for (const s of r.participation) text += `|${pct(s.config.staggerParticipation)}|${Sim.strategyNames[s.config.strategy]}|${f(s.summary.meanWait.mean)}|[${s.summary.meanWait.ci95.map(f).join(', ')}]|${f(s.summary.p95Wait.mean)}|${pct(s.summary.staggerParticipationRate.mean)}|${f(s.pairedRouting.mean)}|${f(s.pairedStagger.mean)}|\n`;
  text += '\n纯路由减少、纯错峰减少和总减少使用各自明确的基准，不能直接把不同基准的百分比相加。每个配对差值及区间保留在JSON的 pairedRouting / pairedStagger / pairedVsBaseline。\n\n';
  text += '## 路由稳健性：固定总容量的代表情境\n\n';
  text += `所有窗口构成都保持 sum(60/窗口均值秒) = ${f(r.routing[0].effectiveCapacityPerMinute)} 人/分钟的总期望容量；强异质窗口均值为 ${r.routing.find(c => c.windowProfile === 'strong').effectiveWindowMeans.map(f).join('、')} 秒。这能把总容量变化与窗口速度差异分开；实际队伍结构仍会影响吞吐与服务归属。所有本表情境 stagger=0，只比较路由/队列组织。\n\n`;
  text += '|窗口构成|CV|人数|最短队伍均值/分钟|工作量均值/分钟|工作量配对减少95%区间/分钟|工作量减少比例|共享队列均值/分钟|\n|---|---:|---:|---:|---:|---|---:|---:|\n';
  const picks = [
    ['homogeneous', 0.35, 960], ['default', 0.35, 960], ['strong', 0.35, 960],
    ['default', 0, 960], ['default', 0.8, 960],
    ['default', 0.35, 480], ['default', 0.35, 1440], ['strong', 0.8, 480]
  ];
  for (const [profile, cv, n] of picks) {
    const c = r.routing.find(x => x.windowProfile === profile && x.serviceCV === cv && x.students === n);
    text += `|${c.windowProfileLabel}|${cv}|${n}|${f(c.series[0].summary.meanWait.mean)}|${f(c.series[1].summary.meanWait.mean)}|[${c.workloadReduction.ci95.map(f).join(', ')}]|${c.workloadReduction.percentOfBaselineMean.toFixed(2)}%|${f(c.series[2].summary.meanWait.mean)}|\n`;
  }
  const effects = r.routing.map(c => c.workloadReduction.percentOfBaselineMean);
  const negative = r.routing.filter(c => c.workloadReduction.mean < 0);
  const crosses = r.routing.filter(c => c.workloadReduction.ci95[0] <= 0 && c.workloadReduction.ci95[1] >= 0);
  text += `\n27个全因子情境中，预计工作量相对最短队伍的平均等待变化范围为 ${Math.min(...effects).toFixed(2)}% 至 ${Math.max(...effects).toFixed(2)}%；${negative.length}个情境点估计为负，${crosses.length}个配对区间包含0。区间未做多重比较校正，本扫参用于描述适用性与交互，不能据此宣称全局支配或普遍显著。共享单队列改变物理队列组织，要求窗口可替代且场地允许；它是结构性参照。\n\n`;
  text += '## 锁定候选的新种子复核\n\n';
  text += `示例设参与概率80%，枚举8/9/10窗口 × 0/6/12/18分钟 × 3策略，共36候选。训练种子20261017..20261021；通过训练均值≤5分钟的候选按窗口数、错峰间隔、训练均值升序偏好排序，取前三，锁定后复核。新种子采用 (baseSeed + ${VALIDATION_OFFSET} + i) >>> 0，i=0..29，并确认与训练种子不重叠。没有按复核结果再排序或换方案。\n\n`;
  text += '|训练名次|方案|训练均值/分钟|新种子均值/分钟|新种子均值95%区间|30次中均值≤5的次数|新均值≤5|区间上限≤5|\n|---|---|---:|---:|---|---:|---|---|\n';
  for (const x of r.validation.selected) {
    const v = x.validation;
    text += `|${x.trainingRank}|${x.training.label}|${f(x.training.summary.meanWait.mean)}|${f(v.candidate.summary.meanWait.mean)}|[${v.candidate.summary.meanWait.ci95.map(f).join(', ')}]|${v.target.passedRuns}/30|${v.target.meanPass ? '是' : '否'}|${v.target.upper95CIPass ? '是' : '否'}|\n`;
  }
  text += '\n均值目标通过不等于每名学生都在5分钟内，也不等于95%的学生/后续场景通过。上限≤5只反映这个合成模型中种子层面期望均值的蒙特卡洛区间。若复核失败，应保留失败状态；若继续调参，需要再划分新的验证种子。三项复核区间未作多重比较校正。窗口数、错峰间隔的排序偏好不是实际测得的成本，也没有引入真实课表或场地可行性约束。\n\n';
  text += '## 复现与验证\n\n';
  text += `执行 node tests/robustness.cjs results，可获得JSON、CSV及本说明。实际审计 ${r.audit.auditedRuns} 次仿真，${r.audit.scalarChecks} 次标量断言，最大绝对残差 ${r.audit.maximumAbsoluteResidual}；断言次数不是命名测试用例数。脚本导出 createFreshSeeds、validateCandidate、pairedComparison 和 summarize 以复用验证规则。\n\n`;
  text += '模型仍未使用实测校园记录，未纳入菜品偏好、库存、放弃/换队、真实课表、行走冲突和座位周转。动画路径与统计队列事件分层；不能把动画中的行走当成已被纳入等待时间的空间约束。\n';
  return text;
}

module.exports = { createFreshSeeds, validateCandidate, pairedComparison, summarize, runStudy, VALIDATION_OFFSET };
if (require.main === module) {
  const outputDir = path.resolve(process.argv[2] || path.join(process.cwd(), 'results'));
  const result = runStudy(outputDir);
  console.log(JSON.stringify({
    outputDir, engineVersion: Sim.VERSION, audit: result.audit,
    participation: result.participation.filter(s => s.config.strategy === 'workload').map(s => ({ rate: s.config.staggerParticipation, meanWait: s.summary.meanWait.mean, p95: s.summary.p95Wait.mean, actualRate: s.summary.staggerParticipationRate.mean })),
    routingEffectRangePercent: [Math.min(...result.routing.map(c => c.workloadReduction.percentOfBaselineMean)), Math.max(...result.routing.map(c => c.workloadReduction.percentOfBaselineMean))],
    validation: result.validation.selected.map(s => ({ rank: s.trainingRank, config: s.training.label, meanWait: s.validation.candidate.summary.meanWait.mean, ci95: s.validation.candidate.summary.meanWait.ci95, target: s.validation.target }))
  }, null, 2));
}
