const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/school-engine.js'),R=require('../dist/research.js');
const P=require('../dist/planner.js');

test('nine classes interleave at a hand-checkable half-minute spacing',()=>{
 const c=R.example(),before=R.clone(c);
 const p=P.makePlan(c,{order:[0,1,2],slot:.5,aWindows:3});
 assert.deepEqual(p.config.grades.map(g=>g.releaseTime),[30,30.5,31]);
 assert.deepEqual(p.config.grades.map(g=>g.classInterval),[1.5,1.5,1.5]);
 assert.deepEqual(p.batches.map(b=>b.release),[30,30.5,31,31.5,32,32.5,33,33.5,34]);
 assert.deepEqual(p.batches.map(b=>b.grade),[0,1,2,0,1,2,0,1,2]);
 assert.equal(p.batches.reduce((n,b)=>n+b.students,0),360);
 assert.deepEqual(c,before);
 const result=E.simulateSchool(p.config);
 for(const b of p.batches) assert.equal(result.classBatches.find(x=>x.classId===b.classId).release,b.release);
});

test('joint allocation preserves heterogeneous speeds, seating and person-level preferences',()=>{
 const c=R.example();c.windowMeans=[16,20,24,16,20,24];c.gradeZoneWeights=[[.8,.2],[.6,.4],[.4,.6]];
 const p=P.makePlan(c,{order:[2,0,1],slot:.75,aWindows:4});
 assert.deepEqual(p.config.windowZones,[0,0,0,0,1,1]);
 for(const key of ['windows','seats','windowMeans','gradeZoneWeights','mealMean','serviceCV','returnDestination'])assert.deepEqual(p.config[key],c[key]);
 assert.deepEqual(p.config.grades.map(g=>g.students),[120,120,120]);
});

test('earliest start respects ready times and a locked first-class anchor',()=>{
 const c=R.example();c.grades[1].readyTime=31;c.grades[1].releaseTime=32;
 const p=P.makePlan(c,{order:[0,1,2],slot:.5,aWindows:3});
 assert.deepEqual(p.config.grades.map(g=>g.releaseTime),[30.5,31,31.5]);
 c.grades[0].releaseLocked=true;
 assert.throws(()=>P.makePlan(c,{order:[0,1,2],slot:.5,aWindows:3}),/锁定|允许/);
 c.grades[1].readyTime=30;
 assert.equal(P.makePlan(c,{order:[0,1,2],slot:.5,aWindows:3}).config.grades[0].releaseTime,30);
});

test('conflicting locks and late occupied classes are rejected',()=>{
 const c=R.example();c.grades[0].releaseLocked=true;c.grades[1].releaseLocked=true;
 assert.throws(()=>P.makePlan(c,{order:[0,1,2],slot:.5,aWindows:3}),/锁定/);
 const d=R.example();d.grades[2].latestReleaseTime=34.1;
 assert.throws(()=>P.makePlan(d,{order:[0,1,2],slot:1,aWindows:3}),/最晚|晚于/);
});

test('empty and explicit empty classes do not enter the displayed release table',()=>{
 const c=R.example();c.students=120;c.grades[0].students=80;c.grades[0].classes=3;c.grades[0].classSizes=[40,40,0];
 c.grades[1].students=0;c.grades[1].classes=0;c.grades[2].students=40;c.grades[2].classes=1;
 const p=P.makePlan(c,{order:[2,0],slot:.5,aWindows:3});
 assert.deepEqual(p.batches.map(b=>b.grade),[2,0,0]);
 assert.deepEqual(p.batches.map(b=>b.students),[40,40,40]);
 assert.equal(new Set(p.batches.map(b=>b.classId)).size,3);
 assert.throws(()=>P.makePlan(c,{order:[0,1,2],slot:.5,aWindows:3}),/顺序/);
});

test('candidate set includes synchronized alternatives once, baseline and all feasible class-order variants',()=>{
 const c=R.example(),set=P.candidates(c);
 assert.equal(set.accepted.filter(p=>p.slot===0).length,5);
 assert.equal(set.accepted.filter(p=>p.slot===.5&&p.aWindows===3).length,6);
 assert.ok(set.accepted.some(p=>p.id==='reference'));
 const unique=new Set(set.accepted.map(p=>P.configKey(p.config)));
 assert.equal(unique.size,set.accepted.length);
 assert.ok(set.accepted.length<=126);
});

test('timetable sizes match the engine uneven-cohort class assignment',()=>{
 const c=R.example();c.students=361;c.grades[0].students=121;
 const rows=P.timetable(c),actual=E.simulateSchool(c).classBatches.filter(x=>x.students);
 assert.deepEqual(rows.map(x=>[x.classId,x.students]).sort(),actual.map(x=>[x.classId,x.students]).sort());
});

test('balanced selection honors whole-time and queue-peak budgets before minimizing worst-grade time',()=>{
 const row=(id,meanTotal,worstGrade,peakQueue)=>({id,summary:{meanTotal,worstGrade,peakQueue}});
 const reference=row('reference',30,40,200);
 const rows=[reference,row('fast',27,42,240),row('fair',30.1,33,190),row('slow',32,31,100),row('balanced',29.9,34,190)];
 const s=P.choose(rows,reference,{meanAllowance:0,peakAllowance:0});
 assert.equal(s.efficiency.id,'fast');assert.equal(s.lowPeak.id,'slow');assert.equal(s.balanced.id,'balanced');
 assert.equal(P.choose(rows,reference,{meanAllowance:.5,peakAllowance:0}).balanced.id,'fair');
});

test('invalid plan parameters fail explicitly rather than silently moving or clipping a grade',()=>{
 const c=R.example();
 for(const slot of [-1,NaN,11])assert.throws(()=>P.makePlan(c,{order:[0,1,2],slot,aWindows:3}));
 for(const order of [[0,0,2],[2,1],[],[3,1,0]])assert.throws(()=>P.makePlan(c,{order,slot:.5,aWindows:3}));
 assert.throws(()=>P.makePlan(c,{order:[0,1,2],slot:.5,aWindows:6}));
 assert.deepEqual(c,R.example());
});

test('unchanged numerical ties retain the original arrangement',()=>{
 const summary={meanTotal:30,worstGrade:35,peakQueue:200};
 const ref={id:'reference',summary};
 assert.equal(P.choose([{id:'p000',summary},ref],ref).balanced.id,'reference');
});

test('unpartitioned configurations keep their window allocation and still permit class scheduling',()=>{
 const c=R.example();c.serviceZones=null;c.windowZones=null;c.gradeZoneWeights=null;c.seatPoolByZone=null;
 const set=P.candidates(c,{slots:[.5]});
 assert.equal(set.accepted.length,7);
 assert.ok(set.accepted.every(p=>p.config.serviceZones===null&&p.config.windowZones===null));
});

test('empty cohorts and nonfinite or negative selection budgets cannot masquerade as a recommendation',()=>{
 const c=R.example();c.students=0;c.grades.forEach(g=>{g.students=0;g.classes=0});
 assert.throws(()=>P.candidates(c),/至少一个/);
 const row={id:'reference',summary:{meanTotal:30,worstGrade:35,peakQueue:200}};
 assert.throws(()=>P.choose([row],row,{meanAllowance:-1}));
 assert.throws(()=>P.choose([row],row,{peakAllowance:NaN}));
});
