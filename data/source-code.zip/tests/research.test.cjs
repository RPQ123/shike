const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/school-engine.js'),R=require('../dist/research.js');
const base=()=>R.example();
test('default is a labelled 360-person assumption, with explicit equal window speeds',()=>{const c=base();assert.equal(c.students,360);assert.equal(c.windowMeans.length,6);assert.ok(c.windowMeans.every(x=>x===20));assert.equal(c.sourceProfile.observedSchoolData,false)});
test('candidate generation preserves population, seats, total windows, and common random demand',()=>{const c=base(),set=R.candidates(c,{gaps:[0,2],reallocate:true});assert.equal(set.accepted.length,10);for(const item of set.accepted){assert.equal(item.config.students,c.students);assert.equal(item.config.seats,c.seats);assert.equal(item.config.windows,c.windows);const a=E.simulateSchool(c).students,b=E.simulateSchool(item.config).students;assert.deepEqual(a.map(s=>[s.randomId,s.zone,s.serviceFactor]),b.map(s=>[s.randomId,s.zone,s.serviceFactor]))}});
test('locked releases are not silently rewritten, infeasible candidates retain reasons',()=>{const c=base();c.grades[0].releaseLocked=true;c.grades[1].releaseLocked=true;const set=R.candidates(c,{gaps:[0,2,4],reallocate:false});assert.equal(set.accepted.length,1);assert.equal(set.rejected.length,2);assert.equal(set.accepted[0].gap,2);assert.ok(set.rejected.every(x=>x.reason.length>0))});
test('screening and verification seeds remain disjoint at uint32 wrap',()=>{const sets=R.seedSets(4294967293,8,20);assert.equal(new Set([...sets.screening,...sets.verification]).size,28);assert.ok(sets.verification.every(x=>x>=0&&x<=4294967295))});
test('Pareto front handles equal points without deleting all equivalent candidates',()=>{const rows=[{id:'a',meanWait:1,meanTotal:3,gradeGap:2},{id:'b',meanWait:1,meanTotal:3,gradeGap:2},{id:'c',meanWait:2,meanTotal:4,gradeGap:3},{id:'d',meanWait:0,meanTotal:5,gradeGap:2}];assert.deepEqual(R.pareto(rows).map(r=>r.id),['a','b','d'])});
test('metric includes release delay and grade total-time differences, all units are minutes',()=>{const c=base(),result=E.simulateSchool(c),m=R.metrics(result);assert.equal(m.meanTotal,result.metrics.meanReadyToEndpoint);assert.equal(m.gradeGap,Math.max(...result.gradeMetrics.map(g=>g.meanReadyToEndpoint))-Math.min(...result.gradeMetrics.map(g=>g.meanReadyToEndpoint)));assert.ok(m.meanTotal>m.meanWait)});
test('research results retain each grade, so aggregate improvement cannot conceal a harmed grade',()=>{
 const result=E.simulateSchool(base()),metrics=R.metrics(result);
 for(const g of result.gradeMetrics){
  assert.equal(metrics[`grade${g.id}Count`],g.count);
  assert.equal(metrics[`grade${g.id}Total`],g.meanReadyToEndpoint);
  assert.equal(metrics[`grade${g.id}OnTime`],g.onTimeRate);
 }
});
test('paired differences use paired rounds and reject mismatched lengths',()=>{const x=R.paired([1,2,3],[2,4,6]);assert.equal(x.mean,2);assert.equal(x.sd,1);assert.equal(x.n,3);assert.throws(()=>R.paired([1,2],[1]))});
test('CSV escapes text and spreadsheet formulas',()=>{const csv=R.csv([{name:'=HYPERLINK("x")',value:2},{name:'a,b\nc',value:3}]);assert.ok(csv.includes("'=HYPERLINK"));assert.ok(csv.includes('"a,b\nc"'))});
test('saved configuration is versioned and cannot masquerade as calibrated school data',()=>{const c=base(),s=R.session(c);assert.equal(s.schema,'dining-lab/2');assert.equal(s.evidence,'synthetic');assert.deepEqual(R.readSession(JSON.stringify(s)),c);assert.throws(()=>R.readSession('{"schema":"other","config":{}}'))});
