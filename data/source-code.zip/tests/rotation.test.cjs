const test=require('node:test'),assert=require('node:assert/strict');
const R=require('../dist/research.js'),P=require('../dist/planner.js'),E=require('../dist/school-engine.js');
const T=require('../dist/rotation.js');
test('rotation preserves physical counter identities when A windows are not a prefix',()=>{
 const c=R.example();c.windowZones=[0,1,0,1,0,1];c.windowMeans=[12,18,24,30,36,42];
 const p=P.makePlan(c,{order:[0,1,2],slot:.5});
 for(const candidate of T.orders(p)) {
  assert.deepEqual(candidate.config.windowZones,c.windowZones);
  assert.deepEqual(candidate.config.windowMeans,c.windowMeans);
 }
});
const plan=()=>P.makePlan(R.example(),{order:[0,1,2],slot:.5,aWindows:4});
const metric=values=>({meanTotal:values.reduce((a,b)=>a+b)/3,meanWait:5,seatWait:1,onTime:.9,peakQueue:150,worstGrade:Math.max(...values),grade0Count:120,grade1Count:120,grade2Count:120,grade0Total:values[0],grade1Total:values[1],grade2Total:values[2]});

test('fixed and cyclic order follow their hand-checkable definitions',()=>{
 const p=plan(),history=[{metrics:metric([20,30,40])}];
 assert.deepEqual(T.nextOrder(p,[],'cyclic').order,[0,1,2]);
 assert.deepEqual(T.nextOrder(p,history,'fixed').order,[0,1,2]);
 assert.deepEqual(T.nextOrder(p,history,'cyclic').order,[1,2,0]);
 assert.deepEqual(T.nextOrder(p,[...history,...history],'cyclic').order,[2,0,1]);
});

test('compensation gives earlier positions to grades with greater prior cumulative complete time',()=>{
 const p=plan(),h=[{metrics:metric([20,30,40])}];
 const next=T.nextOrder(p,h,'feedback');
 assert.deepEqual(next.order,[2,1,0]);assert.deepEqual(next.historyTotals,[20,30,40]);
 assert.match(next.reason,/高三/);
 assert.deepEqual(T.nextOrder(p,[],'feedback').order,p.order);
});

test('locked first release constrains compensation without relaxing the lock',()=>{
 const c=R.example();c.grades[0].releaseLocked=true;
 const p=P.makePlan(c,{order:[0,1,2],slot:.5,aWindows:3});
 const next=T.nextOrder(p,[{metrics:metric([20,30,40])}],'feedback');
 assert.equal(next.order[0],0);assert.equal(next.config.grades[0].releaseTime,30);
 assert.deepEqual(next.order,[0,2,1]);
});

test('period aggregation distinguishes daily worst grade from accumulated fairness',()=>{
 let call=0;const p=plan();
 const run=T.runPeriod(p,{seeds:[10,11,12],mode:'cyclic',evaluate:()=>metric([[20,30,40],[40,20,30],[30,40,20]][call++])});
 assert.deepEqual(run.days.map(d=>d.order),[[0,1,2],[1,2,0],[2,0,1]]);
 assert.equal(run.summary.meanTotal,30);assert.equal(run.summary.periodWorstGrade,30);
 assert.equal(run.summary.periodGradeGap,0);assert.equal(run.summary.meanDailyWorstGrade,40);
 assert.deepEqual(run.days[2].historyBefore.totals,[60,50,70]);
});

test('current and future random seeds cannot affect an order before their outcomes are observed',()=>{
 const p=plan(),a=T.runPeriod(p,{seeds:[201,202,203],mode:'feedback'}),b=T.runPeriod(p,{seeds:[201,777,999],mode:'feedback'});
 assert.deepEqual(a.days.slice(0,2).map(d=>d.order),b.days.slice(0,2).map(d=>d.order));
 assert.deepEqual(a.days[0].metrics,b.days[0].metrics);
});

test('future menu inputs are not accessed before the current outcome exists',()=>{
 const p=plan(),inputs=Array.from({length:3},()=>R.clone(p.config));let completed=0;
 inputs[2].gradeZoneWeights=inputs[2].gradeZoneWeights.map(()=>[.9,.1]);
 const guarded=new Proxy(inputs,{get(target,key){if(/^\d+$/.test(String(key)))assert.ok(Number(key)<=completed,'future day read');return Reflect.get(target,key)}});
 const run=T.runPeriod(p,{seeds:[100,101,102],mode:'feedback',dayInputs:guarded,evaluate:config=>{completed++;return R.metrics(E.simulateSchool(config))}});
 assert.equal(run.days.length,3);
});

test('all retained daily metrics independently reproduce and inputs remain unchanged',()=>{
 const p=plan(),before=R.clone(p);
 const run=T.runPeriod(p,{seeds:[3201,3202,3203],mode:'feedback'});
 for(const day of run.days) assert.deepEqual(day.metrics,R.metrics(E.simulateSchool(day.config)));
 assert.deepEqual(p,before);
 assert.deepEqual(T.runPeriod(p,{seeds:[3201,3202,3203],mode:'feedback'}),run);
});

test('period rejects unsupported policy, invalid seeds and changing grade populations',()=>{
 const p=plan();
 assert.throws(()=>T.runPeriod(p,{seeds:[1,2,3],mode:'oracle'}));
 assert.throws(()=>T.runPeriod(p,{seeds:[],mode:'feedback'}));
 assert.throws(()=>T.runPeriod(p,{seeds:[NaN],mode:'feedback'}));
 const c=R.clone(p.config);c.students=361;c.grades[0].students=121;
 assert.throws(()=>T.runPeriod(p,{seeds:[1],mode:'feedback',dayInputs:[c]}),/人数|构成/);
});
