const test=require('node:test'),assert=require('node:assert/strict');
const B=require('../dist/binhe-cohort'),H=require('../dist/hall-walk'),E=require('../dist/school-engine'),Scene=require('../dist/scene-state');
test('configured seats have one distinct chair each, including partial tables',()=>{
 for(const seats of [2,7,80,480,600,601,5000]){
  const c={...B.create(),seats},h=H.create(c),l=Scene.createLayoutForResult({config:c});
  assert.equal(new Set([...h.seatMap.values()].map(s=>s.position.join(','))).size,seats);
  assert.equal(l.displaySeats.length,seats);
  assert.equal(l.tables.reduce((n,t)=>n+t.chairCount,0),seats);
  for(const [id,seat] of h.seatMap)assert.deepEqual(l.displaySeats[id].position,seat.position);
 }
});
test('changing only seating capacity regenerates the physical layout',()=>{
 const a=Scene.createLayoutForResult({config:{...B.create(),seats:480}}),b=Scene.createLayoutForResult({config:{...B.create(),seats:600}});
 assert.notEqual(a.tables.length,b.tables.length);assert.equal(b.displaySeats.length-a.displaySeats.length,120);
});

test('legacy dedicated-counter inputs keep their compatible layout',()=>{const c={...B.create(),allocation:'dedicated',windowOwners:Array.from({length:16},(_,i)=>i%3)},l=Scene.createLayoutForResult({config:c});assert.equal(!!l.twoSided,false);assert.equal(H.create(c).twoSided,false);});
