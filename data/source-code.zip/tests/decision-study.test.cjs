const test=require('node:test'),assert=require('node:assert/strict');
const R=require('../dist/research.js');
const S=require('../tools/run-decision-study.cjs');
const fs=require('node:fs'),crypto=require('node:crypto');
const D=require('../dist/decision-support.js');

test('supplemental design has nine crossed input cases and seven declared extra checks',()=>{
  const contexts=S.contexts(R.example());
  assert.equal(contexts.filter(x=>x.group==='grid').length,9);
  assert.equal(contexts.filter(x=>x.group==='additional').length,7);
  assert.equal(new Set(contexts.map(x=>x.id)).size,16);
  assert.deepEqual(contexts.find(x=>x.id==='unequal-grades').config.grades.map(g=>g.students),[80,120,160]);
  assert.equal(contexts.find(x=>x.id==='pooled').config.strategy,'pooled');
});
test('a policy changes only its declared gap and counter assignment within each context',()=>{
  const context=S.contexts(R.example()).find(x=>x.id==='unequal-windows');
  const c=S.policyConfig(context.config,{gap:3,aWindows:4});
  assert.deepEqual(c.windowMeans,[16,20,24,16,20,24]);
  assert.deepEqual(c.windowZones,[0,0,0,0,1,1]);
  assert.deepEqual(c.grades.map(g=>g.releaseTime),[30,33,36]);
  assert.equal(c.seats,120);
});
function row(id,nominal,worst,guard='within') {
  return {id,cases:[{contextId:'s1-p0',summary:{meanTotal:nominal},assessment:{total:{mean:worst},guard}}]};
}
test('nominal and guarded selectors can disagree: reject a faster candidate that harms a grade',()=>{
  const rows=[row('g2-a3',30,0),row('fast',29,-1,'exceeded'),row('balanced',29.5,-0.2)];
  const selected=S.select(rows,'g2-a3');
  assert.equal(selected.nominal,'fast');assert.equal(selected.guarded,'balanced');
});
test('guarded selector retains reference when alternatives do not pass the declared check',()=>{
  const rows=[row('g2-a3',30,0),row('fast',29,-1,'uncertain')];
  assert.equal(S.select(rows,'g2-a3').guarded,'g2-a3');
});
test('guarded choice minimizes the worst case, not the best or nominal case',()=>{
  const a=row('a',28,-2);a.cases.push({contextId:'other',summary:{meanTotal:32},assessment:{total:{mean:2},guard:'within'}});
  const b=row('b',29,-0.5);b.cases.push({contextId:'other',summary:{meanTotal:29},assessment:{total:{mean:-0.1},guard:'within'}});
  assert.equal(S.select([row('g2-a3',30,0),a,b],'g2-a3').guarded,'b');
});
test('saved supplemental experiment binds sources, frozen selection and a unique execution ledger',()=>{
  const study=JSON.parse(fs.readFileSync('data/decision-study-results.json','utf8'));
  const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
  for(const [file,hash] of Object.entries(study.sourceHashes)) assert.equal(sha(fs.readFileSync(require('../tools/study-source.cjs').sourceFile(file,hash),'utf8')),hash,file);
  assert.equal(sha(JSON.stringify(JSON.parse(fs.readFileSync('research/decision-protocol.json','utf8')))),study.protocolSha256);
  assert.deepEqual(S.select(study.screened,study.protocol.referenceId),study.selection);
  assert.deepEqual(JSON.parse(fs.readFileSync('data/decision-frozen-selection.json','utf8')),study.frozen);
  assert.ok(Date.parse(study.frozen.frozenAt)<=Date.parse(study.verificationStartedAt));
  const keys=new Set();let executions=0;
  for(const row of study.records) {
    assert.equal(sha(JSON.stringify(row.config)),row.configSha256);
    const range=row.phase==='screening'?study.protocol.screeningSeeds:study.protocol.verificationSeeds;
    assert.deepEqual(row.rounds.map(x=>x.seed),Array.from({length:range.count},(_,i)=>range.start+i));
    for(const round of row.rounds) {
      const key=[row.phase,row.contextId,row.policyId,round.seed].join('/');
      assert.equal(keys.has(key),false);keys.add(key);executions++;
    }
  }
  assert.equal(executions,study.counts.uniqueExecutions);
  assert.equal(study.counts.screeningRuns,2250);
  assert.equal(study.counts.verificationRuns,new Set(study.counts.selectedPolicies).size*16*30);
});
test('every saved verification verdict can be recomputed from its retained paired rounds',()=>{
  const study=JSON.parse(fs.readFileSync('data/decision-study-results.json','utf8'));
  for(const row of study.verification) {
    const a=study.records.find(x=>x.phase==='verification'&&x.contextId===row.contextId&&x.policyId===study.protocol.referenceId);
    const b=study.records.find(x=>x.phase==='verification'&&x.contextId===row.contextId&&x.policyId===row.policyId);
    assert.deepEqual(D.assess(a.config,b.config,a.rounds,b.rounds,study.protocol.thresholdMinutes),row.assessment);
  }
});
