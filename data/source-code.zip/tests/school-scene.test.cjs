'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const E=require('../dist/school-engine.js');
const Scene=require('../dist/scene-state.js');
const config=E.normalizeSchoolConfig(E.DEFAULT_SCHOOL_CONFIG);
const result=E.simulate(config);
const ids=items=>items.map(x=>x.id).sort((a,b)=>a-b);

function checkFrame(r,time){
  const f=Scene.frame(r,time),s=E.snapshot(r,time),c=f.counts;
  for(const key of ['arrived','waiting','inService','completed','notArrived','seatWaiting','dining','returning','returned'])assert.equal(c[key],s[key],key);
  assert.equal(c.notArrived+c.waiting+c.inService+c.seatWaiting+c.dining+c.returning+c.returned,r.students.length);
  assert.deepEqual(ids(f.people.filter(p=>p.state==='waiting')),r.students.filter(p=>p.arrival<=f.time&&p.start>f.time).map(p=>p.id));
  assert.deepEqual(ids(f.diningPeople.filter(p=>p.state==='dining')),r.students.filter(p=>p.seatStart<=f.time&&p.mealEnd>f.time).map(p=>p.id));
  assert.deepEqual(ids(f.diningPeople.filter(p=>p.state==='seat-waiting')),r.students.filter(p=>p.end<=f.time&&p.seatStart>f.time).map(p=>p.id));
  const visible=f.visiblePeople.concat(f.visibleDiningPeople,f.departures);
  assert.equal(new Set(ids(visible)).size,visible.length,'each visible student has exactly one state');
  assert.ok(f.sampling.visibleWaiting<=320);
  assert.ok(f.visibleDiningPeople.filter(p=>p.state==='dining').length<=72);
  assert.ok(f.visibleDiningPeople.filter(p=>p.state==='seat-waiting').length<=48);
  assert.ok(f.departures.length<=64);
  for(const p of visible)assert.ok(p.position.every(Number.isFinite)&&Number.isFinite(p.yaw));
  return f;
}
test('school frame conserves the entire release-to-return population at event boundaries',()=>{
  const p=result.students[0];
  for(const t of [0,config.serviceStart,p.release,p.arrival,p.start,p.end,p.seatStart,p.mealEnd,p.returnTime,50,80,result.metrics.observationEnd])checkFrame(result,t);
});
test('three grade pools preserve actual waiting identities without revealing future windows',()=>{
  for(const allocation of ['dedicated','overflow']){
    const r=E.simulate({...config,allocation,strategy:'pooled'}),f=checkFrame(r,52);
    assert.equal(f.layout.gradePools,true);assert.equal(f.queueGroups.length,3);
    for(const group of f.queueGroups){assert.equal(group.id,'grade-'+group.cohort);for(const id of group.queueIds)assert.equal(r.students[id].cohort,group.cohort);}
    assert.ok(f.people.filter(p=>p.state==='waiting').every(p=>p.window===null));
  }
});
test('overflow uses grade queues even when an old saved strategy is not pooled',()=>{
  const r=E.simulate({...config,allocation:'overflow',strategy:'shortest'}),f=checkFrame(r,52);
  assert.equal(f.pooled,true);assert.equal(f.queueGroups.length,3);assert.equal(f.layout.queues.length,3);
});
test('a student remains in the same representative seat until the meal ends',()=>{
  const a=checkFrame(result,60.15),b=checkFrame(result,60.16);
  const later=new Map(b.visibleDiningPeople.filter(p=>p.state==='dining').map(p=>[p.id,p]));
  let checked=0;
  for(const p of a.visibleDiningPeople.filter(p=>p.state==='dining'))if(later.has(p.id)){
    const other=later.get(p.id);assert.deepEqual(other.position,p.position);assert.equal(other.seatId,p.seatId);assert.equal(other.displaySeatId,p.displaySeatId);checked++;
  }
  assert.ok(checked>10);assert.equal(new Set(a.visibleDiningPeople.filter(p=>p.state==='dining').map(p=>p.displaySeatId)).size,a.visibleDiningPeople.filter(p=>p.state==='dining').length);
});
test('capacity-shortage scenario exposes seat waiting separately from window waiting',()=>{
  const r=E.simulate({...config,seats:80}),f=checkFrame(r,75);
  assert.ok(f.counts.seatWaiting>100);assert.equal(f.visibleDiningPeople.filter(p=>p.state==='seat-waiting').length,48);
  assert.ok(f.sampling.description.includes('等座'));assert.ok(f.sampling.description.includes('人数统计完整'));
});
test('return animation begins at meal completion and follows the numerical return interval',()=>{
  const p=result.students[0],f=Scene.frame(result,p.mealEnd+.01);
  const returning=f.departures.find(x=>x.id===p.id);assert.ok(returning);assert.equal(returning.state,'returning');
  assert.ok(returning.visualProgress>0&&returning.visualProgress<1);
  assert.equal(Scene.frame(result,p.returnTime).departures.some(x=>x.id===p.id),false);
});
test('turning off dining retains the explicitly limited pickup-only scene',()=>{
  const r=E.simulate({...config,diningEnabled:false}),f=Scene.frame(r,60);
  assert.deepEqual(f.diningPeople,[]);assert.deepEqual(f.visibleDiningPeople,[]);assert.equal(f.counts.dining,0);
  assert.equal(f.counts.completed,E.snapshot(r,60).completed);
  assert.ok(f.departures.every(p=>p.state==='departing'));
});
test('school replay can seek back without mutating records or changing identities',()=>{
  const before=JSON.stringify(result),a=Scene.frame(result,55);
  Scene.frame(result,110);Scene.frame(result,25);const b=Scene.frame(result,55);
  assert.deepEqual(b,a);assert.equal(JSON.stringify(result),before);
});
test('A/B school views accept common queue and seat display scales',()=>{
  const a=E.simulate(E.makeSchoolBaseline(config)),b=result;
  const sa=E.snapshot(a,50),sb=E.snapshot(b,50),scale=Math.max(1,sa.waiting/320,sb.waiting/320);
  const options={peoplePerFigure:scale,seatsPerFigure:Math.max(a.config.seats,b.config.seats)/72};
  const fa=Scene.frame(a,50,null,null,options),fb=Scene.frame(b,50,null,null,options);
  assert.equal(fa.sampling.requestedPeoplePerFigure,fb.sampling.requestedPeoplePerFigure);
  assert.equal(fa.counts.waiting,sa.waiting);assert.equal(fb.counts.waiting,sb.waiting);
  assert.ok(fa.visibleDiningPeople.filter(p=>p.state==='dining').length<=72);
  assert.ok(fb.visibleDiningPeople.filter(p=>p.state==='dining').length<=72);
});
