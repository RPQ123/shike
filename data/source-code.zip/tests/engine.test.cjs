'use strict';

// Run from the project directory: node --test tests/engine.test.cjs
// No npm installation or third-party dependency is required.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const E = require('../dist/engine.js');

function close(actual, expected, tolerance = 1e-8, label = '') {
  assert.ok(Math.abs(actual - expected) <= tolerance * Math.max(1, Math.abs(expected)),
    `${label}: got ${actual}, expected ${expected}`);
}

function allFinite(value, label = 'result') {
  if (typeof value === 'number') assert.ok(Number.isFinite(value), `${label} is not finite`);
  else if (Array.isArray(value)) value.forEach((x, i) => allFinite(x, `${label}[${i}]`));
  else if (value && typeof value === 'object') Object.entries(value).forEach(([k, v]) => allFinite(v, `${label}.${k}`));
}

function stateConservation(result, t) {
  const state = E.snapshot(result, t);
  assert.equal(state.arrived, state.completed + state.waiting + state.inService);
  assert.equal(state.arrived + state.notArrived, result.students.length);
  assert.equal(state.completed, state.windows.reduce((a, w) => a + w.completed, 0));
  assert.equal(state.inService, state.windows.reduce((a, w) => a + w.serving, 0));
  assert.equal(state.waiting, state.centralQueue + state.windows.reduce((a, w) => a + w.waiting, 0));
  assert.ok(state.inService <= result.config.windows);
  assert.ok(state.waiting >= 0 && state.completed >= 0 && state.inService >= 0);
  for (const w of state.windows) {
    assert.ok(w.serving === 0 || w.serving === 1);
    assert.ok(w.busyMinutes <= state.time + 1e-8);
    assert.ok(w.progress >= 0 && w.progress <= 1);
    assert.equal(w.queueIds.length, w.waiting);
  }
  if (result.config.strategy === 'pooled' && state.waiting > 0) {
    assert.equal(state.inService, result.config.windows, 'shared queue must never wait with an idle server');
  }
  return state;
}

function validateRun(result) {
  allFinite(result);
  const { students, windows, metrics: m, config } = result;
  assert.equal(students.length, config.students);
  assert.equal(windows.length, config.windows);
  assert.equal(windows.reduce((a, w) => a + w.served, 0), students.length);
  let wait = 0, service = 0, system = 0, scheduledBusy = 0, completeH = 0;
  for (const s of students) {
    assert.equal(students[s.id], s);
    assert.equal(s.cohort, s.id % 3);
    assert.ok(Number.isInteger(s.window) && s.window >= 0 && s.window < config.windows);
    assert.ok(s.arrival >= 0 && s.arrival <= config.horizon);
    assert.ok(s.start >= s.arrival && s.end > s.start);
    assert.ok(s.wait >= 0 && s.service > 0);
    close(s.wait, s.start - s.arrival);
    close(s.service, s.end - s.start);
    wait += s.wait;
    service += s.service;
    system += s.end - s.arrival;
    scheduledBusy += Math.max(0, Math.min(s.end, config.horizon) - s.start);
    if (s.end <= config.horizon) completeH++;
  }
  close(m.queueIntegral, wait, 1e-8, 'exact queue integral');
  close(m.systemIntegral, system, 1e-8, 'exact number-in-system integral');
  close(m.busyIntegral, service, 1e-8, 'exact number-in-service integral');
  close(m.queueIntegral + m.busyIntegral, m.systemIntegral);
  close(m.totalWait, wait);
  close(m.totalService, service);
  close(m.meanQueueLength, m.throughput * m.meanWait, 1e-8, 'finite-run Little identity');
  close(m.meanSystemSize, m.throughput * m.meanSystemTime);
  close(m.utilization, service / (config.windows * m.observationEnd));
  close(m.utilizationScheduled, scheduledBusy / (config.windows * config.horizon));
  assert.equal(m.completedAtHorizon, completeH);
  assert.equal(m.allCompleted, true);
  assert.ok(m.utilization >= 0 && m.utilization <= 1 + 1e-10);
  assert.ok(m.utilizationScheduled >= 0 && m.utilizationScheduled <= 1 + 1e-10);
  close(m.observationEnd, Math.max(config.horizon, ...students.map(s => s.end)));
  close(m.clearanceTime, Math.max(0, m.lastDeparture - config.horizon));
  assert.equal(result.arrivalBins.reduce((a, b) => a + b.count, 0), students.length);
  assert.equal(result.completionBins.reduce((a, b) => a + b.count, 0), students.length);
  assert.equal(result.clampedArrivals.total, result.clampedArrivals.lower + result.clampedArrivals.upper);
  assert.equal(result.clampedArrivals.lower, students.filter(s => s.rawArrival < 0).length);
  assert.equal(result.clampedArrivals.upper, students.filter(s => s.rawArrival > config.horizon).length);
  for (const w of windows) {
    const jobs = students.filter(s => s.window === w.id).sort((a, b) => a.start - b.start || a.id - b.id);
    for (let i = 1; i < jobs.length; i++) assert.ok(jobs[i].start >= jobs[i - 1].end - 1e-10, 'no overlapping services');
    if (config.strategy !== 'pooled') {
      const byArrival = jobs.slice().sort((a, b) => a.arrival - b.arrival || a.id - b.id);
      assert.deepEqual(jobs.map(s => s.id), byArrival.map(s => s.id), 'dedicated queue FCFS');
      close(w.physicalQueueIntegral, jobs.reduce((a, s) => a + s.wait, 0));
    } else assert.equal(w.physicalQueueIntegral, 0);
    close(w.busyMinutes, jobs.reduce((a, s) => a + s.service, 0));
    assert.ok(w.utilization <= 1 + 1e-10);
  }
  // Independently rebuild the exact queue length from completed records.
  const changes = new Map();
  for (const s of students) {
    changes.set(s.arrival, (changes.get(s.arrival) || 0) + 1);
    changes.set(s.start, (changes.get(s.start) || 0) - 1);
  }
  let queue = 0, prior = 0, area = 0, peak = 0;
  for (const [t, delta] of [...changes.entries()].sort((a, b) => a[0] - b[0])) {
    area += queue * (t - prior);
    queue += delta;
    peak = Math.max(peak, queue);
    prior = t;
  }
  assert.equal(queue, 0);
  assert.equal(m.peakQueue, peak);
  close(m.queueIntegral, area);
  const last = result.timeline.at(-1);
  assert.equal(last.time, m.observationEnd);
  assert.equal(last.completed, config.students);
  assert.equal(last.waiting, 0);
  assert.equal(last.inService, 0);
  // Use every arrival and completion for modest runs, not just whole minutes.
  const times = [...new Set([0, config.horizon, m.observationEnd,
    ...students.flatMap(s => [s.arrival, s.start, s.end])])].sort((a, b) => a - b);
  for (let i = 0; i < times.length; i++) {
    stateConservation(result, times[i]);
    if (i) stateConservation(result, (times[i] + times[i - 1]) / 2);
  }
}

const hand = {
  students: 4, windows: 2, windowMeans: [60, 120], serviceCV: 0,
  arrivalPeak: 0, arrivalSpread: 1, horizon: 1, seed: 71
};

test('strict config validation, defaults, deep copy, and multiplier semantics', () => {
  assert.deepEqual(E.normalizeConfig(), E.DEFAULT_CONFIG);
  const invalid = [
    null, [], { students: '960' }, { students: NaN }, { students: Infinity },
    { students: -1 }, { students: 5001 }, { students: 2.5 },
    { windows: 0 }, { windows: 17 }, { serviceMean: 4 }, { serviceMean: 121 },
    { serviceCV: -0.01 }, { serviceCV: 1.01 }, { serviceCV: -Infinity },
    { arrivalSpread: 0 }, { arrivalSpread: 31 }, { stagger: 31 },
    { staggerParticipation: -0.01 }, { staggerParticipation: 1.01 },
    { staggerParticipation: '0.5' }, { staggerParticipation: NaN },
    { staggerParticipation: null }, { staggerParticipation: undefined },
    { horizon: 0 }, { horizon: 361 }, { arrivalPeak: 121 },
    { seed: -1 }, { seed: 4294967296 }, { seed: 1.5 },
    { strategy: '__proto__' }, { strategy: 'unsupported' }, { typo: 1 },
    { windowMeans: [] }, { windows: 1, windowMeans: [NaN] },
    { windows: 1, windowMeans: Array(1) },
    { windows: 1, windowMeans: [0] }, { windows: 1, windowMeans: [601] },
    { windows: 1, windowMeans: '30' }, { students: undefined }
  ];
  for (const config of invalid) assert.throws(() => E.normalizeConfig(config), undefined, JSON.stringify(config));
  const input = Object.freeze({ windows: 2, windowMeans: Object.freeze([25, 70]) });
  const normal = E.normalizeConfig(input);
  normal.windowMeans[0] = 99;
  assert.equal(input.windowMeans[0], 25);
  const multiplierRun = E.simulate({ students: 0, windows: 16, serviceMean: 60 });
  assert.deepEqual(multiplierRun.effectiveWindowMeans, Array.from({ length: 16 }, (_, i) => 60 * E.DEFAULT_WINDOW_MULTIPLIERS[i % 8]));
  assert.equal(multiplierRun.config.windowMeans, null);
  assert.equal(E.normalizeConfig({ students: 0, seed: 0 }).seed, 0);
});

test('hand-calculated heterogeneous pooled queue, simultaneous departures, exact metrics', () => {
  const r = E.simulate({ ...hand, strategy: 'pooled' });
  assert.deepEqual(r.students.map(s => s.arrival), [0, 0, 0, 0]);
  assert.deepEqual(r.students.map(s => s.window), [0, 1, 0, 0]);
  assert.deepEqual(r.students.map(s => s.start), [0, 0, 1, 2]);
  assert.deepEqual(r.students.map(s => s.end), [1, 2, 2, 3]);
  assert.deepEqual(r.students.map(s => s.wait), [0, 0, 1, 2]);
  assert.equal(r.metrics.meanWait, 0.75);
  assert.equal(r.metrics.p95Wait, 2);
  assert.equal(r.metrics.peakQueue, 2);
  assert.equal(r.metrics.queueIntegral, 3);
  assert.equal(r.metrics.systemIntegral, 8);
  assert.equal(r.metrics.totalService, 5);
  assert.equal(r.metrics.observationEnd, 3);
  assert.equal(r.metrics.clearanceTime, 2);
  assert.equal(r.metrics.completionRate, 0.25);
  assert.equal(r.metrics.utilizationScheduled, 1);
  close(r.metrics.utilization, 5 / 6);
  assert.deepEqual(r.timeline, [
    { time: 0, arrived: 4, completed: 0, waiting: 2, inService: 2 },
    { time: 1, arrived: 4, completed: 1, waiting: 1, inService: 2 },
    { time: 2, arrived: 4, completed: 3, waiting: 0, inService: 1 },
    { time: 3, arrived: 4, completed: 4, waiting: 0, inService: 0 }
  ]);
  validateRun(r);
});

test('hand-calculated dedicated shortest queue and expected-workload queue', () => {
  const shortest = E.simulate({ ...hand, strategy: 'shortest' });
  assert.deepEqual(shortest.students.map(s => s.window), [0, 1, 0, 1]);
  assert.deepEqual(shortest.students.map(s => s.end), [1, 2, 2, 4]);
  assert.equal(shortest.metrics.observationEnd, 4);
  assert.equal(shortest.metrics.totalService, 6);
  assert.equal(shortest.metrics.utilization, 0.75);
  const workload = E.simulate({ ...hand, strategy: 'workload' });
  assert.deepEqual(workload.students.map(s => s.window), [0, 1, 0, 0]);
  assert.deepEqual(workload.students.map(s => s.start), [0, 0, 1, 2]);
  validateRun(shortest);
  validateRun(workload);
});

test('departures precede arrivals at the same instant and horizon arrivals are retained', () => {
  const r = E.simulate({
    students: 2, windows: 1, windowMeans: [60], serviceCV: 0,
    arrivalPeak: 0, arrivalSpread: 1, horizon: 1, seed: 0, strategy: 'shortest'
  });
  assert.deepEqual(r.students.map(s => s.arrival), [0, 1]);
  assert.deepEqual(r.students.map(s => s.start), [0, 1]);
  assert.deepEqual(r.students.map(s => s.wait), [0, 0]);
  assert.equal(r.metrics.peakQueue, 0);
  assert.equal(r.metrics.completedAtHorizon, 1);
  assert.deepEqual(r.clampedArrivals, { lower: 1, upper: 1, total: 2 });
  assert.deepEqual(r.arrivalBins, [{ time: 0, count: 1 }, { time: 1, count: 1 }]);
  const atOne = E.snapshot(r, 1);
  assert.equal(atOne.completed, 1);
  assert.equal(atOne.inService, 1);
  assert.equal(atOne.windows[0].currentStudent, 1);
  validateRun(r);
});

test('zero demand is finite, fully drained, and follows the documented empty-ratio convention', () => {
  for (const strategy of Object.keys(E.strategyNames)) {
    const r = E.simulate({ students: 0, windows: 16, strategy });
    assert.equal(r.metrics.meanWait, 0);
    assert.equal(r.metrics.p95Wait, 0);
    assert.equal(r.metrics.completionRate, 0);
    assert.equal(r.metrics.within5min, 0);
    assert.equal(r.metrics.allCompleted, true);
    assert.equal(r.metrics.utilization, 0);
    assert.equal(r.metrics.observationEnd, 120);
    validateRun(r);
  }
});

test('same seed is deterministic, browser UMD matches CommonJS, no Math.random calls', () => {
  const config = { students: 90, seed: 421, strategy: 'random' };
  const before = Math.random;
  let a;
  try {
    Math.random = () => { throw new Error('global Math.random is prohibited'); };
    a = E.simulate(config);
  } finally { Math.random = before; }
  assert.deepEqual(a, E.simulate(config));
  assert.notDeepEqual(a.students.map(s => s.arrival), E.simulate({ ...config, seed: 422 }).students.map(s => s.arrival));
  const sandbox = {};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../dist/engine.js'), 'utf8'), sandbox);
  assert.equal(typeof sandbox.CanteenSim.simulate, 'function');
  assert.equal(JSON.stringify(sandbox.CanteenSim.simulate(config)), JSON.stringify(a));
});

test('paired comparisons preserve per-student arrival and intrinsic service variates', () => {
  const base = { students: 160, windows: 3, windowMeans: [20, 45, 80], seed: 9471, arrivalPeak: 40, arrivalSpread: 7 };
  const reference = E.simulate({ ...base, strategy: 'random' });
  for (const strategy of ['shortest', 'workload', 'pooled']) {
    const r = E.simulate({ ...base, strategy });
    for (let i = 0; i < base.students; i++) {
      assert.equal(r.students[i].arrival, reference.students[i].arrival);
      const x = r.students[i], y = reference.students[i];
      close(x.service / r.windows[x.window].meanService, y.service / reference.windows[y.window].meanService, 1e-12);
    }
  }
  const staggered = E.simulate({ ...base, strategy: 'random', stagger: 12 });
  for (let i = 0; i < base.students; i++) {
    const a = reference.students[i], b = staggered.students[i];
    close(b.rawArrival - a.rawArrival, (a.cohort - 1) * 12, 1e-12);
    assert.equal(a.window, b.window, 'random route stream must not depend on arrival order');
    close(a.service, b.service, 1e-12);
  }
  const longer = E.simulate({ ...base, students: 170, strategy: 'random' });
  for (let i = 0; i < base.students; i++) {
    assert.equal(reference.students[i].arrival, longer.students[i].arrival);
    assert.equal(reference.students[i].window, longer.students[i].window);
    assert.equal(reference.students[i].service, longer.students[i].service);
  }
});

test('expected-workload routing cannot inspect latent actual service lengths', () => {
  const deterministic = E.simulate({ ...hand, strategy: 'workload', serviceCV: 0 });
  const variable = E.simulate({ ...hand, strategy: 'workload', serviceCV: 1 });
  assert.deepEqual(variable.students.map(s => s.arrival), [0, 0, 0, 0]);
  assert.deepEqual(variable.students.map(s => s.window), deterministic.students.map(s => s.window));
  assert.notDeepEqual(variable.students.map(s => s.service), deterministic.students.map(s => s.service));
  const r = E.simulate({ students: 280, windows: 3, windowMeans: [10, 40, 90], serviceCV: 1, arrivalSpread: 2, strategy: 'workload', seed: 828 });
  const seen = [[], [], []];
  for (const s of r.students.slice().sort((a, b) => a.arrival - b.arrival || a.id - b.id)) {
    const scores = seen.map((jobs, j) => {
      const current = jobs.find(x => x.start <= s.arrival && x.end > s.arrival);
      const queued = jobs.filter(x => x.start > s.arrival).length;
      return { id: j, idle: !current, score: (current ? Math.max(r.windows[j].meanService - (s.arrival - current.start), 0) : 0) + queued * r.windows[j].meanService };
    }).sort((a, b) => a.score - b.score || Number(b.idle) - Number(a.idle) || a.id - b.id);
    assert.equal(s.window, scores[0].id, 'route should minimize observable expected workload');
    seen[s.window].push(s);
  }
  validateRun(r);
});

test('pooled simulation agrees with an independent FCFS earliest-available-server scheduler', () => {
  for (const seed of [0, 71, 20261017, 4294967295]) {
    const r = E.simulate({ students: 170, windows: 4, windowMeans: [15, 22, 70, 120], serviceCV: 0.8, arrivalPeak: 20, arrivalSpread: 20, horizon: 40, stagger: 15, strategy: 'pooled', seed });
    const available = [0, 0, 0, 0];
    for (const s of r.students.slice().sort((a, b) => a.arrival - b.arrival || a.id - b.id)) {
      let window = available.findIndex(t => t <= s.arrival);
      if (window === -1) window = available.indexOf(Math.min(...available));
      const start = Math.max(s.arrival, available[window]);
      assert.equal(s.window, window);
      close(s.start, start, 1e-10);
      available[window] = start + s.service;
      close(s.end, available[window], 1e-10);
    }
    validateRun(r);
  }
});

test('conservation, FCFS, exact peaks, no overlap, and full clearing across scenario boundaries', () => {
  const scenarios = [
    { students: 1, windows: 1, serviceCV: 0, serviceMean: 5, arrivalPeak: 0, horizon: 1, arrivalSpread: 1 },
    { students: 73, windows: 3, windowMeans: [1, 65, 600], serviceCV: 1, arrivalPeak: 1, horizon: 2.5, arrivalSpread: 30, stagger: 30 },
    { students: 180, windows: 16, serviceMean: 120, serviceCV: 0.5, arrivalPeak: 60, horizon: 90, arrivalSpread: 1, stagger: 20 }
  ];
  for (const strategy of Object.keys(E.strategyNames)) {
    for (let i = 0; i < scenarios.length; i++) validateRun(E.simulate({ ...scenarios[i], strategy, seed: 1301 + i }));
  }
});

test('minute timeline and JSON-restored playback agree with exact record states', () => {
  const r = E.simulate({ students: 95, windows: 3, windowMeans: [40, 60, 80], arrivalPeak: 8, horizon: 10.5, strategy: 'pooled', seed: 715 });
  const restored = JSON.parse(JSON.stringify(r));
  for (const point of r.timeline) {
    const state = E.snapshot(r, point.time);
    assert.deepEqual({ time: state.time, arrived: state.arrived, completed: state.completed, waiting: state.waiting, inService: state.inService }, point);
    assert.deepEqual(E.snapshot(restored, point.time), state);
  }
  assert.equal(E.snapshot(r, -10).time, 0);
  assert.equal(E.snapshot(r, 1e8).time, r.metrics.observationEnd);
  assert.throws(() => E.snapshot(r, NaN));
  assert.throws(() => E.snapshot(r, Infinity));
  assert.throws(() => E.snapshot(null, 0));
});

test('nearest-rank quantiles and exact five-minute threshold', () => {
  assert.equal(E.quantile([], 0.95), 0);
  assert.equal(E.quantile([8, 1, 4, 2], 0.95), 8);
  assert.equal(E.quantile([8, 1, 4, 2], 0), 1);
  assert.equal(E.quantile([8, 1, 4, 2], 0.5), 2);
  assert.equal(E.quantile([8, 1, 4, 2], 1), 8);
  assert.throws(() => E.quantile([1, NaN]));
  assert.throws(() => E.quantile([1], 1.1));
  const r = E.simulate({ ...hand, windows: 1, windowMeans: [300], strategy: 'pooled' });
  assert.deepEqual(r.students.map(s => s.wait), [0, 5, 10, 15]);
  assert.equal(r.metrics.within5min, 0.5);
  assert.equal(r.metrics.within5Count, 2);
  assert.equal(r.metrics.p95Wait, 15);
});

test('maximum population, uint32 edge seed and long drain do not lose jobs or create NaN', () => {
  const r = E.simulate({ students: 5000, windows: 1, windowMeans: [600], serviceCV: 1, arrivalPeak: 40, arrivalSpread: 30, stagger: 30, horizon: 60, seed: 4294967295, strategy: 'pooled' });
  allFinite(r);
  assert.equal(r.students.length, 5000);
  assert.equal(r.windows[0].served, 5000);
  assert.equal(r.metrics.allCompleted, true);
  assert.ok(r.metrics.observationEnd > 10000);
  assert.equal(r.timeline.at(-1).completed, 5000);
  assert.equal(r.completionBins.reduce((a, b) => a + b.count, 0), 5000);
  close(r.metrics.queueIntegral, r.students.reduce((a, s) => a + s.wait, 0));
  stateConservation(r, 0);
  stateConservation(r, 60);
  stateConservation(r, r.metrics.observationEnd / 2);
  stateConservation(r, r.metrics.observationEnd);
});

test('v1.2 full participation reproduces v1.0 numerical outputs exactly, including legacy JSON defaults', () => {
  // These SHA-256 values were captured from the unmodified v1.0.0 engine.
  // They cover every old numerical output, including every student event,
  // window/cohort statistic, integral, timeline point and histogram bin.
  const fixtures = [
    [{}, 'b1efc4436cada0545b76f28fcd5a12fe7c04a2b074f086d526bed7cfab7df563'],
    [{ strategy: 'workload', stagger: 12 }, '1e51a24d2b38b91e74791fff23eaac1212ff832e390e536499f9c0d6c66e734b'],
    [{ strategy: 'pooled', stagger: 18 }, '76fcc2ee31738662883001d7db7a87228585d71c86a6069ed261c51a484ba49a'],
    [{ strategy: 'random', serviceCV: 1, seed: 0, horizon: 30, arrivalPeak: 10, stagger: 12 }, '2a9691aaa617efe6a3b99dff55c1da497b4d6467b2530331d384c4a5a15767bf']
  ];
  for (const [config, expected] of fixtures) {
    const restoredLegacyConfig = JSON.parse(JSON.stringify(config));
    const current = E.simulate(restoredLegacyConfig);
    assert.equal(current.meta.version, '1.2.0');
    assert.equal(current.config.staggerParticipation, 1);
    assert.deepEqual(current, E.simulate({ ...config, staggerParticipation: 1 }));
    const oldProjection = JSON.parse(JSON.stringify(current));
    delete oldProjection.meta;
    delete oldProjection.config;
    for (const s of oldProjection.students) {
      for (const key of ['staggerParticipant', 'plannedArrivalOffset', 'appliedArrivalOffset', 'targetArrival']) delete s[key];
    }
    for (const c of oldProjection.cohorts) {
      for (const key of ['meanTargetArrival', 'staggerParticipants', 'staggerParticipationRate', 'shiftedStudents']) delete c[key];
    }
    for (const key of ['staggerParticipants', 'staggerParticipationRate', 'shiftedStudents', 'shiftedStudentRate']) delete oldProjection.metrics[key];
    assert.equal(crypto.createHash('sha256').update(JSON.stringify(oldProjection)).digest('hex'), expected);
  }
});

test('zero participation preserves original arrivals and queue outcomes at every stagger setting', () => {
  for (const strategy of Object.keys(E.strategyNames)) {
    const config = { students: 99, arrivalPeak: 8, arrivalSpread: 12, horizon: 30, strategy, seed: 43 };
    const base = E.simulate({ ...config, stagger: 0 });
    const none = E.simulate({ ...config, stagger: 30, staggerParticipation: 0 });
    for (let id = 0; id < config.students; id += 1) {
      for (const key of ['arrival', 'rawArrival', 'start', 'end', 'wait', 'service', 'window']) {
        assert.equal(none.students[id][key], base.students[id][key]);
      }
      assert.equal(none.students[id].staggerParticipant, false);
      assert.equal(none.students[id].appliedArrivalOffset, 0);
      assert.equal(none.students[id].targetArrival, config.arrivalPeak);
    }
    assert.equal(none.metrics.staggerParticipants, 0);
    assert.equal(none.metrics.shiftedStudents, 0);
    assert.equal(none.metrics.meanWait, base.metrics.meanWait);
    assert.equal(none.metrics.p95Wait, base.metrics.p95Wait);
  }
});

test('participation sets are deterministic, nested, and independent of routing, population size and service parameters', () => {
  const base = { students: 180, stagger: 12, seed: 418, arrivalPeak: 40, arrivalSpread: 7 };
  const half = E.simulate({ ...base, staggerParticipation: 0.5 });
  const high = E.simulate({ ...base, staggerParticipation: 0.8 });
  assert.ok(half.metrics.staggerParticipants > 0 && half.metrics.staggerParticipants < base.students);
  assert.ok(high.metrics.staggerParticipants > half.metrics.staggerParticipants);
  for (const s of half.students) {
    if (s.staggerParticipant) assert.equal(high.students[s.id].staggerParticipant, true);
  }
  assert.deepEqual(half, E.simulate({ ...base, staggerParticipation: 0.5 }));
  const changed = E.simulate({ ...base, students: 200, windows: 3, windowMeans: [10, 30, 80], serviceCV: 1, staggerParticipation: 0.5, strategy: 'pooled' });
  for (let id = 0; id < base.students; id += 1) {
    assert.equal(changed.students[id].staggerParticipant, half.students[id].staggerParticipant);
    assert.equal(changed.students[id].arrival, half.students[id].arrival);
  }
  assert.notDeepEqual(half.students.map(s => s.staggerParticipant), E.simulate({ ...base, seed: 419, staggerParticipation: 0.5 }).students.map(s => s.staggerParticipant));
});

test('partial participation retains paired arrival residuals, intrinsic services and random routing streams', () => {
  const base = { students: 180, windows: 3, windowMeans: [20, 45, 80], strategy: 'random', arrivalPeak: 10, arrivalSpread: 15, horizon: 30, stagger: 18, seed: 9471 };
  const reference = E.simulate({ ...base, staggerParticipation: 0 });
  for (const rate of [0.5, 0.8, 1]) {
    const r = E.simulate({ ...base, staggerParticipation: rate });
    for (let id = 0; id < base.students; id += 1) {
      const a = reference.students[id], b = r.students[id];
      close(b.rawArrival - b.targetArrival, a.rawArrival - a.targetArrival, 1e-12);
      assert.equal(a.window, b.window);
      assert.equal(a.service, b.service);
      assert.equal(b.plannedArrivalOffset, (b.cohort - 1) * base.stagger);
      assert.equal(b.appliedArrivalOffset, b.staggerParticipant ? b.plannedArrivalOffset : 0);
      assert.equal(b.targetArrival, base.arrivalPeak + b.appliedArrivalOffset);
    }
    validateRun(r);
  }
});

test('participation and nonzero target shifts have distinct, correct counts including empty runs and middle cohorts', () => {
  for (const config of [
    { students: 0, stagger: 12 },
    { students: 99, stagger: 0, staggerParticipation: 1 },
    { students: 99, stagger: 12, staggerParticipation: 1 },
    { students: 99, stagger: 12, staggerParticipation: 0.5 }
  ]) {
    const r = E.simulate(config), n = r.students.length;
    const participants = r.students.filter(s => s.staggerParticipant).length;
    const shifted = r.students.filter(s => s.appliedArrivalOffset !== 0).length;
    assert.equal(r.metrics.staggerParticipants, participants);
    assert.equal(r.metrics.staggerParticipationRate, n ? participants / n : 0);
    assert.equal(r.metrics.shiftedStudents, shifted);
    assert.equal(r.metrics.shiftedStudentRate, n ? shifted / n : 0);
    for (const c of r.cohorts) {
      const members = r.students.filter(s => s.cohort === c.id);
      const count = members.filter(s => s.staggerParticipant).length;
      assert.equal(c.staggerParticipants, count);
      assert.equal(c.staggerParticipationRate, members.length ? count / members.length : 0);
      assert.equal(c.shiftedStudents, members.filter(s => s.appliedArrivalOffset !== 0).length);
      close(c.meanTargetArrival, members.length ? members.reduce((sum, s) => sum + s.targetArrival, 0) / members.length : 0);
    }
    assert.equal(r.cohorts[1].shiftedStudents, 0, 'the middle cohort has no scheduled shift');
    allFinite(r);
  }
  const full = E.simulate({ students: 99, stagger: 12, staggerParticipation: 1 });
  assert.equal(full.metrics.staggerParticipants, 99);
  assert.equal(full.metrics.shiftedStudents, 66);
});

test('held-out validation seeds stay disjoint across uint32 wrap and preserve the locked candidate', () => {
  const R = require('./robustness.cjs');
  const trainingSeeds = [4294967293, 4294967294, 4294967295, 0, 1];
  const seeds = R.createFreshSeeds(trainingSeeds);
  assert.equal(seeds.length, 30);
  assert.equal(new Set(seeds).size, 30);
  assert.ok(seeds.every(seed => !trainingSeeds.includes(seed) && Number.isInteger(seed) && seed >= 0 && seed <= 4294967295));
  assert.equal(seeds[0], (trainingSeeds[0] + 1000003) >>> 0);
  const candidate = Object.freeze({ students: 45, windows: 2, strategy: 'workload', stagger: 18, staggerParticipation: 0.8, seed: trainingSeeds[0] });
  const normalizedBefore = E.normalizeConfig(candidate);
  const v = R.validateCandidate(candidate, { trainingSeeds, baselineConfig: { ...candidate, stagger: 0, strategy: 'shortest' } });
  assert.deepEqual(v.candidate.config, normalizedBefore);
  assert.deepEqual(v.seeds, seeds);
  assert.deepEqual(v.candidate.seeds, v.baseline.seeds);
  assert.equal(v.lockedBeforeValidation, true);
  assert.equal(v.rerankedAfterValidation, false);
  assert.equal(v.target.totalRuns, 30);
});
