'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const E = require('../dist/school-engine.js');
const Legacy = require('../dist/engine.js');

const clone = x => JSON.parse(JSON.stringify(x));
const close = (a, b, message = '') => assert.ok(Math.abs(a - b) <= 1e-7 * Math.max(1, Math.abs(a), Math.abs(b)), `${message}: ${a} vs ${b}`);
const total = (values, key) => values.reduce((a, b) => a + (typeof key === 'function' ? key(b) : b[key]), 0);
function config(overrides = {}, counts = [30, 34, 32]) {
  const c = clone(E.DEFAULT_SCHOOL_CONFIG);
  c.grades = c.grades.map((g, id) => ({ ...g, students: counts[id], classes: Math.min(g.classes, counts[id]) }));
  Object.assign(c, overrides);
  c.students = c.grades.reduce((n, g) => n + g.students, 0);
  if ('windows' in overrides && !('windowOwners' in overrides)) c.windowOwners = Array.from({ length: c.windows }, (_, i) => Math.min(2, Math.floor(i * 3 / c.windows)));
  return E.normalizeSchoolConfig(c);
}
function earlyConfig(overrides = {}, counts = [6, 5, 4]) {
  const c = config({}, counts);
  c.grades.forEach(g => Object.assign(g, { classes: g.students ? 1 : 0, readyTime: 0, releaseTime: 0, classInterval: 0, assemblyMax: 0, walkMin: 0, walkMax: 0, deadline: 120 }));
  const merged = { ...c, serviceStart: 10, serviceEnd: 110, ...overrides };
  if ('windows' in overrides && !('windowOwners' in overrides)) merged.windowOwners = Array.from({ length: merged.windows }, (_, i) => Math.min(2, Math.floor(i * 3 / merged.windows)));
  return config(merged, counts);
}
function checkCore(r) {
  assert.equal(r.students.length, r.config.students);
  assert.equal(total(r.windows, 'served'), r.students.length);
  assert.equal(total(r.gradeMetrics, 'count'), r.students.length);
  for (const s of r.students) {
    assert.equal(r.students[s.id], s);
    assert.ok(s.release >= s.readyTime);
    assert.ok(s.arrival >= s.release);
    assert.ok(s.start >= s.arrival);
    assert.ok(s.start >= r.config.serviceStart);
    assert.ok(s.end > s.start);
    assert.ok(s.serviceFactor > 0 && s.mealFactor > 0);
    close(s.wait, s.start - s.arrival, 'wait definition');
    close(s.service, r.effectiveWindowMeans[s.window] / 60 * s.serviceFactor, 'service demand');
    if (r.config.diningEnabled) {
      assert.ok(s.seatStart >= s.end);
      assert.ok(s.mealEnd > s.seatStart);
      assert.ok(s.returnTime >= s.mealEnd);
      assert.equal(s.endpointTime, s.returnTime);
      assert.ok(Number.isInteger(s.seatId) && s.seatId >= 0 && s.seatId < r.config.seats);
    } else {
      assert.equal(s.endpointTime, s.end);
      assert.equal(s.seatId, null);
      assert.equal(s.returnTime, null);
    }
    assert.equal(s.late, s.endpointTime > s.deadline);
  }
  for (const w of r.windows) {
    const assigned = r.students.filter(s => s.window === w.id).sort((a, b) => a.start - b.start);
    for (let i = 1; i < assigned.length; i++) assert.ok(assigned[i].start >= assigned[i - 1].end);
    close(w.busyMinutes, total(assigned, 'service'));
    assert.ok(w.utilizationScheduled >= 0 && w.utilizationScheduled <= 1 + 1e-9);
  }
  close(total(r.students, 'wait'), r.metrics.queueIntegral, 'pickup queue area');
  close(r.metrics.independentQueueIntegral, r.metrics.queueIntegral, 'independent pickup event sweep');
  close(total(r.gradeMetrics, 'queueIntegral'), r.metrics.queueIntegral, 'grade queue areas');
  close(total(r.students, 'service'), r.metrics.busyIntegral, 'busy area');
  close(total(r.students, s => s.end - s.arrival), r.metrics.systemIntegral, 'system area');
  close(total(r.students, 'seatWait'), r.metrics.seatQueueIntegral, 'seat queue area');
  close(total(r.students, 'mealDuration'), r.metrics.seatOccupancyIntegral, 'occupied seat area');
  assert.ok(r.metrics.peakSeatsOccupied <= r.config.seats);
  const final = E.snapshot(r, r.metrics.observationEnd);
  assert.equal(final.completed, r.students.length);
  assert.equal(final.waiting + final.inService + final.seatWaiting + final.dining + final.returning, 0);
  assert.equal(final.endpointCompleted, r.students.length);
}

test('school defaults, complete exported config and legacy dispatch remain distinct', () => {
  assert.equal(E.VERSION, '1.6.0');
  assert.equal(E.LEGACY_VERSION, '1.2.0');
  assert.deepEqual(E.DEFAULT_CONFIG, Legacy.DEFAULT_CONFIG);
  const c = E.normalizeSchoolConfig();
  assert.deepEqual(c, E.DEFAULT_SCHOOL_CONFIG);
  assert.deepEqual(E.normalizeConfig(clone(c)), c);
  c.grades[0].students = 99;
  assert.equal(E.DEFAULT_SCHOOL_CONFIG.grades[0].students, 300);
  assert.deepEqual(E.normalizeConfig(), Legacy.normalizeConfig());
});

test('strict school validation rejects invalid shapes, infeasible early release and orphan dedicated grades', () => {
  const c = config();
  const bad = [
    { ...c, surprise: 1 }, { ...c, students: 1 }, { ...c, strategy: ['pooled'] },
    { ...c, diningEnabled: 1 }, { ...c, seats: 0 }, { ...c, serviceEnd: c.serviceStart },
    { ...c, windowOwners: [0] }, { ...c, windowOwners: c.windowOwners.map(() => 3) },
    { ...c, windowMeans: [30] }, { ...c, grades: [] },
    { ...c, grades: c.grades.map((g, i) => i ? g : { ...g, releaseTime: g.readyTime - 1 }) },
    { ...c, grades: c.grades.map((g, i) => i ? g : { ...g, walkMin: 10, walkMax: 2 }) },
    { ...c, grades: c.grades.map((g, i) => i ? g : { ...g, classes: 0 }) },
    { ...c, grades: c.grades.map((g, i) => i ? g : { ...g, unknown: 1 }) },
    { ...c, allocation: 'dedicated', windowOwners: c.windowOwners.map(() => 0) }
  ];
  for (const input of bad) assert.throws(() => E.normalizeConfig(input));
  assert.throws(() => E.normalizeConfig({ mode: 'other' }));
  assert.throws(() => E.snapshot(null, 1));
  assert.throws(() => E.snapshot(E.simulate(c), NaN));
});

test('partial school config derives the student total and window ownership explicitly', () => {
  const c = E.normalizeSchoolConfig({ mode: 'school', windows: 6 });
  assert.equal(c.students, 960);
  assert.deepEqual(c.windowOwners, [0, 0, 1, 1, 2, 2]);
  assert.deepEqual(E.normalizeConfig(clone(c)), c);
});

test('all arrivals follow feasible class releases without clipping, class sizes and delays are shared', () => {
  const r = E.simulate(config({ seed: 371 }, [301, 343, 319]));
  checkCore(r);
  assert.equal(r.clampedArrivals.total, 0);
  for (const g of r.config.grades) {
    const batches = r.classBatches.filter(b => b.grade === g.id);
    assert.equal(batches.length, g.classes);
    assert.equal(total(batches, 'students'), g.students);
    assert.ok(Math.max(...batches.map(b => b.students)) - Math.min(...batches.map(b => b.students)) <= 1);
    for (const b of batches) {
      const people = r.students.filter(s => s.classId === b.classId);
      assert.equal(people.length, b.students);
      assert.equal(b.release, g.releaseTime + b.classIndex * g.classInterval);
      for (const s of people) {
        assert.equal(s.release, b.release); assert.equal(s.assembly, b.assembly); assert.equal(s.walk, b.walk);
        assert.ok(s.arrivalJitter >= 0 && s.arrivalJitter <= 0.5);
        close(s.arrival, s.release + s.assembly + s.walk + s.arrivalJitter);
      }
    }
  }
});

test('baseline and gap scenarios preserve each person and class random demand', () => {
  const c = config();
  c.grades[0].readyTime = 22; c.grades[1].readyTime = 24;
  const baseline = E.makeSchoolBaseline(c), gaps = E.makeSchoolGapConfig(c, 15);
  assert.deepEqual(baseline.grades.map(g => g.releaseTime), [25, 25, 25]);
  assert.deepEqual(gaps.grades.map(g => g.releaseTime), [25, 40, 55]);
  assert.deepEqual(E.makeSchoolGapConfig(c, 0), baseline);
  const a = E.simulate(baseline), b = E.simulate(gaps);
  for (let id = 0; id < a.students.length; id++) {
    for (const key of ['randomId', 'classId', 'assembly', 'walk', 'arrivalJitter', 'serviceFactor', 'mealFactor', 'routeDraw']) assert.equal(a.students[id][key], b.students[id][key]);
    close(b.students[id].arrival - a.students[id].arrival, b.students[id].release - a.students[id].release);
  }
  assert.deepEqual(c.grades.map(g => g.releaseTime), [25, 35, 45], 'helper must not mutate its source');
});

test('gap helper preserves a user-defined senior-first release order', () => {
  const c = config();
  c.grades[0].releaseTime = 45; c.grades[1].releaseTime = 35; c.grades[2].releaseTime = 25;
  const gaps = E.makeSchoolGapConfig(c, 10);
  assert.deepEqual(gaps.grades.map(g => g.releaseTime), [45, 35, 25]);
  assert.deepEqual(E.makeSchoolGapConfig(c, 0), E.makeSchoolBaseline(c));
});

test('changing an earlier grade population does not change another grade individual demand', () => {
  const a = E.simulate(config({}, [30, 34, 32])), b = E.simulate(config({}, [60, 34, 32]));
  const first = a.students.filter(s => s.grade === 1), second = b.students.filter(s => s.grade === 1);
  for (let i = 0; i < first.length; i++) {
    for (const key of ['randomId', 'classId', 'assembly', 'walk', 'arrivalJitter', 'serviceFactor', 'mealFactor', 'arrival']) assert.equal(first[i][key], second[i][key]);
  }
});

for (const allocation of ['shared', 'dedicated', 'overflow']) {
  for (const strategy of ['pooled', 'shortest', 'workload', 'random']) {
    test(`${allocation}/${strategy}: continuous completion, eligibility, independent queue and seat conservation`, () => {
      const c = config({ allocation, strategy, windows: 6, windowOwners: [0, 0, 1, 1, 2, 2], seats: 20, seed: 813, serviceCV: 0.7 });
      const r = E.simulate(c); checkCore(r);
      if (allocation === 'dedicated') assert.ok(r.students.every(s => c.windowOwners[s.window] === s.grade));
      if (allocation === 'overflow') assert.equal(r.meta.effectiveStrategy, 'grade-priority-pooled');
      for (const t of r.timeline.filter((_, i) => i % 9 === 0)) {
        const snap = E.snapshot(r, t.time);
        assert.equal(snap.arrived, snap.waiting + snap.inService + snap.completed);
        assert.equal(snap.completed, snap.seatWaiting + snap.dining + snap.returning + snap.returned);
        assert.equal(total(snap.gradeStates, 'waiting'), snap.waiting);
        assert.equal(snap.dining, new Set(snap.diningIds.map(id => r.students[id].seatId)).size);
        assert.equal(snap.waiting, t.waiting);
      }
    });
  }
}

test('shared and grade-dedicated pooled queues are FCFS across continuous grade arrivals', () => {
  for (const allocation of ['shared', 'dedicated', 'overflow']) {
    const c = earlyConfig({ allocation, strategy: 'pooled', windows: 3, windowOwners: [0, 1, 2] }, [50, 53, 51]);
    const r = E.simulate(c);
    const groups = allocation === 'shared' ? [r.students] : [0, 1, 2].map(g => r.students.filter(s => s.grade === g));
    for (const group of groups) {
      const order = group.slice().sort((a, b) => a.arrival - b.arrival || a.id - b.id);
      for (let i = 1; i < order.length; i++) assert.ok(order[i].start >= order[i - 1].start, 'later FCFS arrival started first');
    }
  }
});

test('overflow preserves own-grade priority and then serves otherwise orphan grades', () => {
  const c = earlyConfig({ allocation: 'overflow', windows: 3, windowOwners: [0, 1, 2], windowMeans: [60, 60, 60], serviceCV: 0 }, [15, 7, 3]);
  const r = E.simulate(c);
  const first = r.students.filter(s => s.start === c.serviceStart);
  assert.equal(first.length, 3);
  assert.ok(first.every(s => c.windowOwners[s.window] === s.grade));
  const borrowed = r.students.filter(s => c.windowOwners[s.window] !== s.grade);
  assert.ok(borrowed.length > 0);
  for (const s of borrowed) {
    const owner = c.windowOwners[s.window];
    assert.equal(r.students.filter(other => other.grade === owner && other.arrival <= s.start && other.start > s.start).length, 0, 'borrowed while own-grade queue was waiting');
  }
  const orphan = E.simulate(earlyConfig({ allocation: 'overflow', windows: 1, windowOwners: [0] }, [0, 0, 5]));
  checkCore(orphan); assert.equal(orphan.windows[0].served, 5);
});

test('overflow output is independent of the irrelevant routing-strategy selector', () => {
  const a = E.simulate(config({ allocation: 'overflow', strategy: 'random' }));
  const b = E.simulate(config({ allocation: 'overflow', strategy: 'workload' }));
  assert.deepEqual(a.students, b.students);
  assert.deepEqual(a.metrics, b.metrics);
});

test('workload routing before opening cannot use unobserved individual or queued service lengths', () => {
  const c = earlyConfig({ strategy: 'workload', windows: 3, windowMeans: [15, 45, 90], serviceCV: 0 }, [40, 35, 30]);
  const deterministic = E.simulate(c), variable = E.simulate({ ...c, serviceCV: 1 });
  assert.ok(variable.students.every(s => s.arrival < c.serviceStart));
  assert.deepEqual(variable.students.map(s => s.arrival), deterministic.students.map(s => s.arrival));
  assert.deepEqual(variable.students.map(s => s.window), deterministic.students.map(s => s.window));
  assert.notDeepEqual(variable.students.map(s => s.service), deterministic.students.map(s => s.service));
});

test('pooled results match an independent earliest-available-server scheduler with opening and eligibility constraints', () => {
  for (const allocation of ['shared', 'dedicated']) {
    for (const seed of [0, 87, 4294967295]) {
      const c = config({ allocation, windows: 6, windowOwners: [0, 0, 1, 1, 2, 2], windowMeans: [15, 90, 25, 55, 40, 70], serviceStart: 35, seed });
      const r = E.simulate(c), available = new Array(c.windows).fill(c.serviceStart);
      for (const s of r.students.slice().sort((a, b) => a.arrival - b.arrival || a.id - b.id)) {
        const eligible = available.map((time, id) => ({ time, id })).filter(w => allocation === 'shared' || c.windowOwners[w.id] === s.grade);
        const idle = eligible.find(w => w.time <= s.arrival);
        const next = idle || eligible.sort((a, b) => a.time - b.time || a.id - b.id)[0];
        const start = Math.max(s.arrival, next.time);
        assert.equal(s.window, next.id); close(s.start, start);
        available[next.id] = start + r.effectiveWindowMeans[next.id] / 60 * s.serviceFactor;
        close(s.end, available[next.id]);
      }
    }
  }
});

test('supply opening is a real constraint; planned closing measures overtime while clearing all arrivals', () => {
  const c = earlyConfig({ windows: 1, windowMeans: [60], serviceCV: 0, serviceStart: 20, serviceEnd: 21, horizon: 21, diningEnabled: false }, [3, 0, 0]);
  const r = E.simulate(c); checkCore(r);
  assert.deepEqual(r.students.map(s => s.start).sort((a, b) => a - b), [20, 21, 22]);
  assert.equal(r.metrics.lastPickup, 23); assert.equal(r.metrics.overtimeMinutes, 2);
  assert.equal(r.metrics.completedByServiceEnd, 1); assert.equal(r.metrics.serviceEndCompletionRate, 1 / 3);
  assert.equal(r.metrics.utilizationScheduled, 1);
  const afterClose = clone(c); afterClose.grades[0].releaseTime = 30;
  const late = E.simulate(afterClose);
  assert.equal(late.metrics.completedByServiceEnd, 0);
  assert.equal(late.metrics.allCompleted, true);
  assert.ok(late.metrics.overtimeMinutes > 9);
});

test('limited seats have FCFS waiting, unique occupancy and exact physical-seat reuse', () => {
  const r = E.simulate(earlyConfig({ seats: 2, mealMean: 8, mealCV: 0.5, windows: 3, windowMeans: [1, 1, 1], serviceCV: 0 }, [12, 8, 6]));
  checkCore(r); assert.ok(r.metrics.meanSeatWait > 0); assert.equal(r.metrics.peakSeatsOccupied, 2);
  const order = r.students.slice().sort((a, b) => a.end - b.end || a.id - b.id);
  for (let i = 1; i < order.length; i++) assert.ok(order[i].seatStart >= order[i - 1].seatStart);
  for (let seat = 0; seat < r.config.seats; seat++) {
    const users = r.students.filter(s => s.seatId === seat).sort((a, b) => a.seatStart - b.seatStart);
    for (let i = 1; i < users.length; i++) assert.ok(users[i].seatStart >= users[i - 1].mealEnd);
  }
  const events = r.students.flatMap(s => [{ time: s.seatStart, value: 1 }, { time: s.mealEnd, value: -1 }]).sort((a, b) => a.time - b.time);
  let seats = 0, peak = 0, area = 0, last = 0;
  for (let i = 0; i < events.length;) {
    const time = events[i].time; area += seats * (time - last);
    while (i < events.length && events[i].time === time) seats += events[i++].value;
    peak = Math.max(peak, seats); assert.ok(seats >= 0 && seats <= 2); last = time;
  }
  assert.equal(seats, 0); assert.equal(peak, r.metrics.peakSeatsOccupied); close(area, r.metrics.seatOccupancyIntegral);
});

test('deadline semantics change explicitly with endpoint, including exact equality and empty grades', () => {
  const c = earlyConfig({ windows: 1, windowMeans: [60], serviceCV: 0, seats: 1, mealMean: 5, mealCV: 0, returnMinutes: 2 }, [1, 0, 0]);
  const initial = E.simulate(c); assert.equal(initial.students[0].end, 11); assert.equal(initial.students[0].returnTime, 18);
  c.grades[0].deadline = 18;
  const exact = E.simulate(c); assert.equal(exact.metrics.onTimeRate, 1); assert.equal(exact.metrics.lateCount, 0);
  c.grades[0].deadline = 17.9;
  const late = E.simulate(c); assert.equal(late.metrics.onTimeRate, 0); assert.equal(late.metrics.lateCount, 1); close(late.metrics.maxLateness, 0.1);
  const pickupOnly = E.simulate({ ...c, diningEnabled: false }); checkCore(pickupOnly);
  assert.equal(pickupOnly.metrics.onTimeRate, 1); assert.equal(pickupOnly.metrics.endpointLabel, '取餐完成');
  assert.equal(late.metrics.endpointLabel, '返回教室');
  assert.equal(late.gradeMetrics[1].onTimeRate, 0); assert.equal(late.gradeMetrics[1].lastReturn, 0);
});

test('next release retains the earlier grade queue, occupied seats and in-progress return', () => {
  const c = config({ windows: 3, seats: 5 }, [90, 80, 70]);
  const r = E.simulate(c), overlap = r.batchOverlaps[1];
  assert.ok(overlap.previousWaiting > 0);
  assert.ok(overlap.previousDining > 0);
  const snap = E.snapshot(r, c.grades[1].releaseTime);
  assert.equal(overlap.previousWaiting, snap.gradeStates[0].waiting);
  assert.equal(overlap.previousDining, snap.gradeStates[0].dining);
  assert.equal(overlap.previousStillOnSite, snap.gradeStates[0].waiting + snap.gradeStates[0].inService + snap.gradeStates[0].seatWaiting + snap.gradeStates[0].dining);
});

test('pooled snapshots show actual pools without assigning a waiting student to a future window', () => {
  for (const allocation of ['shared', 'dedicated', 'overflow']) {
    const c = earlyConfig({ allocation, windows: 3, windowOwners: [0, 1, 2] });
    const r = E.simulate(c), snap = E.snapshot(r, 5);
    assert.equal(snap.waiting, r.students.length);
    assert.equal(snap.centralQueueIds.length, r.students.length);
    assert.equal(snap.windows.reduce((n, w) => n + w.queueIds.length, 0), 0);
    assert.deepEqual(snap.gradeQueueIds.map(ids => ids.length), c.grades.map(g => g.students));
  }
});

test('empty-school output is finite and has no artificial overtime or occupancy', () => {
  const r = E.simulate(config({ allocation: 'dedicated' }, [0, 0, 0])); checkCore(r);
  for (const [key, value] of Object.entries(r.metrics)) if (typeof value === 'number') assert.ok(Number.isFinite(value), key);
  assert.equal(r.metrics.overtimeMinutes, 0); assert.equal(r.metrics.meanWait, 0); assert.equal(r.metrics.onTimeRate, 0);
  assert.equal(r.classBatches.length, 0); assert.equal(r.metrics.peakSeatsOccupied, 0);
});

test('very long but finite seat drainage uses bounded output bins without changing exact metrics', () => {
  const r = E.simulate(earlyConfig({ seats: 1, mealMean: 90, mealCV: 0, windows: 3, windowMeans: [1, 1, 1], serviceCV: 0 }, [100, 100, 100]));
  checkCore(r);
  assert.ok(r.metrics.observationEnd > 14400);
  assert.ok(r.meta.binWidthMinutes > 1);
  assert.ok(r.timeline.length <= 14402);
  assert.equal(total(r.arrivalBins, 'count'), 300); assert.equal(total(r.completionBins, 'count'), 300);
  close(r.metrics.totalMealMinutes, 27000);
});

test('browser UMD and Node APIs reproduce identical school results', () => {
  const context = vm.createContext({});
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../dist/engine.js'), 'utf8'), context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../dist/hall-walk.js'), 'utf8'), context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../dist/school-engine.js'), 'utf8'), context);
  const c = config({ seed: 981, allocation: 'overflow', seats: 15 });
  context.input = clone(c);
  const browser = vm.runInContext('JSON.stringify(CanteenSim.simulate(input))', context);
  assert.equal(browser, JSON.stringify(E.simulate(c)));
});

test('v1.2 numerical output, configuration and snapshots remain byte-identical through the wrapper', () => {
  const cases = [
    {}, { students: 0 }, { students: 237, windows: 6, stagger: 12, staggerParticipation: 0.8, strategy: 'workload', seed: 883 },
    { students: 400, windows: 3, windowMeans: [15, 30, 60], strategy: 'pooled', arrivalSpread: 1, serviceCV: 1 }
  ];
  for (const c of cases) {
    assert.equal(JSON.stringify(E.normalizeConfig(c)), JSON.stringify(Legacy.normalizeConfig(c)));
    const current = E.simulate(c), previous = Legacy.simulate(c);
    assert.equal(JSON.stringify(current), JSON.stringify(previous));
    for (const t of [0, 40, 70, previous.metrics.observationEnd]) assert.equal(JSON.stringify(E.snapshot(current, t)), JSON.stringify(Legacy.snapshot(previous, t)));
  }
});
