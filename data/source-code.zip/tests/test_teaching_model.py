import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'learning'))
from teaching_model import simulate


class TeachingModelTests(unittest.TestCase):
    def test_three_students_one_window_by_hand(self):
        people = [dict(id=i, ready=0, arrival=0, service=[10], meal=0) for i in range(3)]
        result = simulate(people, windows=1, seats=3)
        self.assertEqual([p['wait'] for p in result], [0, 10, 20])
        self.assertEqual([p['finish'] for p in result], [10, 20, 30])

    def test_delayed_arrival_reduces_queue_but_not_whole_elapsed_time(self):
        a = [dict(id=i, ready=0, arrival=0, service=[10], meal=0) for i in range(3)]
        b = [{**p, 'arrival': i * 10} for i, p in enumerate(a)]
        first, second = simulate(a, 1, 3), simulate(b, 1, 3)
        self.assertEqual(sum(p['wait'] for p in first), 30)
        self.assertEqual(sum(p['wait'] for p in second), 0)
        self.assertEqual([p['whole'] for p in first], [p['whole'] for p in second])

    def test_seat_is_an_independent_bottleneck(self):
        people = [dict(id=i, ready=0, arrival=0, service=[10, 10], meal=100) for i in range(2)]
        result = simulate(people, 2, 1)
        self.assertEqual([p['wait'] for p in result], [0, 0])
        self.assertEqual([p['seat_wait'] for p in result], [0, 100])
        self.assertEqual([p['finish'] for p in result], [110, 210])

    def test_equal_times_choose_lowest_window_id(self):
        result = simulate([dict(id=7, ready=0, arrival=20, service=[10, 10], meal=0)], 2, 1)
        self.assertEqual(result[0]['window'], 0)

    def test_invalid_resource_and_duplicate_ids_rejected(self):
        person = dict(id=0, ready=0, arrival=0, service=[10], meal=5)
        with self.assertRaises(ValueError): simulate([person], 0, 1)
        with self.assertRaises(ValueError): simulate([person, person], 1, 1)
        with self.assertRaises(ValueError): simulate([{**person, 'service': [-1]}], 1, 1)


if __name__ == '__main__':
    unittest.main()
