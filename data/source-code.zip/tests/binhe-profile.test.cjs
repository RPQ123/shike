const test = require('node:test');
const assert = require('node:assert/strict');
const B = require('../dist/binhe-cohort.js');
const R = require('../dist/research.js');
const E = require('../dist/school-engine.js');
const P = require('../dist/planner.js');

test('2026 school-year demand uses the three corresponding annual admission plans exactly once', () => {
  const old = JSON.stringify(R.example());
  const c = B.create();
  assert.deepEqual(B.cohorts.map(g => [g.admissionYear, g.students]), [[2026,580],[2025,530],[2024,500]]);
  assert.deepEqual(c.grades.map(g => g.students), [580,530,500]);
  assert.equal(c.students, 1610);
  assert.equal(c.sourceProfile.observedSchoolData, false);
  assert.equal(c.strategy, 'fastest');
  assert.equal(c.serviceZones, null);
  assert.equal(JSON.stringify(R.example()), old);
  const batches = P.timetable(c);
  assert.equal(batches.length,33);
  for (const g of c.grades) assert.equal(batches.filter(b=>b.grade===g.id).reduce((a,b)=>a+b.students,0),g.students);
  assert.ok(batches.every(b=>b.students>0 && b.students<=50));
});

test('the admission-scale profile conserves every simulated student and supports all scheduling candidates', () => {
  const c=B.create(), r=E.simulateSchool(c);
  assert.equal(r.students.length,1610);
  assert.deepEqual(r.gradeMetrics.map(g=>g.count),[580,530,500]);
  assert.ok(r.students.every(s=>Number.isFinite(s.end)));
  assert.equal(P.candidates(c,{reallocate:false}).accepted.length,26);
  const changed=B.create();changed.grades[0].students=1;
  assert.equal(B.create().grades[0].students,580);
});
