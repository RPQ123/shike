const test = require('node:test'),
  assert = require('node:assert/strict');
const R = require('../dist/research.js'),
  P = require('../dist/planner.js');
const S = require('../tools/run-innovation-study.cjs');
test('saved research choices, physical ledger and every causal history remain reproducible',()=>{
 const a=require('../tools/audit-innovation-study.cjs').audit(false);
 assert.equal(a.passed,true);assert.equal(a.uniqueExecutions,14370);assert.equal(a.replayed,0);
});
test('declared study has fourteen distinct contexts and daily menu changes preserve populations', () => {
  const cs = S.contexts(R.example());
  assert.equal(cs.length, 14);
  assert.equal(new Set(cs.map((c) => c.id)).size, 14);
  assert.equal(
    cs.find((c) => c.id === 'seats-60').config.serviceZones.reduce((s, z) => s + z.seats, 0),
    60
  );
  const menu = cs.find((c) => c.id === 'menu-shift');
  const days = S.dayInputs(P.makePlan(menu.config, { order: [1, 2, 0], slot: 0.75, aWindows: 4 }), menu, 3);
  assert.deepEqual(
    days.map((c) => c.gradeZoneWeights[0][0]),
    [0.75, 0.55, 0.9]
  );
  assert.ok(days.every((c) => JSON.stringify(c.grades.map((g) => g.students)) === '[120,120,120]'));
  assert.ok(days.every((c) => c.windowZones.filter((z) => z === 0).length === 4));
});
test('component ablations preserve input resource counts and remove only their declared component', () => {
  const c = R.example(),
    joint = P.makePlan(c, { order: [1, 2, 0], slot: 0.75, aWindows: 4 });
  const rows = S.policyPlans(c, joint, { gap: 2, aWindows: 3 });
  const find = (id) => rows.find((x) => x.id === id).plan;
  assert.deepEqual(find('class-only').config.windowZones, c.windowZones);
  assert.deepEqual(
    find('class-only').config.grades.map((g) => g.releaseTime),
    joint.config.grades.map((g) => g.releaseTime)
  );
  assert.deepEqual(find('window-only').config.grades, c.grades);
  assert.deepEqual(find('window-only').config.windowZones, joint.config.windowZones);
  assert.equal(find('joint-fixed').config.windows, c.windows);
  assert.equal(find('joint-fixed').config.seats, c.seats);
});
test('hindsight search uses a known future only as a labelled benchmark and finds a hand-checkable cycle', () => {
  const c = R.example(),
    joint = P.makePlan(c, { order: [0, 1, 2], slot: 0.5, aWindows: 4 });
  const oracle = S.hindsight(joint, [3, 4, 5], [], (cfg) => {
    const order = [0, 1, 2].sort((a, b) => cfg.grades[a].releaseTime - cfg.grades[b].releaseTime);
    const values = [0, 0, 0];
    order.forEach((id, p) => (values[id] = 20 + 10 * p));
    return {
      meanTotal: 30,
      meanWait: 2,
      seatWait: 0,
      onTime: 1,
      peakQueue: 90,
      worstGrade: 40,
      ...Object.fromEntries(values.map((v, id) => ['grade' + id + 'Total', v]))
    };
  });
  assert.equal(oracle.kind, 'future-known-benchmark');
  assert.equal(oracle.summary.periodWorstGrade, 30);
  assert.equal(oracle.summary.periodGradeGap, 0);
  assert.equal(oracle.sequences, 216);
  assert.ok(oracle.days.every((d) => d.decisionReason.includes('未来')));
});
