const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../dist/school-engine.js');
const R = require('../dist/research.js');
const P = require('../dist/planner.js');
const Common = require('../dist/common-windows.js');

test('common-window migration removes food and grade restrictions without mutating imported evidence', () => {
  const old = R.example(), saved = JSON.stringify(old);
  old.allocation = 'dedicated';
  const c = Common.normalize(old);
  assert.equal(c.serviceZones, null);
  assert.equal(c.windowZones, null);
  assert.equal(c.gradeZoneWeights, null);
  assert.equal(c.seatPoolByZone, null);
  assert.equal(c.allocation, 'shared');
  assert.equal(c.strategy, 'fastest');
  assert.deepEqual(c.grades, R.example().grades);
  assert.deepEqual(c.windowMeans, old.windowMeans);
  assert.equal(c.seats, old.seats);
  assert.equal(JSON.stringify(R.example()), saved);
  assert.equal(old.allocation, 'dedicated');
  assert.deepEqual(Common.normalize(c), c);
});

test('every arriving student can use an idle faster window regardless of old food choice', () => {
  const c = Common.normalize(R.example());
  c.windows = 2; c.windowMeans = [600, 10]; c.windowOwners = [0, 2];
  c.serviceCV = 0; c.serviceStart = 0;
  c.grades.forEach((g, id) => Object.assign(g, { students: id === 0 ? 6 : 0, classes: 1, assemblyMax: 0, walkMin: 0, walkMax: 0 }));
  c.students = 6;
  const r = E.simulateSchool(c);
  assert.deepEqual(r.students.map(s => s.window), [1, 1, 1, 1, 1, 1]);
  const arrivals = r.students.slice().sort((a,b) => a.arrival-b.arrival || a.id-b.id);
  assert.equal(arrivals[0].window, 1);
  assert.equal(arrivals[0].wait, 0);
  assert.ok(arrivals.every(s => s.end < s.arrival + 10));
  assert.equal(r.effectiveServiceZones.length, 1);
  assert.equal(r.students.filter(s => s.zone === 0).length, 6);
});

test('equal speed common counters remain balanced for a simultaneous large arrival', () => {
  const c = Common.normalize(R.example());
  c.windows = 16; c.windowMeans = Array(16).fill(20); c.windowOwners = Array(16).fill(0);
  c.serviceCV = 0; c.serviceStart = 31;
  c.grades.forEach(g => Object.assign(g, { students: 800, classes: 1, readyTime: 30, releaseTime: 30, assemblyMax: 0, walkMin: 0, walkMax: 0 }));
  c.students = 2400;
  const r = E.simulateSchool(c), s = E.snapshot(r, 30.5);
  const queues = s.windows.map(w => w.waiting);
  assert.ok(Math.max(...queues) - Math.min(...queues) <= 1);
  assert.equal(s.waiting, 2400);
  assert.equal(queues.reduce((a,b) => a+b, 0), s.waiting);
  assert.equal(new Set(s.windows.flatMap(w => w.queueIds)).size, s.waiting);
});

test('planner and period inputs retain common routing and do not reintroduce food partitions', () => {
  const c = Common.normalize(R.example());
  const plans = P.candidates(c);
  assert.ok(plans.accepted.length > 1);
  for (const p of plans.accepted) {
    assert.equal(p.config.serviceZones, null);
    assert.equal(p.config.strategy, 'fastest');
    assert.equal(p.aWindows, null);
    assert.doesNotMatch(p.label, /A\/B/);
  }
});
