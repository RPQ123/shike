'use strict';
const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/school-engine.js'),P=require('../dist/binhe-profile.js'),S=require('../dist/scene-state.js');
const base=P.createConfig();
const config={...base,students:180,grades:base.grades.map((g,i)=>({...g,students:60,classes:3,classSizes:[25,20,15],releaseTime:30+i,classInterval:.5})),windows:4,windowMeans:[10,10,10,10],windowOwners:[0,1,2,0],windowZones:[0,0,0,1],seats:32,serviceZones:[{id:0,name:'餐品甲',seats:24,walkExtra:0,returnExtra:0},{id:1,name:'餐品乙',seats:8,walkExtra:0,returnExtra:1}],gradeZoneWeights:[[.5,.5],[.5,.5],[.5,.5]],seatPoolByZone:[0,0],seatWaitingCapacity:0,mealMean:6,mealCV:0};
const result=E.simulate(config),cross=result.students.find(s=>s.seatZone!==s.zone),waiter=result.students.find(s=>s.seatWait>1);
function verify(r,t){
  const f=S.frame(r,t),snap=E.snapshot(r,t);
  for(const k of ['waiting','inService','seatWaiting','dining','returning','returned','notArrived'])assert.equal(f.counts[k],snap[k],k);
  assert.deepEqual(f.physicalSeatStates,snap.physicalSeatStates);assert.deepEqual(f.seatPoolStates,snap.seatPoolStates);
  assert.equal(f.physicalSeatStates.reduce((n,z)=>n+z.dining,0),f.counts.dining);
  assert.equal(f.seatPoolStates.reduce((n,z)=>n+z.seatWaiting,0),f.counts.seatWaiting);
  for(const p of f.visibleDiningPeople.filter(p=>p.state==='dining')){
    const record=r.students[p.id],physical=f.layout.displaySeats[p.displaySeatId];
    assert.equal(p.zone,record.zone);assert.equal(p.seatZone,record.seatZone);assert.equal(physical.zone,record.seatZone);
    assert.equal(p.seatId,record.seatId);assert.deepEqual(p.position,physical.position);
  }
  const visible=[...f.visiblePeople,...f.visibleDiningPeople,...f.departures];assert.equal(new Set(visible.map(p=>p.id)).size,visible.length);
  for(const p of visible)assert.ok(p.position.every(Number.isFinite));
  return f;
}
test('shared seating layout retains separate food windows and explicit physical seat groups',()=>{
  const f=verify(result,40);assert.equal(f.layout.sharedSeating,true);assert.deepEqual(f.layout.seatPools,[{id:0,zoneIds:[0,1],seats:32}]);
  assert.equal(f.layout.zones.length,2);assert.equal(f.queueGroups.length,2);
  for(const q of f.queueGroups)for(const id of q.queueIds)assert.equal(result.students[id].zone,q.zone);
  assert.ok(f.sampling.description.includes('连通就座空间'));
});
test('a cross-origin diner is drawn in the actual physical seat rather than the food zone',()=>{
  assert.ok(cross,'fixture must exercise cross-origin seating');
  const f=verify(result,(cross.seatStart+cross.mealEnd)/2),person=f.diningPeople.find(p=>p.id===cross.id);
  assert.ok(person);assert.notEqual(person.zone,person.seatZone);assert.equal(person.seatZone,cross.seatZone);
  assert.equal(person.seatPool,0);
});
test('waiting avatars hide future physical seats and preserve group FCFS identity',()=>{
  assert.ok(waiter);const f=verify(result,(waiter.end+waiter.seatStart)/2),waiting=f.diningPeople.filter(p=>p.state==='seat-waiting');
  assert.deepEqual(waiting.map(p=>p.id),f.seatPoolStates[0].seatWaitingIds);
  for(const [i,p] of waiting.entries()){assert.equal(p.seatId,null);assert.equal(p.seatZone,null);assert.equal(p.seatPool,0);assert.equal(p.queueIndex,i);assert.equal(p.queueId,'seat-pool-0');}
});
test('shared-seat return paths start from the actual seat zone at the numerical meal boundary',()=>{
  assert.ok(cross);const f=verify(result,cross.mealEnd),p=f.departures.find(p=>p.id===cross.id);assert.ok(p);
  assert.equal(p.seatZone,cross.seatZone);assert.equal(p.visualProgress,0);assert.equal(p.seatId,cross.seatId);
  const seats=f.layout.displaySeats.filter(s=>s.zone===cross.seatZone);
  assert.ok(seats.some(s=>s.position[0]===p.route[0][0]&&s.position[2]===p.route[0][2]));
  assert.equal(S.frame(result,cross.returnTime).departures.some(p=>p.id===cross.id),false);
});
test('cross-origin seats remain fixed while seeking and do not mutate numerical records',()=>{
  const before=JSON.stringify(result),t=(cross.seatStart+cross.mealEnd)/2,a=verify(result,t);
  verify(result,result.metrics.observationEnd);verify(result,0);assert.deepEqual(verify(result,t),a);assert.equal(JSON.stringify(result),before);
});
test('capacity diagnostics do not invent physical blocking or reduce scene people counts',()=>{
  const without=E.simulate({...config,seatWaitingCapacity:null}),t=(waiter.end+waiter.seatStart)/2;
  const a=verify(result,t),b=verify(without,t);assert.deepEqual(a.counts,b.counts);assert.deepEqual(a.diningPeople,b.diningPeople);
  assert.ok(result.metrics.seatBufferExceeded);assert.ok(without.validityWarnings.some(w=>w.code==='SEAT_BUFFER_UNASSESSED'));
});
test('shared-seat sampling keeps actual occupancy counts with bounded avatars under heavy load',()=>{
  const c={...base,seatPoolByZone:[0,0],seats:160,serviceZones:base.serviceZones.map(z=>({...z,seats:z.id?40:120}))},r=E.simulate(c),f=verify(r,70);
  assert.ok(f.counts.seatWaiting>48);assert.ok(f.visibleDiningPeople.filter(p=>p.state==='seat-waiting').length<=48);
  assert.ok(f.visibleDiningPeople.filter(p=>p.state==='dining').length<=72);assert.equal(f.layout.seatPools[0].seats,160);
});
test('multiple disjoint seat pools keep their own waiting identities and physical capacities',()=>{
  const r=E.simulate({...config,seatPoolByZone:[0,1]}),f=verify(r,45);assert.equal(f.layout.sharedSeating,false);
  for(const p of f.diningPeople.filter(p=>p.state==='seat-waiting')){assert.equal(p.seatPool,p.zone);assert.equal(p.queueId,'seat-pool-'+p.zone);}
  for(const p of f.visibleDiningPeople.filter(p=>p.state==='dining'))assert.equal(p.seatZone,p.zone);
});
