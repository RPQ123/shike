const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../dist/school-engine.js');
const R = require('../dist/research.js');
const Common = require('../dist/common-windows.js');
const Scene = require('../dist/scene-state.js');

test('common hall has opposing counter banks, central seats and two end entrances', () => {
  for (const windows of [2, 3, 6, 15, 16]) {
    const c = Common.normalize(R.example()); c.windows = windows; c.windowMeans = Array(windows).fill(20); c.windowOwners = Array(windows).fill(0);
    const r = E.simulate(c), l = Scene.createLayoutForResult(r);
    assert.equal(l.twoSided, true);
    const left = l.windows.filter(w => w.x < 0), right = l.windows.filter(w => w.x > 0);
    assert.equal(left.length, Math.ceil(windows / 2)); assert.equal(right.length, Math.floor(windows / 2));
    assert.equal(l.entries.length, 2); assert.ok(l.entries[0][2] < -6 && l.entries[1][2] > 17);
    assert.ok(l.tables.every(t => Math.abs(t.position[0]) <= 5));
    for (const w of l.windows) assert.ok(Math.abs(w.servicePosition[0]) < Math.abs(w.x));
    const f = Scene.frame(r, r.metrics.peakQueueTime, l);
    assert.equal(f.queueGroups.reduce((n,q) => n+q.count,0), f.counts.waiting);
    const heads = new Set();
    for (const q of f.queueGroups) {
      assert.equal(q.window, l.windows[q.window].id);
      for (const p of q.slots) { assert.ok(Math.abs(p[0]) > 11); assert.ok(p[2] > l.bounds.minZ && p[2] < l.bounds.maxZ); }
      heads.add(q.slots[0].join(','));
    }
    assert.equal(heads.size, windows);
    const waiting = f.people.filter(p => p.state === 'waiting');
    assert.ok(waiting.some(p => p.arrivalPath[0][2] === l.entries[0][2]));
    assert.ok(waiting.some(p => p.arrivalPath[0][2] === l.entries[1][2]));
    const later = Scene.frame(r, 60, l);
    for (const p of later.departures) assert.ok(l.entries.some(e => e.every((v,i) => v === p.route.at(-1)[i])));
    assert.equal(E.snapshot(r, f.time).waiting, f.counts.waiting);
  }
});
