'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const E = require('../dist/school-engine.js');

const clone = value => JSON.parse(JSON.stringify(value));
const sum = (values, key) => values.reduce((total, value) => total + (typeof key === 'function' ? key(value) : value[key]), 0);
const close = (a, b, label = '') => assert.ok(Math.abs(a - b) <= 1e-8 * Math.max(1, Math.abs(a), Math.abs(b)), `${label}: ${a} vs ${b}`);
const byArrival = (a, b) => a.arrival - b.arrival || a.id - b.id;
const byPickup = (a, b) => a.end - b.end || a.id - b.id;
function config(overrides = {}, counts = [37, 35, 33]) {
  const c = {
    ...clone(E.DEFAULT_SCHOOL_CONFIG),
    windows: 6, windowOwners: [0, 1, 2, 0, 1, 2], windowZones: [0, 0, 0, 1, 1, 1],
    serviceZones: [{ id: 0, name: '一层服务区', seats: 8, walkExtra: 0, returnExtra: 0 }, { id: 1, name: '二层服务区', seats: 9, walkExtra: 1.5, returnExtra: 2 }],
    gradeZoneWeights: [[1, 2], [2, 1], [1, 1]],
    grades: clone(E.DEFAULT_SCHOOL_CONFIG.grades).map((g, id) => ({ ...g, students: counts[id], classes: Math.min(3, counts[id]) })),
    ...overrides
  };
  c.students = sum(c.grades, 'students');
  if (c.serviceZones && !Object.hasOwn(overrides, 'seats')) c.seats = sum(c.serviceZones, 'seats');
  return E.normalizeSchoolConfig(c);
}
function early(overrides = {}, counts = [17, 8, 5]) {
  return config({
    serviceStart: 10, serviceEnd: 110,
    serviceZones: [{ id: 0, name: '甲区', seats: 8, walkExtra: 0, returnExtra: 0 }, { id: 1, name: '乙区', seats: 9, walkExtra: 0, returnExtra: 0 }],
    grades: clone(E.DEFAULT_SCHOOL_CONFIG.grades).map((g, id) => ({ ...g, students: counts[id], classes: counts[id] ? 1 : 0, readyTime: 0, releaseTime: 0, classInterval: 0, assemblyMax: 0, walkMin: 0, walkMax: 0 })),
    ...overrides
  }, counts);
}
function intervalSweep(records, startKey, endKey) {
  const events = records.flatMap(s => [{ time: s[startKey], delta: 1 }, { time: s[endKey], delta: -1 }]).sort((a, b) => a.time - b.time);
  let count = 0, peak = 0, area = 0, last = 0;
  for (let i = 0; i < events.length;) {
    const time = events[i].time;
    area += count * (time - last);
    while (i < events.length && events[i].time === time) count += events[i++].delta;
    assert.ok(count >= 0, 'negative interval occupancy');
    peak = Math.max(peak, count); last = time;
  }
  assert.equal(count, 0);
  return { area, peak };
}
function verifyZones(r) {
  assert.equal(sum(r.zoneMetrics, 'count'), r.students.length);
  assert.equal(sum(r.zoneMetrics, 'windowCount'), r.config.windows);
  assert.equal(sum(r.zoneMetrics, 'seats'), r.config.seats);
  assert.equal(sum(r.zoneMetrics, 'lateCount'), r.metrics.lateCount);
  for (const key of ['queueIntegral', 'totalWait', 'totalService', 'seatQueueIntegral', 'totalSeatWait', 'seatOccupancyIntegral', 'totalMealMinutes', 'configuredCapacityPerMinute']) close(sum(r.zoneMetrics, key), r.metrics[key], 'zone sum ' + key);
  let offset = 0;
  for (const z of r.zoneMetrics) {
    const people = r.students.filter(s => s.zone === z.id), windows = r.windows.filter(w => w.zone === z.id);
    assert.equal(people.length, z.count); assert.equal(windows.length, z.windowCount);
    assert.deepEqual(z.windowIds, windows.map(w => w.id));
    close(z.configuredCapacityPerMinute, sum(windows, w => 60 / r.effectiveWindowMeans[w.id]));
    close(z.meanWait, people.length ? sum(people, 'wait') / people.length : 0);
    close(z.meanSeatWait, people.length ? sum(people, 'seatWait') / people.length : 0);
    close(z.onTimeRate, people.length ? people.filter(s => !s.late).length / people.length : 0);
    const queue = intervalSweep(people, 'arrival', 'start');
    close(queue.area, z.queueIntegral); close(queue.area, z.independentQueueIntegral); assert.equal(queue.peak, z.peakQueue);
    for (const s of people) {
      assert.equal(r.config.windowZones[s.window], s.zone);
      if (r.config.allocation === 'dedicated') assert.equal(r.config.windowOwners[s.window], s.grade);
      assert.ok(s.arrival >= s.release + s.zoneWalk);
      assert.ok(s.start >= Math.max(s.arrival, r.config.serviceStart));
      close(s.arrival, s.release + s.assembly + s.walk + s.arrivalJitter + s.zoneWalk);
      if (r.config.diningEnabled) {
        assert.equal(s.seatZone, s.zone);
        assert.ok(s.seatId >= offset && s.seatId < offset + z.seats);
        close(s.returnTime, s.mealEnd + r.config.returnMinutes + s.zoneReturn);
      }
    }
    if (r.config.diningEnabled) {
      const waiting = intervalSweep(people, 'end', 'seatStart'), occupancy = intervalSweep(people, 'seatStart', 'mealEnd');
      close(waiting.area, z.seatQueueIntegral); close(occupancy.area, z.seatOccupancyIntegral);
      assert.equal(waiting.peak, z.peakSeatWaiting); assert.equal(occupancy.peak, z.peakSeatsOccupied);
      assert.ok(occupancy.peak <= z.seats);
      const order = people.slice().sort(byPickup);
      for (let i = 1; i < order.length; i++) assert.ok(order[i].seatStart >= order[i - 1].seatStart, 'FCFS seat start within zone');
      for (let id = offset; id < offset + z.seats; id++) {
        const occupants = people.filter(s => s.seatId === id).sort((a, b) => a.seatStart - b.seatStart);
        for (let i = 1; i < occupants.length; i++) assert.ok(occupants[i].seatStart >= occupants[i - 1].mealEnd, 'physical seat reused before release');
      }
    }
    for (const [key, value] of Object.entries(z)) if (typeof value === 'number') assert.ok(Number.isFinite(value), 'finite zone metric ' + key);
    offset += z.seats;
  }
  const final = E.snapshot(r, r.metrics.observationEnd);
  assert.equal(final.endpointCompleted, r.students.length);
  assert.equal(sum(final.zoneStates, 'endpointCompleted'), r.students.length);
  assert.ok(final.zoneStates.every(z => z.waiting + z.inService + z.seatWaiting + z.dining + z.returning === 0));
}

test('optional zones derive total seats, window mapping and canonical grade probabilities', () => {
  assert.equal(E.VERSION, '1.6.0');
  assert.equal(E.DEFAULT_SCHOOL_CONFIG.serviceZones, null);
  assert.equal(E.DEFAULT_SCHOOL_CONFIG.windowZones, null);
  assert.equal(E.DEFAULT_SCHOOL_CONFIG.gradeZoneWeights, null);
  assert.equal(E.DEFAULT_SCHOOL_CONFIG.returnDestination, 'classroom');
  assert.equal(E.DEFAULT_SCHOOL_CONFIG.sourceProfile, null);
  const c = E.normalizeSchoolConfig({ mode: 'school', windows: 6, serviceZones: [{ seats: 10 }, { seats: 20 }] });
  assert.equal(c.seats, 30);
  assert.deepEqual(c.windowZones, [0, 0, 0, 1, 1, 1]);
  assert.deepEqual(c.gradeZoneWeights, [[0.5, 0.5], [0.5, 0.5], [0.5, 0.5]]);
  assert.deepEqual(c.serviceZones[0], { id: 0, name: '服务区 1', seats: 10, walkExtra: 0, returnExtra: 0 });
  assert.deepEqual(E.normalizeSchoolConfig(clone(c)), c);
});

test('zone schema rejects invalid counts, identities, capacities, times and mappings', () => {
  const c = config();
  const bad = [
    { ...c, serviceZones: [] }, { ...c, serviceZones: [0, 1, 2, 3, 4].map(id => ({ id, seats: 1 })) },
    { ...c, serviceZones: Array(2) }, { ...c, gradeZoneWeights: Array(3) },
    { ...c, gradeZoneWeights: [Array(2), [1, 1], [1, 1]] },
    { ...c, serviceZones: c.serviceZones.map((z, id) => ({ ...z, id: id + 1 })) },
    { ...c, serviceZones: c.serviceZones.map(z => ({ ...z, unexpected: true })) },
    { ...c, serviceZones: c.serviceZones.map(z => ({ ...z, name: ' ' })) },
    { ...c, serviceZones: c.serviceZones.map(z => ({ ...z, seats: 0 })) },
    { ...c, serviceZones: c.serviceZones.map(z => ({ ...z, seats: 1.5 })) },
    { ...c, serviceZones: c.serviceZones.map(z => ({ ...z, walkExtra: -1 })) },
    { ...c, serviceZones: c.serviceZones.map(z => ({ ...z, returnExtra: 15.1 })) },
    { ...c, serviceZones: c.serviceZones.map(z => ({ ...z, walkExtra: NaN })) },
    { ...c, seats: c.seats + 1 }, { ...c, windowZones: [0] },
    { ...c, windowZones: c.windowZones.map(() => 2) }, { ...c, windowZones: c.windowZones.map(() => 0.5) },
    { ...c, serviceZones: null }, { ...c, serviceZones: null, windowZones: null },
    { ...c, gradeZoneWeights: [[1, 1]] }, { ...c, gradeZoneWeights: [[1], [1], [1]] },
    { ...c, gradeZoneWeights: [[-1, 2], [1, 1], [1, 1]] },
    { ...c, gradeZoneWeights: [[0, 0], [1, 1], [1, 1]] },
    { ...c, gradeZoneWeights: [[Infinity, 1], [1, 1], [1, 1]] },
    { ...c, returnDestination: 'unknown' }
  ];
  for (const input of bad) assert.throws(() => E.normalizeSchoolConfig(input));
  const overCapacity = { mode: 'school', serviceZones: [{ seats: 3000 }, { seats: 3000 }] };
  assert.throws(() => E.normalizeSchoolConfig(overCapacity), /座位总数/);
});

test('every positive-demand zone needs a compatible window, dedicated additionally checks owner in that zone', () => {
  const c = config();
  assert.throws(() => E.normalizeSchoolConfig({ ...c, windowZones: c.windowZones.map(() => 0) }), /区内窗口/);
  assert.throws(() => E.normalizeSchoolConfig({ ...c, allocation: 'dedicated', windowOwners: [0, 0, 0, 1, 1, 2] }), /本年级所属/);
  assert.throws(() => E.normalizeSchoolConfig({ ...c, windowZones: c.windowZones.map(() => 0), gradeZoneWeights: [[Number.MAX_VALUE, Number.MIN_VALUE], [1, 0], [1, 0]] }), /区内窗口/);
  const limited = config({ windowZones: [0, 0, 0, 0, 0, 0], gradeZoneWeights: [[1, 0], [1, 0], [1, 0]] });
  verifyZones(E.simulate(limited));
});

test('finite extreme weights normalize without overflow and remain unchanged on repeated JSON imports', () => {
  for (const weights of [[1, 2], [Number.MAX_VALUE, Number.MAX_VALUE], [Number.MIN_VALUE, Number.MIN_VALUE], [Number.MAX_VALUE, Number.MIN_VALUE], [0.1, 0.7]]) {
    const c = config({ gradeZoneWeights: [weights, weights, weights] });
    for (const row of c.gradeZoneWeights) { assert.equal(sum(row, x => x), 1); assert.ok(row.every(x => x >= 0 && Number.isFinite(x))); }
    let reimported = c;
    for (let i = 0; i < 10; i++) reimported = E.normalizeSchoolConfig(clone(reimported));
    assert.deepEqual(reimported, c);
  }
});

test('source profile is cloned, strictly validated and cannot claim observed school calibration', () => {
  const profile = { id: 'binhe-plan-2026', title: '2026秋季三届招生计划规模推演', asOf: '2026-10-17', status: 'research-assumptions', observedSchoolData: false };
  const c = config({ sourceProfile: profile });
  assert.deepEqual(c.sourceProfile, profile); assert.notEqual(c.sourceProfile, profile);
  assert.deepEqual(E.normalizeSchoolConfig(clone(c)), c);
  for (const bad of [{ ...profile, unknown: 1 }, { ...profile, observedSchoolData: true }, { ...profile, observedSchoolData: 0 }, { ...profile, status: 'calibrated' }, { ...profile, id: '' }, { ...profile, title: 'x'.repeat(161) }, { ...profile, asOf: '2026-02-30' }, { ...profile, asOf: '2026-2-01' }, {}]) assert.throws(() => config({ sourceProfile: bad }));
  assert.equal(config({ sourceProfile: { ...profile, status: 'modified', asOf: '2024-02-29' } }).sourceProfile.status, 'modified');
  const a = E.simulate(c), b = E.simulate({ ...c, sourceProfile: null });
  for (const key of ['students', 'windows', 'metrics', 'zoneMetrics', 'timeline', 'diningTimeline']) assert.deepEqual(a[key], b[key]);
});

for (const allocation of ['shared', 'dedicated', 'overflow']) for (const strategy of ['pooled', 'shortest', 'workload', 'random']) {
  test(`zones ${allocation}/${strategy}: eligible service, independent integrals and physical-seat conservation`, () => {
    const r = E.simulate(config({ allocation, strategy, seed: 981, serviceCV: 0.8, mealCV: 0.6, windowMeans: [15, 90, 25, 55, 40, 70] }));
    verifyZones(r);
  });
}

test('shared and dedicated zone pools match an independent earliest-free-window scheduler', () => {
  for (const allocation of ['shared', 'dedicated']) for (const seed of [0, 87, 4294967295]) {
    const c = config({ allocation, seed, serviceStart: 35, windowMeans: [15, 90, 25, 55, 40, 70] });
    const r = E.simulate(c), available = Array(c.windows).fill(c.serviceStart);
    for (const s of r.students.slice().sort(byArrival)) {
      const eligible = available.map((time, id) => ({ time, id })).filter(w => c.windowZones[w.id] === s.zone && (allocation === 'shared' || c.windowOwners[w.id] === s.grade));
      const next = eligible.find(w => w.time <= s.arrival) || eligible.sort((a, b) => a.time - b.time || a.id - b.id)[0];
      const start = Math.max(s.arrival, next.time);
      assert.equal(s.window, next.id); close(s.start, start);
      available[next.id] = start + r.effectiveWindowMeans[next.id] / 60 * s.serviceFactor;
      close(s.end, available[next.id]);
    }
  }
});

test('zone FCFS is maintained per shared pool or per grade across overlapping releases', () => {
  for (const allocation of ['shared', 'dedicated', 'overflow']) {
    const r = E.simulate(config({ allocation, serviceStart: 40 }, [81, 72, 63]));
    for (const z of r.zoneMetrics) {
      const groups = allocation === 'shared' ? [r.students.filter(s => s.zone === z.id)] : [0, 1, 2].map(g => r.students.filter(s => s.zone === z.id && s.grade === g));
      for (const people of groups) {
        const order = people.slice().sort(byArrival);
        for (let i = 1; i < order.length; i++) assert.ok(order[i].start >= order[i - 1].start);
      }
    }
  }
});

test('queued students cannot take an idle fast window in another zone', () => {
  const c = early({ windows: 2, windowOwners: [0, 0], windowZones: [0, 1], windowMeans: [60, 1], serviceCV: 0, diningEnabled: false, serviceEnd: 11, gradeZoneWeights: [[1, 0], [0, 0], [0, 0]] }, [4, 0, 0]);
  const r = E.simulate(c); verifyZones(r);
  assert.deepEqual(r.students.map(s => s.start).sort((a, b) => a - b), [10, 11, 12, 13]);
  assert.equal(r.windows[1].served, 0); assert.equal(r.zoneMetrics[1].configuredCapacityPerMinute, 60);
  assert.equal(r.zoneMetrics[0].overtimeMinutes, 3); assert.equal(r.zoneMetrics[1].overtimeMinutes, 0);
  assert.equal(r.metrics.overtimeMinutes, 3); assert.equal(r.metrics.completedByServiceEnd, 1);
  const at = E.snapshot(r, 10.5);
  assert.equal(at.zoneStates[0].waiting, 3); assert.equal(at.windows[1].serving, 0);
});

test('seat queues stay in their own zone even while the other zone has 100 unused seats', () => {
  const c = early({ windows: 2, windowOwners: [0, 1], windowZones: [0, 1], windowMeans: [1, 1], serviceCV: 0, mealMean: 10, mealCV: 0,
    serviceZones: [{ id: 0, name: '小区', seats: 1, walkExtra: 0, returnExtra: 0 }, { id: 1, name: '大区', seats: 100, walkExtra: 0, returnExtra: 0 }], gradeZoneWeights: [[1, 0], [0, 1], [0, 0]] }, [6, 1, 0]);
  const r = E.simulate(c); verifyZones(r);
  assert.ok(r.zoneMetrics[0].meanSeatWait > 20); assert.equal(r.zoneMetrics[1].meanSeatWait, 0);
  assert.ok(r.students.filter(s => s.zone === 0).every(s => s.seatId === 0));
  assert.equal(r.students.find(s => s.zone === 1).seatId, 1);
  const snap = E.snapshot(r, 22);
  assert.ok(snap.zoneStates[0].seatWaiting > 0); assert.equal(snap.zoneStates[0].seatsOccupied, 1);
  assert.equal(snap.zoneStates[1].seatsOccupied, 0); assert.equal(snap.zoneStates[1].seats, 100);
});

test('zone seat identities and FCFS schedules match a separate linear-scan allocator', () => {
  const r = E.simulate(config({ mealCV: 1, serviceCV: 1, seed: 104 }, [80, 71, 62]));
  let offset = 0;
  const available = r.config.serviceZones.map(z => {
    const seats = Array.from({ length: z.seats }, (_, id) => ({ id: offset + id, free: 0 })); offset += z.seats; return seats;
  });
  for (const s of r.students.slice().sort(byPickup)) {
    const seat = available[s.zone].slice().sort((a, b) => a.free - b.free || a.id - b.id)[0];
    const start = Math.max(seat.free, s.end);
    assert.equal(s.seatId, seat.id); close(s.seatStart, start);
    seat.free = start + r.config.mealMean * s.mealFactor;
    close(s.mealEnd, seat.free); close(s.returnTime, seat.free + r.config.returnMinutes + r.config.serviceZones[s.zone].returnExtra);
  }
});

test('overflow first serves each zone owner, then borrows only within that same zone', () => {
  const c = early({ allocation: 'overflow', gradeZoneWeights: [[1, 1], [1, 1], [1, 1]], windowMeans: [60, 60, 60, 60, 60, 60], serviceCV: 0, seed: 712 }, [51, 41, 21]);
  const r = E.simulate(c), first = r.students.filter(s => s.start === c.serviceStart);
  assert.equal(first.length, 6); assert.ok(first.every(s => c.windowOwners[s.window] === s.grade));
  const borrowed = r.students.filter(s => c.windowOwners[s.window] !== s.grade);
  assert.ok(borrowed.length > 0);
  for (const s of borrowed) {
    assert.equal(c.windowZones[s.window], s.zone);
    assert.equal(r.students.filter(other => other.zone === s.zone && other.grade === c.windowOwners[s.window] && other.arrival <= s.start && other.start > s.start).length, 0, 'borrowed while own-grade queue was waiting in this zone');
  }
  const otherStrategy = E.simulate({ ...c, strategy: 'random' });
  assert.deepEqual(r.students, otherStrategy.students); assert.deepEqual(r.metrics, otherStrategy.metrics);
});

test('overflow can serve an ownerless grade locally without following its owner to another zone', () => {
  const c = early({ allocation: 'overflow', windows: 2, windowOwners: [0, 2], windowZones: [0, 1], gradeZoneWeights: [[0, 0], [0, 0], [1, 0]] }, [0, 0, 5]);
  const r = E.simulate(c); verifyZones(r);
  assert.ok(r.students.every(s => s.window === 0 && s.zone === 0)); assert.equal(r.windows[1].served, 0);
  assert.throws(() => E.normalizeSchoolConfig({ ...c, allocation: 'dedicated' }), /本年级所属/);
});

test('independent routing inside each zone cannot read unobserved personal service requirements', () => {
  for (const strategy of ['workload', 'shortest', 'random']) {
    const c = early({ strategy, serviceCV: 0, windowMeans: [15, 45, 90, 20, 50, 110] }, [40, 35, 30]);
    const a = E.simulate(c), b = E.simulate({ ...c, serviceCV: 1 });
    assert.ok(a.students.every(s => s.arrival < c.serviceStart));
    assert.deepEqual(a.students.map(s => [s.zone, s.arrival, s.window]), b.students.map(s => [s.zone, s.arrival, s.window]));
    assert.notDeepEqual(a.students.map(s => s.service), b.students.map(s => s.service));
  }
});

test('paired scenarios preserve each person zone draw and demand under releases, rules and resource changes', () => {
  const c = config({ seed: 273 });
  const a = E.simulate(E.makeSchoolBaseline(c));
  const changed = { ...E.makeSchoolGapConfig(c, 15), allocation: 'dedicated', strategy: 'random', windowOwners: [2, 0, 1, 2, 0, 1], windowMeans: [60, 15, 40, 80, 20, 30] };
  const b = E.simulate(changed);
  for (let id = 0; id < a.students.length; id++) {
    for (const key of ['randomId', 'classId', 'zone', 'zoneDraw', 'zoneWalk', 'zoneReturn', 'assembly', 'walk', 'arrivalJitter', 'routeDraw', 'serviceFactor', 'mealFactor']) assert.equal(a.students[id][key], b.students[id][key]);
    close(b.students[id].arrival - a.students[id].arrival, b.students[id].release - a.students[id].release);
  }
  assert.deepEqual(changed.gradeZoneWeights, c.gradeZoneWeights); assert.deepEqual(changed.serviceZones, c.serviceZones);
  const enlarged = E.simulate(config({ seed: 273 }, [74, 35, 33]));
  const sameGrade = enlarged.students.filter(s => s.grade === 1), oldGrade = a.students.filter(s => s.grade === 1);
  for (let i = 0; i < oldGrade.length; i++) for (const key of ['randomId', 'zone', 'zoneDraw', 'assembly', 'walk', 'arrivalJitter', 'serviceFactor', 'mealFactor']) assert.equal(oldGrade[i][key], sameGrade[i][key]);
});

test('zone probabilities use the documented independent draw and have reproducible cumulative boundaries', () => {
  const c = config({ gradeZoneWeights: [[1, 3], [3, 1], [1, 1]] }, [250, 250, 250]);
  const a = E.simulate(c), b = E.simulate({ ...c, gradeZoneWeights: [[3, 1], [1, 3], [1, 1]] });
  for (const s of a.students) {
    assert.ok(s.zoneDraw > 0 && s.zoneDraw < 1);
    assert.equal(s.zone, s.zoneDraw < c.gradeZoneWeights[s.grade][0] ? 0 : 1);
    assert.equal(s.zoneDraw, b.students[s.id].zoneDraw);
    assert.equal(s.serviceFactor, b.students[s.id].serviceFactor); assert.equal(s.mealFactor, b.students[s.id].mealFactor);
  }
  assert.ok(a.students.some(s => s.zone !== b.students[s.id].zone));
});

test('zone walk and return extras affect only their documented stages and destination changes only the label', () => {
  const c = early({ serviceStart: 0, windows: 2, windowOwners: [0, 1], windowZones: [0, 1], windowMeans: [60, 60], serviceCV: 0, mealMean: 5, mealCV: 0, returnMinutes: 2.5, gradeZoneWeights: [[1, 0], [0, 1], [0, 0]],
    serviceZones: [{ id: 0, name: '甲', seats: 1, walkExtra: 2.25, returnExtra: 1.5 }, { id: 1, name: '乙', seats: 1, walkExtra: 6.5, returnExtra: 3.25 }] }, [1, 1, 0]);
  const r = E.simulate(c), zero = E.simulate({ ...c, serviceZones: c.serviceZones.map(z => ({ ...z, walkExtra: 0, returnExtra: 0 })) });
  for (const s of r.students) {
    const previous = zero.students[s.id];
    close(s.arrival - previous.arrival, s.zoneWalk); close(s.end - previous.end, s.zoneWalk);
    close(s.mealEnd - previous.mealEnd, s.zoneWalk); close(s.returnTime - previous.returnTime, s.zoneWalk + s.zoneReturn);
  }
  for (const [destination, label] of [['classroom', '返回教室'], ['dormitory', '返回宿舍'], ['gate', '到达校门']]) {
    const alternate = E.simulate({ ...c, returnDestination: destination });
    assert.deepEqual(alternate.students, r.students); assert.equal(alternate.metrics.endpointLabel, label);
    assert.ok(alternate.zoneMetrics.every(z => z.endpointLabel === label));
    assert.equal(alternate.meta.deadlineMeaning, 'return-to-' + destination + '-complete');
  }
  const exact = clone(c); exact.grades[0].deadline = r.students[0].returnTime;
  assert.equal(E.simulate(exact).gradeMetrics[0].onTimeRate, 1);
  exact.grades[0].deadline -= 0.001;
  assert.equal(E.simulate(exact).gradeMetrics[0].lateCount, 1);
});

test('pickup-only mode retains zone window and walking constraints but has no seat or return stage', () => {
  const c = config({ diningEnabled: false, returnDestination: 'dormitory' });
  const a = E.simulate(c), b = E.simulate({ ...c, returnMinutes: 60, serviceZones: c.serviceZones.map(z => ({ ...z, returnExtra: 15 })) });
  verifyZones(a); assert.equal(a.metrics.endpointLabel, '取餐完成'); assert.equal(a.meta.deadlineMeaning, 'pickup-complete');
  for (const s of a.students) {
    assert.equal(s.endpointTime, s.end); assert.equal(s.endpointTime, b.students[s.id].endpointTime);
    for (const key of ['seatId', 'seatZone', 'seatStart', 'mealEnd', 'returnTime']) assert.equal(s[key], null);
    assert.equal(s.mealDuration, 0); assert.equal(s.seatWait, 0);
  }
  assert.ok(a.zoneMetrics.every(z => z.peakSeatsOccupied === 0 && z.seatQueueIntegral === 0 && z.seatOccupancyIntegral === 0));
});

test('zone snapshots partition all lifecycle counts, real waiting queues and current physical seats', () => {
  const r = E.simulate(early({ allocation: 'overflow' }, [41, 32, 23]));
  const times = [...new Set([0, 5, 10, ...r.students.flatMap(s => [s.arrival, s.start, s.end, s.seatStart, s.mealEnd, s.returnTime]), r.metrics.observationEnd])].sort((a, b) => a - b);
  for (const time of times) {
    const snap = E.snapshot(r, time);
    for (const key of ['arrived', 'waiting', 'inService', 'pickedUp', 'seatWaiting', 'dining', 'seatsOccupied', 'returning', 'returned', 'notArrived', 'onSite', 'endpointCompleted']) assert.equal(sum(snap.zoneStates, key), snap[key], key);
    assert.equal(sum(snap.zoneStates, 'centralQueue'), snap.centralQueue);
    assert.equal(sum(snap.zoneQueueIds, ids => ids.length), snap.waiting);
    assert.deepEqual(snap.zoneQueueIds.flat().sort((a, b) => a - b), snap.centralQueueIds.slice().sort((a, b) => a - b));
    for (const zone of snap.zoneStates) {
      assert.equal(zone.arrived, zone.waiting + zone.inService + zone.pickedUp);
      assert.equal(zone.pickedUp, zone.seatWaiting + zone.dining + zone.returning + zone.returned);
      assert.equal(zone.count, zone.arrived + zone.notArrived);
      assert.equal(zone.waiting, snap.zoneGradeQueueIds[zone.id].flat().length);
      assert.ok(zone.seatsOccupied <= zone.seats);
      for (const id of snap.zoneQueueIds[zone.id]) { const s = r.students[id]; assert.equal(s.zone, zone.id); assert.ok(s.arrival <= time && s.start > time); }
      for (const [grade, ids] of snap.zoneGradeQueueIds[zone.id].entries()) assert.ok(ids.every(id => r.students[id].grade === grade && r.students[id].zone === zone.id));
    }
    assert.equal(snap.dining, new Set(snap.diningIds.map(id => r.students[id].seatId)).size);
    assert.ok(snap.windows.every(w => w.queueIds.length === 0 && w.waiting === 0), 'pooled waiting students must not appear at their future assigned window');
  }
});

test('independent-window snapshots keep zone pools as aggregates and physical queues as actual assignments', () => {
  const r = E.simulate(early({ strategy: 'workload' }));
  const snap = E.snapshot(r, 5);
  assert.equal(snap.centralQueue, 0); assert.equal(snap.centralQueueIds.length, 0);
  assert.equal(snap.waiting, r.students.length); assert.equal(sum(snap.windows, w => w.queueIds.length), snap.waiting);
  for (const w of snap.windows) assert.ok(w.queueIds.every(id => r.students[id].window === w.id && r.students[id].zone === w.zone));
  assert.equal(sum(snap.zoneQueueIds, ids => ids.length), snap.waiting);
});

test('four zones and an entirely empty school preserve finite capacities and zero lifecycle occupancy', () => {
  const c = config({ windows: 1, windowOwners: [0], windowZones: [0], allocation: 'dedicated', serviceZones: [0, 1, 2, 3].map(id => ({ id, name: '区' + id, seats: id + 1, walkExtra: 15, returnExtra: 15 })), gradeZoneWeights: [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]] }, [0, 0, 0]);
  const r = E.simulate(c); verifyZones(r);
  assert.equal(r.zoneMetrics.length, 4); assert.equal(r.metrics.overtimeMinutes, 0);
  assert.ok(r.zoneMetrics.every(z => z.count === 0 && z.onTimeRate === 0 && z.peakQueue === 0));
  assert.equal(E.snapshot(r, 50).zoneStates.length, 4);
});

test('late arrivals and long independent seat drainage are fully served beyond scheduled closing and bounded bins', () => {
  const c = early({ windows: 2, windowOwners: [0, 1], windowZones: [0, 1], windowMeans: [1, 1], serviceCV: 0, mealMean: 90, mealCV: 0, serviceEnd: 11,
    serviceZones: [{ id: 0, name: '慢区', seats: 1, walkExtra: 15, returnExtra: 15 }, { id: 1, name: '快区', seats: 100, walkExtra: 0, returnExtra: 0 }], gradeZoneWeights: [[1, 0], [0, 1], [0, 0]] }, [180, 1, 0]);
  const r = E.simulate(c); verifyZones(r);
  assert.ok(r.students.filter(s => s.zone === 0).every(s => s.arrival > c.serviceEnd));
  assert.ok(r.metrics.overtimeMinutes > 4); assert.ok(r.metrics.observationEnd > 14400); assert.ok(r.meta.binWidthMinutes > 1);
  assert.ok(r.timeline.length <= 14402); assert.equal(sum(r.arrivalBins, 'count'), 181); assert.equal(sum(r.completionBins, 'count'), 181);
  assert.equal(r.zoneMetrics[1].meanSeatWait, 0); assert.equal(r.zoneMetrics[0].lateCount, 180);
  assert.ok(r.students.filter(s => s.zone === 0).every(s => s.returnTime > 120), 'even the first return needs at least 15 + 90 + 5 + 15 minutes');
});

test('browser UMD reproduces Node partitioned results and source metadata exactly', () => {
  const context = vm.createContext({});
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../dist/engine.js'), 'utf8'), context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../dist/hall-walk.js'), 'utf8'), context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../dist/school-engine.js'), 'utf8'), context);
  const c = config({ allocation: 'overflow', returnDestination: 'dormitory', sourceProfile: { id: 'example', title: '分区假设案例', asOf: '2026-10-17', status: 'research-assumptions', observedSchoolData: false } });
  context.input = clone(c);
  assert.equal(vm.runInContext('JSON.stringify(CanteenSim.simulate(input))', context), JSON.stringify(E.simulate(c)));
});

// Golden output was generated from the sealed v1.3 school engine, SHA-256
// 5d02f59c9bd72bfc016dda51905be31339c6ec8544667d8f5e3ba26060959cfb.
// This projection retains every old result field except textual metadata and
// endpoint label; it also retains the old snapshot shape at five timestamps.
// No dependence on the v1.4/v1.5 implementation is used to generate expectations.
// v1.5 adds only opt-in fields here; strip those additions from this old-shape
// projection while preserving the original v1.3 golden hash constants.
function v13Projection(r) {
  const p = clone(r); delete p.meta;
  for (const key of ['returnDestination', 'serviceZones', 'windowZones', 'gradeZoneWeights', 'sourceProfile', 'seatPoolByZone', 'seatWaitingCapacity', 'indoorWalkSpeed']) delete p.config[key];
  for (const g of [...p.config.grades, ...p.gradeMetrics, ...p.cohorts]) for (const key of ['classSizes', 'latestReleaseTime', 'releaseLocked']) delete g[key];
  for (const s of p.students) for (const key of ['zone', 'zoneName', 'zoneDraw', 'zoneWalk', 'zoneReturn', 'seatZone', 'seatPool', 'seatQueueArrival', 'seatWalkStart', 'indoorWalk', 'approachRoute', 'seatRoute', 'waitingPosition', 'displaySeatId']) delete s[key];
  for (const w of p.windows) delete w.zone;
  for (const key of ['effectiveServiceZones', 'effectiveWindowZones', 'zoneMetrics', 'effectiveSeatPoolByZone', 'effectiveSeatPools', 'physicalSeatMetrics', 'validityWarnings']) delete p[key];
  for (const key of ['seatBufferAssessed', 'seatBufferExceeded', 'seatBufferOverflowPeak']) delete p.metrics[key];
  delete p.metrics.endpointLabel;
  delete p.metrics.meanIndoorWalk;
  for (const g of [...p.gradeMetrics,...p.cohorts]) delete g.meanIndoorWalk;
  for (const t of p.diningTimeline) delete t.walkingToSeat;
  for (const batch of p.batchOverlaps) for (const grade of batch.byGrade) delete grade.walkingToSeat;
  return { result: p, step: r.meta.timelineStepMinutes, binWidth: r.meta.binWidthMinutes, snapshots: [0, 25, 37.5, 70, r.metrics.observationEnd].map(time => {
    const state = clone(E.snapshot(r, time));
    for (const key of ['zoneStates', 'zoneQueueIds', 'zoneGradeQueueIds', 'physicalSeatStates', 'seatPoolStates']) delete state[key];
    delete state.walkingToSeat; delete state.walkingToSeatIds;
    for (const g of state.gradeStates) delete g.walkingToSeat;
    for (const w of state.windows) delete w.zone;
    return state;
  }) };
}
const goldenInputs = [
  { mode: 'school' },
  { mode: 'school', students: 0, grades: E.DEFAULT_SCHOOL_CONFIG.grades.map(g => ({ ...g, students: 0, classes: 0 })) }
];
for (const allocation of ['shared', 'dedicated', 'overflow']) for (const strategy of ['pooled', 'shortest', 'workload', 'random']) goldenInputs.push({ mode: 'school', allocation, strategy, windows: 6, windowOwners: [0, 0, 1, 1, 2, 2], windowMeans: [15, 90, 25, 55, 40, 70], seats: 5, mealCV: 0.7, serviceCV: 1, seed: 879, grades: E.DEFAULT_SCHOOL_CONFIG.grades.map((g, i) => ({ ...g, students: [31, 27, 23][i], classes: 3, releaseTime: 25 + 5 * i, deadline: 80 })) });
goldenInputs.push({ ...goldenInputs[2], diningEnabled: false, serviceStart: 35, serviceEnd: 36, horizon: 36 });
const goldenHashes = [
  '113605e6756e656552d6383a9ce5677685905c055cbdc97183738b651e3d6c6b',
  'b5a99084897e35115cac902f087e42eabf53edb00fd3c272706497a49d97e0e6',
  '041f027edd7488fc4f0093e7948b763bb6c1bfdce0b418f355b753f2dd041b32',
  '63e32c24cbe3eff844880d4c026526bd50f90ca9a751264a8578a9d13e189be5',
  'fe709384e43011e6bc7af6b2abd87370f3ae731e348f20f20a550518270dea81',
  'a195fdeccbbb8f2a35b39b925f01c0574dbdaa89eac5b290b3aa96c198eea4c1',
  '3878befc4127d406c1a9172fa0f7edd982682a666276d705a538350b500ec62d',
  '5778a7780de5149442dc4457f1cac590617289473a3f1f3dfd90001a1fc947ea',
  '8c73bb3235abec468c2da7d69f5f706bd95f938f6387bb6e0432751064b0c6aa',
  '95bd57bb1baece910d6cea7b43bdb5c438ca499d2a34be77785e21a285816add',
  '8f1a12f68753a3d7ecd39e07b7e2cd24c8c64f1636a696273b7e28cfc5dc7d51',
  '5c794d08bd5e83dc835e6e505806ec73935c97283eabd15f43983cafd94da0cb',
  '00049ff0d930c95c58d007552ad069fb3f4c24639ee6ae108755804fb39958fb',
  '79180e919002d86e77b802dc7c38b65e9624aed14c0f056516dca174eb1db869',
  '6054bc3aeeedff90d8118a3c4e2c6d3e80316f7bd897c9c4d37fdf48c1aff281'
];
goldenInputs.forEach((input, id) => test(`unpartitioned v1.3 golden regression ${id}: ${input.allocation || 'default'}/${input.strategy || 'default'}`, () => {
  const hash = crypto.createHash('sha256').update(JSON.stringify(v13Projection(E.simulate(input)))).digest('hex');
  assert.equal(hash, goldenHashes[id]);
}));

test('an explicit single zone without extra travel preserves every unpartitioned numerical result', () => {
  const c = E.normalizeSchoolConfig({ mode: 'school', seed: 804, seats: 19 });
  const a = E.simulate(c), b = E.simulate({ ...c, serviceZones: [{ id: 0, name: '同一食堂', seats: 19, walkExtra: 0, returnExtra: 0 }], windowZones: null, gradeZoneWeights: null });
  assert.deepEqual(v13Projection(b), v13Projection(a));
});

test('new snapshots can replay a restored v1.3 school result that has no zone fields', () => {
  const current = E.simulate({ mode: 'school' }), restored = clone(current);
  for (const key of ['returnDestination', 'serviceZones', 'windowZones', 'gradeZoneWeights', 'sourceProfile']) delete restored.config[key];
  for (const key of ['zoneMetrics', 'effectiveServiceZones', 'effectiveWindowZones']) delete restored[key];
  for (const s of restored.students) for (const key of ['zone', 'zoneName', 'zoneDraw', 'zoneWalk', 'zoneReturn', 'seatZone']) delete s[key];
  for (const w of restored.windows) delete w.zone;
  for (const time of [0, 40, 65, current.metrics.observationEnd]) assert.deepEqual(E.snapshot(restored, time), E.snapshot(current, time));
});
