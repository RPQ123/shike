/* v1.5: exact class plans, timetable restrictions and physical seat pools.
 * Seating references below use linear lists and independent event sweeps,
 * not the production heap or production event-summary helpers.
 */
const test = require('node:test');
const assert = require('node:assert/strict');
const E = require('../dist/school-engine.js');

const clone = x => JSON.parse(JSON.stringify(x));
const close = (a, b, message = '') => assert.ok(Math.abs(a - b) <= 1e-8 * Math.max(1, Math.abs(a), Math.abs(b)), `${message}: ${a} vs ${b}`);
const grade = (id, students = 12, changes = {}) => ({ id, name: ['高一', '高二', '高三'][id], students,
  classes: students ? 3 : 0, readyTime: 30, releaseTime: 30 + id * 5,
  classInterval: .2, assemblyMax: 1, walkMin: 2, walkMax: 4, deadline: 150, ...changes });
function config(changes = {}) {
  return E.normalizeSchoolConfig({ mode: 'school', grades: [grade(0), grade(1), grade(2)],
    windows: 6, windowOwners: [0, 1, 2, 0, 1, 2], windowMeans: [20, 25, 30, 20, 25, 30],
    serviceMean: 25, serviceCV: .35, serviceStart: 25, serviceEnd: 100, horizon: 160,
    diningEnabled: true, seats: 12, mealMean: 10, mealCV: .2, returnMinutes: 4,
    returnDestination: 'dormitory', seed: 20261017, ...changes });
}
function zoned(changes = {}) {
  return config({ serviceZones: [{ id: 0, name: '餐品甲／就座区甲', seats: 8, walkExtra: 0, returnExtra: 1 },
    { id: 1, name: '餐品乙／就座区乙', seats: 4, walkExtra: 2, returnExtra: 4 }],
    windowZones: [0, 0, 0, 1, 1, 1], gradeZoneWeights: [[.7, .3], [.3, .7], [.5, .5]], ...changes });
}
function saturated(changes = {}) {
  return config({ grades: [grade(0, 8, { classes: 1, readyTime: 30, releaseTime: 30, classInterval: 0, assemblyMax: 0, walkMin: 0, walkMax: 0 }), grade(1, 0), grade(2, 0)],
    windows: 2, windowOwners: [0, 0], windowMeans: [60, 60], serviceMean: 60, serviceCV: 0,
    mealMean: 10, mealCV: 0, seats: 21,
    serviceZones: [{ id: 0, name: '有空座的就座区', seats: 20, walkExtra: 0, returnExtra: 5 }, { id: 1, name: '取餐需求区', seats: 1, walkExtra: 0, returnExtra: 1 }],
    windowZones: [0, 1], gradeZoneWeights: [[0, 1], [0, 0], [0, 0]], ...changes });
}
function independentSeatReplay(r) {
  const zones = r.config.serviceZones || [{ id: 0, seats: r.config.seats, returnExtra: 0 }];
  const mapping = r.config.seatPoolByZone || zones.map((_, i) => i), seats = [];
  for (const z of zones) for (let k = 0; k < z.seats; k++) seats.push({ id: seats.length, zone: z.id, free: 0 });
  const records = [];
  for (const s of r.students.slice().sort((a, b) => a.end - b.end || a.id - b.id)) {
    const eligible = seats.filter(p => mapping[p.zone] === mapping[s.zone]);
    eligible.sort((a, b) => a.free - b.free || a.id - b.id);
    const seat = eligible[0], start = Math.max(s.end, seat.free), duration = r.config.mealMean * s.mealFactor;
    const mealEnd = start + duration, extra = zones[seat.zone].returnExtra || 0;
    records.push({ id: s.id, foodZone: s.zone, seatId: seat.id, seatZone: seat.zone, seatPool: mapping[s.zone],
      seatStart: start, seatWait: start - s.end, mealDuration: duration, mealEnd,
      zoneReturn: extra, returnTime: mealEnd + r.config.returnMinutes + extra });
    seat.free = mealEnd;
  }
  return records.sort((a, b) => a.id - b.id);
}
function sweep(records, startKey, endKey) {
  const deltas = new Map();
  for (const r of records) {
    deltas.set(r[startKey], (deltas.get(r[startKey]) || 0) + 1);
    deltas.set(r[endKey], (deltas.get(r[endKey]) || 0) - 1);
  }
  let time = 0, stock = 0, peak = 0, area = 0;
  for (const [t, d] of [...deltas].sort((a, b) => a[0] - b[0])) { area += (t - time) * stock; stock += d; peak = Math.max(peak, stock); time = t; }
  assert.equal(stock, 0); return { peak, area };
}

test('v1.5 keeps new fields opt-in and normalizes them as independent copies', () => {
  const c = config(); assert.equal(E.VERSION, '1.6.0');
  assert.equal(c.seatPoolByZone, null); assert.equal(c.seatWaitingCapacity, null);
  c.grades.forEach(g => { assert.equal(g.classSizes, null); assert.equal(g.latestReleaseTime, null); assert.equal(g.releaseLocked, false); });
  const input = zoned({ seatPoolByZone: [1, 1], grades: [grade(0, 12, { classSizes: [1, 3, 8] }), grade(1), grade(2)] });
  const out = E.normalizeSchoolConfig(input); out.grades[0].classSizes[0] = 99; out.seatPoolByZone[0] = 0;
  assert.deepEqual(input.grades[0].classSizes, [1, 3, 8]); assert.deepEqual(input.seatPoolByZone, [1, 1]);
});

test('explicit class sizes generate exact batch populations and preserve empty indices', () => {
  const c = config({ grades: [grade(0, 5, { classes: 5, classSizes: [0, 2, 0, 3, 0], classInterval: 2 }), grade(1, 0), grade(2, 0)] });
  const r = E.simulate(c), batches = r.classBatches.filter(b => b.grade === 0);
  assert.deepEqual(batches.map(b => b.students), [0, 2, 0, 3, 0]);
  assert.deepEqual(r.students.map(s => s.classIndex), [1, 1, 3, 3, 3]);
  assert.deepEqual(r.students.map(s => s.release), [32, 32, 36, 36, 36]);
  assert.deepEqual(r.students.map(s => s.classId), ['0-1', '0-1', '0-3', '0-3', '0-3']);
});

test('explicit empty classes can outnumber students, whereas balanced fallback cannot', () => {
  const c = config({ grades: [grade(0, 1, { classes: 4, classSizes: [0, 0, 1, 0] }), grade(1, 0), grade(2, 0)] });
  assert.equal(E.simulate(c).students[0].classIndex, 2);
  assert.throws(() => config({ grades: [grade(0, 1, { classes: 4 }), grade(1, 0), grade(2, 0)] }), /班级数/);
});

test('class-size validation rejects mismatched shape, sums, types and noninteger counts', () => {
  for (const sizes of [[1, 2], [1, 2, 8], [1, -1, 12], [1, .5, 10.5], [1, '1', 10], null]) {
    if (sizes === null) continue;
    assert.throws(() => config({ grades: [grade(0, 12, { classSizes: sizes }), grade(1), grade(2)] }), /classSizes/);
  }
  const sparse = Array(3); sparse[0] = 12;
  assert.throws(() => config({ grades: [grade(0, 12, { classSizes: sparse }), grade(1), grade(2)] }), /classSizes/);
});

test('all-zero explicit class plans retain their configured indices without generating students', () => {
  const c = config({ grades: [grade(0, 0, { classes: 2, classSizes: [0, 0], latestReleaseTime: 0 }), grade(1, 0), grade(2, 0)] });
  const r = E.simulate(c); assert.equal(r.students.length, 0);
  assert.deepEqual(r.classBatches.map(b => b.classId), ['0-0', '0-1']);
  assert.deepEqual(E.makeSchoolBaseline(c), c); assert.deepEqual(E.makeSchoolGapConfig(c, 10), c);
});

test('explicit class plans preserve each person service, meal and route draws', () => {
  const a = E.simulate(config()), c = config(); c.grades[0].classSizes = [1, 3, 8];
  const b = E.simulate(c); assert.equal(b.students.length, a.students.length);
  for (let i = 0; i < a.students.length; i++) for (const k of ['randomId', 'serviceFactor', 'mealFactor', 'zoneDraw', 'routeDraw', 'arrivalJitter']) assert.equal(b.students[i][k], a.students[i][k], k);
  assert.notDeepEqual(b.classBatches.map(x => x.students), a.classBatches.map(x => x.students));
});

test('latest release applies to the last occupied class and ignores empty trailing classes', () => {
  const g = grade(0, 2, { classes: 4, classSizes: [0, 2, 0, 0], releaseTime: 30, classInterval: 5, latestReleaseTime: 35 });
  const c = config({ grades: [g, grade(1, 0), grade(2, 0)] });
  assert.equal(E.simulate(c).gradeMetrics[0].lastRelease, 35);
  assert.throws(() => config({ grades: [{ ...g, latestReleaseTime: 34.99 }, grade(1, 0), grade(2, 0)] }), /最后一个有学生班级/);
});

test('latest release counts class intervals for balanced fallback, not just the first class', () => {
  const g = grade(0, 12, { releaseTime: 30, classInterval: 5, latestReleaseTime: 40 });
  assert.equal(E.simulate(config({ grades: [g, grade(1, 0), grade(2, 0)] })).gradeMetrics[0].lastRelease, 40);
  assert.throws(() => config({ grades: [{ ...g, latestReleaseTime: 39 }, grade(1, 0), grade(2, 0)] }), /最晚放行/);
});

test('latest release and release lock reject invalid types and ranges', () => {
  for (const latest of [-1, 1441, '40', NaN]) assert.throws(() => config({ grades: [grade(0, 12, { latestReleaseTime: latest }), grade(1), grade(2)] }), /latestReleaseTime/);
  for (const locked of [0, 1, null, 'true']) assert.throws(() => config({ grades: [grade(0, 12, { releaseLocked: locked }), grade(1), grade(2)] }), /releaseLocked/);
});

test('zero-demand grade cannot delay the common baseline or consume a gap position', () => {
  const c = config({ grades: [grade(0, 4, { classes: 2 }), grade(1, 4, { classes: 2 }), grade(2, 0, { readyTime: 100, releaseTime: 100, releaseLocked: true })] });
  const common = E.makeSchoolBaseline(c), gap = E.makeSchoolGapConfig(c, 5);
  assert.deepEqual(common.grades.map(g => g.releaseTime), [30, 30, 100]);
  assert.deepEqual(gap.grades.map(g => g.releaseTime), [30, 35, 100]);
});

test('empty grade in the middle of the input order is skipped when scheduling', () => {
  const c = config({ grades: [grade(0, 4, { classes: 2, releaseTime: 30 }), grade(1, 0, { releaseTime: 35 }), grade(2, 4, { classes: 2, releaseTime: 40 })] });
  assert.deepEqual(E.makeSchoolGapConfig(c, 10).grades.map(g => g.releaseTime), [30, 35, 40]);
});

test('one locked grade sets a feasible common release without altering its time', () => {
  const c = config(); c.grades[1].releaseLocked = true;
  const before = clone(c), common = E.makeSchoolBaseline(c);
  assert.deepEqual(common.grades.map(g => g.releaseTime), [35, 35, 35]); assert.deepEqual(c, before);
  for (let i = 0; i < 3; i++) assert.equal(common.grades[i].deadline, c.grades[i].deadline);
});

test('different locked release times make a common baseline explicitly infeasible', () => {
  const c = config(); c.grades[0].releaseLocked = true; c.grades[1].releaseLocked = true;
  assert.throws(() => E.makeSchoolBaseline(c), /共同放行不可行/);
});

test('a locked common release earlier than another grade readiness is rejected', () => {
  const c = config({ grades: [grade(0, 12, { releaseLocked: true }), grade(1, 12, { readyTime: 35 }), grade(2)] });
  assert.throws(() => E.makeSchoolBaseline(c), /早于其他年级允许放行/);
});

test('gap helper can retain multiple locks even when common baseline is impossible', () => {
  const c = config(); c.grades[0].releaseLocked = true; c.grades[1].releaseLocked = true;
  assert.throws(() => E.makeSchoolBaseline(c), /共同放行不可行/);
  assert.deepEqual(E.makeSchoolGapConfig(c, 5).grades.map(g => g.releaseTime), [30, 35, 40]);
  assert.throws(() => E.makeSchoolGapConfig(c, 10), /锁定首班/);
});

test('locked gap anchor rejects early release and last-class late release', () => {
  const c = config(); c.grades[1].releaseLocked = true;
  assert.throws(() => E.makeSchoolGapConfig(c, 10), /早于允许放行/);
  const late = config(); late.grades[2].latestReleaseTime = 40.4;
  assert.throws(() => E.makeSchoolGapConfig(late, 10), /最晚放行/);
});

test('manual new configurations may change a locked grade without historical comparison', () => {
  const c = config(); c.grades[0].releaseLocked = true; c.grades[0].releaseTime = 50;
  assert.equal(E.normalizeSchoolConfig(c).grades[0].releaseTime, 50);
});

test('schedule helpers preserve service, seating, deadline, identity and explicit classes', () => {
  const c = zoned({ seatPoolByZone: [0, 0], seatWaitingCapacity: 10 }); c.grades[0].classSizes = [1, 3, 8];
  for (const revised of [E.makeSchoolBaseline(c), E.makeSchoolGapConfig(c, 10)]) {
    const a = clone(c), b = clone(revised);
    a.grades.forEach(g => delete g.releaseTime); b.grades.forEach(g => delete g.releaseTime);
    assert.deepEqual(a, b);
  }
});

test('seat mappings validate effective-zone length and integer group labels', () => {
  for (const mapping of [[], [0], [0, 2], [0, -1], [0, .5], ['0', 1], [0, 1, 1]]) assert.throws(() => zoned({ seatPoolByZone: mapping }), /seatPoolByZone/);
  assert.deepEqual(config({ seatPoolByZone: [0] }).seatPoolByZone, [0]);
  assert.throws(() => config({ seatPoolByZone: [0, 0] }), /seatPoolByZone/);
});

test('shared physical seats remove a manufactured bottleneck without changing food service', () => {
  const restricted = E.simulate(saturated()), shared = E.simulate(saturated({ seatPoolByZone: [0, 0] }));
  close(restricted.metrics.meanSeatWait, 31.5); close(shared.metrics.meanSeatWait, 0);
  assert.equal(shared.config.seats, restricted.config.seats);
  for (let i = 0; i < shared.students.length; i++) {
    assert.equal(shared.students[i].zone, 1); assert.equal(shared.students[i].window, 1);
    assert.equal(shared.students[i].start, restricted.students[i].start); assert.equal(shared.students[i].end, restricted.students[i].end);
  }
  assert.ok(shared.students.some(s => s.seatZone === 0));
});

test('physical seat return extra comes from actual seat area instead of food choice', () => {
  const r = E.simulate(saturated({ seatPoolByZone: [0, 0] }));
  for (const s of r.students) {
    assert.equal(s.zone, 1); assert.equal(s.seatZone, 0); assert.equal(s.zoneReturn, 5);
    close(s.returnTime, s.mealEnd + r.config.returnMinutes + 5);
  }
});

test('shared seating matches an independent linear-seat reference under heterogeneous demand', () => {
  for (const mapping of [null, [0, 0], [1, 1], [1, 0]]) {
    const r = E.simulate(zoned({ seatPoolByZone: mapping })), expected = independentSeatReplay(r);
    for (const a of expected) for (const k of ['seatId', 'seatZone', 'seatPool', 'seatStart', 'seatWait', 'mealDuration', 'mealEnd', 'zoneReturn', 'returnTime']) close(r.students[a.id][k], a[k], k);
  }
});

test('two shared pools remain isolated and retain original physical seat-id prefixes', () => {
  const c = config({ grades: [grade(0, 80, { classes: 4 }), grade(1, 0), grade(2, 0)], windows: 4, windowOwners: [0, 0, 0, 0], windowMeans: [10, 10, 10, 10],
    seats: 10, serviceZones: [1, 2, 3, 4].map((seats, id) => ({ id, name: '物理区' + id, seats })),
    windowZones: [0, 1, 2, 3], gradeZoneWeights: [[.25, .25, .25, .25], [0, 0, 0, 0], [0, 0, 0, 0]], seatPoolByZone: [1, 1, 3, 3] });
  const r = E.simulate(c), expected = independentSeatReplay(r);
  assert.deepEqual(r.effectiveSeatPools.map(p => ({ id: p.id, zoneIds: p.zoneIds, seats: p.seats, seatIds: p.seatIds })), [
    { id: 1, zoneIds: [0, 1], seats: 3, seatIds: [0, 1, 2] }, { id: 3, zoneIds: [2, 3], seats: 7, seatIds: [3, 4, 5, 6, 7, 8, 9] }
  ]);
  for (const s of r.students) { assert.equal(c.seatPoolByZone[s.zone], c.seatPoolByZone[s.seatZone]); assert.equal(s.seatId, expected[s.id].seatId); }
});

test('seat sharing never relaxes food eligibility for any supported queue allocation', () => {
  for (const allocation of ['shared', 'dedicated', 'overflow']) for (const strategy of ['pooled', 'shortest', 'workload', 'random']) {
    const a = E.simulate(zoned({ allocation, strategy })), b = E.simulate(zoned({ allocation, strategy, seatPoolByZone: [0, 0] }));
    for (let i = 0; i < b.students.length; i++) {
      const s = b.students[i]; assert.equal(b.config.windowZones[s.window], s.zone);
      if (allocation === 'dedicated') assert.equal(b.config.windowOwners[s.window], s.grade);
      for (const k of ['arrival', 'zone', 'window', 'start', 'end', 'wait', 'service']) assert.equal(s[k], a.students[i][k], `${allocation}/${strategy}/${k}`);
    }
  }
});

test('physical-seat metrics conserve occupancy and keep food-origin counts separate', () => {
  const r = E.simulate(saturated({ seatPoolByZone: [0, 0] }));
  assert.equal(r.zoneMetrics[0].count, 0); assert.equal(r.zoneMetrics[1].count, 8);
  assert.equal(r.physicalSeatMetrics[0].servedDiners, 8); assert.equal(r.physicalSeatMetrics[1].servedDiners, 0);
  assert.deepEqual(r.physicalSeatMetrics[0].foodOriginCounts, [0, 8]);
  for (const z of r.physicalSeatMetrics) {
    const records = r.students.filter(s => s.seatZone === z.id), ref = sweep(records, 'seatStart', 'mealEnd');
    close(z.seatOccupancyIntegral, ref.area); assert.equal(z.peakSeatsOccupied, ref.peak);
    assert.ok(z.peakSeatsOccupied <= z.seats); assert.ok(z.seatUtilization <= 1);
  }
  close(r.physicalSeatMetrics.reduce((a, z) => a + z.seatOccupancyIntegral, 0), r.metrics.seatOccupancyIntegral);
  for (const z of r.zoneMetrics) for (const key of ['seatOccupancyIntegral', 'peakSeatsOccupied', 'seatUtilization']) assert.equal(z[key], null);
  assert.equal(r.zoneMetrics[1].foodOriginPeakDining, 8);
});

test('only ambiguous shared-group aliases become unavailable, independent areas keep aliases', () => {
  const c = config({ seats: 12, windows: 3, windowOwners: [0, 1, 2], windowMeans: [20, 20, 20],
    serviceZones: [0, 1, 2].map(id => ({ id, name: '区' + id, seats: 4 })), windowZones: [0, 1, 2],
    gradeZoneWeights: [[.5, .5, 0], [0, .5, .5], [.5, 0, .5]], seatPoolByZone: [0, 0, 2] });
  const r = E.simulate(c); assert.equal(r.zoneMetrics[0].seatUtilization, null);
  close(r.zoneMetrics[2].seatUtilization, r.physicalSeatMetrics[2].seatUtilization);
  close(r.zoneMetrics[2].foodOriginSeatOccupancyIntegral, r.zoneMetrics[2].seatOccupancyIntegral);
});

test('snapshot physical areas and pools agree with half-open seat occupancy at every event', () => {
  const r = E.simulate(zoned({ seatPoolByZone: [0, 0] }));
  const times = new Set([0, r.metrics.observationEnd]);
  r.students.forEach(s => [s.end, s.seatStart, s.mealEnd, s.returnTime].forEach(t => times.add(t)));
  for (const t of times) {
    const snap = E.snapshot(r, t), dining = r.students.filter(s => s.seatStart <= t && t < s.mealEnd);
    assert.equal(snap.physicalSeatStates.reduce((a, p) => a + p.dining, 0), dining.length);
    assert.equal(new Set(snap.physicalSeatStates.flatMap(p => p.seatIds)).size, dining.length);
    for (const p of snap.physicalSeatStates) assert.deepEqual(p.diningIds, dining.filter(s => s.seatZone === p.id).map(s => s.id));
    for (const p of snap.seatPoolStates) {
      assert.equal(p.dining, dining.filter(s => s.seatPool === p.id).length);
      assert.equal(p.seatWaiting, r.students.filter(s => s.seatPool === p.id && s.end <= t && t < s.seatStart).length);
      assert.ok(p.seatsOccupied <= p.seats);
    }
    assert.equal(snap.zoneStates[0].seatsOccupied, null);
  }
});

test('seat occupancy never overlaps for the same physical seat', () => {
  const r = E.simulate(zoned({ seatPoolByZone: [0, 0] })), groups = new Map();
  r.students.forEach(s => { if (!groups.has(s.seatId)) groups.set(s.seatId, []); groups.get(s.seatId).push(s); });
  for (const people of groups.values()) {
    people.sort((a, b) => a.seatStart - b.seatStart);
    for (let i = 1; i < people.length; i++) assert.ok(people[i].seatStart >= people[i - 1].mealEnd);
  }
});

test('global waiting capacity validates nonnegative integer input and distinguishes unassessed', () => {
  for (const capacity of [-1, .5, 5001, '0', NaN]) assert.throws(() => config({ seatWaitingCapacity: capacity }), /seatWaitingCapacity/);
  const r = E.simulate(saturated()); assert.equal(r.metrics.seatBufferAssessed, false); assert.equal(r.metrics.seatBufferExceeded, false);
  assert.equal(r.validityWarnings[0].code, 'SEAT_BUFFER_UNASSESSED'); assert.ok(r.validityWarnings[0].peak > 0);
});

test('capacity exceedance uses exact global event peak without changing simulated queues', () => {
  const base = E.simulate(saturated()), peak = base.metrics.peakSeatWaiting;
  for (const capacity of [0, peak - 1, peak, 5000]) {
    const r = E.simulate(saturated({ seatWaitingCapacity: capacity }));
    assert.deepEqual(r.students, base.students); assert.deepEqual(r.timeline, base.timeline); assert.deepEqual(r.diningTimeline, base.diningTimeline);
    assert.equal(r.metrics.seatBufferAssessed, true); assert.equal(r.metrics.seatBufferExceeded, capacity < peak);
    assert.equal(r.metrics.seatBufferOverflowPeak, Math.max(0, peak - capacity));
    assert.equal(r.validityWarnings.some(w => w.code === 'SEAT_BUFFER_CAPACITY_EXCEEDED'), capacity < peak);
  }
});

test('capacity is global across pools, not a separate cap for every food or seating zone', () => {
  const c = zoned({ seats: 2, serviceZones: [{ id: 0, name: '甲', seats: 1 }, { id: 1, name: '乙', seats: 1 }], seatWaitingCapacity: 3 });
  const r = E.simulate(c), ref = sweep(r.students.map(s => ({ end: s.end, seatStart: s.seatStart })), 'end', 'seatStart');
  assert.equal(r.metrics.peakSeatWaiting, ref.peak); assert.equal(r.metrics.seatBufferOverflowPeak, Math.max(0, ref.peak - 3));
});

test('no dining or no waiting creates no false buffer exceedance', () => {
  const pickup = E.simulate(saturated({ diningEnabled: false, seatWaitingCapacity: 0 }));
  assert.equal(pickup.metrics.seatBufferAssessed, false); assert.equal(pickup.metrics.seatBufferExceeded, false); assert.deepEqual(pickup.validityWarnings, []);
  assert.ok(pickup.physicalSeatMetrics.every(p => p.servedDiners === 0));
  const seated = E.simulate(saturated({ seatPoolByZone: [0, 0], seatWaitingCapacity: 0 }));
  assert.equal(seated.metrics.seatBufferAssessed, true); assert.equal(seated.metrics.peakSeatWaiting, 0); assert.deepEqual(seated.validityWarnings, []);
});

test('configuration roundtrip retains schedule constraints, pool mapping and diagnostic scope', () => {
  const c = zoned({ seatPoolByZone: [1, 1], seatWaitingCapacity: 3 });
  c.grades[0].classSizes = [1, 3, 8]; c.grades[0].latestReleaseTime = 40; c.grades[0].releaseLocked = true;
  const a = E.simulate(c), b = E.simulate(clone(a.config)); assert.deepEqual(a, b);
  assert.equal(a.meta.seatBlockingFeedback, false); assert.match(a.meta.seatBufferCapacityModel, /diagnostic-only/);
  assert.equal(a.meta.crossZoneRouting, false); assert.equal(a.meta.crossZoneSeats, true);
});

test('added capabilities do not let source metadata claim unverified observed school data', () => {
  const source = { id: 'source', title: '研究', asOf: '2026-10-18', status: 'modified', observedSchoolData: false };
  const c = config({ sourceProfile: source }); assert.equal(E.simulate(c).config.sourceProfile.observedSchoolData, false);
  assert.throws(() => config({ sourceProfile: { ...source, observedSchoolData: true } }), /实测|false/);
});
