const test = require('node:test'),
  assert = require('node:assert/strict');
const C = require('../tasks/innovation-run-contract.json'),
  T = require('../tools/innovation-time.cjs');
const deadline = Date.parse(C.earliestCompletion);
test('five-hour gate rejects the instant just before this new task deadline', () => {
  assert.equal(T.measure(C, deadline - 1).complete, false);
  assert.throws(() => T.requireComplete(C, deadline - 1), /尚未达到五小时/);
});
test('five-hour gate accepts its exact deadline and records 18000 elapsed seconds', () => {
  const x = T.requireComplete(C, deadline);
  assert.equal(x.complete, true);
  assert.equal(x.elapsedSeconds, 18000);
});
test('an earlier task or a shortened declared interval cannot satisfy the new gate', () => {
  assert.throws(() => T.requireComplete({ ...C, startedAt: '2026-10-18T05:55:05+08:00' }, deadline));
  assert.throws(() => T.requireComplete({ ...C, minimumSeconds: 10800 }, deadline));
});
