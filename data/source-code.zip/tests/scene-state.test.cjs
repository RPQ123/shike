'use strict';

// Run: node --test tests/scene-state.test.cjs
// Pure state tests: no browser, WebGL renderer, npm package, or network needed.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const E = require('../dist/engine.js');
const Scene = require('../dist/scene-state.js');

function close(a, b, epsilon = 1e-10) { assert.ok(Math.abs(a - b) <= epsilon, `${a} != ${b}`); }

function manual(students, count = 1, strategy = 'shortest', observationEnd = 4) {
  return {
    students: students.map((s, id) => ({
      id, cohort: id % 3, arrival: s[0], start: s[1], end: s[2],
      window: s[3] || 0, service: s[2] - s[1], wait: s[1] - s[0]
    })),
    windows: Array.from({ length: count }, (_, id) => ({ id, meanService: 1 })),
    config: { students: students.length, windows: count, strategy },
    metrics: { observationEnd }
  };
}

function assertProjection(result, time, f = Scene.frame(result, time)) {
  const snap = E.snapshot(result, time);
  const expected = result.students.filter(s => s.arrival <= snap.time && s.end > snap.time);
  assert.deepEqual(f.people.map(p => p.id), expected.map(s => s.id));
  assert.equal(new Set(f.people.map(p => p.id)).size, f.people.length);
  assert.equal(f.people.length, snap.waiting + snap.inService);
  assert.equal(f.counts.waiting, snap.waiting);
  assert.equal(f.counts.inService, snap.inService);
  assert.equal(f.counts.completed, snap.completed);
  assert.equal(f.counts.arrived, snap.arrived);
  assert.equal(f.counts.active, snap.waiting + snap.inService);
  assert.equal(f.counts.notArrived, snap.notArrived);
  assert.equal(f.counts.total, snap.arrived + snap.notArrived);
  assert.deepEqual(f.snapshot, snap);
  assert.equal(f.queueGroups.reduce((n, g) => n + g.count, 0), snap.waiting);
  assert.equal(f.sampling.activeTotal, f.people.length);
  assert.equal(f.sampling.activeVisible, f.visiblePeople.length);
  assert.equal(f.sampling.activeTotal - f.sampling.activeVisible, f.sampling.omittedWaiting);
  const byId = new Map(f.people.map(p => [p.id, p]));
  for (const p of f.visiblePeople) assert.equal(byId.get(p.id), p, 'visible list reuses the exact logical person');
  assert.equal(new Set(f.visiblePeople.map(p => p.id)).size, f.visiblePeople.length);
  assert.equal(f.people.filter(p => p.visible).length, f.visiblePeople.length);
  for (const p of f.people) {
    const s = result.students[p.id];
    assert.equal(p.cohort, s.cohort);
    assert.equal(p.state, s.start <= snap.time ? 'serving' : 'waiting');
    assert.equal(p.visualTransition, false);
    assert.equal(p.arrival, s.arrival);
    assert.equal(p.start, s.start);
    assert.equal(p.end, s.end);
    assert.ok(p.position.every(Number.isFinite));
    assert.ok(Number.isFinite(p.yaw));
    if (p.state === 'serving') {
      assert.equal(p.window, s.window);
      assert.equal(f.windows[p.window].currentStudent, p.id);
      assert.equal(p.visible, true);
      close(p.serviceProgress, (snap.time - s.start) / s.service);
    }
  }
  f.windows.forEach((w, i) => {
    assert.equal(w.currentStudent, snap.windows[i].currentStudent);
    assert.deepEqual(w.queueIds, snap.windows[i].queueIds);
    assert.equal(w.progress, snap.windows[i].progress);
  });
  for (const g of f.queueGroups) {
    const ids = f.pooled ? snap.centralQueueIds : snap.windows[g.window].queueIds;
    assert.deepEqual(g.queueIds, ids);
    assert.equal(g.omittedCount, g.count - g.visibleCount);
    assert.equal(new Set(g.visibleIds).size, g.visibleCount);
    ids.forEach((id, index) => {
      assert.equal(byId.get(id).queueId, g.id);
      assert.equal(byId.get(id).queueIndex, index);
      assert.equal(byId.get(id).window, g.window);
    });
  }
  for (const p of f.departures) {
    assert.ok(!byId.has(p.id), 'departing figure cannot also be waiting or serving');
    assert.equal(p.state, 'departing');
    assert.equal(p.visualTransition, true);
    assert.ok(result.students[p.id].end <= snap.time);
    assert.ok(p.visualProgress >= 0 && p.visualProgress < 1);
    assert.ok(p.position.every(Number.isFinite));
  }
  return f;
}

test('1–16 windows have finite, separate service positions and queue slots within the floor', () => {
  for (let count = 1; count <= 16; count++) {
    for (const pooled of [false, true]) {
      const l = Scene.createLayout(count, pooled);
      assert.equal(l.windowCount, count);
      assert.equal(l.windows.length, count);
      close(l.bounds.width, 45.6);
      assert.equal(l.slots.length, 16);
      assert.equal(l.slots.filter(s => s.open).length, count);
      assert.deepEqual(l.slots.map(s => s.position), Scene.createLayout(16, pooled).slots.map(s => s.position));
      assert.equal(l.bounds.minZ, -7.7);
      assert.equal(l.bounds.maxZ, 18);
      assert.equal(l.queues.length, pooled ? 1 : count);
      assert.equal(new Set(l.windows.map(w => w.x)).size, count);
      for (const w of l.windows) {
        assert.deepEqual(w.position, [w.x, 0, -5]);
        assert.deepEqual(w.servicePosition, [w.x, 0, -3.65]);
        assert.deepEqual(w.queueHead, [w.x, 0, -2.3]);
      }
      for (const q of l.queues) {
        assert.equal(l.queues.reduce((sum, q) => sum + q.capacity, 0), 320);
        assert.equal(q.slots.length, q.capacity);
        assert.equal(new Set(q.slots.map(p => p.join(','))).size, q.slots.length);
        for (const [x, y, z] of q.slots) {
          assert.ok(x > l.bounds.minX && x < l.bounds.maxX);
          assert.equal(y, 0);
          assert.ok(z >= -2.3 && z < 10.8, 'queues stay clear of dining tables');
        }
      }
      assert.equal(Object.isFrozen(l), true);
      assert.equal(Object.isFrozen(l.queues[0].slots[0]), true);
    }
  }
});

test('default peak reproduces exact waiting identities, service identities, ranks and counts', () => {
  const result = E.simulate();
  assertProjection(result, result.metrics.peakQueueTime);
});

test('same-time arrival, service completion and dispatch use the engine boundary convention', () => {
  const r = manual([[0, 0, 1], [0, 1, 2], [1, 2, 3], [2, 3, 4]]);
  const atZero = assertProjection(r, 0);
  assert.deepEqual(atZero.people.map(p => [p.id, p.state]), [[0, 'serving'], [1, 'waiting']]);
  const atOne = assertProjection(r, 1);
  assert.deepEqual(atOne.people.map(p => [p.id, p.state]), [[1, 'serving'], [2, 'waiting']]);
  assert.deepEqual(atOne.windows[0].queueIds, [2]);
  assert.equal(atOne.windows[0].currentStudent, 1);
  assert.equal(atOne.counts.notArrived, 1);
  assert.deepEqual(atOne.departures.map(p => p.id), [0]);
  assert.equal(atOne.departures[0].visualProgress, 0);
});

test('zero-wait arrivals appear directly in service and never enter the waiting count', () => {
  const r = manual([[1, 1, 2], [2, 2, 3]]);
  assert.equal(assertProjection(r, 1 - 1e-8).people.length, 0);
  const f = assertProjection(r, 1);
  assert.equal(f.counts.waiting, 0);
  assert.deepEqual(f.people.map(p => [p.id, p.state]), [[0, 'serving']]);
  assert.deepEqual(f.queueGroups[0].queueIds, []);
});

test('recent departures are visual only, expire after the declared duration, and can finish beyond observationEnd', () => {
  const r = manual([[0, 0, 1]], 1, 'shortest', 1);
  const atEnd = assertProjection(r, 1);
  assert.equal(atEnd.people.length, 0);
  assert.equal(atEnd.counts.completed, 1);
  assert.equal(atEnd.departures.length, 1);
  const duration = atEnd.layout.departureDuration;
  assert.ok(duration >= 1);
  const during = assertProjection(r, 1 + duration / 2);
  assert.equal(during.time, 1);
  close(during.departures[0].visualProgress, 0.5);
  assert.notDeepEqual(during.departures[0].position, atEnd.departures[0].position);
  assert.equal(assertProjection(r, 1 + duration).departures.length, 0);
  assert.equal(assertProjection(r, 20).departures.length, 0);
});

test('rewinding reproduces identical frames, preserves identities, and does not mutate simulation data', () => {
  const r = E.simulate({ students: 150, windows: 3, serviceMean: 50, arrivalPeak: 5, arrivalSpread: 1 });
  const l = Scene.createLayout(3, false);
  const before = JSON.stringify(r), first = Scene.frame(r, 7.3, l);
  Scene.frame(r, 1000, l);
  Scene.frame(r, 0, l);
  const again = Scene.frame(r, 7.3, l);
  assert.deepEqual(again, first);
  assert.equal(JSON.stringify(r), before);
  assertProjection(r, 7.3, again);
});

test('shared queue retains global FCFS identity and does not assign waiting people to future windows', () => {
  const r = E.simulate({ students: 500, windows: 4, strategy: 'pooled', arrivalPeak: 3, arrivalSpread: 1 });
  const f = assertProjection(r, 6);
  assert.ok(f.counts.waiting > 0);
  assert.equal(f.queueGroups.length, 1);
  assert.equal(f.queueGroups[0].window, null);
  assert.deepEqual(f.queueGroups[0].queueIds, f.snapshot.centralQueueIds);
  assert.equal(f.windows.every(w => w.waiting === 0 && w.queueIds.length === 0), true);
  assert.equal(f.people.filter(p => p.state === 'waiting').every(p => p.window === null), true);
});

test('provided engine snapshot gives the identical projection and rejects a stale time', () => {
  const r = E.simulate({ students: 60, windows: 2, arrivalPeak: 2, arrivalSpread: 1 });
  const l = Scene.createLayout(2, false), snap = E.snapshot(r, 3);
  const before = JSON.stringify(snap);
  assert.deepEqual(Scene.frame(r, 3, l, snap), Scene.frame(r, 3, l));
  assert.equal(JSON.stringify(snap), before);
  assert.throws(() => Scene.frame(r, 3.1, l, snap), /快照/);
});

test('5000 people at one window remain exact once each while sampled crowd keeps queue head and tail', () => {
  const r = E.simulate({ students: 5000, windows: 1, serviceMean: 120, serviceCV: 0, arrivalPeak: 0, arrivalSpread: 1 });
  const f = assertProjection(r, 5), q = f.queueGroups[0];
  assert.ok(f.people.length > 4900);
  assert.equal(f.visiblePeople.length, 321);
  assert.equal(q.visibleCount, 320);
  assert.deepEqual(q.visibleIds.slice(0, 4), q.queueIds.slice(0, 4));
  assert.equal(q.visibleIds.at(-1), q.queueIds.at(-1));
  assert.equal(q.omittedCount, q.count - 320);
  assert.deepEqual(Scene.frame(r, 5), f);
});

test('5000 people across 16 windows share the same global 320 waiting budget', () => {
  const r = E.simulate({ students: 5000, windows: 16, serviceMean: 120, serviceCV: 0, arrivalPeak: 0, arrivalSpread: 1 });
  const f = assertProjection(r, 5);
  assert.equal(f.visiblePeople.length, 336);
  assert.equal(f.people.filter(p => p.state === 'serving').length, 16);
  assert.equal(f.queueGroups.reduce((sum, q) => sum + q.visibleCount, 0), 320);
  assert.ok(f.sampling.omittedWaiting > 3900);
});

test('5000 shared-queue people use the same 320 waiting budget and keep every service figure', () => {
  const r = E.simulate({ students: 5000, windows: 16, strategy: 'pooled', serviceMean: 120, serviceCV: 0, arrivalPeak: 0, arrivalSpread: 1 });
  const f = assertProjection(r, 5);
  assert.equal(f.visiblePeople.length, 336);
  assert.equal(f.queueGroups[0].visibleCount, 320);
  assert.equal(f.queueGroups[0].visibleIds.at(-1), f.snapshot.centralQueueIds.at(-1));
  assert.ok(f.sampling.omittedWaiting > 4500);
});

test('fast service caps completed transition figures independently of all truthful simulation counts', () => {
  const r = E.simulate({ students: 5000, windows: 16, strategy: 'pooled', serviceMean: 5, windowMeans: Array(16).fill(1), serviceCV: 0, arrivalPeak: 0, arrivalSpread: 1, horizon: 1 });
  const f = assertProjection(r, 0.5);
  assert.ok(f.sampling.recentDepartures > 64);
  assert.equal(f.departures.length, 64);
  assert.equal(f.sampling.omittedDepartures, f.sampling.recentDepartures - 64);
  assert.equal(new Set(f.departures.map(p => p.id)).size, 64);
  assert.deepEqual(Scene.frame(r, 0.5), f);
});

test('zero demand, negative time, invalid inputs and mismatched layouts have explicit behavior', () => {
  const r = E.simulate({ students: 0, windows: 1 });
  const f = assertProjection(r, -10);
  assert.equal(f.time, 0);
  assert.deepEqual(f.people, []);
  assert.deepEqual(f.departures, []);
  assert.equal(f.counts.active, 0);
  assert.equal(f.sampling.sampled, false);
  assert.throws(() => Scene.createLayout(0), /窗口数/);
  assert.throws(() => Scene.createLayout(17), /窗口数/);
  assert.throws(() => Scene.createLayout(1.5), /窗口数/);
  assert.throws(() => Scene.createLayout(1, 'pooled'), /布尔/);
  assert.throws(() => Scene.frame(r, NaN), /有限数值/);
  assert.throws(() => Scene.frame(r, Infinity), /有限数值/);
  assert.throws(() => Scene.frame(null, 0), /simulate/);
  assert.throws(() => Scene.frame(r, 0, Scene.createLayout(2, false)), /布局/);
  assert.throws(() => Scene.frame(r, 0, Scene.createLayout(1, true)), /布局/);
});

test('browser UMD exposes the same state API when loaded after the simulation engine', () => {
  const context = vm.createContext({});
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../dist/engine.js'), 'utf8'), context);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '../dist/scene-state.js'), 'utf8'), context);
  assert.equal(context.CanteenSceneState.VERSION, Scene.VERSION);
  const f = vm.runInContext('CanteenSceneState.frame(CanteenSim.simulate({students: 0}), 0)', context);
  assert.equal(f.counts.total, 0);
  assert.equal(f.layout.windows.length, 8);
});

test('one overcrowded queue among 16 windows still fits the fixed queue zone with every representative separate', () => {
  const r = manual(Array.from({length: 5000}, (_, i) => [0, 100 + i, 101 + i, 7]), 16, 'shortest', 5200);
  const f = assertProjection(r, 1), waiting = f.visiblePeople.filter(p => p.state === 'waiting');
  assert.equal(waiting.length, 320);
  assert.equal(new Set(waiting.map(p => p.position.join(','))).size, 320);
  assert.equal(f.queueGroups[7].visibleCount, 320);
  for (const p of waiting) {
    assert.ok(p.position[0] > f.layout.bounds.minX + 2 && p.position[0] < f.layout.bounds.maxX - 2);
    assert.ok(p.position[2] >= -2.3 && p.position[2] <= 7.581);
  }
});

test('A/B frames use one requested representation scale while conserving complete counts and nonempty queue heads', () => {
  const a = manual(Array.from({length: 1200}, (_, i) => [0, 100 + i, 101 + i, i % 8]), 8, 'shortest', 1400);
  const b = manual(Array.from({length: 600}, (_, i) => [0, 100 + i, 101 + i, i % 8]), 8, 'shortest', 800);
  const scale = 1200 / 320;
  const fa = Scene.frame(a, 1, null, null, {peoplePerFigure: scale}), fb = Scene.frame(b, 1, null, null, {peoplePerFigure: scale});
  assert.equal(fa.sampling.visibleWaiting, 320); assert.equal(fb.sampling.visibleWaiting, 160);
  assert.equal(fa.counts.waiting, 1200); assert.equal(fb.counts.waiting, 600);
  assert.equal(fa.sampling.requestedPeoplePerFigure, scale); assert.equal(fb.sampling.requestedPeoplePerFigure, scale);
  assert.equal(fa.sampling.peoplePerFigure, fb.sampling.peoplePerFigure);
  for (const f of [fa, fb]) for (const q of f.queueGroups) assert.equal(q.visibleIds[0], q.queueIds[0]);
  assert.ok(fb.sampling.description.includes('取整'));
  assert.throws(() => Scene.frame(a, 1, null, null, {peoplePerFigure: 0.5}), /比例/);
});

test('shared display scale explicitly preserves sparse queue heads instead of hiding a nonempty queue', () => {
  const r = manual(Array.from({length: 16}, (_, i) => [0, 100 + i, 101 + i, i]), 16, 'shortest', 130);
  const f = Scene.frame(r, 1, null, null, {peoplePerFigure: 20});
  assert.equal(f.sampling.visibleWaiting, 16);
  assert.equal(f.queueGroups.every(q => q.visibleCount === 1 && q.visibleIds[0] === q.queueIds[0]), true);
  assert.equal(f.sampling.peoplePerFigure, 1); assert.equal(f.sampling.requestedPeoplePerFigure, 20);
});

test('entrance and departure routes use marked aisles, stay on the floor and clear table-chair envelopes', () => {
  const r = manual(Array.from({length: 900}, (_, i) => [0, 100 + i, 101 + i, i % 16]), 16, 'shortest', 1100);
  const f = Scene.frame(r, 1), layout = f.layout;
  const pointSegmentDistance = (p, a, b) => {
    const dx=b[0]-a[0], dz=b[2]-a[2], t=Math.max(0,Math.min(1,((p[0]-a[0])*dx+(p[2]-a[2])*dz)/(dx*dx+dz*dz||1)));
    return Math.hypot(p[0]-a[0]-t*dx,p[2]-a[2]-t*dz);
  };
  const paths = [];
  for (const q of f.queueGroups) {
    const tail = f.visiblePeople.find(p => p.id === q.visibleIds.at(-1));
    assert.deepEqual(tail.arrivalPath[0], layout.entry);
    assert.deepEqual(tail.arrivalPath.at(-1), tail.position);
    paths.push(tail.arrivalPath);
  }
  for (let i=0; i<16; i++) {
    const path=Scene.departureRoute(layout,i);
    assert.deepEqual(path[0],layout.windows[i].servicePosition); assert.deepEqual(path.at(-1),layout.exit);
    paths.push(path);
  }
  for (const path of paths) {
    for (const p of path) assert.ok(p[0]>layout.bounds.minX && p[0]<layout.bounds.maxX && p[2]>layout.bounds.minZ && p[2]<layout.bounds.maxZ);
    for (let i=1;i<path.length;i++) for (const table of layout.tables) assert.ok(pointSegmentDistance(table.position,path[i-1],path[i])>table.clearanceRadius+.24,'route must clear a chair and avatar envelope');
  }
});

test('departure arc-length positions follow each bend and yield reproducible seek positions', () => {
  const layout=Scene.createLayout(16,false), path=Scene.departureRoute(layout,0);
  const start=Scene.samplePath(path,0), end=Scene.samplePath(path,1);
  assert.deepEqual(start.position,path[0]); assert.deepEqual(end.position,path.at(-1));
  const quarter=Scene.samplePath(path,.25), half=Scene.samplePath(path,.5);
  close(half.distance,quarter.distance*2);
  for (const progress of [.1,.3,.6,.9]) {
    const p=Scene.samplePath(path,progress);
    assert.ok(path.slice(1).some((b,i)=>Math.abs(p.position[0]-path[i][0])<1e-8&&Math.abs(p.position[0]-b[0])<1e-8||Math.abs(p.position[2]-path[i][2])<1e-8&&Math.abs(p.position[2]-b[2])<1e-8),'no diagonal corner cutting');
    assert.deepEqual(Scene.samplePath(path,progress),p);
  }
});
