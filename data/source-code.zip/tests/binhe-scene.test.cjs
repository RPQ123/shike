'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const E=require('../dist/school-engine.js');
const P=require('../dist/binhe-profile.js');
const S=require('../dist/scene-state.js');
const profile=P.createConfig();
function checkFrame(r,t) {
  const f=S.frame(r,t),snap=E.snapshot(r,t);
  for(const key of ['waiting','inService','seatWaiting','dining','returning','returned','notArrived'])assert.equal(f.counts[key],snap[key],key);
  assert.equal(f.counts.waiting+f.counts.inService+f.counts.seatWaiting+f.counts.dining+f.counts.returning+f.counts.returned+f.counts.notArrived,r.students.length);
  assert.equal(f.queueGroups.reduce((n,q)=>n+q.count,0),snap.waiting);
  for(const q of f.queueGroups)for(const id of q.queueIds){assert.equal(r.students[id].zone,q.zone);if(q.cohort!==null)assert.equal(r.students[id].grade,q.cohort);}
  for(const p of f.visibleDiningPeople.filter(p=>p.state==='dining')){
    const seat=f.layout.displaySeats[p.displaySeatId];assert.equal(seat.zone,p.zone);assert.equal(p.seatZone,p.zone);
  }
  const visible=f.visiblePeople.concat(f.visibleDiningPeople,f.departures);
  assert.equal(new Set(visible.map(p=>p.id)).size,visible.length);
  for(const p of visible){assert.ok(p.position.every(Number.isFinite));assert.ok(Number.isFinite(p.yaw));}
  assert.ok(f.visiblePeople.filter(p=>p.state==='waiting').length<=320);
  assert.ok(f.visibleDiningPeople.filter(p=>p.state==='dining').length<=72);
  assert.ok(f.visibleDiningPeople.filter(p=>p.state==='seat-waiting').length<=48);
  return f;
}
test('Binhe plan profile is independently reproducible and explicitly unmeasured',()=>{
  assert.equal(P.admissionPlans.reduce((n,p)=>n+p.plannedStudents,0),1610);
  assert.deepEqual(P.admissionPlans.map(p=>[p.year,p.plannedStudents]),[[2026,580],[2025,530],[2024,500]]);
  assert.equal(profile.sourceProfile.observedSchoolData,false);
  assert.equal(P.evidence.filter(e=>e.level==='official-plan').length,3);
  assert.ok(P.assumptions.some(a=>a.field==='grades.students'&&a.note.includes('100%')));
  const changed=P.createConfig();changed.grades[0].students=1;changed.serviceZones[0].seats=1;
  assert.equal(P.createConfig().grades[0].students,580);assert.equal(P.createConfig().serviceZones[0].seats,480);
});
test('zone FCFS queues show exact zone membership and hide future window assignments',()=>{
  const r=E.simulate(profile);
  for(const t of [0,35,45,55,65,r.metrics.observationEnd]){
    const f=checkFrame(r,t);assert.equal(f.layout.zonePools,true);assert.equal(f.queueGroups.length,2);
    assert.deepEqual(f.queueGroups.map(q=>q.queueIds),f.snapshot.zoneQueueIds);
    for(const p of f.people.filter(p=>p.state==='waiting'))assert.equal(p.window,null);
    for(const w of f.windows)assert.equal(w.zone,r.config.windowZones[w.id]);
  }
});
test('zone-by-grade priority pools remain distinct for dedicated and overflow modes',()=>{
  for(const allocation of ['dedicated','overflow']){
    const r=E.simulate({...profile,allocation,strategy:allocation==='overflow'?'shortest':'pooled'}),f=checkFrame(r,55);
    assert.equal(f.queueGroups.length,6);assert.equal(f.layout.queues.length,6);
    for(const q of f.queueGroups){assert.equal(q.id,`zone-${q.zone}-grade-${q.cohort}`);assert.deepEqual(q.queueIds,f.snapshot.zoneGradeQueueIds[q.zone][q.cohort]);}
  }
});
test('independent window queues retain their actual zone and own waiting identities',()=>{
  for(const strategy of ['shortest','workload','random']){
    const r=E.simulate({...profile,strategy}),f=checkFrame(r,55);
    assert.equal(f.layout.zonePools,false);assert.equal(f.layout.zoned,true);assert.equal(f.queueGroups.length,16);
    for(const q of f.queueGroups){assert.equal(q.zone,profile.windowZones[q.window]);assert.deepEqual(q.queueIds,f.snapshot.windows[q.window].queueIds);}
  }
});
test('independent logical seats map to their own zone and stay fixed until meal completion',()=>{
  const c={...profile,seats:160,serviceZones:profile.serviceZones.map(z=>({...z,seats:z.id?40:120}))},r=E.simulate(c);
  const a=checkFrame(r,70),b=checkFrame(r,70.01),map=new Map(b.visibleDiningPeople.map(p=>[p.id,p]));
  assert.ok(a.counts.seatWaiting>0);assert.ok(a.sampling.description.includes('不跨区借座'));
  let checked=0;
  for(const p of a.visibleDiningPeople.filter(p=>p.state==='dining'))if(map.get(p.id)?.state==='dining'){
    const q=map.get(p.id);assert.deepEqual(p.position,q.position);assert.equal(p.displaySeatId,q.displaySeatId);checked++;
  }
  assert.ok(checked>10);
  const waitingZones=new Set(a.visibleDiningPeople.filter(p=>p.state==='seat-waiting').map(p=>p.zone));assert.deepEqual([...waitingZones].sort(),[0,1]);
});
test('four zones and twelve grade pools keep every nonempty head within the shared drawing budget',()=>{
  const c={...profile,windows:12,windowMeans:Array(12).fill(40),windowOwners:Array.from({length:12},(_,i)=>i%3),allocation:'overflow',serviceZones:Array.from({length:4},(_,i)=>({id:i,name:'区'+i,seats:160,walkExtra:i,returnExtra:i/2})),windowZones:Array.from({length:12},(_,i)=>Math.floor(i/3)),gradeZoneWeights:Array.from({length:3},()=>[1,1,1,1])};
  const r=E.simulate(c),f=checkFrame(r,60);assert.equal(f.queueGroups.length,12);
  for(const q of f.queueGroups)if(q.count){assert.equal(q.visibleIds[0],q.queueIds[0]);assert.ok(q.visibleCount>=1);}
  for(const p of f.visiblePeople)assert.ok(p.position[0]>f.layout.bounds.minX&&p.position[0]<f.layout.bounds.maxX);
});
test('reverse seek and A/B common scales preserve zone identities without editing the result',()=>{
  const r=E.simulate(profile),before=JSON.stringify(r),f=checkFrame(r,55);
  checkFrame(r,100);checkFrame(r,20);assert.deepEqual(checkFrame(r,55),f);assert.equal(JSON.stringify(r),before);
  const b=E.simulate(E.makeSchoolBaseline(profile)),opts={peoplePerFigure:4,seatsPerFigure:640/72};
  for(const result of [r,b]){const frame=S.frame(result,55,null,null,opts);assert.equal(frame.sampling.requestedPeoplePerFigure,4);assert.equal(frame.zoneStates.length,2);}
});
