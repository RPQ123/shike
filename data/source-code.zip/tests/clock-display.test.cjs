const test = require('node:test');
const assert = require('node:assert/strict');
const R = require('../dist/research.js');

test('display clock retains elapsed days when overload runs past midnight', () => {
  assert.equal(R.clockLabel(30), '11:50:00');
  assert.equal(R.clockLabel(760), '+1天 00:00:00');
  assert.equal(R.clockLabel(2200, false), '+2天 00:00');
  assert.equal(R.clockLabel(759.9999), '+1天 00:00:00');
});
