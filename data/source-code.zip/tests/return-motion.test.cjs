const test=require('node:test'),assert=require('node:assert/strict');
const E=require('../dist/school-engine.js'),S=require('../dist/scene-state.js');
const config=require('../data/schedule-study-session.json').config;
const result=E.simulateSchool(config),layout=S.createLayoutForResult(result);
test('return walking uses the same student pace as counter-to-seat walking',()=>{
  const s=result.students.slice().sort((a,b)=>a.mealEnd-b.mealEnd)[0];
  const a=S.frame(result,s.mealEnd,layout).departures.find(p=>p.id===s.id);
  const b=S.frame(result,s.mealEnd+1/60,layout).departures.find(p=>p.id===s.id);
  assert.ok(a&&b);
  const pace=config.indoorWalkSpeed*(.94+(s.id%13)*.01);
  assert.ok(Math.abs((b.routeDistance-a.routeDistance)-pace)<1e-7);
  const leaveTime=s.mealEnd+S.samplePath(a.route,1).length/pace/60;
  assert.ok(leaveTime<s.returnTime);
  const outside=S.frame(result,leaveTime+1e-5,layout);
  assert.equal(outside.departures.some(p=>p.id===s.id),false);
  assert.equal(outside.counts.returning,E.snapshot(result,leaveTime+1e-5).returning);
});
test('return seeks are deterministic and never alter computation records',()=>{
  const before=JSON.stringify(result),t=result.students[10].mealEnd+1/60;
  const first=S.frame(result,t,layout);S.frame(result,0,layout);
  assert.deepEqual(S.frame(result,t,layout),first);
  assert.equal(JSON.stringify(result),before);
});
