const test=require('node:test');
const assert=require('node:assert/strict');
const E=require('../dist/school-engine.js');
const B=require('../dist/binhe-cohort.js');
const Scene=require('../dist/scene-state.js');
const fixture=(extra={})=>E.simulate({...B.create(),indoorWalkSpeed:1.1,...extra});

test('pickup, walk, seat and meal have separate chronological events',()=>{
 const r=fixture();
 for(const s of r.students){
  assert.ok(s.seatWalkStart>=s.end);
  assert.ok(s.seatStart>s.seatWalkStart);
  assert.ok(s.seatStart>=s.end+s.indoorWalk-1e-9);
  assert.equal(s.mealEnd,s.seatStart+s.mealDuration);
  assert.ok(Math.abs(s.seatStart-s.end-s.indoorWalk-s.seatWait)<1e-9);
 }
});
test('the window-to-table journey is a visible carrying state and seeks deterministically',()=>{
 const r=fixture(),p=r.students.slice().sort((a,b)=>a.end-b.end)[0],t=(p.seatWalkStart+p.seatStart)/2;
 const a=Scene.frame(r,t),person=a.visibleDiningPeople.find(x=>x.id===p.id);
 assert.ok(person);assert.equal(person.state,'walking-to-seat');
 assert.ok(person.route.length>=4);assert.ok(person.routeDistance>0);
 assert.notDeepEqual(person.position,a.layout.displaySeats[person.displaySeatId].position);
 Scene.frame(r,t+10);assert.deepEqual(Scene.frame(r,t),a);
 assert.equal(Scene.frame(r,p.seatStart).diningPeople.find(x=>x.id===p.id).state,'dining');
});
test('all completed pickups occupy exactly one post-pickup stage',()=>{
 const r=fixture({seats:80});
 for(const t of [35,40,50,60,80,110]){
  const s=E.snapshot(r,t),f=Scene.frame(r,t);
  assert.equal(s.completed,s.walkingToSeat+s.seatWaiting+s.dining+s.returning+s.returned);
  assert.equal(f.counts.walkingToSeat,s.walkingToSeat);
  assert.equal(f.counts.dining,s.dining);
  assert.equal(f.counts.seatWaiting,s.seatWaiting);
  const visible=f.visiblePeople.concat(f.visibleDiningPeople,f.departures);
  assert.equal(new Set(visible.map(p=>p.id)).size,visible.length);
 }
});
test('a reserved seat is never allocated to another student before departure',()=>{
 const r=fixture({seats:12});const groups=new Map();
 for(const s of r.students){if(!groups.has(s.seatId))groups.set(s.seatId,[]);groups.get(s.seatId).push(s)}
 for(const list of groups.values()){
  list.sort((a,b)=>a.seatWalkStart-b.seatWalkStart);
  for(let i=1;i<list.length;i++)assert.ok(list[i].seatWalkStart>=list[i-1].mealEnd);
 }
});
test('doubling walking speed shortens the same routes and never changes window service',()=>{
 const slow=fixture(),fast=fixture({indoorWalkSpeed:2.2});
 for(let i=0;i<slow.students.length;i++){
  const a=slow.students[i],b=fast.students[i];assert.equal(a.start,b.start);assert.equal(a.end,b.end);
 }
 const H=require('../dist/hall-walk.js'),hall=H.create(slow.config),s=slow.students[0];
 const a=H.plan(hall,s,0,s.end,1.1),b=H.plan(hall,s,0,s.end,2.2);
 assert.deepEqual(a.seatRoute,b.seatRoute);assert.ok(a.walkMinutes>b.walkMinutes);
});
test('zero indoor walking reproduces the frozen model numerical results',()=>{
 const old=require('../research/frozen-model-2.3.1/dist/school-engine.js');
 const OldB=require('../research/frozen-model-2.3.1/dist/binhe-cohort.js');
 const original=old.simulate(OldB.create()),updated=fixture({indoorWalkSpeed:0});
 for(let i=0;i<original.students.length;i++)for(const key of ['end','seatStart','seatWait','mealEnd','returnTime'])assert.equal(updated.students[i][key],original.students[i][key]);
});
test('routes from both banks stay outside tables, chairs and counter cabinets',()=>{
 const H=require('../dist/hall-walk.js'),c={...B.create(),indoorWalkSpeed:1.1},hall=H.create(c);
 const representatives=new Map();for(const [id,seat] of hall.seatMap)if(!representatives.has(seat.id))representatives.set(seat.id,id);
 assert.equal(representatives.size,c.seats);
 for(let window=0;window<c.windows;window++)for(const seatId of representatives.values()){
  const s={id:seatId,window,end:10};const target=hall.seatMap.get(seatId);
  const trips=[H.plan(hall,s,seatId,0,1.1),H.plan(hall,s,seatId,20,1.1)];
  for(const points of [trips[0].seatRoute,trips[1].seatRoute,trips[1].approachRoute])for(let i=1;i<points.length;i++){
   const a=points[i-1],b=points[i];
   for(let j=0;j<=30;j++){
    const x=a[0]+(b[0]-a[0])*j/30,z=a[2]+(b[2]-a[2])*j/30;
    assert.ok(Math.abs(x)<20.46,'route enters a counter cabinet');
    for(const t of hall.tables){assert.ok(!(Math.abs(x-t.position[0])<(t.width||1.96)/2+.08&&Math.abs(z-t.position[2])<.72),'route crosses tabletop');}
    for(const seat of new Set(hall.seatMap.values())){
     if(seat.id===target.id)continue;
     assert.ok(!(Math.abs(x-seat.position[0])<.26&&Math.abs(z-seat.position[2])<.28),'route crosses another chair');
    }
   }
  }
 }
});
test('visible students waiting for seats do not occupy the same waiting point',()=>{
 const r=fixture({seats:80});
 for(const t of [40,50,60]){
  const f=Scene.frame(r,t),waiters=f.visibleDiningPeople.filter(p=>p.state==='seat-waiting');
  const positions=waiters.map(p=>p.position[0]+','+p.position[2]);assert.equal(new Set(positions).size,positions.length);
 }
});
