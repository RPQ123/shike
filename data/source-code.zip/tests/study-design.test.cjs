const test=require('node:test'),assert=require('node:assert/strict');
const fs=require('node:fs'),path=require('node:path');
const file=path.join(__dirname,'../data/study-results.json');
test('population-only sensitivity does not silently change class count or release structure',()=>{
 const study=JSON.parse(fs.readFileSync(file,'utf8'));
 const base=study.contexts.find(c=>c.id==='primary').config;
 for(const context of study.contexts.filter(c=>c.id.startsWith('people-'))){
  assert.deepEqual(context.config.grades.map(g=>[g.classes,g.classInterval,g.releaseTime,g.readyTime]),base.grades.map(g=>[g.classes,g.classInterval,g.releaseTime,g.readyTime]));
 }
});
test('saved study respects seeds, counts and complete-time decomposition',()=>{
 const study=JSON.parse(fs.readFileSync(file,'utf8'));
 assert.equal(study.results.length,66);
 for(const row of study.results){
  assert.equal(row.rounds.length,30);
  for(const run of row.rounds){
   assert.ok(Math.abs(Object.values(run.flow).reduce((a,b)=>a+b,0)-run.meanTotal)<1e-8);
   assert.equal(run.grades.reduce((n,g)=>n+g.count,0),row.config.students);
  }
 }
 const s=study.candidateSearch.selection;
 assert.equal(new Set([...s.screenSeeds,...s.validationSeeds]).size,40);
});
