# 校园食堂方案比较软件 2.5.0

浏览器可直接打开dist/index.html，核心使用JavaScript。Python放行表工具仅用标准库。
Node.js运行：npm test（262项核心检查）；node tools/audit-schedule-study.cjs。
重做660次研究：node tools/run-schedule-study.cjs（会更新data/schedule-*研究记录）。
核对Python：python tools/student_schedule.py。
报告、协议与原始记录位于data。历史研究及冻结代码按原名称保存，与本次660次研究分别复核。
1610人为示例参数；各校修改人数、窗口、座位及时间后应重新比较。
