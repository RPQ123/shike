"""Render Word-exported student PDFs and bind page images to the exact files."""
from pathlib import Path
import hashlib,json,argparse
import pypdfium2 as pdfium
from PIL import Image,ImageDraw

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--document-dir',default='documents/student-edition')
parser.add_argument('--prefix',default='student')
args=parser.parse_args()
records=[]
for stem,label in [('研究报告_公文格式','report'),('软件使用与学生研究指南','guide')]:
    source=root/args.document_dir/(stem+'.pdf')
    folder=root/'qa'/(args.prefix+'-doc-render')/label
    folder.mkdir(parents=True,exist_ok=True)
    tiles=[]
    with pdfium.PdfDocument(source) as pdf:
        counts=[]
        for index,page in enumerate(pdf):
            picture=page.render(scale=1.3).to_pil()
            picture.save(folder/f'page-{index+1:02}.png')
            counts.append(len(page.get_textpage().get_text_range()))
            picture.thumbnail((300,440))
            tile=Image.new('RGB',(320,470),'#dddddd')
            tile.paste(picture,((320-picture.width)//2,10))
            ImageDraw.Draw(tile).text((10,450),f'{label} page {index+1}',fill='black')
            tiles.append(tile)
        sheet=Image.new('RGB',(1280,470*((len(tiles)+3)//4)),'white')
        for index,tile in enumerate(tiles):sheet.paste(tile,((index%4)*320,(index//4)*470))
        sheet.save(folder/'contact.png')
        records.append({'file':source.relative_to(root).as_posix(),'pages':len(pdf),'pageCharacters':counts,'pdfSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'docxSha256':hashlib.sha256(source.with_suffix('.docx').read_bytes()).hexdigest()})
(root/'qa'/(args.prefix+'-document-render.json')).write_text(json.dumps(records,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(records,ensure_ascii=True))
