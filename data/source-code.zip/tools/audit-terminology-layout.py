"""Regression checks for precise terms and Word's character-indent precedence."""
from pathlib import Path
import json,re,hashlib,argparse
from docx import Document
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--document-dir',default='documents/terminology-edition')
parser.add_argument('--prefix',default='terminology')
args=parser.parse_args()
folder=root/args.document_dir
report=Document(folder/'研究报告_公文格式.docx')
old=Document(root/'documents/visual-edition/研究报告_公文格式.docx')
text='\n'.join(p.text for p in report.paragraphs)
assert '学校在实际进行学生就餐方案调整时' in text
assert '（一）参数设置' in text
for term in ['比较用的设置','比较用的安排','学校试行时','试行时','实验设置','窗口和座位分别影响哪里']:
    assert term not in text,term

captions=[p for p in report.paragraphs if re.match(r'^[图表]\d+\s',p.text)]
equations=[p for p in report.paragraphs if p._p.xpath('.//m:oMath') or (p.alignment==WD_ALIGN_PARAGRAPH.CENTER and '＝' in p.text)]
images=[p for p in report.paragraphs if p._p.xpath('.//w:drawing')]
cells=[p for t in report.tables for row in t.rows for cell in row.cells for p in cell.paragraphs]
assert len(captions)==10 and len(equations)==4 and len(images)==4
for p in captions+equations+images+cells:
    ind=p._p.get_or_add_pPr().find(qn('w:ind'))
    assert ind is not None,(p.text,'missing explicit indent override')
    assert ind.get(qn('w:firstLine'))=='0' and ind.get(qn('w:firstLineChars'))=='0',p.text
    assert all(v=='0' for v in ind.attrib.values()),(p.text,dict(ind.attrib))
for p in captions+equations+images:assert p.alignment==WD_ALIGN_PARAGRAPH.CENTER,p.text
body=next(p for p in report.paragraphs if p.text.startswith('本研究以'))
assert body._p.get_or_add_pPr().find(qn('w:ind')).get(qn('w:firstLineChars'))=='200'
for t in report.tables:
    ind=t._tbl.tblPr.find(qn('w:tblInd'));assert ind.get(qn('w:w'))=='0'

# Only the inaccurate parameter-column label changes inside existing tables.
oldcells=[[[c.text for c in row.cells] for row in t.rows] for t in old.tables]
newcells=[[[c.text for c in row.cells] for row in t.rows] for t in report.tables]
oldcells[1][0][1]='参数设置'
assert oldcells==newcells
for a,b in zip(old.inline_shapes,report.inline_shapes):
    read=lambda d,s:d.part.related_parts[s._inline.graphic.graphicData.pic.blipFill.blip.embed].blob
    assert read(old,a)==read(report,b)
guide=Document(folder/'软件使用与学生研究指南.docx')
assert '实验设置' not in '\n'.join(p.text for p in guide.paragraphs)
result={'passed':True,'captionsCenteredWithoutIndent':len(captions),'equationsCenteredWithoutIndent':len(equations),
 'imagesCenteredWithoutIndent':len(images),'tableCellParagraphsWithoutIndent':len(cells),
 'bodyFirstLineCharacters':2,'numericalTablesUnchanged':True,'figureImageBytesUnchanged':True,
 'parameterColumnHeader':'参数设置','schoolImplementationLanguage':'学校在实际进行学生就餐方案调整时',
 'docxSha256':hashlib.sha256((folder/'研究报告_公文格式.docx').read_bytes()).hexdigest()}
(root/'qa'/f'{args.prefix}-layout-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
