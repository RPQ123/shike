from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from matplotlib import transforms
from matplotlib.ticker import FuncFormatter

root=Path(__file__).resolve().parents[1];out=root/'figures/student'
s=json.loads((root/'data/schedule-study-results.json').read_text('utf-8'))
plt.rcParams.update({'font.family':'FangSong','font.size':12,'svg.fonttype':'none','pdf.fonttype':42,
 'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#B7C7C8','axes.labelcolor':'#294D50','text.color':'#294D50','xtick.color':'#5B7475','ytick.color':'#3E5C60'})
def save(fig,name):
    for ext in ['png','pdf','svg']:fig.savefig(out/(name+'.'+ext),dpi=400,facecolor='white')
    plt.close(fig)
rows=s['initial'];fig,ax=plt.subplots(figsize=(6.6,3.3));fig.subplots_adjust(left=.25,right=.75,top=.79,bottom=.19)
labels=['不实行错峰','仅按年级错峰','年级与班级\n结合错峰'];values=np.array([r['summary']['meanWait'] for r in rows]);lo=np.array([min(v['meanWait'] for v in r['rounds']) for r in rows]);hi=np.array([max(v['meanWait'] for v in r['rounds']) for r in rows]);y=np.arange(3)
ax.barh(y,values,height=.46,color=['#A6B6C0','#557B98','#168C80']);ax.errorbar(values,y,xerr=[values-lo,hi-values],fmt='none',ecolor='#355468',elinewidth=.8,capsize=2.5)
ax.set(yticks=y,yticklabels=labels,xlim=(0,18),xticks=[0,5,10,15],ylim=(-.6,2.6),xlabel='平均排队 / 分钟');ax.invert_yaxis();ax.spines.left.set_visible(False);ax.tick_params(axis='y',length=0,pad=9)
for label in ax.get_yticklabels():label.set_fontweight('bold')
for i,v in enumerate(values):ax.text(hi[i]+.4,i,f'{v:.2f}',ha='left',va='center',fontsize=14,fontweight='bold',color='#168C80' if i==2 else '#294D50')
blend=transforms.blended_transform_factory(ax.transAxes,ax.transData)
for i,r in enumerate(rows):ax.text(1.30,i,f'{r["summary"]["meanTotal"]:.2f}',transform=blend,ha='center',va='center',fontweight='bold',fontsize=13)
fig.text(.25,.91,'第一阶段 · 三种安排',fontweight='bold',fontsize=14);fig.text(.90,.91,'完整用时',ha='center',fontsize=12,fontweight='bold');fig.text(.90,.83,'分钟',ha='center',fontsize=11)
save(fig,'20-three-arrangements')

rows=s['intervals'];x=np.array([r['seconds'] for r in rows]);wait=np.array([r['summary']['meanWait'] for r in rows]);last=np.array([r['summary']['lastEndpointMax'] for r in rows]);chosen=s['selectedSeconds'];ix=list(x).index(chosen)
fig,(a,b)=plt.subplots(2,1,sharex=True,figsize=(6.6,5.3));fig.subplots_adjust(left=.15,right=.94,top=.91,bottom=.13,hspace=.30)
for ax in [a,b]:ax.spines.left.set_visible(False);ax.tick_params(axis='y',length=0);ax.grid(axis='y',color='#E5ECEA',lw=.7);ax.axvline(chosen,color='#78ADA3',lw=1,ls=':',zorder=1)
a.plot(x,wait,color='#168C80',lw=1.8,marker='o',markersize=4);a.scatter([chosen],[wait[ix]],s=65,facecolor='white',edgecolor='#168C80',linewidth=2,zorder=4);a.set(ylabel='平均排队 / 分钟',ylim=(-.8,17),yticks=[0,5,10,15]);a.text(chosen+3,wait[ix]+1.3,f'{wait[ix]:.2f}分钟',fontweight='bold',fontsize=12)
b.plot(x,last,color='#557B98',lw=1.5,zorder=2);ok=last<=s['protocol']['returnTarget'];b.scatter(x[ok],last[ok],color='#168C80',s=22,label='满足返回目标',zorder=3);b.scatter(x[~ok],last[~ok],color='#BA8B4E',s=22,label='晚于返回目标',zorder=3);b.axhline(s['protocol']['returnTarget'],color='#A88B63',ls='--',lw=1);b.set(ylabel='最晚一次返回',xlabel='相邻组出发间隔 / 秒',xticks=[0,15,30,45,60,70,90,105,120],yticks=[90,100,110,120,130],ylim=(84,133),xlim=(-3,124))
b.yaxis.set_major_formatter(FuncFormatter(lambda v,pos:f'{int((680+v)//60):02}:{int((680+v)%60):02}'));b.legend(loc='upper left',frameon=False,fontsize=10.5,handlelength=1)
fig.text(.15,.965,'第二阶段 · 出发间隔比较',fontweight='bold',fontsize=14);b.text(chosen,85.5,f'{chosen}秒',ha='center',fontweight='bold',fontsize=12,color='#168C80')
save(fig,'21-group-intervals')
receipt={'passed':True,'source':'data/schedule-study-results.json','groups':3,'intervals':13,'initialExecutions':90,'intervalExecutions':390,'selectedSeconds':chosen,'font':'FangSong','uncertainty':'meanWait minimum and maximum of 30 runs; lower panel shows latest individual endpoint over all 30 interval runs','figures':['20-three-arrangements','21-group-intervals']}
(root/'qa/schedule-figures.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
