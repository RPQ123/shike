"""Deliver the reviewed revision using one consistent report inside the archive."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib
root=Path(__file__).resolve().parents[1]
out=root.parent/'【成品】提交材料'
qa=root/'qa'
audit=json.loads((qa/'prose-final-audit.json').read_text('utf-8'))
assert audit['passed']
visual={
 'passed':True,'reportPages':13,'guidePages':2,'formsPages':{'application':4,'novelty':5,'process':1},
 'reviewed':'All report, guide and revised form pages inspected at full page size',
 'layout':'Retained template typography, section geometry and page furniture; no clipping or missing paragraphs',
 'reportPdfSha256':audit['checks'][-1]['sha256']
}
(qa/'prose-visual-review.json').write_text(json.dumps(visual,ensure_ascii=False,indent=2),encoding='utf-8')
design=json.loads((qa/'design-document-render.json').read_text('utf-8'))
(qa/'design-visual-review.json').write_text(json.dumps({'passed':True,'pages':[13,2],'files':design,'review':'All 15 pages inspected'},ensure_ascii=False,indent=2),encoding='utf-8')
old=json.loads((qa/'prose-before-20261019/submission-final-audit.json').read_text('utf-8'))
current={**audit,'visualReview':visual,'reportPdf':'04-研究报告_语言修订.pdf','retainedEarlierPdf':'04-研究报告.pdf (open in another process; the revision is delivered separately)','remainingItems':old['remainingItems']}
(qa/'submission-materials/final-audit.json').write_text(json.dumps(current,ensure_ascii=False,indent=2),encoding='utf-8')
files={}
for f in out.rglob('*'):
    if not f.is_file() or f.name=='04-研究报告_语言修订.pdf':continue
    name=f.relative_to(out).as_posix()
    files[name]=(root/'documents/plain-language-edition/研究报告_公文格式.pdf').read_bytes() if name=='04-研究报告.pdf' else f.read_bytes()
assert len(files)==16
sha=lambda raw:hashlib.sha256(raw).hexdigest()
assert sha(files['04-研究报告.pdf'])==audit['checks'][-1]['sha256']
target=root/'release/packages/校园食堂研究_语言修订版_提交材料.zip'
with ZipFile(target,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
with ZipFile(target) as z:
    assert z.testzip() is None
    assert all(z.read(name)==raw for name,raw in files.items())
receipt={'passed':True,'file':str(target),'bytes':target.stat().st_size,'sha256':sha(target.read_bytes()),'entries':{name:sha(raw) for name,raw in files.items()},'reportInsideArchive':'04-研究报告.pdf is the revised 13-page report'}
(qa/'prose-package.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'file':str(target),'bytes':target.stat().st_size,'entries':len(files)},ensure_ascii=False))
