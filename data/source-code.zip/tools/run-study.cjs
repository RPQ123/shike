// Predefined synthetic experiment batch. See research/experiment-protocol.json.
const fs = require('node:fs');
const crypto = require('node:crypto');
const E = require('../dist/school-engine.js');
const R = require('../dist/research.js');
const protocol = JSON.parse(fs.readFileSync('research/experiment-protocol.json','utf8'));
const start = new Date().toISOString();
const hash = x => crypto.createHash('sha256').update(typeof x === 'string' ? x : JSON.stringify(x)).digest('hex');
const seeds = ({start,count}) => Array.from({length:count},(_,i)=>start+i);
const average = xs => xs.reduce((s,x)=>s+x,0)/xs.length;
const policies = ['sync','gap2','gap4','twoThirdsA','fiveSixthsA','pooled'];

function resize(c, n, windows=c.windows, seats=c.seats, rescaleClasses=false) {
  c.students=n;
  c.grades.forEach((g,i)=>{g.students=Math.floor(n/3)+(i<n%3?1:0);if(rescaleClasses)g.classes=Math.max(1,Math.ceil(g.students/40));g.classSizes=null;});
  c.windows=windows;c.windowMeans=Array(windows).fill(c.serviceMean);c.windowOwners=Array.from({length:windows},(_,i)=>Math.min(2,Math.floor(i*3/windows)));
  c.windowZones=Array.from({length:windows},(_,i)=>i<Math.ceil(windows/2)?0:1);
  c.seats=seats;c.serviceZones[0].seats=Math.round(seats*.75);c.serviceZones[1].seats=seats-c.serviceZones[0].seats;
  return E.normalizeSchoolConfig(c);
}
function contexts() {
  const rows=[{id:'primary',label:'教学基准',config:R.example()}];
  for(const seats of protocol.sensitivity.seats)rows.push({id:'seats-'+seats,label:'座位数 '+seats,config:resize(R.example(),360,6,seats)});
  for(const mean of protocol.sensitivity.serviceMeanSeconds){const c=R.example();c.serviceMean=mean;c.windowMeans=Array(c.windows).fill(mean);rows.push({id:'service-'+mean,label:'服务均值 '+mean+'秒',config:c})}
  for(const share of protocol.sensitivity.mealAPreference){const c=R.example();c.gradeZoneWeights=Array.from({length:3},()=>[share,1-share]);rows.push({id:'share-'+share,label:'A类比例 '+share,config:c})}
  for(const n of protocol.sensitivity.students)rows.push({id:'people-'+n,label:'人数 '+n,config:resize(R.example(),n)});
  for(const c of protocol.sensitivity.scaleScenarios)rows.push({id:'scale-'+c.students,label:'规模压力场景 '+c.students,config:resize(R.example(),c.students,c.windows,c.seats,true)});
  return rows;
}
function policy(input, id) {
  let c=E.makeSchoolGapConfig(input,id==='sync'?0:id==='gap4'?4:2);
  if(id==='twoThirdsA'||id==='fiveSixthsA'){
    const a=Math.min(c.windows-1,Math.ceil(c.windows*(id==='twoThirdsA'?2/3:5/6)));
    c.windowZones=Array.from({length:c.windows},(_,i)=>i<a?0:1);
  }
  if(id==='pooled')c.strategy='pooled';
  return E.normalizeSchoolConfig(c);
}
function record(config, seed) {
  const result=E.simulateSchool({...config,seed}),r=R.metrics(result),people=result.students;
  const mean=fn=>average(people.map(fn));
  const flow={releaseDelay:mean(s=>s.releaseDelay),walking:mean(s=>s.assembly+s.walk+s.arrivalJitter+s.zoneWalk),queue:r.meanWait,service:mean(s=>s.service),seatWait:r.seatWait,meal:mean(s=>s.mealDuration),return:mean(s=>s.endpointTime-s.mealEnd)};
  const sum=Object.values(flow).reduce((a,b)=>a+b,0);
  if(Math.abs(sum-r.meanTotal)>1e-8)throw new Error('Flow decomposition mismatch');
  return {seed,...r,flow,grades:result.gradeMetrics.map(g=>({id:g.id,count:g.count,meanWait:g.meanWait,meanTotal:g.meanReadyToEndpoint,onTime:g.onTimeRate})),warnings:result.validityWarnings.map(w=>w.code||w.message)};
}
const scenarioRows=contexts(), results=[],comparisons=[],flat=[];
fs.mkdirSync('data',{recursive:true});
for(const context of scenarioRows){
  const local=[];
  for(const id of policies){
    const config=policy(context.config,id),rounds=seeds(protocol.mainSeeds).map(seed=>record(config,seed));
    const row={context:context.id,label:context.label,policy:id,config,configSha256:hash(config),rounds,summary:R.summarize(rounds.map(({seed,flow,grades,warnings,...m})=>m))};
    local.push(row);results.push(row);
    for(const r of rounds){const {flow,grades,warnings,...m}=r;flat.push({context:context.id,policy:id,...m,...Object.fromEntries(Object.entries(flow).map(([k,v])=>['flow_'+k,v])),...Object.fromEntries(grades.map(g=>['grade'+g.id+'_meanTotal',g.meanTotal]))})}
  }
  const reference=local.find(x=>x.policy==='gap2');
  for(const row of local){const differences={};for(const key of ['meanTotal','meanWait','p95Wait','gradeGap'])differences[key]=R.paired(reference.rounds.map(r=>r[key]),row.rounds.map(r=>r[key]));comparisons.push({context:context.id,policy:row.policy,reference:'gap2',differences})}
  console.log('Completed context '+context.id);
}
const base=R.example(),candidateSet=R.candidates(base,{reallocate:true});
const screenSeeds=seeds(protocol.candidateSelection.screeningSeeds),validationSeeds=seeds(protocol.candidateSelection.validationSeeds);
const screened=candidateSet.accepted.map(item=>({...item,...R.evaluate(item.config,screenSeeds)}));
const front=R.pareto(screened).sort((a,b)=>a.meanTotal-b.meanTotal||a.meanWait-b.meanWait||a.id.localeCompare(b.id));
const selected=front[0];
const selection={at:new Date().toISOString(),criterion:protocol.candidateSelection.selection,candidateId:selected.id,configSha256:hash(selected.config),screenSeeds,validationSeeds};
// Freeze selected id on disk BEFORE inspecting held-out outcomes.
fs.writeFileSync('data/frozen-selection.json',JSON.stringify(selection,null,2));
const validation=R.compare(base,selected.config,validationSeeds);
const output={schema:'dining-study/2',evidence:'synthetic',startedAt:start,finishedAt:new Date().toISOString(),modelVersion:E.VERSION,researchVersion:R.VERSION,protocolSha256:hash(protocol),modelSha256:hash(fs.readFileSync('dist/school-engine.js','utf8')),protocol,contexts:scenarioRows,results,comparisons,candidateSearch:{screened,front:front.map(x=>x.id),rejected:candidateSet.rejected,selection,validation}};
output.sourceHashes=Object.fromEntries(['dist/engine.js','dist/school-engine.js','dist/research.js','tools/run-study.cjs'].map(file=>[file,hash(fs.readFileSync(file,'utf8'))]));
fs.writeFileSync('data/study-results.json',JSON.stringify(output));
fs.writeFileSync('data/study-rounds.csv',R.csv(flat));
fs.writeFileSync('data/study-summary.json',JSON.stringify({startedAt:start,finishedAt:output.finishedAt,mainRuns:flat.length,screeningRuns:screened.length*screenSeeds.length,validationRuns:validationSeeds.length*2,selected:selection.candidateId,primary:results.filter(x=>x.context==='primary').map(x=>({policy:x.policy,...x.summary})),validation:validation.differences},null,2));
console.log(JSON.stringify({mainRuns:flat.length,screeningRuns:250,validationRuns:60,selected:selection.candidateId,finishedAt:output.finishedAt}));
