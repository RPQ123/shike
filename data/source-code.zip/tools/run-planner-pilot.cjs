// Exploratory development pilot; not a held-out result or formal final selection.
const fs=require('node:fs'),crypto=require('node:crypto');
const P=require('../dist/planner.js'),E=require('../dist/school-engine.js'),R=require('../dist/research.js');
const sourceHashes=Object.fromEntries(['dist/planner.js','dist/school-engine.js','dist/research.js'].map(p=>[p,crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')]));
const config=R.example(),seeds=[220001,220002,220003],set=P.candidates(config);
const rows=set.accepted.map(plan=>{
 const rounds=seeds.map(seed=>R.metrics(E.simulateSchool({...plan.config,seed})));
 return {...plan,rounds,summary:R.summarize(rounds)};
});
const reference=rows.find(x=>x.id==='reference'),selection=P.choose(rows,reference,{meanAllowance:.5,peakAllowance:0});
const report={at:new Date().toISOString(),scope:'Exploratory pilot observed before the formal protocol; do not count as unseen validation',sourceHashes,seeds,candidates:rows.length,modelExecutions:rows.length*seeds.length,rejected:set.rejected,rows,selection:Object.fromEntries(['efficiency','lowPeak','balanced'].map(k=>[k,selection[k].id]))};
fs.writeFileSync('qa/innovation-pilot.json',JSON.stringify(report,null,2));
console.log(JSON.stringify({candidates:rows.length,modelExecutions:report.modelExecutions,choices:Object.fromEntries([['reference',reference],...['efficiency','lowPeak','balanced'].map(k=>[k,selection[k]])].map(([k,row])=>[k,{id:row.id,meanTotal:row.summary.meanTotal,worstGrade:row.summary.worstGrade,peakQueue:row.summary.peakQueue}]))},null,2));
