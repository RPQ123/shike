"""Fetch primary-source metadata and lawful reading copies for the scheduling extension."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import hashlib
import json
import urllib.request
import urllib.error

ROOT=Path(__file__).resolve().parents[1]
HEADERS={'User-Agent':'DiningLab-student-research/2.2 (source verification)','Accept':'application/json'}
TASKS=[
 ('fair-timetable','https://api.crossref.org/works/10.1007/s10479-014-1553-2','crossref'),
 ('fair-over-time','https://api.crossref.org/works/10.1007/s10107-022-01904-6','crossref'),
 ('dynamic-servers','https://api.crossref.org/works?query.title=Dynamic%20Server%20Allocation%20at%20Parallel%20Queues&rows=2','crossref-search'),
 ('ortools','https://api.github.com/repos/google/or-tools','github'),
 ('fairpy','https://api.github.com/repos/erelsgl/fairpy','github'),
 ('lodi-pdf','https://arxiv.org/pdf/2101.03716','pdf'),
 ('timetable-pdf','https://arxiv.org/pdf/1303.2860','pdf'),
 ('temporal-pdf','https://arxiv.org/pdf/2410.23416','pdf')]

def fetch(task):
    key,url,kind=task
    record={'id':key,'url':url,'kind':kind}
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers=HEADERS),timeout=35) as r:
            blob=r.read();record.update(status=r.status,bytes=len(blob),sha256=hashlib.sha256(blob).hexdigest(),contentType=r.headers.get('Content-Type'))
        if kind=='pdf':
            assert blob.startswith(b'%PDF'),'Expected actual PDF bytes'
            path=ROOT/'research'/('innovation-'+key+'.pdf');path.write_bytes(blob)
            from pypdf import PdfReader
            reader=PdfReader(path)
            record.update(localReadingCopy=path.name,pages=len(reader.pages),readingScope='Retrieved and text-extracted; method reading documented separately')
            print(json.dumps({'id':key,'pages':len(reader.pages),'openingText':reader.pages[0].extract_text()[:1700]},ensure_ascii=True))
        else:
            data=json.loads(blob)
            if kind.startswith('crossref'):record['metadata']=data.get('message',data)
            else:
                record['metadata']={k:data.get(k) for k in ['full_name','html_url','description','default_branch','pushed_at','license']}
                branch=data['default_branch']
                for suffix in ['commits/'+branch,'readme']:
                    endpoint=url+'/'+suffix
                    try:
                        with urllib.request.urlopen(urllib.request.Request(endpoint,headers=HEADERS),timeout=25) as r: extra=json.load(r)
                        if suffix.startswith('commits'):record['commit']=extra['sha']
                        else:
                            import base64
                            text=base64.b64decode(extra.get('content','')).decode('utf8',errors='replace')
                            record['readme']={'sha':extra.get('sha'),'bytes':len(text.encode('utf8')),'url':extra.get('html_url')}
                            print(json.dumps({'id':key,'readmeOpening':text[:1200]},ensure_ascii=True))
                    except Exception as error:record[suffix+'Error']=str(error)
    except Exception as error:record.update(status='failed',error=str(error))
    return record

with ThreadPoolExecutor(max_workers=4) as pool: records=list(pool.map(fetch,TASKS))
out={'retrievedAt':datetime.now(timezone.utc).isoformat(),'purpose':'Targeted scheduling and temporal fairness research; not systematic review','records':records}
(ROOT/'research/innovation-retrieval.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'retrievals':[{k:r.get(k) for k in ['id','status','pages','error']} for r in records]},ensure_ascii=True))
