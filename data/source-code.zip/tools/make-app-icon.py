"""Render the app's warm clay text mark as a Windows icon."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
fonts = [Path('C:/Windows/Fonts/msyhbd.ttc'), Path('C:/Windows/Fonts/simhei.ttf')]
font_file = next((p for p in fonts if p.is_file()), None)
if font_file is None:
    raise FileNotFoundError('Regeneration needs an installed Microsoft YaHei Bold or SimHei font; use the supplied ICO for ordinary builds.')
scale = 4
canvas = Image.new('RGBA', (256*scale,256*scale))
draw = ImageDraw.Draw(canvas)
draw.rounded_rectangle((8*scale,8*scale,248*scale,248*scale), radius=55*scale, fill='#b65a3e')
font = ImageFont.truetype(str(font_file), 174*scale)
bounds = draw.textbbox((0,0),'食',font=font)
draw.text(((256*scale-(bounds[2]-bounds[0]))/2-bounds[0],
           (256*scale-(bounds[3]-bounds[1]))/2-bounds[1]-3*scale),'食',font=font,fill='white')
canvas = canvas.resize((256,256),Image.Resampling.LANCZOS)
canvas.save(root/'desktop/DiningLab.ico',sizes=[(n,n) for n in [16,24,32,48,64,128,256]])
canvas.save(root/'desktop/icon-preview.png')
print('Created desktop/DiningLab.ico and icon-preview.png from the existing app mark.')
