"""Check prose, numerical tables, template fidelity and rendered Word output."""
from pathlib import Path
from zipfile import ZipFile
from docx import Document
from lxml import etree as E
from PIL import Image,ImageDraw
import pypdfium2 as pdfium
import hashlib,json,re,unicodedata,subprocess

root=Path(__file__).resolve().parents[1];base=root.parent
out=base/'【成品】提交材料';qa=root/'qa'
sha=lambda b:hashlib.sha256(b).hexdigest()
norm=lambda s:re.sub(r'\s+','',unicodedata.normalize('NFKC',s))
folder=root/'documents/plain-language-edition'
report=Document(folder/'研究报告_公文格式.docx')
old=Document(qa/'prose-before-20261019/design-edition/研究报告_公文格式.docx')
assert [[[c.text for c in row.cells] for row in t.rows] for t in report.tables]==[[[c.text for c in row.cells] for row in t.rows] for t in old.tables]
assert len(report.inline_shapes)==4 and len(report.tables)==7
text='\n'.join(p.text for p in report.paragraphs)
for word in ['需要强调的是','值得注意的是','这并不意味着','不能简单地','并非','遗憾的是','仍明显落后','实测表明','已在学校应用','独立完成']:
    assert word not in text,word
assert '高一至高三年级学生的平均就餐排队时间' in text
assert '每轮排队最多人数的平均值' in text
assert '平均完整用时' in text and '增加约24秒' in text
assert '使用了AI辅助' in text
assert not re.search(r'\d',next(p.text for p in report.paragraphs if p.text.startswith('摘要：')))
for name,expected in json.loads((qa/'submission-materials/original-template-hashes.json').read_text('utf-8')).items():
    assert sha((base/name).read_bytes())==expected,name

receipt=json.loads((qa/'submission-materials/build-receipt.json').read_text('utf-8'))
assert receipt['introCharacters']==len(''.join(receipt['intro']))<=410
for record in receipt['documents']:
    source=Path(record['source']);dest=out/record['file']
    with ZipFile(source) as original,ZipFile(dest) as revised:
        changed=[n for n in original.namelist() if original.read(n)!=revised.read(n)]
        assert set(changed)<= {'word/document.xml','docProps/core.xml'}
        for tag in ['sectPr']:
            ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
            a=E.fromstring(original.read('word/document.xml')).find('.//w:'+tag,ns)
            b=E.fromstring(revised.read('word/document.xml')).find('.//w:'+tag,ns)
            assert E.tostring(a)==E.tostring(b)
assert (out/'03-参赛学生诚信承诺书.docx').read_bytes()==(qa/'prose-before-20261019/submission/03-参赛学生诚信承诺书.docx').read_bytes()
assert (out/'03-参赛学生诚信承诺书.pdf').read_bytes()==(qa/'prose-before-20261019/submission/03-参赛学生诚信承诺书.pdf').read_bytes()
assert (out/'04-研究报告.docx').read_bytes()==(folder/'研究报告_公文格式.docx').read_bytes()
for original,target in [('binhe-cohort-rounds.csv','05-原始实验记录.csv'),('binhe-cohort-summary.csv','06-计算结果汇总.csv'),('binhe-cohort-timetable.csv','07-班级放行表.csv')]:
    raw=(root/'data'/original).read_bytes()
    assert raw==(out/target).read_bytes()
    assert raw==subprocess.check_output(['git','show','HEAD:data/'+original],cwd=root)

export=json.loads((qa/'prose-submission-render/export-receipt.json').read_text('utf-8-sig'))
checks=[]
for record in export:
    doc=Document(record['source']);source=Path(record['pdf'])
    pdf=pdfium.PdfDocument(source)
    rendered='\n'.join(line for page in pdf for line in page.get_textpage().get_text_range().splitlines() if not re.fullmatch(r'\s*[-－–—]\s*\d+\s*[-－–—]\s*',line))
    paragraphs=[p.text for p in doc.paragraphs]
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:paragraphs.extend(p.text for p in cell.paragraphs)
    missing=[s for s in paragraphs if norm(s) and norm(s) not in norm(rendered)]
    assert not missing,(source.name,missing[:3])
    for page in pdf:
        assert '\ufffd' not in page.get_textpage().get_text_range()
    dest=Path(record['delivered']) if record['delivered'] else None
    if dest:assert source.read_bytes()==dest.read_bytes()
    # The report was already rendered and reviewed with render-student-pages.py.
    if not source.name.startswith('研究报告'):
        target=qa/'prose-submission-render'/source.stem;target.mkdir(exist_ok=True)
        tiles=[]
        for i,page in enumerate(pdf):
            picture=page.render(scale=1.3).to_pil();picture.save(target/f'page-{i+1:02}.png')
            picture.thumbnail((300,440));tile=Image.new('RGB',(320,470),'#dddddd');tile.paste(picture,((320-picture.width)//2,10));ImageDraw.Draw(tile).text((10,450),str(i+1),fill='black');tiles.append(tile)
        sheet=Image.new('RGB',(1280,470*((len(tiles)+3)//4)),'white')
        for i,tile in enumerate(tiles):sheet.paste(tile,((i%4)*320,(i//4)*470))
        sheet.save(target/'contact.png')
    checks.append({'pdf':str(source),'pages':len(pdf),'sha256':sha(source.read_bytes()),'paragraphsChecked':len(paragraphs),'missingParagraphs':[],'delivered':None if dest is None else str(dest)})
    pdf.close()
skill=Path.home()/'.codex/skills/anti-defensive-writing/SKILL.md'
assert skill.is_file()
result={'passed':True,'reportPages':13,'guidePages':2,'tablesUnchanged':7,'figuresUnchanged':4,'originalTemplatesUnchanged':True,'officialIntegrityStatementsUnchanged':True,'personalFields':'unchanged and blank','originalStudyDataUnchanged':True,'introCharacters':receipt['introCharacters'],'skill':str(skill),'skillSha256':sha(skill.read_bytes()),'skillSource':'https://github.com/Adkid-Zephyr/anti-defensive-writing-Skill/tree/main/skills/anti-defensive-writing','renderer':'Word ExportAsFixedFormat and PDFium; canonical renderer attempted but LibreOffice unavailable','checks':checks}
(qa/'prose-final-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
