const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const E=require('../dist/school-engine'),R=require('../dist/research'),P=require('../dist/planner'),T=require('../dist/rotation');
const hash=b=>crypto.createHash('sha256').update(b).digest('hex');
const s=JSON.parse(fs.readFileSync('data/common-study-results.json','utf8'));
for(const [file,sha] of Object.entries(s.sourceHashes))assert.equal(hash(fs.readFileSync(file)),sha,file);
assert.equal(hash(JSON.stringify(s.protocol)),s.protocolSha256);
const frozen=JSON.parse(fs.readFileSync('data/common-frozen-selection.json','utf8'));
assert.deepEqual(frozen.selection,s.selection);assert.equal(frozen.frozenAt,s.frozenAt);
const choices=P.choose(s.screened,s.screened.find(r=>r.id==='reference'),s.protocol.criteria);
assert.deepEqual(Object.fromEntries(Object.keys(s.selection).map(k=>[k,choices[k].id])),s.selection);
assert.ok(Date.parse(s.frozenAt)<=Date.parse(s.completedAt));
let replayed=0;
function check(config,seeds,rounds,summary) {
  assert.deepEqual(R.summarize(rounds),summary);
  if(process.argv.includes('--replay'))for(let i=0;i<seeds.length;i++) {
    const m=R.metrics(E.simulateSchool({...config,seed:seeds[i]}));replayed++;
    for(const k of Object.keys(m))assert.ok(Math.abs(m[k]-rounds[i][k])<1e-9,k);
  }
}
const ids=range=>Array.from({length:range.count},(_,i)=>range.start+i);
for(const row of s.screened)check(row.config,ids(s.protocol.screenSeeds),row.rounds,row.summary);
for(const context of s.contexts) {
  for(const row of context.rows)check(row.config,ids(s.protocol.verifySeeds),row.rounds,row.summary);
  check({...context.rows[0].config,strategy:'shortest'},ids(s.protocol.verifySeeds),context.shortest.rounds,context.shortest.summary);
}
for(const policy of s.period) {
  assert.deepEqual(R.summarize(policy.rounds.map(r=>r.summary)),policy.summary);
  for(const period of policy.rounds) {
    assert.deepEqual(T.summarize(period.days,period.days[0].config),period.summary);
    for(const day of period.days)check(day.config,[day.seed],[day.metrics],R.summarize([day.metrics]));
  }
}
assert.equal(s.executions,s.screened.length*10+s.contexts.length*5*30+3*30*3);
if(process.argv.includes('--replay'))assert.equal(replayed,s.executions);
console.log(JSON.stringify({passed:true,executions:s.executions,replayed,contexts:s.contexts.length,candidates:s.screened.length,selection:s.selection}));
