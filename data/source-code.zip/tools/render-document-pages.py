"""Render the Word-exported QA PDFs for page-by-page inspection (not delivery)."""
from pathlib import Path
import json
import hashlib
import pypdfium2 as pdfium
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parents[1]
records = []
for name, source in [('report', '研究报告_公文格式.docx'), ('guide', '软件使用与学生研究指南.docx')]:
    folder = root / 'qa' / (name + '-render')
    pdf = pdfium.PdfDocument(folder / 'current.pdf')
    thumbnails, counts = [], []
    for i, page in enumerate(pdf):
        picture = page.render(scale=1.3).to_pil()
        picture.save(folder / f'current-{i+1:02}.png')
        counts.append(len(page.get_textpage().get_text_range()))
        picture.thumbnail((300, 440))
        tile = Image.new('RGB', (320, 470), '#dddddd')
        tile.paste(picture, ((320-picture.width)//2, 15))
        ImageDraw.Draw(tile).text((10, 450), f'{name} page {i+1}', fill='black')
        thumbnails.append(tile)
    sheet = Image.new('RGB', (1280, 470*((len(thumbnails)+3)//4)), 'white')
    for i, tile in enumerate(thumbnails):
        sheet.paste(tile, ((i%4)*320, (i//4)*470))
    sheet.save(folder / 'contact-current.png')
    records.append({'source': source, 'sha256': hashlib.sha256((root/'documents'/source).read_bytes()).hexdigest(), 'pages': len(pdf), 'pageCharacterCounts': counts})
(root/'qa/document-render.json').write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps(records, ensure_ascii=True))
