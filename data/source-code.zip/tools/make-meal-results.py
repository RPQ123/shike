"""Draw the four release comparisons from all saved verification executions."""
from pathlib import Path
import json,csv
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'figures/student'
s=json.loads((ROOT/'data/binhe-cohort-results.json').read_text('utf-8'))
rows=s['contexts'][0]['rows']
assert [r['id'] for r in rows]==['reference','efficiency','balanced','lowPeak']
assert all(len(r['rounds'])==30 for r in rows)
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei'],
 'font.size':11,'svg.fonttype':'none','pdf.fonttype':42,'axes.unicode_minus':False,
 'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,
 'axes.edgecolor':'#8C9893','axes.linewidth':.7})
fig,ax=plt.subplots(figsize=(6,3.4))
fig.subplots_adjust(left=.18,right=.98,top=.82,bottom=.17)
labels=['参照安排','用时最短','均衡安排','短排队安排']
records=[]
for metric,label,color,offset in [('meanWait','平均排队时间','#6291A4',-.16),('meanTotal','平均完整用时','#406F60',.16)]:
    means=np.array([r['summary'][metric] for r in rows])
    lower=np.array([min(v[metric] for v in r['rounds']) for r in rows])
    upper=np.array([max(v[metric] for v in r['rounds']) for r in rows])
    y=np.arange(len(rows))+offset
    ax.barh(y,means,height=.27,color=color,edgecolor='none',label=label,zorder=2)
    ax.errorbar(means,y,xerr=np.vstack([means-lower,upper-means]),fmt='none',ecolor='#203A35',elinewidth=.8,capsize=2,zorder=3)
    for i,mean in enumerate(means):
        ax.text(upper[i]+.6,y[i],f'{mean:.2f}',va='center',ha='left',fontsize=11,color='#263B3A')
        records.append({'安排':labels[i],'指标':label,'次数':30,'平均_分钟':mean,'最小_分钟':lower[i],'最大_分钟':upper[i]})
ax.set(yticks=np.arange(4),yticklabels=labels,xlim=(0,42),xticks=[0,10,20,30,40],xlabel='时间 / 分钟')
ax.invert_yaxis();ax.tick_params(axis='y',length=0,pad=8)
ax.legend(loc='lower left',bbox_to_anchor=(0,1.04),ncol=2,frameon=False,fontsize=11,borderaxespad=0)
assert len(fig.axes)==1
fig.canvas.draw()
stem=OUT/'15-meal-arrangements'
stem.with_suffix('.alignment.json').write_text(json.dumps({'panels':1,'verdict':'NOT APPLICABLE','reason':'Single-axis comparison.'}),encoding='utf-8')
fig.savefig(stem.with_suffix('.png'),dpi=600,facecolor='white')
fig.savefig(stem.with_suffix('.pdf'),facecolor='white')
fig.savefig(stem.with_suffix('.svg'),facecolor='white')
svg=stem.with_suffix('.svg')
svg.write_text('\n'.join(line.rstrip() for line in svg.read_text('utf-8').splitlines())+'\n',encoding='utf-8',newline='\n')
with stem.with_suffix('.csv').open('w',encoding='utf-8-sig',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=list(records[0]),lineterminator='\n');writer.writeheader();writer.writerows(records)
plt.close(fig)
print(json.dumps({'groups':4,'executionsPerGroup':30,'metrics':2,'figure':stem.name}))
