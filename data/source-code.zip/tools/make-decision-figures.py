"""Draw supplemental paired model results; all cases retained, no school measurements."""
from pathlib import Path
import csv
import hashlib
import json
import math
import os
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'data/decision-study-results.json'
study = json.loads(SOURCE.read_text(encoding='utf8'))
selected = study['selection']['nominal']
cases = [row for row in study['verification'] if row['policyId'] == selected]
assert len(cases) == 16
assert len({row['contextId'] for row in cases}) == 16
assert all(row['assessment']['total']['n'] == 30 for row in cases)
out = ROOT / 'figures'
qa = ROOT / 'qa'
plt.rcParams.update({'font.family': 'Microsoft YaHei', 'font.size': 9,
    'axes.unicode_minus': False, 'svg.fonttype': 'none', 'pdf.fonttype': 42,
    'axes.spines.top': False, 'axes.spines.right': False, 'axes.linewidth': 0.7,
    'xtick.color': '#445a52', 'ytick.color': '#445a52'})
audit_dir = os.environ.get('DINING_FIGURE_AUDIT_DIR')
if audit_dir:
    sys.path.insert(0, audit_dir)
    from audit_panel_alignment import require_matplotlib_panel_alignment
records = []


def save(fig, name):
    fig.canvas.draw()
    scientific_axes = [ax for ax in fig.axes if ax.get_label() != '<colorbar>']
    assert len(scientific_axes) == 1, 'This script is specified for single-panel figures'
    if audit_dir:
        require_matplotlib_panel_alignment(fig, json_out=str(qa / (name + '-alignment.json')),
            tolerance_pt=1.5, gutter_tolerance_pt=1.5, strict=True)
    else:
        (qa / (name + '-alignment.json')).write_text(json.dumps({
            'status': 'NOT APPLICABLE', 'reason': 'One scientific axes; colorbar is an auxiliary scale',
            'axesBounds': [list(ax.get_position().bounds) for ax in fig.axes]}, indent=2), encoding='utf8')
    files = []
    for suffix in ['png', 'svg', 'pdf']:
        path = out / (name + '.' + suffix)
        fig.savefig(path, dpi=300, bbox_inches='tight', facecolor='white')
        files.append({'file': path.relative_to(ROOT).as_posix(), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
    records.append({'name': name, 'scientificAxes': 1, 'source': SOURCE.relative_to(ROOT).as_posix(),
        'sourceSha256': hashlib.sha256(SOURCE.read_bytes()).hexdigest(), 'files': files})
    plt.close(fig)


nominal = next(row for row in cases if row['contextId'] == 's1-p0')['assessment']
effects = [('全体平均', nominal['total'])] + [(g['name'], g['delta']) for g in nominal['grades']]
fig, ax = plt.subplots(figsize=(6.0, 3.2))
for i, (label, effect) in enumerate(effects):
    color = '#aa693b' if effect['mean'] > 0 else '#216b56'
    ax.errorbar(effect['mean'], i, xerr=[[effect['mean']-effect['low']], [effect['high']-effect['mean']]],
        fmt='o', color=color, markersize=6, capsize=3, linewidth=1.4)
    label_x = -2 if abs(effect['mean']) < 1 else effect['mean']
    ax.text(label_x, i-0.20, f"{effect['mean']:+.2f}", ha='center', va='bottom', fontsize=9, color='#183b30')
ax.axvline(0, color='#344f45', linewidth=0.8)
ax.axvline(0.5, color='#b68a4d', linestyle='--', linewidth=0.8)
ax.set_yticks(range(len(effects)), [label for label, _ in effects])
ax.set_ylim(3.5, -0.6)
low = min(e['low'] for _, e in effects)
high = max(e['high'] for _, e in effects)
ax.set_xlim(math.floor(low)-1, math.ceil(high)+1)
ax.set_xlabel('完整用时差 B−A / 分钟；负值为缩短')
ax.set_title('总体缩短与年级受损可以同时出现', fontsize=11, pad=14)
ax.grid(axis='x', alpha=0.13)
ax.set_axisbelow(True)
fig.text(0.99, 0.01, '30轮配对模型实验；横线为逐项95%区间；虚线为年级0.5分阈值', ha='right', fontsize=8)
fig.tight_layout(rect=(0, 0.07, 1, 1))
save(fig, '04-grade-tradeoff')

labels = []
for row in cases:
    context = next(c for c in study['contexts'] if c['id'] == row['contextId'])
    if context['group'] == 'grid':
        mean = context['config']['windowMeans'][0]
        share = context['config']['gradeZoneWeights'][0][0]
        labels.append(f'服务{mean/20:g}倍 / A餐{share*100:.0f}%')
    else:
        labels.append(context['label'])
array = np.array([[row['assessment']['total']['mean']] +
    [g['delta']['mean'] for g in row['assessment']['grades']] for row in cases])
limit = math.ceil(float(np.abs(array).max()))
cmap = LinearSegmentedColormap.from_list('time_change', ['#4f937e', '#ffffff', '#c88a5d'])
fig, ax = plt.subplots(figsize=(6.0, 6.1))
im = ax.imshow(array, cmap=cmap, norm=TwoSlopeNorm(vmin=-limit, vcenter=0, vmax=limit), aspect='auto')
ax.set_yticks(range(16), labels)
ax.set_xticks(range(4), ['全体平均', '高一', '高二', '高三'])
ax.tick_params(length=0)
ax.axhline(8.5, color='#687a70', linestyle='--', linewidth=0.7)
ax.axvline(0.5, color='#9daa9f', linewidth=0.7)
for i in range(16):
    for j in range(4):
        ax.text(j, i, f'{array[i,j]:+.2f}', ha='center', va='center', fontsize=9,
            color='white' if abs(array[i,j]) > limit*0.72 else '#203e34')
ax.set_title('所列条件下，总体收益伴随年级取舍', fontsize=11, pad=14)
fig.colorbar(im, ax=ax, shrink=0.82, pad=0.04, label='B−A / 分钟')
fig.text(0.98, 0.01, '每情景30轮；格内为均值差，非发生概率；上下分区为9组网格与7组补充条件', ha='right', fontsize=7.5)
fig.tight_layout(rect=(0, 0.045, 1, 1))
save(fig, '05-scenario-grade-effects')

with (out / 'decision-source-data.csv').open('w', encoding='utf-8-sig', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=['context', 'outcome', 'mean', 'low', 'high', 'pairs', 'policy', 'reference'])
    writer.writeheader()
    for row in cases:
        a = row['assessment']
        for outcome, effect in [('all', a['total'])] + [('grade'+str(g['id']), g['delta']) for g in a['grades']]:
            writer.writerow({'context': row['contextId'], 'outcome': outcome, **{k: effect[k] for k in ['mean','low','high']},
                'pairs': effect['n'], 'policy': selected, 'reference': study['protocol']['referenceId']})
(qa / 'decision-figure-audit.json').write_text(json.dumps({'backend':'Python/matplotlib', 'verificationCases':16,
    'cells':64, 'observationsExcluded':0, 'scope':'Frozen nominal candidate vs reference; screening is kept separately, not treated as verification.',
    'figures':records}, ensure_ascii=False, indent=2), encoding='utf8')
print(json.dumps({'figures':[r['name'] for r in records], 'cases':len(cases)}))
