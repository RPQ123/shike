// Actual repeated scenario flow, shared by the long observation and its regression check.
const assert=require('node:assert/strict');
async function runIdenticalScenarios(page) {
  if (await page.locator('#scenario-section').getAttribute('open') === null)
    await page.locator('#scenario-section>summary').click();
  await page.locator('#scenario-run').click();
  await page.waitForFunction(()=>!window.DiningLabSnapshot.busy);
  const scenario=await page.evaluate(()=>window.DiningLabSnapshot.scenarioCheck);
  assert.ok(scenario && scenario.cases.length===9,'Expected nine complete scenarios');
  assert.ok(scenario.cases.every(item=>item.assessment.total.mean===0),'Identical A/B scenario drift');
  assert.equal(await page.locator('#export-scenarios').isDisabled(),false);
}
module.exports={runIdenticalScenarios};
