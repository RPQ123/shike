param([string]$DocumentDir = 'documents\design-edition')
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$wordApp = New-Object -ComObject Word.Application
$wordApp.Visible = $false
$wordApp.DisplayAlerts = 0
try {
    foreach ($name in @('研究报告_公文格式', '软件使用与学生研究指南')) {
        $sourcePath = Join-Path $projectRoot (Join-Path $DocumentDir ($name + '.docx'))
        $pdfPath = Join-Path $projectRoot (Join-Path $DocumentDir ($name + '.pdf'))
        $wordDoc = $wordApp.Documents.Open($sourcePath, $false, $true)
        try {
            $wordDoc.Fields.Update() | Out-Null
            $wordDoc.ExportAsFixedFormat($pdfPath, 17)
            Write-Output $pdfPath
        } finally { $wordDoc.Close(0) }
    }
} finally { $wordApp.Quit() }
