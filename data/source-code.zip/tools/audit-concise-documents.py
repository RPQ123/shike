"""Bind the admission-scale report to actual calculations and retained template."""
from pathlib import Path
from zipfile import ZipFile
import json,hashlib,csv,re
from docx import Document
from report_common import number as f
from report_admission import clock
root=Path(__file__).resolve().parents[1]
s=json.loads((root/'data/binhe-cohort-results.json').read_text('utf-8'))
folder=root/'documents/concise-edition'
report=Document(folder/'研究报告_公文格式.docx')
text='\n'.join(p.text for p in report.paragraphs)
assert len(report.tables)==7 and len(report.inline_shapes)==4
assert all(t in text for t in ['高一580人','高二530人','高三500人','共1610人','共完成800次计算','人数采用教育局公布的高中招生计划','表2的实验设置','使用了AI辅助'])
assert all(t not in text for t in ['全国一等奖','实测表明','已在学校应用','边界条件','P95','95%','路由','独立种子'])
headings=['一、研究背景','二、研究目的','三、资料收集','四、具体想法','五、工作计划','六、具体实施计划','七、结论']
assert [p.text for p in report.paragraphs if p.text in headings]==headings
assert report.paragraphs[0].text.replace('\n','')=='校园食堂错峰就餐与窗口分配仿真软件的设计与实现'
assert all(word not in text for word in ['Windows','封装','按钮','界面操作','软件的价值','作为高中生','制作一套'])
background=text.split('一、研究背景',1)[1].split('二、研究目的',1)[0]
assert all(word in background for word in ['年级错峰','两侧','座位','前后','班级出发间隔'])
assert text.count('滨河')==1
abstract=next(p.text for p in report.paragraphs if p.text.startswith('摘要：'))
assert not re.search(r'[0-9０-９]',abstract)
assert all(word not in abstract for word in ['滨河','招生计划','Usluer','Kambli'])
assert all(word not in text for word in ['需要强调的是','值得注意的是','这并不意味着','不能简单地','并非','不是对学校现行作息的转录','不能保证','不能只','不代表','Usluer','Kambli','SimPy','Three.js','Ege Academic','Hospitality and Tourism'])
purpose=text.split('二、研究目的',1)[1].split('三、资料收集',1)[0]
assert '各班出发的顺序和间隔' in purpose and '设计' not in purpose and '制作' not in purpose
assert '窗口、座位、分组和时刻采用表2的实验设置' in text
conclusion=text.split('七、结论',1)[1].split('参考资料',1)[0]
assert all(word in conclusion for word in ['班级交错放行','窗口和座位','课表','固定均衡顺序'])
assert all(word not in conclusion for word in ['软件功能','设计了一套','完成了软件','三维界面'])
for shape,name in zip(report.inline_shapes,['student/11-hall-plan.png','student/12-meal-flow.png','student/13-window-choice.png','student/15-meal-arrangements.png']):
    assert report.part.related_parts[shape._inline.graphic.graphicData.pic.blipFill.blip.embed].blob==(root/'figures'/name).read_bytes()
cells=lambda t:[[c.text for c in r.cells] for r in t.rows][1:]
assert cells(report.tables[0])==[['高一','2026','580'],['高二','2025','530'],['高三','2024','500'],['合计','—','1610']]
plan=next(r for r in s['screened'] if r['id']==s['selection']['balanced'])
assert cells(report.tables[2])==[[g['name'],str(g['classes']),clock(g['releaseTime']),clock(g['releaseTime']+(g['classes']-1)*g['classInterval'])] for g in plan['config']['grades']]
rows={r['id']:r['summary'] for r in s['contexts'][0]['rows']}
names={'reference':'参照安排','efficiency':'用时最短','balanced':'均衡安排','lowPeak':'队伍更短'}
assert cells(report.tables[3])==[[names[k],f(r['meanTotal']),f(r['meanWait']),f(r['peakQueue'],1)] for k,r in rows.items()]
assert cells(report.tables[4])==[[['高一','高二','高三'][i],f(rows['reference'][f'grade{i}Total']),f(rows['balanced'][f'grade{i}Total'])] for i in range(3)]
assert cells(report.tables[5])==[[str(r['windows']),str(r['seats']),f(r['summary']['meanWait']),f(r['summary']['seatWait']),f(r['summary']['meanTotal'])] for r in s['cases']]
assert cells(report.tables[6])==[[{'fixed':'顺序保持不变','cyclic':'循环轮换','feedback':'参考前几餐用时'}[r['mode']],*[f(r['summary'][f'grade{i}Total']) for i in range(3)]] for r in s['period']]
period={r['mode']:r['summary'] for r in s['period']}
assert period['fixed']['periodGradeGap']<period['cyclic']['periodGradeGap']
assert period['fixed']['periodGradeGap']<period['feedback']['periodGradeGap']
with (root/'data/binhe-cohort-rounds.csv').open(encoding='utf-8-sig') as stream:
    csvrows=list(csv.DictReader(stream));assert len(csvrows)==800
    assert all([int(float(r[k])) for k in ['高一人数','高二人数','高三人数']]==[580,530,500] for r in csvrows)
guide='\n'.join(p.text for p in Document(folder/'软件使用与学生研究指南.docx').paragraphs)
assert '1610' in guide and '360' not in guide and '报告表6' in guide
template=root/'documents/templates/公文模板.docx'
assert hashlib.sha256(template.read_bytes()).hexdigest()=='ec93c69c2f33639421d1d89cf4fc1e1b0f926b6b1c9bee8ce3fda7167a523ae7'
for path in folder.glob('*.docx'):
    with ZipFile(template) as original,ZipFile(path) as revised:
        for name in original.namelist():
            if not name.endswith('/') and name.startswith(('word/styles','word/theme/','word/footer','word/header','word/numbering')):assert original.read(name)==revised.read(name),name
result={'passed':True,'tables':7,'figures':4,'executions':800,'cohortCounts':[580,530,500],'students':1610,'csvRows':800,'templateParts':'byte-identical','negativeFindingsPreserved':['average total time increase under balanced schedule','simple rotation does not improve this unequal-cohort scenario'],'figureBytes':'exact match to current PNG files','focus':'Lunch scheduling problem; program used as calculation instrument','titlePreserved':True,'abstractContainsNoSpecificNumbers':True,'schoolNameMentions':1,'researchReferences':'three verified Chinese papers','sourceAndSettingsNotes':'concentrated in section three'}
(root/'qa/concise-document-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result))
