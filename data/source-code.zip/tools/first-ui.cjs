const {chromium}=require('playwright');
const fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 const page=await browser.newPage({viewport:{width:1440,height:1000}});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));page.on('console',m=>{if(m.type()==='error')errors.push(m.text())});
 await page.goto('http://127.0.0.1:8769/');await page.waitForTimeout(2000);
 fs.mkdirSync('qa',{recursive:true});
 await page.screenshot({path:'qa/first-ui.png',fullPage:true});
 fs.writeFileSync('qa/first-ui.json',JSON.stringify({title:await page.title(),errors,buttons:await page.getByRole('button').allTextContents(),text:(await page.locator('body').innerText()).slice(0,15000),webgl:await page.evaluate(()=>{let c=document.createElement('canvas');let gl=c.getContext('webgl2');return gl?{version:gl.getParameter(gl.VERSION),renderer:gl.getParameter(gl.RENDERER)}:null})},null,2));
 console.log(JSON.stringify({errors,screenshot:'qa/first-ui.png'}));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});

