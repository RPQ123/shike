"""Fill retained competition templates; leave identity and signatures empty."""
from pathlib import Path
from copy import deepcopy
from zipfile import ZipFile, ZIP_DEFLATED
from lxml import etree as E
from docx import Document
import json, hashlib, shutil, argparse, re

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--schedule-study',default=None)
args=parser.parse_args()
SCHEDULE=json.loads((ROOT/args.schedule_study).read_text('utf-8')) if args.schedule_study else None
BASE=ROOT.parent
QA=ROOT/'qa/submission-materials'
OUT=BASE/'【成品】提交材料'
TEMPLATES=BASE/'【模板】提交材料'
TITLE='校园食堂错峰就餐与窗口分配仿真软件的设计与实现'
NS={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
W='{'+NS['w']+'}'
sha=lambda b:hashlib.sha256(b).hexdigest()
OUT.mkdir(exist_ok=True)

def setp(p,text,size=None,bold=None,font=None):
    """Change only the editable paragraph's contents and optional fill role."""
    text=re.sub(r'(?<=\d)[ \t\u00a0\u3000]+|[ \t\u00a0\u3000]+(?=\d)','',text)
    props=p.get_or_add_pPr()
    for name in ['autoSpaceDN','autoSpaceDE']:
        node=props.find(W+name)
        if node is None:node=E.SubElement(props,W+name)
        node.set(W+'val','0')
    rpr=p.find('w:r/w:rPr',NS)
    if rpr is None:rpr=p.find('w:pPr/w:rPr',NS)
    rpr=deepcopy(rpr) if rpr is not None else E.Element(W+'rPr')
    for tag,value in [('sz',None if size is None else str(round(size*2))),('szCs',None if size is None else str(round(size*2))),('b',None if bold is None else ('1' if bold else '0')),('bCs',None if bold is None else ('1' if bold else '0'))]:
        if value is not None:
            node=rpr.find(W+tag)
            if node is None:node=E.SubElement(rpr,W+tag)
            node.set(W+'val',value)
    if font:
        node=rpr.find(W+'rFonts')
        if node is None:node=E.SubElement(rpr,W+'rFonts')
        for key in ['ascii','hAnsi','eastAsia']:node.set(W+key,font)
    for child in list(p):
        if child.tag!=W+'pPr':p.remove(child)
    run=E.SubElement(p,W+'r');run.append(rpr)
    for i,line in enumerate(text.split('\n')):
        if i:E.SubElement(run,W+'br')
        t=E.SubElement(run,W+'t');t.set('{http://www.w3.org/XML/1998/namespace}space','preserve');t.text=line

def cellbody(cell,lines,keep=1,size=10.5,font='宋体'):
    paras=cell.findall(W+'p')
    proto=deepcopy(paras[min(keep,len(paras)-1)])
    for p in paras[keep:]:cell.remove(p)
    for text in lines:
        p=deepcopy(proto);setp(p,text,size=size,bold=False,font=font)
        ind=p.get_or_add_pPr().get_or_add_ind()
        for key in ['firstLine','firstLineChars','hanging','hangingChars']:ind.set(W+key,'0')
        cell.append(p)

receipts=[]
def write_from(source,dest,mutate):
    original=source.read_bytes();doc=Document(source)
    mutate(doc)
    xml=E.tostring(doc._element,xml_declaration=True,encoding='UTF-8',standalone=True)
    with ZipFile(source) as z,ZipFile(dest,'w',ZIP_DEFLATED) as output:
        for item in z.infolist():
            raw=z.read(item.filename)
            if item.filename=='word/document.xml':raw=xml
            if item.filename=='docProps/core.xml':
                core=E.fromstring(raw)
                for tag in ['{http://purl.org/dc/elements/1.1/}creator','{http://schemas.openxmlformats.org/package/2006/metadata/core-properties}lastModifiedBy']:
                    for el in core.findall(tag):el.text=''
                raw=E.tostring(core,xml_declaration=True,encoding='UTF-8',standalone=True)
            output.writestr(item,raw)
    with ZipFile(source) as a,ZipFile(dest) as b:
        assert set(a.namelist())==set(b.namelist())
        changes=[n for n in a.namelist() if a.read(n)!=b.read(n)]
        assert set(changes)<= {'word/document.xml','docProps/core.xml'}
    assert source.read_bytes()==original
    receipts.append({'file':dest.name,'source':str(source),'sourceSha256':sha(original),'sha256':sha(dest.read_bytes()),'changedParts':changes})

INTRO=[
 '研究目的：我想通过调整班级出发时间和开放窗口数量，设计一份就餐方案，缩短高一至高三年级学生的平均排队时间。',
 '研究方法：按三个年级的人数安排各班出发的顺序和间隔，用软件比较不同方案，再分别改变窗口和座位数量，记录排队、等座和从允许出发到返回教室的用时，形成班级放行表。人数取自招生计划，窗口数、座位数和相关时间作为仿真参数设定。',
 '实验结果：按平均排队时间比较后，采用每轮按60秒间隔交错出发的安排，平均排队由13.07分钟降到1.08分钟，完整用时增加约70秒。增加窗口加快取餐，座位不足会增加取餐后的等待。',
 '分析、结论：不同年级的班级交错出发，可以缩短在食堂排队的时间。开放窗口数量和可用座位数量应根据学生主要在哪个环节等待来调整，班级放行表可根据学校实际课表和就餐人数调整。'
]
assert len(''.join(INTRO))<=410
if SCHEDULE:
    rows=SCHEDULE['verification'];waits=[r['summary']['meanWait'] for r in rows]
    increase=rows[2]['summary']['meanTotal']-rows[1]['summary']['meanTotal']
    INTRO=[
      '研究目的：我想通过比较三种就餐安排，找出能缩短高中学生平均排队时间的方案，并编制各班的出发时间表。',
      '研究方法：在人数、开放窗口数量和座位数量相同的条件下，先比较不实行错峰、仅按年级错峰、年级与班级结合错峰，再比较连续出发的两个班应相隔多久。每种安排和每个间隔各计算30次，记录排队、等座、完整用时和最后一名学生返回教室的时刻，共660次。人数和资源均为示例参数。',
      f'实验结果：三种方案最终的平均排队时间分别为{waits[0]:.2f}、{waits[1]:.2f}和{waits[2]:.2f}分钟。所选相邻组间隔为70秒，平均完整用时比仅按年级错峰增加{increase:.2f}分钟。',
      '分析、结论：在年级错峰的基础上错开各班的出发时刻，可以减少食堂排队。学校可填写本校参数，生成班级放行表，再用实际排队时间和学生返回教室的时刻检查调整效果。'
    ]
    assert len(''.join(INTRO))<=410

def application(d):
    setp(d.paragraphs[9]._p,'作品名称：'+TITLE)
    # Retain the original two-column subject list and choose one subject only.
    for t in d.paragraphs[25]._p.findall('.//w:t',NS):
        if t.text=='□':t.text='☑';break
    squares=[t for t in d.paragraphs[31]._p.findall('.//w:t',NS) if t.text=='□']
    assert len(squares)==2;squares[1].text='☑'
    setp(d.tables[0].cell(1,2).paragraphs[0]._p,'  □初中生   ☑高中生')
    setp(d.tables[0].cell(1,10).paragraphs[0]._p,'高二')
    c=d.tables[1].cell(3,1)._tc
    cellbody(c,INTRO,keep=0,size=11,font='仿宋_GB2312')
    c=d.tables[2].cell(0,1)._tc
    cellbody(c,[
      '1. 研究报告：04-研究报告.docx。',
      '2. 查新报告：02-查新报告.pdf。',
      '3. 查重报告：',
      '4. 作品附件：原始计算记录、计算结果汇总、班级放行表、研究过程记录、软件使用指南和辅助图片；另附可运行软件及源码。',
      '（入围终评的作品，需在终评现场向评委提供清单中列出的所有附件材料。）',
      '5. 诚信承诺书：03-参赛学生诚信承诺书.pdf。',
      '6. 证明材料：',
      '（依托专业机构或实验室开展的研究须提供该机构或实验室主管部门/单位的许可依据；涉及医疗保健用品、动植物新品种、国家保护的动植物等内容的项目须提供有关部门的证明材料。）'
    ],keep=0,size=10.5)

app=next(QA.glob('3-*.docx'))
write_from(app,OUT/'01-少年组作品申报书.docx',application)

PAPERS=[
 ('高渝淳、尹楷、罗添、李阳、张慧','关于国内高校食堂设计的研究：文献综述——基于数学模型的食堂设计研究','应用数学进展，2019，8（5）：1036—1041','从排队打饭、寻找座位及窗口与座位配合等角度整理食堂设计问题，为分环节比较提供参考。','https://doi.org/10.12677/aam.2019.85118'),
 ('何恒、胡钟敏、张顶立','基于Flexsim仿真的快餐厅系统改进研究','广西科技大学学报，2019，30（3）：70—75','将快餐厅分为订餐、备餐和用餐环节，通过计算比较流程调整对排队和接待量的影响。','https://doi.org/10.16375/j.cnki.cn45-1395/t.2019.03.012'),
 ('刘兴果、李思怡、宋思瑶','时变排队模型下的高校食堂排队预测研究','计算机科学与应用，2026，16（9）：62—73','研究客流随时段变化时的窗口排队，输出运行指标和图表，为窗口调度提供参考。','https://doi.org/10.12677/csa.2026.169289'),
 ('heyxingxing','明湖餐厅就餐仿真系统（canteen-sim）','GitHub公开项目，2026年10月19日检索','项目说明展示学生进餐、窗口排队、找座就餐和离开过程，支持窗口配置比较及三维展示。','https://github.com/heyxingxing/canteen-sim')
]

def novelty(d):
    setp(d.paragraphs[5]._p,'作品名称：'+TITLE,size=14)
    setp(d.paragraphs[9]._p,'查新完成日期：2026年10月19日')
    t=d.tables[0]
    setp(t.cell(0,1).paragraphs[0]._p,TITLE,size=10.5)
    cellbody(t.cell(2,0)._tc,[
      '作品设计了一份调整班级出发时间和开放窗口数量的校园就餐方案，目的是缩短高一至高三年级学生的平均排队时间。方案将年级错峰细化到各班何时出发，结合窗口打饭速度和座位使用情况，形成班级放行表。',
      '比较时分别记录打饭前排队、取餐后等座和从允许出发到返回教室的用时，以全体平均排队时间作为主要指标。软件用于比较不同安排，为学校调整学生就餐方案提供参考。'
    ])
    cellbody(t.cell(3,0)._tc,[
      '1. 安排不同年级的班级交错出发，比较出发顺序和间隔对排队的影响，并将出发前的等待计入整段午餐用时。',
      '2. 结合窗口、座位数量比较打饭前排队和取餐后等座，比较全体学生的平均排队时间，形成班级放行表，并提出开放窗口数量和可用座位数量的建议。'
    ])
    cellbody(t.cell(4,0)._tc,[
      '检索日期：2026年10月19日。',
      '检索范围：公开网络中的中文食堂排队、错峰就餐及窗口配置研究；通过期刊出版社网站、广西科技大学学报官方平台核对题录和内容，并检索GitHub公开项目说明。文献年份截至检索日。',
      '检索词：校园食堂、错峰就餐、班级出发、窗口配置、座位、排队、仿真。',
      '检索组合：（食堂＋错峰＋班级）；（食堂＋排队＋窗口配置）；（食堂＋座位＋仿真）；并检索作品完整名称。',
      '检索方式：先找相近研究，再按题名查看原文或摘要，比较研究对象、调整内容和输出结果。'
    ])
    results=['选取三篇中文论文和一个公开项目进行比较，内容摘述如下：']
    for i,(author,title,source,summary,url) in enumerate(PAPERS,1):
        results.extend([f'{i}.《{title}》',f'作者：{author}。来源：{source}。',f'内容摘述：{summary}',f'链接：{url}'])
    cellbody(t.cell(5,0)._tc,results)
    cellbody(t.cell(6,0)._tc,[
      '已检出食堂排队、窗口与座位配合及三维就餐演示等相近研究。文献1整理了食堂设计的多个环节；文献2比较快餐厅流程调整；文献3研究随时段变化的客流；项目4支持窗口配置比较。',
      '本作品结合高中按班级组织就餐的情况，重点比较各班出发的顺序和间隔，并分别查看窗口、座位数量变化后的等待情况。出发前的等待计入整段午餐用时，比较结果按三个年级分别整理，最终形成班级放行表，并提出开放窗口数量和可用座位数量的建议。',
      '根据检索和比较，本作品的研究内容属于高中午餐安排的方案设计与应用改进。具体做法是安排班级交错出发，让出发间隔与窗口打饭速度相配合，以平均排队时间选择方案，再用等座时间和完整用时检查安排是否合适。'
    ])
    cellbody(t.cell(8,0)._tc,[
      '1. 关于国内高校食堂设计的研究：文献综述——基于数学模型的食堂设计研究。',
      '2. 基于Flexsim仿真的快餐厅系统改进研究。',
      '3. 时变排队模型下的高校食堂排队预测研究。',
      '4. 明湖餐厅就餐仿真系统公开项目说明。',
      '上述资料的作者、出处、内容摘述及公开链接列在第五栏。'
    ])
    cellbody(t.cell(9,0)._tc,[
      '文献1、3查阅公开全文；文献2依据期刊官方题录和摘要；项目4依据公开项目说明。',
    ])
    # Retain both statements and the signature/stamp line, with useful space.
    declaration=t.cell(7,0)._tc
    for blank in declaration.findall(W+'p')[8:]:
        assert not ''.join(blank.itertext()).strip()
        declaration.remove(blank)
    # The template permits resizing fields. Keep each completed field intact.
    for row in t.rows:
        trpr=row._tr.find(W+'trPr')
        if trpr is None:trpr=E.SubElement(row._tr,W+'trPr');row._tr.insert(0,trpr)
        if trpr.find(W+'cantSplit') is None:E.SubElement(trpr,W+'cantSplit')

nov=next(QA.glob('1-*.docx'))
def schedule_novelty(d):
    novelty(d)
    if not SCHEDULE:return
    t=d.tables[0]
    cellbody(t.cell(2,0)._tc,[
      '本作品针对高中学生午餐排队问题，设计了不实行错峰、仅按年级错峰、年级与班级结合错峰三种方案的比较方法。先比较三种方案，再固定年级顺序，比较连续出发的两个班相隔多久更合适，最后生成班级放行表。',
      '软件按选择方案、运行过程、仿真结果三个步骤使用，用JavaScript计算并展示学生入场、排队、取餐、就座、用餐和离场的过程，另用Python核对放行表。学校可调整人数、开放窗口数量和座位数量，比较平均排队时间，并检查学生能否按时返回教室。'
    ])
    cellbody(t.cell(3,0)._tc,[
      '1. 在就餐人数和食堂资源相同的条件下，先比较三种安排，再比较相邻班级的出发间隔。选出间隔后，重新生成全体学生的各环节用时，再次计算三种方案，检查结果。',
      '2. 根据全体学生的平均排队时间选择方案，同时检查所有学生能否按时返回教室。所选方案既可在三维页面回放，也可导出为列明各班人数和出发时刻的放行表。'
    ])
    cellbody(t.cell(6,0)._tc,[
      '检索发现，已有研究讨论食堂排队、餐厅流程调整和三维就餐展示，具体内容见第五栏。学校公开管理方案中，也已有按年级错时、按班级分批用餐的安排。',
      '本作品先比较三种方案，再比较出发间隔，并在选定间隔后重新计算，检查结果。研究以1610人参加午餐为示例，保存了660次计算记录、所用参数和班级放行表。',
      '本作品属于高中就餐方案的设计与应用改进。学校应用时可填入本校人数和食堂条件，比较调整前后的排队时间及学生返回教室的时刻，再通过匿名反馈了解学生对等待和就餐秩序的感受。'
    ])
write_from(nov,OUT/'02-查新报告.docx',schedule_novelty)

def integrity(d):
    setp(d.paragraphs[2]._p,'申报作品：'+TITLE,size=14)
integritySource=next(TEMPLATES.rglob('5-*.docx'))
write_from(integritySource,OUT/'03-参赛学生诚信承诺书.docx',integrity)

shutil.copyfile(ROOT/'documents/polish-edition/研究报告_公文格式.docx',OUT/'04-研究报告.docx')
data_files=[('schedule-study-rounds.csv','05-原始实验记录.csv'),('schedule-study-summary.csv','06-计算结果汇总.csv'),('schedule-study-timetable.csv','07-班级放行表.csv')] if SCHEDULE else [('binhe-cohort-rounds.csv','05-原始实验记录.csv'),('binhe-cohort-summary.csv','06-计算结果汇总.csv'),('queue-focus-timetable.csv','07-班级放行表.csv')]
for src,dst in data_files:
    shutil.copyfile(ROOT/'data'/src,OUT/dst)

# A short process record uses the already-retained report's paragraph roles.
report=ROOT/'documents/polish-edition/研究报告_公文格式.docx'
def process(d):
    title=deepcopy(d.paragraphs[0]._p)
    body=deepcopy(next(p._p for p in d.paragraphs if p.text.startswith('高中午餐时间' if SCHEDULE else '本研究以')))
    container=d._element.body
    for child in list(container):
        if child.tag!=W+'sectPr':container.remove(child)
    setp(title,'研究过程记录');container.insert(0,title)
    entries=[
      '记录日期：2026年10月19日。',
      '确定问题：研究怎样缩短高一至高三学生的平均排队时间，重点比较各班何时出发、开放多少个打饭窗口、需要多少个座位。',
      '参数设置：三个年级人数按对应入学年的招生计划填写。将窗口数、座位数、打饭时间和用餐时间设为可调整的仿真参数，先估算每分钟能接待多少人。',
      '设计与比较：按班级大小分组，比较不同出发顺序和间隔，选出候选方案后重新计算；再分别改变窗口和座位数量，并比较连续三餐的出发顺序，共保存800次计算记录。',
      '结果与修改：以全体平均排队时间作为主要指标，从四种复算安排中选出每轮按60秒间隔交错出发的安排。平均排队由13.07分钟降到1.08分钟，完整用时增加约70秒，据此形成班级放行表。',
      '下一步：按实际课表安排班级间隔，记录末批学生开始吃饭和返回教室的时刻，再据结果调整。',
      '程序编写、检索、计算、绘图和文字整理使用了AI辅助。计算记录、汇总表和放行表与报告一起保存。'
    ]
    if SCHEDULE:
        entries=[
          '记录日期：2026年10月20日。',
          '确定问题：比较不实行错峰、仅按年级错峰、年级与班级结合错峰三种安排，目的是缩短学生的平均就餐排队时间。',
          '参数设置：以三个年级共1610人、16个窗口、480个座位为示例。三种安排采用相同的人数和食堂条件。',
          '设计与计算：先比较三种安排，再比较13个相邻组间隔。选定间隔后复算，并比较不同年级间隔，共保存660次计算记录。',
          f'结果与调整：三种方案的平均排队时间分别为{waits[0]:.2f}、{waits[1]:.2f}、{waits[2]:.2f}分钟。相邻组间隔选70秒，全部学生按时返回教室；平均完整用时比仅年级错峰增加{increase:.2f}分钟。',
          '软件与代码：JavaScript负责计算和三维展示，Python负责核对放行表，33行结果逐行一致。',
          '检查与修改：操作分为选择方案、运行过程、仿真结果。修复离场步速和人物点击，核对网页与Windows版结果，更新提交材料中的数据和截图。',
          '应用与推广：学校可修改参数、导出放行表，再用实际排队时间、返回教室时刻和匿名反馈检查调整效果。',
        ]
    for text in entries:
        p=deepcopy(body);setp(p,text);container.insert(len(container)-1,p)
write_from(report,OUT/'08-研究过程记录.docx',process)
for ext in ['docx','pdf']:
    shutil.copyfile(ROOT/'documents/polish-edition'/('软件使用与学生研究指南.'+ext),OUT/('09-软件使用指南.'+ext))

imgs=OUT/'辅助图片';imgs.mkdir(exist_ok=True)
image_files=[('12-meal-flow.png','图1-就餐流程.png'),('22-software-setup.png','图2-软件设置页面.png'),('16-software-scene.png','图3-三维回放页面.png'),('13-window-choice.png','图4-窗口选择.png'),('23-software-comparison.png','图5-三种安排比较.png'),('21-group-intervals.png','图6-出发间隔比较.png')] if SCHEDULE else [('11-hall-plan.png','图1-食堂位置关系示意图.png'),('12-meal-flow.png','图2-午餐过程示意图.png'),('13-window-choice.png','图3-窗口选择示意图.png'),('15-meal-arrangements.png','图4-方案比较结果.png')]
for source,name in image_files:
    shutil.copyfile(ROOT/'figures/student'/source,imgs/name)
if SCHEDULE:
    for source,name in [('24-class-parameters.png','图7-各班人数与放行时间设置.png'),('25-usage-results.png','图8-就餐结果与各年级用时统计.png')]:
        shutil.copyfile(ROOT/'figures/student'/source,imgs/name)

for name in (['12-meal-flow','13-window-choice'] if SCHEDULE else ['11-hall-plan','12-meal-flow','13-window-choice']):
    for ext in ['.drawio','.svg']:
        shutil.copyfile(ROOT/'figures/student'/(name+ext),imgs/(name+ext))
if SCHEDULE:
    for name in ['23-software-comparison.svg','21-group-intervals.svg']:
        shutil.copyfile(ROOT/'figures/student'/name,imgs/name)

receipt={'title':TITLE,'introCharacters':len(''.join(INTRO)),'intro':INTRO,'documents':receipts,'personalInformation':'blank; no signatures or stamps added','copiedReportSha256':sha((OUT/'04-研究报告.docx').read_bytes())}
(QA/'build-receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'introCharacters':receipt['introCharacters'],'files':[p.relative_to(OUT).as_posix() for p in OUT.rglob('*') if p.is_file()]},ensure_ascii=False,indent=2))
