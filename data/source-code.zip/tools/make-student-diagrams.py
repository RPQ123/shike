"""Draw original, editable teaching diagrams from the implemented meal rules."""
from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures/student'
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei'],
 'font.size':12,'svg.fonttype':'none','pdf.fonttype':42,'axes.unicode_minus':False})
INK='#263B3A'; GREEN='#DDECE4'; BLUE='#E3EDF3'; GRAY='#ECF0F0'; ACCENT='#407D6C'
records=[]

def canvas(height):
    fig, ax = plt.subplots(figsize=(6,height))
    fig.subplots_adjust(left=.015,right=.985,bottom=.025,top=.975)
    ax.set(xlim=(0,12),ylim=(0,height*2));ax.axis('off')
    return fig,ax

def label(ax,x,y,text,size=12,**kwargs):
    return ax.text(x,y,text,ha='center',va='center',fontsize=size,color=INK,**kwargs)

def box(ax,x,y,w,h,text,fill=GREEN,size=12):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=0.10',
        linewidth=.8,edgecolor='#829A93',facecolor=fill))
    label(ax,x+w/2,y+h/2,text,size)

def arrow(ax,a,b,double=False):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='<->' if double else '-|>',
        mutation_scale=12,linewidth=1.2,color=ACCENT))

def save(fig,stem,claim,source):
    # Every diagram has one drawing surface; a multi-panel comparison would need
    # its own alignment audit rather than silently reusing this exemption.
    assert len(fig.axes)==1, 'Multiple panels require a panel-alignment audit.'
    fig.canvas.draw()
    (OUT/(stem+'.alignment.json')).write_text(json.dumps({
        'panels':1,'verdict':'NOT APPLICABLE','reason':'Single-axis schematic; no comparable panels.'
    },indent=2),encoding='utf-8')
    fig.savefig(OUT/(stem+'.png'),dpi=600,facecolor='white')
    fig.savefig(OUT/(stem+'.svg'),facecolor='white')
    fig.savefig(OUT/(stem+'.pdf'),facecolor='white')
    records.append({'name':stem,'claim':claim,'source':source,'type':'single-axis schematic',
      'dataExclusions':'none; diagrams illustrate rules rather than measured school geometry',
      'fontPt':12,'widthCm':15.24,'statisticalUncertainty':'not applicable to conceptual diagrams'})
    plt.close(fig)

fig,ax=canvas(2.8)
for xs,ys in [([.8,.8],[.7,4.8]),([11.2,11.2],[.7,4.8]),
              ([.8,5.5],[.7,.7]),([6.5,11.2],[.7,.7]),
              ([.8,5.5],[4.8,4.8]),([6.5,11.2],[4.8,4.8])]:
    ax.plot(xs,ys,color='#B4C0BB',linewidth=1)
for side,x in [('左',1.15),('右',9.4)]:
    for i,y in enumerate([1.15,2.4,3.65]):
        box(ax,x,y,1.45,.65,f'{side}窗{i+1}',GREEN)
label(ax,6,5.16,'后端出入口')
label(ax,6,.25,'前端出入口')
arrow(ax,(6,4.9),(6,4.1),True);arrow(ax,(6,.6),(6,1.4),True)
for x in [4.1,6.7]:
    for y in [1.65,2.65,3.65]:
        box(ax,x,y,1.2,.48,'餐桌',GRAY,11)
label(ax,6,3.38,'中间就餐区',11)
arrow(ax,(3.7,2.1),(2.8,2.1));arrow(ax,(8.2,2.1),(9.1,2.1))
save(fig,'11-hall-plan','两侧为窗口，中间为座位，前后两端可进出。',
     'Student-described arrangement; six universal windows used as an illustrative configuration; not surveyed dimensions.')

fig,ax=canvas(1.85)
for x,text in [(0.25,'班级放行'),(4.45,'走到食堂'),(8.65,'选窗排队')]:
    box(ax,x,2.25,3.1,.78,text)
for x,text in [(8.65,'打饭取餐'),(4.45,'等座用餐'),(.25,'返程结束')]:
    box(ax,x,.48,3.1,.78,text,BLUE)
arrow(ax,(3.5,2.64),(4.3,2.64));arrow(ax,(7.7,2.64),(8.5,2.64))
arrow(ax,(10.2,2.12),(10.2,1.4));arrow(ax,(8.5,.87),(7.7,.87));arrow(ax,(4.3,.87),(3.5,.87))
save(fig,'12-meal-flow','计算学生从放行至返程的各个环节。','Implemented school-engine event sequence; ordering only, no measured durations.')

fig,ax=canvas(2.0)
box(ax,.25,2.3,2.65,.85,'甲窗口\n空闲，每人30秒',GRAY,11)
box(ax,3.35,2.3,8.25,.85,'本人打饭30秒  →  还需30秒',GRAY,12)
box(ax,.25,.85,2.65,.85,'乙窗口\n每人10秒',GREEN,11)
box(ax,3.35,.85,3.35,.85,'当前还需5秒',GREEN,12)
box(ax,7.15,.85,4.45,.85,'本人10秒  →  共15秒',GREEN,12)
arrow(ax,(3,2.73),(3.24,2.73));arrow(ax,(3,1.28),(3.24,1.28));arrow(ax,(6.8,1.28),(7.04,1.28))
label(ax,6,.28,'两处都没有其他人等待时，选择乙窗口',11)
save(fig,'13-window-choice','人数相同时，比较还需时间才能选到预计更快的窗口。',
     'Worked arithmetic example: 30 seconds versus 5 + 10 = 15 seconds, using r + (q+1)*m.')

(OUT/'figure-contract.json').write_text(json.dumps({'backend':'Python / Matplotlib','audience':'High-school student and competition readers','figures':records},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'figures':len(records),'formats':['png','svg','pdf']},ensure_ascii=True))
