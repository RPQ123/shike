const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const R = require('../dist/research.js');
const E = require('../dist/school-engine.js');
const D = require('../dist/decision-support.js');

(async () => {
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
  const errors = [], checks = [], network = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('request', req => network.push(req.url()));
  const snapshot = () => page.evaluate(() => window.DiningLabSnapshot);
  const check = (name, condition) => { assert.ok(condition, name); checks.push(name); };
  try {
    await page.goto('http://127.0.0.1:8769/');
    await page.waitForFunction(() => window.DiningLabSnapshot);
    const original = await snapshot();
    check('360 students and correct default metrics', original.config.students === 360 && Math.abs(original.metrics.meanWait - 9.435938785293592) < 1e-8);
    check('actual WebGL canvas', await page.locator('#scene3d canvas').count() === 1);
    await page.getByRole('button', { name: '查看窗口 1', exact: true }).click();
    check('window inspection reads result records', (await page.locator('#inspect-detail').innerText()).includes('实际平均服务'));
    await page.getByRole('button', { name: '设置方案', exact: false }).click();
    await page.getByRole('button', { name: '运行这个方案' }).click();
    assert.deepEqual((await snapshot()).config, original.config); checks.push('unchanged form does not mutate config');
    await page.getByRole('button', { name: '方案比较' }).click();
    await page.getByRole('button', { name: '保存当前方案为 A' }).click();
    await page.locator('#repeats').selectOption('10');
    await page.getByRole('button', { name: '开始比较' }).click();
    await page.waitForFunction(() => window.DiningLabSnapshot.comparison && !window.DiningLabSnapshot.busy);
    let current = await snapshot();
    check('identical A/B yields exactly zero paired differences', Object.values(current.comparison.differences).every(x => x.mean === 0 && x.low === 0 && x.high === 0));
    await page.getByRole('button', { name: '修改 B' }).click();
    await page.locator('[name="aWindows"]').fill('4');
    await page.getByRole('button', { name: '运行这个方案' }).click();
    await page.getByRole('button', { name: '开始比较' }).click();
    await page.waitForFunction(() => !window.DiningLabSnapshot.busy);
    current = await snapshot();
    const expected = R.compare(original.config, current.config, current.comparison.seeds);
    // Chrome/Node may differ in the final few bits of transcendental functions.
    // 1e-9 minutes is far below any displayed or physically measurable resolution.
    for (const key of Object.keys(expected.differences)) {
      for (const field of ['mean', 'sd', 'low', 'high'])
        assert.ok(Math.abs(current.comparison.differences[key][field] - expected.differences[key][field]) < 1e-9);
    }
    checks.push('UI experiment matches independent Node rerun within 1e-9 minutes');
    await page.screenshot({ path: 'qa/ui-comparison.png', fullPage: true });
    const downloadEvent = page.waitForEvent('download');
    await page.getByRole('button', { name: '导出实验', exact: true }).click();
    const dl = await downloadEvent; await dl.saveAs('qa/ui-export.json');
    assert.deepEqual(JSON.parse(fs.readFileSync('qa/ui-export.json')), current.comparison); checks.push('export is full computed comparison');
    await page.getByRole('button', { name: '方案筛选' }).click();
    if (await page.locator('#legacy-search').getAttribute('open') === null) await page.locator('#legacy-search>summary').click();
    await page.getByRole('button', { name: '开始筛选', exact: true }).click();
    await page.waitForFunction(() => window.DiningLabSnapshot.search && !window.DiningLabSnapshot.busy, { timeout: 120000 });
    current = await snapshot();
    check('25 finite candidates screened', current.search.screened.length === 25);
    check('validation seeds disjoint', !current.search.seedSets.screening.some(x => current.search.seedSets.verification.includes(x)));
    const retained = current.search.front.length;
    check('All retained candidates remain in the UI', await page.locator('[data-verify]').count() === retained);
    check('Only the first four candidates are expanded initially', await page.locator('[data-verify]:visible').count() === Math.min(4, retained));
    if (retained > 4) {
      await page.locator('.more-candidates > summary').click();
      check('Expanding candidates exposes every retained choice', await page.locator('[data-verify]:visible').count() === retained);
      await page.locator('.more-candidates > summary').click();
    }
    await page.locator('[data-verify]').first().click();
    await page.waitForFunction(() => window.DiningLabSnapshot.search.verifications.length && !window.DiningLabSnapshot.busy);
    current = await snapshot();
    check('30 fresh paired verification rounds', current.search.verifications[0].original.length === 30);
    const verification = current.search.verifications[0];
    const verifiedConfig = current.search.screened.find(x => x.id === verification.candidate).config;
    assert.deepEqual(verification.decision, D.assess(current.search.original, verifiedConfig, verification.original, verification.candidateRounds));
    check('Candidate verification explains grade impacts and exports the recomputable assessment', await page.locator('#verification-output .decision-insight').count() === 1);
    await page.screenshot({ path: 'qa/ui-search.png', fullPage: true });
    await page.getByRole('button', { name: '载入仿真' }).click();
    check('candidate apply returns to replay', (await snapshot()).tab === 'live');
    await page.getByRole('button', { name: '2D', exact: true }).click();
    check('2D uses same whole-population queue count', (await page.locator('#live-counts').innerText()).includes('排队') && (await page.locator('#scene2d .queue-count').count()) === current.config.windows);
    await page.getByRole('button', { name: '设置方案', exact: false }).click();
    await page.locator('[name="aWindows"]').fill('6');
    await page.getByRole('button', { name: '运行这个方案' }).click();
    check('infeasible parameter error remains visible', (await page.locator('#parameter-error').innerText()).includes('总窗口数'));
    await page.getByRole('button', { name: '取消', exact: true }).click();
    // Import a valid nonuniform scenario and make no edits. Preserve every hidden field.
    const mixed = R.example(); mixed.windowMeans = [17, 18, 19, 20, 21, 22]; mixed.grades[1].releaseTime = 32.345;
    mixed.gradeZoneWeights = [[.8, .2], [.6, .4], [.4, .6]]; mixed.returnDestination = 'dormitory'; mixed.sourceProfile = null;
    await page.locator('#file-input').setInputFiles({ name: 'mixed.json', mimeType: 'application/json', buffer: Buffer.from(JSON.stringify(R.session(mixed))) });
    await page.waitForFunction(() => window.DiningLabSnapshot.config.windowMeans[0] === 17);
    await page.getByRole('button', { name: '设置方案', exact: false }).click();
    await page.getByRole('button', { name: '运行这个方案' }).click();
    assert.deepEqual((await snapshot()).config, E.normalizeSchoolConfig(mixed)); checks.push('nonuniform imported scene survives no-op editing exactly');
    for (const width of [360, 768, 1024, 1440]) {
      await page.setViewportSize({ width, height: 1000 });
      await page.waitForTimeout(150);
      const geometry = await page.evaluate(() => ({ width: innerWidth, scroll: document.documentElement.scrollWidth }));
      check('no document horizontal overflow at ' + width, geometry.scroll <= geometry.width + 1);
      await page.screenshot({ path: `qa/ui-${width}.png`, fullPage: true });
    }
    const fallback = await browser.newPage();
    await fallback.goto('http://127.0.0.1:8769/?renderer=2d');
    await fallback.waitForFunction(() => window.DiningLabSnapshot);
    check('forced no-WebGL fallback keeps correct calculation', (await fallback.evaluate(() => window.DiningLabSnapshot)).mode === '2d');
    check('no runtime errors', errors.length === 0);
    check('no external runtime requests', network.every(url => url.startsWith('http://127.0.0.1:8769/') || url.startsWith('blob:')));
    fs.writeFileSync('qa/ui-check.json', JSON.stringify({ time: new Date().toISOString(), build: original.build, checks, errors, network }, null, 2));
    console.log(JSON.stringify({ passed: checks.length, errors }));
  } catch (error) {
    await page.screenshot({ path: 'qa/ui-failure.png', fullPage: true });
    fs.writeFileSync('qa/ui-check-failure.json', JSON.stringify({ checks, errors, error: String(error) }, null, 2));
    throw error;
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exit(1); });
