const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 const page=await browser.newPage({viewport:{width:1440,height:1100},acceptDownloads:true});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 try{
  await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);
  await page.locator('[data-tab=compare]').click();
  const fields=await page.locator('#result-scenario').textContent();
  for(const text of ['方案：年级与班级结合错峰','学生人数：1610人','窗口数量：16个','座位数量：480个']) assert.ok(fields.includes(text),fields);
  const tickCount=await page.locator('.chart-time-tick').count();assert.ok(tickCount>=7,tickCount);
  await page.locator('.file-menu > summary').click();
  const pending=page.waitForEvent('download');await page.locator('#export-run').click();
  const data=JSON.parse(fs.readFileSync(await(await pending).path(),'utf8'));
  if(await page.locator('.file-menu').getAttribute('open')!==null) await page.locator('.file-menu > summary').click();
  // Hover values must equal exported samples, not interpolation or fabricated counts.
  const result=data.result||data,curve=result.timeline;
  assert.ok(curve?.length,'Export must contain queue timeline');
  const peak=curve.reduce((best,p)=>p.waiting>best.waiting?p:best,curve[0]);
  const chart=page.locator('#queue-chart');await chart.scrollIntoViewIfNeeded();
  const box=await chart.locator('svg').boundingBox();
  await page.mouse.move(box.x+46+peak.time/result.metrics.observationEnd*(box.width-60),box.y+120);
  const tip=chart.locator('.queue-tooltip');await tip.waitFor({state:'visible'});
  assert.equal(Number(await tip.getAttribute('data-time')),peak.time);
  assert.equal(await tip.locator('strong').first().innerText(),peak.waiting+'人');
  const seat=result.diningTimeline.reduce((best,p)=>Math.abs(p.time-peak.time)<Math.abs(best.time-peak.time)?p:best);
  assert.equal(await tip.locator('strong').nth(1).innerText(),seat.seatWaiting+'人');
  await page.screenshot({path:'qa/readability-chart-hover.png'});
  await page.locator('#page-compare').screenshot({path:'qa/readability-results-desktop.png'});
  await chart.focus();await page.keyboard.press('End');
  assert.equal(Number(await tip.getAttribute('data-time')),curve.at(-1).time);
  await page.keyboard.press('Home');assert.equal(Number(await tip.getAttribute('data-time')),curve[0].time);
  await page.keyboard.press('ArrowRight');assert.equal(Number(await tip.getAttribute('data-time')),curve[1].time);
  await page.keyboard.press('Escape');assert.ok(await tip.isHidden());
  await page.locator('#result-back').click();await page.locator('#setup-seats').fill('600');await page.locator('#setup-windows').fill('12');
  await page.getByRole('button',{name:'开始仿真',exact:true}).click();
  await page.locator('#live-next').click();
  assert.ok((await page.locator('#result-scenario').textContent()).includes('座位数量：600个'));
  assert.ok((await page.locator('#result-scenario').textContent()).includes('窗口数量：12个'));
  for(const width of [320,390,768]){
   await page.setViewportSize({width,height:900});await page.waitForTimeout(120);
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
   await chart.scrollIntoViewIfNeeded();await chart.click({position:{x:90,y:120}});
   await tip.waitFor({state:'visible'});
   const b=await tip.boundingBox();assert.ok(b.x>=0&&b.x+b.width<=width+1);
   await page.screenshot({path:`qa/readability-results-${width}.png`,fullPage:true});
  }
  assert.deepEqual(errors,[]);
  const receipt={passed:true,build:(await page.evaluate(()=>window.DiningLabSnapshot)).build.id,tickCount,peakSample:peak,hoverMatchesExport:true,keyboardNavigation:true,changedConfigSummary:true,responsiveWidths:[320,390,768],errors};
  fs.writeFileSync('qa/readability-chart-audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
