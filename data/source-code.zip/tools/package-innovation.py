"""Package version 2.2 from explicit lists; clock and terminal evidence gate final output."""
from pathlib import Path
from datetime import datetime, timezone
import importlib.util, json, re, sys

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('dining_package_helpers',ROOT/'tools/package-release.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
files_under=helper.files_under
def main():
 final='--final' in sys.argv
 build=json.loads(re.search(r'Object\.freeze\((.*)\);',(ROOT/'dist/build-info.js').read_text(),re.S).group(1))
 final_files=[]
 if final:
  contract=json.loads((ROOT/'tasks/innovation-run-contract.json').read_text(encoding='utf-8'))
  assert contract['minimumSeconds']==18000
  start=datetime.fromisoformat(contract['startedAt']);end=datetime.fromisoformat(contract['earliestCompletion'])
  assert (end-start).total_seconds()==18000 and datetime.now(timezone.utc)>=end,'New five-hour task has not elapsed'
  terminal=json.loads((ROOT/'qa/innovation-reliability-summary.json').read_text(encoding='utf-8'))
  assert terminal['build']==build['id'] and terminal['taskTime']['taskStartedAt']==contract['startedAt']
  segment=terminal['segments'][0];assert segment['completionRecorded'] and segment['observedMinutes']>=30
  assert segment['cycles']>=15 and not segment['failures'] and not segment['runtimeErrors']
  assert datetime.fromisoformat(segment['terminal']['at'])>=end
  final_files=[ROOT/'qa'/n for n in ['innovation-reliability-summary.json','innovation-final-review.md','soak-innovation-final.jsonl']]
  assert all(p.is_file() for p in final_files)
 for name,h in build['files'].items():
  assert helper.digest((ROOT/'dist'/name).read_bytes())==h
  assert helper.digest((ROOT/'release/desktop/DiningLab/_internal/dist'/name).read_bytes())==h
 assert (ROOT/'dist/build-info.js').read_bytes()==(ROOT/'release/desktop/DiningLab/_internal/dist/build-info.js').read_bytes()
 label='食刻2.2';desktop=ROOT/'release/desktop/DiningLab'
 desktop_entries=[(p,'DiningLab/'+p.relative_to(desktop).as_posix()) for p in sorted(desktop.rglob('*')) if p.is_file()]
 desktop_entries += [(p,'DiningLab/licenses/'+p.name) for p in files_under('licenses')]
 desktop_entries.append((ROOT/'PROVENANCE.txt','DiningLab/PROVENANCE.txt'))
 desktop_note='食刻2.2 班级排程与跨餐轮换\n\n完整解压后双击DiningLab.exe，保留_internal文件夹。使用本机Microsoft Edge WebView2 Runtime。\n在方案筛选中生成班级放行表，选择目标后载入仿真；连续餐次可比较固定、循环和用时补偿。\n默认为360人合成教学场景。研究报告、六页指南、源码和完整实验见配套研究材料。\n离线网页入口为配套源码包dist/index.html。\n'
 packages=[helper.package(label+'_Windows桌面版.zip',desktop_entries,{'DiningLab/先读我.txt':desktop_note})]
 roots=['README.md','PROVENANCE.txt','package.json','package-lock.json','.gitignore','.gitattributes','.prettierrc.json','CAPABILITY-MAP.md','CAPABILITY-MAP-innovation.md']
 source=[ROOT/n for n in roots]+sorted(ROOT.glob('SPEC-*.md'))
 for folder in ['dist','desktop','tests','tools','learning','scenarios','examples','data','figures','documents','licenses']:source+=files_under(folder)
 research=['evidence-register.json','experiment-protocol.json','retrieval-manifest.json','award-list-verification.json','规则与证据说明.md','获奖资料复核.md','补充调研与适用边界.md','innovation-retrieval.json','innovation-evidence.json','innovation-protocol.json','innovation-comparison.md','open-claude-ui-reference.json','comparable-cafeteria-project.json']
 research += [p.name for p in (ROOT/'research').glob('decision-*.json')]
 source += [ROOT/'research'/n for n in research]+files_under('research/reference-files')
 source += [ROOT/'tasks'/n for n in ['innovation-run-contract.json','innovation-directions.md','innovation-iteration-log.md']]
 qa=['artifact.md','document-render.json','document-audit.json','oracle-result.json','stress-audit.json','ui-check.json','ui-data-check.json','ui-keyboard-check.json','ui-scale-check.json','ui-decision-check.json','ui-refresh-check.json','ui-planner-check.json','ui-planner-boundaries.json','ui-innovation-layout.json','desktop-exe-test.json','desktop-click-check.json','desktop-download-check.json','innovation-desktop-build.json','innovation-study-audit.json','innovation-figure-audit.json','innovation-figure-contract.md','innovation-figure-source-audit.json','innovation-document-visual-review.json','innovation-writing-audit.md','innovation-code-review.md','innovation-webview-investigation.md','webview-planner-before.json','webview-planner-diagnosis.json','desktop-innovation-exe-test-before.json','desktop-innovation-exe-test-after.json','innovation-pilot.json','innovation-core-tests.log','innovation-learning-tests.log','innovation-early-final-rejection.json','soak-innovation-round1.jsonl']
 for name in ['06-class-timetable','07-component-comparison','08-feedback-vs-cyclic','09-five-meal-prefix']:
  qa += [name+'-'+kind+'.json' for kind in ['alignment','collisions','text']]
 source += [ROOT/'qa'/n for n in qa]+final_files
 source += [ROOT/'qa'/n for n in ['ui-3d-animation-check.json','desktop-innovation-native-3d-test.json','innovation-3d-demo.json','innovation-source-reproduction.json','innovation-materials-reproduction.json','innovation-candidate-package-audit.json','innovation-reproduction-investigation.md','innovation-candidate2-offline.log']]
 entries=[(p,label+'/'+p.relative_to(ROOT).as_posix()) for p in sorted(set(source))]
 packages.append(helper.package(label+'_源码与研究材料.zip',entries,{}))
 documents=[ROOT/'documents/研究报告_公文格式.docx',ROOT/'documents/软件使用与学生研究指南.docx']
 packages.append(helper.package(label+'_Word文章与指南.zip',[(p,p.name) for p in documents],{'材料说明.txt':'研究报告采用公文版式，配套六页学生使用与研究指南。数值为合成模型实验，协助来源在文末说明。正式申报表及签章按当届学校报送要求另行办理。完整软件和逐轮数据在配套两个包中。\n'}))
 index={'build':build['id'],'iteration':'innovation-planner','stage':'final' if final else 'candidate','packages':packages,'documentBytes':sum(p.stat().st_size for p in documents)}
 (ROOT/'release/packages/package-index.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
 print(json.dumps(index,ensure_ascii=True))
if __name__=='__main__':main()
