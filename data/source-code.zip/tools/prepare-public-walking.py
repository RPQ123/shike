"""Refresh the selected Site's static files and public anonymous study records."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import shutil, json, hashlib
root=Path(__file__).resolve().parents[1]
site=root.parent/'sites/shike-canteen/dist'
assert (site.parent/'.openai/hosting.json').is_file()
assert json.loads((site.parent/'.openai/hosting.json').read_text())['project_id']=='appgprj_6ad5d73157d88191ac95da12347e8860'
for f in (root/'dist').rglob('*'):
    if f.is_file():
        out=site/f.relative_to(root/'dist');out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,out)
data=site/'data';data.mkdir(exist_ok=True)
for name in ['binhe-cohort-results.json','binhe-cohort-rounds.csv','binhe-cohort-summary.csv','binhe-cohort-timetable.csv','binhe-cohort-selection.json','binhe-cohort-session.json','indoor-walking-results.json','indoor-walking-rounds.csv','indoor-walking-summary.csv','indoor-walking-session.json']:
    shutil.copyfile(root/'data'/name,data/name)
for name in ['binhe-cohort-protocol.json','binhe-public-facts-2026-10-19.json']:
    shutil.copyfile(root/'research'/name,data/name)
with ZipFile(data/'all-research-data.zip','w',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for f in sorted((root/'data').iterdir()):
        if f.is_file():z.write(f,'data/'+f.name)
    for name in ['binhe-cohort-protocol.json','binhe-public-facts-2026-10-19.json']:
        z.write(root/'research'/name,'research/'+name)
old=(data/'index.html').read_text('utf-8')
old=old.replace('href="binhe-cohort-session.json"><strong>默认场景','href="indoor-walking-session.json"><strong>默认场景')
old=old.replace('可导入软件的招生计划人数场景','可导入软件，包含端盘步行和入座过程')
old=old.replace('最新800次计算的完整记录','原方案研究的800次计算记录，采用更新前的模型')
old=old.replace('完整研究结果<span>','原方案研究结果<span>')
old=old.replace('默认场景、800次计算和放行表相互对应。','默认场景已加入端盘步行。新增150次对照计算单独保存；原800次方案研究及放行表保留更新前的设置。')
addition=''
for name,title,desc in [
    ('indoor-walking-results.json','端盘步行对照结果','五组设置、每组30次：比较速度、座位数量与完整用时'),
    ('indoor-walking-rounds.csv','端盘步行逐次记录','150次计算，可用Excel打开'),
    ('indoor-walking-summary.csv','端盘步行汇总','端盘到位时间、等座时间与完整用时')]:
    addition+=f'<a class="item" download href="{name}"><strong>{title}<span>下载 ↓</span></strong><p>{desc}</p></a>'
if 'href="indoor-walking-results.json"' not in old:old=old.replace('<a class="item" download href="binhe-cohort-results.json">',addition+'<a class="item" download href="binhe-cohort-results.json">')
(data/'index.html').write_text(old,encoding='utf-8',newline='\n')
receipt={'files':len(list(site.rglob('*'))),'dataZipBytes':(data/'all-research-data.zip').stat().st_size,'dataZipSha256':hashlib.sha256((data/'all-research-data.zip').read_bytes()).hexdigest()}
(root/'qa/indoor-public-data.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
print(json.dumps(receipt))
