const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{const browser=await chromium.launch({headless:true,channel:'chrome'});const errors=[];
const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:2,acceptDownloads:true});page.on('pageerror',e=>errors.push(e.message));
const snap=()=>page.evaluate(()=>window.DiningLabSnapshot);
try {
 await page.goto(process.env.DINING_TEST_URL||'http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);
 assert.equal((await snap()).tab,'setup');assert.equal(await page.locator('.workflow-nav button').count(),3);
 assert.ok(await page.locator('.rail').evaluate(el=>el.getBoundingClientRect().height)<200);
 await page.screenshot({path:'qa/workflow-setup-desktop.png',fullPage:true});
 const waits={};
 for(const kind of ['none','grade','combined']) {
  await page.locator('[data-tab=setup]').click();await page.locator(`[name=preset][value=${kind}]`).check();
  if(kind==='none') assert.equal(await page.locator('#setup-gap').isVisible(),false);
  await page.locator('#setup-form button[type=submit]').click();const s=await snap();assert.equal(s.tab,'live');
  assert.equal(s.config.sourceProfile.id,'schedule-'+kind);waits[kind]=s.metrics.meanWait;
  assert.ok(await page.locator('#scene3d canvas').isVisible());
  const canvas=page.locator('#scene3d canvas'),pixels=await canvas.screenshot();await page.locator('#play').click();await page.waitForTimeout(450);await page.locator('#play').click();assert.notDeepEqual(pixels,await canvas.screenshot());
  await page.locator('#live-next').click();assert.equal((await snap()).tab,'compare');assert.ok(await page.locator('#kpis').isVisible());assert.ok(await page.locator('#queue-chart svg').isVisible());assert.equal(await page.locator('#study-run-three').isVisible(),false);
 }
 assert.ok(waits.none>waits.grade&&waits.grade>waits.combined);
 await page.locator('#result-back').click();await page.locator('#setup-students-0').fill('600');await page.locator('#setup-windows').fill('12');await page.locator('#setup-gap').fill('65');await page.locator('#setup-deadline').fill('12:55');
 await page.locator('[data-tab=live]').click();const changed=await snap();assert.equal(changed.config.students,1630);assert.equal(changed.config.windows,12);assert.equal(changed.config.grades[0].deadline,95);assert.ok(Math.abs(changed.config.grades[0].classInterval-3.25)<1e-9);
 await page.locator('#live-next').click();assert.ok((await page.locator('#result-scenario').innerText()).includes('1630'));
 await page.locator('#page-compare .file-menu summary').click();const download=page.waitForEvent('download');await page.locator('#export-run').click();const exported=JSON.parse(fs.readFileSync(await(await download).path(),'utf8'));assert.equal(exported.config.windows,12);assert.equal(exported.result.students.length,1630);
 await page.locator('#result-back').click();await page.locator('#setup-students-0').fill('-1');await page.locator('#setup-form button[type=submit]').click();assert.equal((await snap()).tab,'setup');assert.equal((await snap()).config.students,1630);
 // A running comparison can be cancelled after visiting setup, but parameters
 // cannot mutate underneath its saved seeds and input configuration.
 await page.locator('#setup-students-0').fill('600');
 await page.locator('[data-tab=compare]').click();await page.locator('#research-tools > summary').click();await page.locator('#study-run-three').click();
 await page.locator('[data-tab=setup]').click();await page.locator('#setup-windows').fill('8');await page.locator('#setup-form button[type=submit]').click();
 assert.equal((await snap()).config.windows,12);assert.ok((await page.locator('#setup-error').innerText()).includes('方案比较正在进行'));
 await page.locator('[data-tab=compare]').click();await page.locator('#study-cancel').click();await page.waitForFunction(()=>!DiningLabSnapshot.busy);
 // Fresh page restores the example; browser state is not silently persisted.
 await page.reload();await page.waitForFunction(()=>window.DiningLabSnapshot);assert.equal((await snap()).config.students,1610);
 await page.locator('#setup-advanced').click();await page.locator('[name=g0_releaseTime]').fill('11:55');await page.getByRole('button',{name:'运行这个方案'}).click();
 assert.equal((await snap()).config.grades[0].releaseTime,35);assert.ok(await page.locator('#setup-custom').isVisible());assert.equal(await page.locator('[name=preset]:checked').count(),0);
 await page.locator('#setup-windows').fill('14');await page.locator('#setup-form button[type=submit]').click();assert.equal((await snap()).config.grades[0].releaseTime,35);assert.equal((await snap()).config.windows,14);
 await page.reload();await page.waitForFunction(()=>window.DiningLabSnapshot);
 for(const width of [1440,768,390]) {
  await page.setViewportSize({width,height:1000});
  for(const tab of ['setup','live','compare']) {await page.locator(`[data-tab=${tab}]`).click();await page.waitForTimeout(250);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,tab+' width '+width);await page.screenshot({path:`qa/workflow-${tab}-${width}.png`,fullPage:true});}
 }
 assert.deepEqual(errors,[]);const receipt={passed:true,build:(await snap()).build.id,steps:3,presetWaits:waits,parameterHandoff:true,invalidInputBlocked:true,actual3DAnimation:true,exportMatchesParameters:true,widths:[1440,768,390],errors};fs.writeFileSync('qa/workflow-ui-audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
