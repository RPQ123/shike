// Check native modal focus and keyboard operation in actual Chrome.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');

(async () => {
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [], checks = [];
  page.on('pageerror', e => errors.push(String(e)));
  try {
    await page.goto(pathToFileURL(path.resolve('dist/index.html')).href);
    await page.waitForFunction(() => window.DiningLabSnapshot);
    await page.keyboard.press('Tab');
    assert.equal(await page.locator(':focus').getAttribute('class'), 'skip-link');
    checks.push('First keyboard target is the skip-to-content link');
    await page.locator('#parameters').focus();
    await page.keyboard.press('Enter');
    const dialog = page.getByRole('dialog', { name: '设置方案' });
    assert.equal(await dialog.count(), 1);
    assert.ok(await page.evaluate(() => document.activeElement.closest('#parameter-dialog')));
    await page.getByRole('button', { name: '运行这个方案' }).focus();
    await page.keyboard.press('Tab');
    // Chrome may take one stop through browser chrome (activeElement is body).
    // The next document target must still belong to the modal, never the inert page.
    if (await page.evaluate(() => document.activeElement === document.body))
      await page.keyboard.press('Tab');
    assert.ok(await page.evaluate(() => document.activeElement.closest('#parameter-dialog')));
    await page.keyboard.press('Escape');
    assert.equal(await dialog.count(), 0);
    assert.equal(await page.locator(':focus').getAttribute('id'), 'parameters');
    checks.push('Named modal contains tab focus; Escape restores its invoking button');
    await page.getByRole('button', { name: '2D', exact: true }).focus();
    await page.keyboard.press('Enter');
    await page.locator('#scene2d [data-window="0"]').focus();
    await page.keyboard.press('Enter');
    assert.match(await page.locator('#inspect-detail').innerText(), /实际平均服务/);
    checks.push('2D window records can be opened with Enter');
    await page.getByRole('button', { name: '3D', exact: true }).click();
    assert.equal(await page.locator('.scene-station-label.is-closed button').count(), 0);
    assert.equal(await page.locator('button.scene-station-label').count(), 6);
    checks.push('Only the six open 3D windows are interactive; closed slots are labels');
    await page.screenshot({ path: 'qa/ui-default-3d.png', fullPage: true });
    assert.deepEqual(errors, []);
    fs.writeFileSync('qa/ui-keyboard-check.json', JSON.stringify({ at: new Date().toISOString(), build: await page.evaluate(()=>window.DiningLabSnapshot.build), checks, errors }, null, 2));
    console.log(JSON.stringify({ passed: checks.length, errors }));
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exit(1); });
