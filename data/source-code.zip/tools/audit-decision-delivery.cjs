// Bind this supplemental iteration to its research, documents, frozen build and packages.
// No former three/five-hour task timing is reused. --final requires this run's terminal log.
const fs=require('node:fs'), crypto=require('node:crypto'), assert=require('node:assert/strict');
const R=require('../dist/research.js'), D=require('../dist/decision-support.js');
const S=require('./run-decision-study.cjs');
const load=p=>JSON.parse(fs.readFileSync(p,'utf8'));
const sha=x=>crypto.createHash('sha256').update(x).digest('hex');
const checks=[];
const final=process.argv.includes('--final'), packages=process.argv.includes('--packages');
const build=JSON.parse(fs.readFileSync('dist/build-info.js','utf8').match(/Object\.freeze\((.*)\);/s)[1]);
for(const [file,hash] of Object.entries(build.files)) {
 assert.equal(sha(fs.readFileSync('dist/'+file)),hash,file);
 assert.equal(sha(fs.readFileSync('release/desktop/DiningLab/_internal/dist/'+file)),hash,'desktop/'+file);
}
assert.equal(sha(fs.readFileSync('dist/build-info.js')),sha(fs.readFileSync('release/desktop/DiningLab/_internal/dist/build-info.js')));
checks.push('Current desktop and offline resources match all stamped file hashes');
for(const [file,protocol] of [['data/study-results.json','research/experiment-protocol.json'],['data/decision-study-results.json','research/decision-protocol.json']]) {
 const study=load(file);
 for(const [source,hash] of Object.entries(study.sourceHashes)) assert.equal(sha(fs.readFileSync(source)),hash,source);
 assert.equal(sha(JSON.stringify(load(protocol))),study.protocolSha256);
}
const study=load('data/decision-study-results.json');
assert.deepEqual(S.select(study.screened,study.protocol.referenceId),study.selection);
assert.deepEqual(load('data/decision-frozen-selection.json'),study.frozen);
assert.ok(Date.parse(study.frozen.frozenAt)<=Date.parse(study.verificationStartedAt));
let executions=0;const unique=new Set();
for(const row of study.records) {
 assert.equal(sha(JSON.stringify(row.config)),row.configSha256);
 const expected=R.summarize(row.rounds.map(({seed,...metrics})=>metrics));
 for(const key of Object.keys(expected)) assert.ok(Math.abs(expected[key]-row.summary[key])<1e-9,`${row.contextId}/${row.policyId}/${key}`);
 const range=row.phase==='screening'?study.protocol.screeningSeeds:study.protocol.verificationSeeds;
 assert.deepEqual(row.rounds.map(x=>x.seed),Array.from({length:range.count},(_,i)=>range.start+i));
 for(const round of row.rounds) {
  const id=[row.phase,row.contextId,row.policyId,round.seed].join('/');
  assert.ok(!unique.has(id)); unique.add(id); executions++;
 }
}
assert.equal(executions,3210);assert.equal(executions,study.counts.uniqueExecutions);
for(const row of study.verification) {
 const a=study.records.find(x=>x.phase==='verification'&&x.contextId===row.contextId&&x.policyId===study.protocol.referenceId);
 const b=study.records.find(x=>x.phase==='verification'&&x.contextId===row.contextId&&x.policyId===row.policyId);
 assert.deepEqual(D.assess(a.config,b.config,a.rounds,b.rounds,study.protocol.thresholdMinutes),row.assessment);
}
checks.push('Both research batches retain matching sources/protocols; 3210 unique supplemental executions and all held-out verdicts recompute');
const docs=load('qa/document-audit.json');assert.equal(docs.templateUnchanged,true);
for(const item of docs.documents) assert.equal(sha(fs.readFileSync('documents/'+item.file)),item.sha256);
for(const figure of load('qa/decision-figure-audit.json').figures) {
 assert.equal(sha(fs.readFileSync(figure.source)),figure.sourceSha256);
 for(const file of figure.files) assert.equal(sha(fs.readFileSync(file.file)),file.sha256);
}
checks.push('Reviewed Word documents and all new figure exports match their audited data and hashes');
for(const file of ['ui-check.json','ui-decision-check.json','ui-refresh-check.json','ui-data-check.json','ui-keyboard-check.json','ui-scale-check.json','desktop-click-check.json','ui-soak-repeat-check.json']) {
 const qa=load('qa/'+file);assert.equal(qa.build.id,build.id,file);
 assert.deepEqual(qa.errors||qa.logs||[],[],file);
 assert.ok(Date.parse(qa.at||qa.time)>=Date.parse(build.createdAt));
}
assert.equal(load('qa/desktop-exe-test.json').ok,true);
assert.equal(load('qa/desktop-download-check.json').ok,true);
const core=fs.readFileSync('qa/decision-core-tests.log','utf8');
const coreTests=Number(core.match(/tests (\d+)/)?.[1]);
assert.ok(coreTests>=212);assert.match(core,/fail 0\b/);assert.match(core,new RegExp('pass '+coreTests+'\\b'));
assert.match(fs.readFileSync('qa/decision-learning-tests.log','utf8'),/Ran 5 tests[\s\S]*OK/);
checks.push('Current-build browser, WebView2, offline, core and teaching-model checks passed');
const log='qa/soak-decision-final.jsonl';
const events=fs.readFileSync(log,'utf8').trim().split('\n').map(JSON.parse);
const starts=events.filter(x=>x.event==='start');assert.equal(starts.length,1,'Do not concatenate observations');
const start=starts[0], cycles=events.filter(x=>x.event==='cycle'), terminal=events.find(x=>x.event==='complete');
assert.equal(start.initial.build.id,build.id);
assert.ok(Date.parse(start.at)>=Date.parse(build.createdAt));
assert.ok(!events.some(x=>['failure','stopped','pageerror'].includes(x.event)));
const heaps=cycles.flatMap(x=>x.memory.filter(m=>m.name==='JSHeapUsedSize').map(m=>m.value/1048576));
const segment={file:log,start:start.at,until:start.until,build:build.id,cycles:cycles.length,
 completionRecorded:!!terminal,failures:[],runtimeErrors:[],
 heapMiBRange:heaps.length?[Math.min(...heaps),Math.max(...heaps)]:null};
if(final) {
 assert.ok(terminal,'Current reliability observation must finish');
 assert.ok(Date.parse(terminal.at)>=Date.parse(start.until));
 assert.ok(terminal.elapsedSeconds>=1800,'At least 30 actual minutes of final-build observation');
 assert.equal(terminal.cycles,cycles.length);assert.equal(terminal.failures,0);assert.deepEqual(terminal.errors,[]);
 assert.ok(cycles.length>=15 && cycles.every(x=>x.interfaceChecks&&x.decisionChecks));
 segment.terminal=terminal;segment.observedMinutes=terminal.elapsedSeconds/60;
 fs.writeFileSync('qa/decision-reliability-summary.json',JSON.stringify({build:build.id,segments:[segment],scope:'This iteration has no new user-imposed fixed duration. This is an actual completed final-build interaction observation, not the former three/five-hour task. Heap ranges do not prove absence of leaks.'},null,2));
 checks.push('This final build completed its own 30+ minute interaction observation without recorded failures');
}
if(packages) {
 const index=load('release/packages/package-index.json');assert.equal(index.build,build.id);
 assert.equal(index.iteration,'research-decision-support');
 if(final) assert.equal(index.stage,'final');
 for(const p of index.packages) assert.equal(sha(fs.readFileSync('release/packages/'+p.file)),p.sha256);
 const smoke=load('qa/package-smoke.json');assert.equal(smoke.build,build.id);
 assert.equal(smoke.sourceCoreTests,coreTests);assert.equal(smoke.desktopUnpackedStartup,true);
 assert.equal(smoke.extractedArchives.length,2);
 for(const item of smoke.extractedArchives) {
  const p=index.packages.find(x=>x.file===item.file);
  assert.equal(item.sha256,p.sha256);assert.equal(item.manifestSha256,p.manifestSha256);assert.equal(item.verifiedFiles,p.entries);
 }
 checks.push('Newly extracted source/desktop archives match exact ZIP and manifest hashes and actual offline/EXE launch tests');
}
const report={at:new Date().toISOString(),build:build.id,checks,coreTests,supplementalExecutions:executions,
 documentsBytes:docs.combinedBytes,segments:[segment],status:final?(packages?'final':'terminal evidence ready; package verification pending'):'candidate'};
fs.writeFileSync('qa/decision-delivery-audit.json',JSON.stringify(report,null,2));
console.log(JSON.stringify({build:build.id,checks:checks.length,status:report.status,cycles:cycles.length}));
