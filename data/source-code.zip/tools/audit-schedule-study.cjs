const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const S=require('../dist/schedule-study'),E=require('../dist/school-engine'),R=require('../dist/research');
const data=JSON.parse(fs.readFileSync('data/schedule-study-results.json','utf8')),sha=b=>crypto.createHash('sha256').update(b).digest('hex');
assert.equal(data.protocolSha256,sha(fs.readFileSync('data/schedule-study-protocol.json')));
for(const [file,hash] of Object.entries(data.sourceHashes))assert.equal(sha(fs.readFileSync(file)),hash,file);
let executions=0;
for(const stage of ['initial','intervals','verification','gradeCheck'])for(const row of data[stage]){
 for(const raw of row.rounds){const actual=S.metrics(E.simulateSchool({...row.config,seed:raw.seed}));for(const key of Object.keys(actual))assert.ok(Math.abs(actual[key]-raw[key])<1e-9,`${stage}/${row.id}/${raw.seed}/${key}`);executions++}
 assert.deepEqual(S.summarize(row.rounds),row.summary);
}
assert.equal(executions,data.executions);assert.equal(executions,660);assert.equal(S.select(data.intervals,data.protocol.returnTarget).seconds,data.selectedSeconds);
assert.ok(data.verification[2].summary.meanWait<data.verification[1].summary.meanWait&&data.verification[1].summary.meanWait<data.verification[0].summary.meanWait);
assert.ok(data.verification[2].summary.lastEndpointMax<=data.protocol.returnTarget);
assert.ok(data.verification[2].summary.meanTotal>data.verification[1].summary.meanTotal,'Keep the real full-time increase');
const allSeeds=Object.values(data.protocol.seeds).flat();assert.equal(new Set(allSeeds).size,allSeeds.length);
const receipt={passed:true,executions,selectedSeconds:data.selectedSeconds,allRowsRecomputed:true,completeTimeIncreasePreserved:true,verificationWithinReturnTarget:true,sourceHashes:data.sourceHashes,resultsSha256:sha(fs.readFileSync('data/schedule-study-results.json'))};
fs.writeFileSync('qa/schedule-data-audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
