"""Record sentence coverage and preserve the factual contents of the report."""
from pathlib import Path
from docx import Document
from zipfile import ZipFile
import hashlib, json, re

root = Path(__file__).resolve().parents[1]
before = root / 'qa/sentence-before-20261020/documents/schedule-edition'
after = root / 'documents/sentence-edition'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
notes = {
 1: '摘要先写方案设计和研究目的，再说明比较方法、软件作用与结论；取消含糊的“使排队改善与午间安排相协调”。',
 4: '原句将人数与速度比较，量纲不一致；改为同一时段到达人数与可接待人数比较，并合并重复解释。',
 5: '明确年级错峰后仍需考虑同一年级各班的到达时间；用两个实际问题代替“进一步比较”的空泛连接。',
 6: '统一计时起点，直接说明推迟出发为何会增加在教室等待的时间，保留平均排队为主要指标。',
 8: '将研究目的写成两个具体问题，并解释班级放行表就是列明各班出发时刻的表。',
 10: '分别交代学校方案和三篇国内论文提供了什么信息；不增加走访、调查或新的检索日期。',
 11: '明确一组代表一个班，并在使用前定义相邻组间隔；1610人仍为示例。',
 13: '补上“软件”这一动作主体，明确只改变出发时刻的比较方法。',
 15: '按三方案比较、间隔比较、放行表顺序说明，并将等座和返回时刻写全。',
 19: '将“每组计算”改为“每种方案或间隔重复计算”，区分班级组与实验次数；说明不同阶段使用不同随机用时。',
 21: '按操作者填写、进入页面、比较、导出的顺序写，避免用抽象的软件组织顺序代替说明。',
 23: '明确JavaScript负责网页，Python是独立核对工具；区分记录时刻与计算时间。',
 25: '用轮次、年级、班级解释两层for和if的作用，写清出发秒数相对哪个起点。',
 32: '解释从0计数、出发序号及其与间隔的关系；代码逐字不改。',
 34: '先定义单人排队时间，再写全体平均值，避免将三年级平均值直接相加求平均。',
 36: '说明新到学生、正在打饭的学生和队伍中等候者的区别，使q、m、r的含义与公式对应。',
 38: '写明乙窗口正在服务但无人继续排队，列出5+10=15秒的推算；不把排队时间与取餐总耗时混同。',
 40: '定义完整用时及其平均值；单独定义最后一名学生返回教室的时刻。',
 41: '写明16窗口持续打饭的估算条件，保留高中除法和速度关系，不把估算写成实测。',
 44: '将“将出发时间相隔”改为“将出发间隔设为”；说明10分钟的来由和5/15分钟的检查目的。',
 47: '给每个数字配上对应方案；解释同一时段到达人数减少与队伍变短的关系，并明确细线对应平均排队时间。',
 49: '说明A33计算年级顺序数，但本阶段固定一个顺序，仅比较间隔。',
 50: '将嵌套条件拆为保留可按时返回的安排、比较排队、补充附近间隔、最后选择四步。',
 53: '明确70/75秒分别对应的返回时刻，区分筛选数据与重新生成用时后的最终复核。',
 56: '把“把等待留在教室”展开为学生更晚出发、站队缩短、教室等待增加和平均返回推后的关系；保留3.53分钟增加。',
 58: '说明年级间隔变长与班级间隔是两个层面的安排，替换“分散这批人数”等搭配。',
 60: '明确210秒从高三第一个班到第二个班计算，避免被读成从高一出发后再等210秒；保留空时段的规则。',
 62: '写清观察者记录哪些时刻，以及这些记录分别用来判断什么。',
 63: '区分输入参数、软件比较、学校试行和实际记录；解释“座位周转”为座位是否及时腾出。',
 65: '结论按方案逐项对应数据，直接说明班级错峰的排队效果。',
 66: '保留13个候选、13:00返回目标和平均完整用时增加，写清学校如何据此安排午间时间。',
 67: '把“人数与接待能力接近”改为同一时间间隔内的接待人数与班级人数大致相当。',
 68: '用学校作主体，拆开参数输入与操作结果，说明公开网页、Windows与供餐区域的使用方式。',
 69: '明确教师和食堂工作人员商定、班级按表出发、记录后调整的实施顺序。',
 70: '将无主语的“实际应用希望”改为推广目的；情绪改善仍由应用后的匿名反馈检查。'
}

records = []
stats = {}
for stem in ['研究报告_公文格式', '软件使用与学生研究指南']:
    old = Document(before / (stem + '.docx'))
    new = Document(after / (stem + '.docx'))
    a = [p for p in old.paragraphs if p.text.strip()]
    b = [p for p in new.paragraphs if p.text.strip()]
    assert len(a) == len(b), 'Paragraph structure must be preserved'
    changed = 0
    for index, (left, right) in enumerate(zip(a, b)):
        x, y = left.text, right.text
        changed += x != y
        reference = x.startswith('[')
        code = x.startswith(('for round_index', '    for position', '        if round_index', '            seconds', '                       + position', '            slots.append'))
        if code or reference:
            assert x == y
        equation = '＝' in x and left.alignment == 1
        structural = reference or code or equation or bool(re.match(r'^(?:[一二三四五六七八九十]+、|（[一二三四五六七八九十]+）|[图表]\d|关键词：)', x)) or x == a[0].text
        if structural:
            continue
        # Chinese sentence punctuation avoids splitting decimal numbers and URLs.
        sentences = [s for s in re.findall(r'[^。！？]+[。！？]?', x) if s.strip()]
        reason = notes.get(index) if stem.startswith('研究报告') else '按实际操作顺序校订；解释组、完整用时、末名返回的平均值与最晚值，并保留按钮名称。'
        reason = reason or '检查主语、指代、用词与前后衔接；原句含义和必要表述保留。'
        for sentence_index, sentence in enumerate(sentences, 1):
            records.append({'document': stem, 'paragraph': index, 'sentence': sentence_index,
                            'before': sentence, 'afterParagraph': y,
                            'decision': '所在段落已校订' if x != y else '保留', 'review': reason})
    stats[stem] = {'nonemptyParagraphs': len(a), 'changedParagraphs': changed,
                   'originalSentencesReviewed': sum(row['document'] == stem for row in records)}
    assert old.sections[0]._sectPr.xml == new.sections[0]._sectPr.xml
    assert len(old.inline_shapes) == len(new.inline_shapes)
    assert len(old.tables) == len(new.tables)
    for left, right in zip(old.tables, new.tables):
        assert [[re.findall(r'\d+(?:\.\d+)?', c.text) for c in row.cells] for row in left.rows] == [[re.findall(r'\d+(?:\.\d+)?', c.text) for c in row.cells] for row in right.rows]
    with ZipFile(before / (stem + '.docx')) as original, ZipFile(after / (stem + '.docx')) as revised:
        for name in original.namelist():
            if name.startswith(('word/styles', 'word/theme/', 'word/header', 'word/footer', 'word/numbering', 'word/media/')):
                assert original.read(name) == revised.read(name), name

build = json.loads((root / 'dist/build-info.js').read_text('utf-8').split('Object.freeze(', 1)[1].rsplit(');', 1)[0])
for name, digest in build['files'].items():
    assert sha((root / 'dist' / name).read_bytes()) == digest
saved = json.loads((root / 'qa/sentence-before-20261020/qa/schedule-package-audit.json').read_text('utf-8'))
assert sha((root / 'data/schedule-study-results.json').read_bytes()) == saved['resultsSha256']
result = {'passed': True, 'reviewDate': '2026-10-20', 'statistics': stats,
          'originalBodySentencesReviewed': len(records), 'sentences': records,
          'numericTablesUnchanged': True, 'referencesUnchanged': True, 'codeUnchanged': True,
          'figuresAndFormattingPreserved': True, 'simulationBuildUnchanged': build['id'],
          'reportPdfSha256': sha((after / '研究报告_公文格式.pdf').read_bytes())}
(root / 'qa/sentence-review-ledger.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({k: v for k, v in result.items() if k != 'sentences'}, ensure_ascii=False, indent=2))
