"""Rebuild figures and DOCX files in a new directory without changing supplied artifacts."""
from pathlib import Path
from datetime import datetime, timezone
from zipfile import ZipFile
import argparse, hashlib, json, os, shutil, subprocess, sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--figure-python', default=sys.executable, help='Python with matplotlib/numpy, if different from the DOCX Python')
    args = parser.parse_args()
    started = datetime.now(timezone.utc)
    target = ROOT/'qa'/('materials-reproduction-'+started.strftime('%Y%m%d%H%M%S%f'))
    assert not target.exists()
    assert target.resolve().is_relative_to((ROOT/'qa').resolve())
    for directory in ['tools', 'data', 'figures', 'qa', 'documents/templates']:
        (target/directory).mkdir(parents=True)
    tools = ['make-report.py','make-guide.py','report_innovation.py','guide_innovation.py','document_metadata.py','make-innovation-figures.py']
    copied = ['tools/'+name for name in tools] + ['documents/templates/公文模板.docx','data/innovation-study-results.json']
    source_hashes = {}
    for file in copied:
        source_hashes[file] = sha(ROOT/file)
        shutil.copyfile(ROOT/file,target/file)
    env = dict(os.environ, PYTHONIOENCODING='utf-8')
    env.pop('DINING_FIGURE_AUDIT_DIR', None)
    def run(python, script, *extra):
        result = subprocess.run([python,'tools/'+script,*extra],cwd=target,env=env,capture_output=True,text=True,encoding='utf-8')
        (target/(script+'.log')).write_text(result.stdout+result.stderr,encoding='utf-8')
        if result.returncode:
            raise RuntimeError(script+': '+result.stderr)
    run(args.figure_python,'make-innovation-figures.py','--render-only')
    figure_names = ['06-class-timetable','07-component-comparison','08-feedback-vs-cyclic','09-five-meal-prefix']
    figures = []
    for name in figure_names:
        assert sha(target/'figures'/(name+'.png')) == sha(ROOT/'figures'/(name+'.png')), name+' PNG differs'
        figures.append({'file':'figures/'+name+'.png','sha256':sha(target/'figures'/(name+'.png'))})
    assert sha(target/'figures/innovation-source-data.csv') == sha(ROOT/'figures/innovation-source-data.csv'), 'Source CSV differs'
    run(sys.executable,'make-report.py')
    run(sys.executable,'make-guide.py')
    documents = []
    for name in ['研究报告_公文格式.docx','软件使用与学生研究指南.docx']:
        with ZipFile(ROOT/'documents'/name) as expected, ZipFile(target/'documents'/name) as actual:
            assert set(actual.namelist()) == set(expected.namelist()), name+' ZIP entries differ'
            for part in actual.namelist():
                left,right = expected.read(part),actual.read(part)
                if part=='docProps/core.xml':
                    def remove_run_dates(blob):
                        tree=ET.fromstring(blob)
                        for key in ['created','modified']:
                            item=tree.find('{http://purl.org/dc/terms/}'+key)
                            if item is not None: item.text='RUN-TIME'
                        return ET.tostring(tree)
                    left,right=remove_run_dates(left),remove_run_dates(right)
                assert left==right, name+'/'+part+' differs'
            documents.append({'file':'documents/'+name,'originalSha256':sha(ROOT/'documents'/name),'partsCompared':len(actual.namelist()),
                              'documentXmlSha256':hashlib.sha256(actual.read('word/document.xml')).hexdigest(),
                              'excludedFields':['docProps/core.xml created','docProps/core.xml modified']})
    report={'passed':True,'startedAt':started.isoformat(),'completedAt':datetime.now(timezone.utc).isoformat(),
            'target':str(target),'sourceHashes':source_hashes,'figures':figures,
            'sourceCsvSha256':sha(target/'figures/innovation-source-data.csv'),'documents':documents,
            'scope':'Fresh figure and DOCX generation from the supplied sources, data and retained template. PNG and CSV bytes match exactly; every DOCX ZIP part matches except two actual run dates. No external Codex skill required for render-only reproduction. This is reproduction, not a new visual or external publication audit.'}
    report_file=target/'reproduction-audit.json'
    report_file.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'passed':True,'target':str(target),'reportFile':str(report_file),'figures':len(figures),'documents':len(documents)},ensure_ascii=True))

if __name__=='__main__': main()
