const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'}),page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});const errors=[];page.on('pageerror',e=>errors.push(e.message));const snap=()=>page.evaluate(()=>DiningLabSnapshot);
 try{
  await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);
  assert.equal(await page.locator('[name=preset]:checked').inputValue(),'combined');assert.ok(await page.locator('.setup-order').evaluate(e=>e.open));
  const drag=async(id,to)=>{const a=page.locator(`[data-grade="${id}"]`);await a.scrollIntoViewIfNeeded();const b=await a.boundingBox(),target=await page.locator('.grade-order-block').nth(to).boundingBox();await page.mouse.move(b.x+b.width/2,b.y+b.height/2);await page.mouse.down();await page.mouse.move(target.x+target.width/2,target.y+target.height/2,{steps:12});await page.mouse.up();};
  await drag(0,0);assert.equal(await page.locator('#setup-order').inputValue(),'0,2,1');
  await page.locator('[data-grade="1"]').focus();await page.keyboard.press('Home');assert.equal(await page.locator('#setup-order').inputValue(),'1,0,2');
  await page.locator('#setup-form button[type=submit]').click();assert.deepEqual((await snap()).config.grades.slice().sort((a,b)=>a.releaseTime-b.releaseTime).map(g=>g.id),[1,0,2]);
  assert.equal(await page.locator('#peak').innerText(),'查看排队最高峰时刻');assert.equal(await page.locator('#speed option').first().innerText(),'1倍速');
  assert.equal(await page.locator('#scene-labels').innerText(),'隐藏场景信息');await page.locator('#scene-labels').click();assert.equal(await page.locator('.scene-label-layer').isVisible(),false);assert.equal(await page.locator('#scene-labels').innerText(),'显示场景信息');await page.locator('#scene-labels').click();assert.ok(await page.locator('.scene-label-layer').isVisible());
  const counts=[];
  for(const seats of [480,600,601,7,80,5000]){
   await page.locator('[data-tab=setup]').click();await page.locator('#setup-seats').fill(String(seats));await page.locator('#setup-form button[type=submit]').click();await page.waitForTimeout(180);
   const s=await snap();assert.equal(s.config.seats,seats);assert.equal(s.rendering.seatCount,seats);assert.equal(s.rendering.chairsDrawn,seats);assert.equal(s.rendering.tableCount,Math.ceil(seats/8));assert.ok(await page.locator('#scene3d canvas').isVisible());
   counts.push({seats,tables:s.rendering.tableCount,chairs:s.rendering.chairsDrawn});
   if(seats===600){await page.screenshot({path:'qa/seating-600-live.png',fullPage:true});await page.locator('#live-next').click();await page.locator('.file-menu summary').click();const promise=page.waitForEvent('download');await page.locator('#export-run').click();const result=JSON.parse(fs.readFileSync(await(await promise).path(),'utf8'));assert.equal(result.config.seats,600);assert.ok(result.result.students.every(s=>s.seatId<600));}
  }
  await page.reload();await page.waitForFunction(()=>window.DiningLabSnapshot);
  for(const width of [1440,768,390,320]){
   await page.setViewportSize({width,height:1000});
   for(const tab of ['setup','live','compare']){
    await page.locator(`[data-tab=${tab}]`).click();await page.waitForTimeout(300);
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,tab+' '+width);
    if(tab==='setup'){const boxes=await page.locator('.grade-order-block').evaluateAll(els=>els.map(e=>({width:e.clientWidth,scroll:e.scrollWidth})));assert.ok(boxes.every(b=>b.scroll<=b.width+1),JSON.stringify({width,boxes}));}
    if(width===1440||width===390)await page.screenshot({path:`qa/seating-${tab}-${width}.png`,fullPage:true});
   }
  }
  assert.deepEqual(errors,[]);const receipt={passed:true,build:(await snap()).build.id,counts,dragChangesActualReleaseOrder:true,keyboardOrdering:true,defaultCombined:true,labelsToggle:true,widths:[1440,768,390,320],errors};fs.writeFileSync('qa/seating-ui-audit.json',JSON.stringify(receipt,null,2));console.log(receipt);
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
