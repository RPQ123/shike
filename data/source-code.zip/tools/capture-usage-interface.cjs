const {chromium}=require('playwright');
const fs=require('node:fs'),crypto=require('node:crypto'),assert=require('node:assert/strict');
(async()=>{
  const browser=await chromium.launch({headless:true,channel:'chrome'});
  try{
    const page=await browser.newPage({viewport:{width:680,height:1100},deviceScaleFactor:3});
    await page.goto('http://127.0.0.1:8771/');
    await page.waitForFunction(()=>!!window.DiningLabSnapshot);
    await page.locator('#setup-advanced').click();
    const section=page.locator('.parameter-group').filter({has:page.locator('summary',{hasText:'班级安排与时间限制'})});
    await section.locator('summary').click();
    await section.scrollIntoViewIfNeeded();
    const first=section.locator('.grade-fields').first();
    const clip=await first.evaluate(el=>{
      const a=el.parentElement.getBoundingClientRect(),b=el.getBoundingClientRect();
      return {x:a.x+scrollX,y:a.y+scrollY,width:a.width,height:b.bottom-a.y+12};
    });
    await page.screenshot({path:'figures/student/24-class-parameters.png',clip});
    await page.locator('#close-parameters').click();
    await page.locator('#setup-form button[type=submit]').click();
    await page.locator('#live-next').click();
    await page.locator('.result-overview').screenshot({path:'figures/student/25-usage-results.png'});
    const snapshot=await page.evaluate(()=>window.DiningLabSnapshot);
    assert.ok(await page.locator('#result-scenario').innerText());
    const files=['24-class-parameters.png','25-usage-results.png'].map(name=>({name,sha256:crypto.createHash('sha256').update(fs.readFileSync('figures/student/'+name)).digest('hex')}));
    const receipt={passed:true,build:snapshot.build.id,deviceScaleFactor:3,source:'Live application UI, unmodified DOM; parameter fold and computed result',files};
    fs.writeFileSync('qa/usage-interface-capture.json',JSON.stringify(receipt,null,2));
    console.log(JSON.stringify(receipt));
  }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
