const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const R = require('../dist/research.js');

(async () => {
  const browser = await chromium.launch({ headless:true, channel:'chrome' });
  const page = await browser.newPage();
  page.setDefaultTimeout(5000);
  const errors=[];
  page.on('pageerror', e=>errors.push(String(e)));
  try {
    await page.goto('http://127.0.0.1:8769/?renderer=2d');
    await page.waitForFunction(()=>window.DiningLabSnapshot);
    const config=R.example();
    config.students=5000;
    config.grades.forEach((g,i)=>{g.students=i===2?1666:1667;g.classes=50;g.latestReleaseTime=null});
    config.windows=16; config.windowMeans=Array(16).fill(20);
    config.windowZones=Array.from({length:16},(_,i)=>i<8?0:1);
    config.windowOwners=Array.from({length:16},(_,i)=>Math.min(2,Math.floor(i*3/16)));
    await page.locator('#file-input').setInputFiles({name:'large.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(R.session(config)))});
    await page.waitForFunction(()=>window.DiningLabSnapshot.config.students===5000);
    await page.locator('[data-tab="search"]').click();
    if (await page.locator('#legacy-search').getAttribute('open') === null) await page.locator('#legacy-search>summary').click();
    await page.locator('#search-run').click();
    await page.getByRole('button',{name:'取消本轮计算',exact:true}).click();
    await page.waitForFunction(()=>!window.DiningLabSnapshot.busy);
    assert.equal((await page.evaluate(()=>window.DiningLabSnapshot)).search,null);
    assert.match(await page.locator('#search-output').innerText(),/已取消/);
    assert.equal(await page.locator('#parameters').isEnabled(),true);
    await page.locator('[data-tab="live"]').click();
    await page.locator('#example-reset').click();
    assert.equal((await page.evaluate(()=>window.DiningLabSnapshot)).config.students,360);
    assert.deepEqual(errors,[]);
    fs.writeFileSync('qa/ui-interruption-check.json',JSON.stringify({at:new Date().toISOString(),people:5000,cancelled:true,noPartialRecommendation:true,editableAfterCancel:true,errors},null,2));
    console.log('Maximum-size search cancels without partial recommendation; editing remains usable.');
  } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
