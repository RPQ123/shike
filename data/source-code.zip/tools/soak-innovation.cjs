// Real repeat operations on one retained browser, with a frozen offline build.
const {chromium}=require('playwright'),fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const E=require('../dist/school-engine.js'),R=require('../dist/research.js');
const deadline=Date.parse(process.argv[2]),file=process.argv[3];
if(!Number.isFinite(deadline)||deadline<=Date.now()||!file)throw new Error('Use a future ISO deadline and a fresh JSONL path');
if(fs.existsSync(file))throw new Error('Observation log already exists; retain it and choose a new path');
const log=row=>fs.appendFileSync(file,JSON.stringify({at:new Date().toISOString(),...row})+'\n');
const sha=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
const started=Date.now();
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'}),page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
 page.setDefaultTimeout(15000);
 const errors=[];page.on('pageerror',e=>{errors.push(String(e));log({event:'pageerror',error:String(e)});});
 const cdp=await page.context().newCDPSession(page);await cdp.send('Performance.enable');
 let cycle=0;
 try{
  await page.goto('http://127.0.0.1:8769/');await page.waitForFunction(()=>window.DiningLabSnapshot);
  const build=await page.evaluate(()=>window.DiningLabSnapshot.build);
  log({event:'start',until:new Date(deadline).toISOString(),initial:{build,userAgent:await page.evaluate(()=>navigator.userAgent)},scope:'Replay, planner, held-out results, cross-meal controls, goal changes, responsive layout and repeated retained-browser memory'});
  while(Date.now()<deadline){
   const cycleStarted=Date.now();cycle++;
   for(const [name,expected] of Object.entries(build.files))assert.equal(sha('dist/'+name),expected,'Build source changed during observation: '+name);
   if(cycle%10===0){await page.reload();await page.waitForFunction(()=>window.DiningLabSnapshot);assert.equal((await page.evaluate(()=>window.DiningLabSnapshot.build)).id,build.id);}
   await page.setViewportSize({width:[1440,1024,768,320][cycle%4],height:1000});
   await page.locator('[data-tab="live"]').click();await page.locator('#example-reset').click();
   await page.locator(cycle%3?'#view-3d':'#view-2d').click();await page.locator('#speed').selectOption('3');await page.locator('#play').click();
   await page.waitForTimeout(2000);if(await page.getByRole('button',{name:'暂停回放',exact:true}).isVisible())await page.getByRole('button',{name:'暂停回放',exact:true}).click();
   const state=await page.evaluate(()=>window.DiningLabSnapshot),expected=R.metrics(E.simulateSchool(state.config));
   for(const k of Object.keys(expected))assert.ok(Number.isFinite(state.metrics[k])&&Math.abs(state.metrics[k]-expected[k])<1e-9,'Model metric '+k);
   const phase=E.snapshot(E.simulateSchool(state.config),state.time),counts=(await page.locator('#live-counts').innerText()).match(/\d+/g).map(Number);
   assert.deepEqual(counts,[phase.waiting,phase.inService,phase.seatWaiting,phase.dining,phase.returning,phase.endpointCompleted]);
   let planner=null, crossMeal=false, identicalComparison=false;
   if(cycle%3===1){
    await page.locator('[data-tab="search"]').click();await page.locator('#planner-run').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy,null,{timeout:120000});
    const s=await page.evaluate(()=>window.DiningLabSnapshot.planner);assert.equal(s.candidateCount,126);assert.equal(s.verification.seeds.length,30);assert.equal(await page.locator('.planner-choice').count(),3);
    const row=s.verification.rows.find(r=>r.id===s.selection.balanced),m=R.metrics(E.simulateSchool({...row.config,seed:s.verification.seeds[0]}));
    for(const k of Object.keys(m))assert.ok(Math.abs(m[k]-row.rounds[0][k])<1e-9,'Planner held-out '+k);
    if(cycle%6===1){
     crossMeal=true;
     if(await page.locator('#planner-period-section').getAttribute('open')===null)await page.locator('#planner-period-section>summary').click();
     await page.locator('#planner-period-run').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy,null,{timeout:120000});
     assert.equal((await page.evaluate(()=>window.DiningLabSnapshot.planner.period)).repeats,30);
     await page.locator('#planner-period-day').selectOption('1');await page.locator('#planner-period-load').click();
     await page.locator('[data-tab="search"]').click();await page.locator('.planner-choice[data-role="efficiency"]').click();
     assert.equal(await page.locator('#planner-load').isEnabled(),true);
     await page.locator('.planner-choice[data-role="balanced"]').click();
    }
    assert.equal(await page.locator('#planner-timetable tbody tr').count(),9);planner={candidateCount:s.candidateCount,selection:s.selection};
    await page.locator('#planner-load').click();
   }
   if(cycle%7===0){
    identicalComparison=true;
    await page.locator('[data-tab="compare"]').click();await page.locator('#set-baseline').click();await page.locator('#repeats').selectOption('10');await page.locator('#compare-run').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy);
    const d=await page.evaluate(()=>window.DiningLabSnapshot.comparison.differences);assert.ok(Object.values(d).every(x=>x.mean===0&&x.low===0&&x.high===0));
   }
   assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),'Active page horizontal overflow');
   const memory=(await cdp.send('Performance.getMetrics')).metrics.filter(m=>['JSHeapUsedSize','JSHeapTotalSize','Nodes','Documents','JSEventListeners'].includes(m.name));
   log({event:'cycle',cycle,elapsedSeconds:(Date.now()-started)/1000,build:build.id,viewport:page.viewportSize(),planner,crossMeal,identicalComparison,counts,memory,errors:errors.length});
   const pause=Math.min(120000-(Date.now()-cycleStarted),deadline-Date.now());if(pause>0)await new Promise(resolve=>setTimeout(resolve,pause));
  }
  assert.deepEqual(errors,[]);log({event:'complete',cycles:cycle,failures:0,errors,elapsedSeconds:(Date.now()-started)/1000});
  console.log(JSON.stringify({cycles:cycle,failures:0,errors,elapsedSeconds:(Date.now()-started)/1000}));
 }catch(error){log({event:'failure',cycle,error:String(error)});await page.screenshot({path:file.replace(/\.jsonl$/,'.failure.png'),fullPage:true}).catch(()=>{});throw error;}
 finally{await browser.close();}
})().catch(e=>{log({event:'stopped',error:String(e)});console.error(e);process.exitCode=1;});
