param([string]$RevisionLabel = '排队时间修订')
$ErrorActionPreference='Stop'
$projectRoot=Split-Path -Parent $PSScriptRoot
$submission=Join-Path (Split-Path -Parent $projectRoot) '【成品】提交材料'
$output=Join-Path $projectRoot 'qa/queue-submission-render'
New-Item -ItemType Directory -Path $output -Force | Out-Null
$receipts=@()
$wordApp=New-Object -ComObject Word.Application
$wordApp.Visible=$false
$wordApp.DisplayAlerts=0
try {
    foreach ($name in @('01-少年组作品申报书','02-查新报告','08-研究过程记录')) {
        $source=Join-Path $submission ($name+'.docx')
        $pdf=Join-Path $output ($name+'.pdf')
        $document=$wordApp.Documents.Open($source,$false,$true)
        try {$document.Fields.Update() | Out-Null;$document.ExportAsFixedFormat($pdf,17)}
        finally {$document.Close(0)}
        $dest=$null
        if (-not $name.StartsWith('08-')) {
            $dest=Join-Path $submission ($name+'.pdf')
            try {Copy-Item -LiteralPath $pdf -Destination $dest -ErrorAction Stop}
            catch {$dest=Join-Path $submission ($name+'_'+$RevisionLabel+'.pdf');Copy-Item -LiteralPath $pdf -Destination $dest -ErrorAction Stop}
        }
        $receipts+=@{source=$source;pdf=$pdf;delivered=$dest}
    }
} finally {$wordApp.Quit()}
$reportSource=Join-Path $projectRoot 'documents/queue-focus-edition/研究报告_公文格式.pdf'
$reportDest=Join-Path $submission '04-研究报告.pdf'
try {Copy-Item -LiteralPath $reportSource -Destination $reportDest -ErrorAction Stop}
catch {$reportDest=Join-Path $submission ('04-研究报告_'+$RevisionLabel+'.pdf');Copy-Item -LiteralPath $reportSource -Destination $reportDest -ErrorAction Stop}
$receipts+=@{source=(Join-Path $submission '04-研究报告.docx');pdf=$reportSource;delivered=$reportDest}
$receipts | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath (Join-Path $output 'export-receipt.json') -Encoding utf8
$receipts | ForEach-Object {Write-Output $_.pdf}
