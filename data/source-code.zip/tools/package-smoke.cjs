// Inspect the actual extracted offline source package, not the development directory.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { pathToFileURL, fileURLToPath } = require('node:url');
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
function verifyExtracted(root, archive) {
  const blob = fs.readFileSync(path.join(root, 'MANIFEST.json'));
  assert.equal(sha(blob), archive.manifestSha256, 'Extracted manifest must belong to the current archive');
  const manifest = JSON.parse(blob);
  assert.equal(manifest.length, archive.entries);
  for (const item of manifest) {
    const file = path.resolve(root, item.file);
    const relative = path.relative(root, file);
    assert.ok(relative !== '..' && !relative.startsWith('..' + path.sep) && !path.isAbsolute(relative));
    const bytes = fs.readFileSync(file);
    assert.equal(bytes.length, item.bytes, item.file);
    assert.equal(sha(bytes), item.sha256, item.file);
  }
  return {
    file: archive.file,
    sha256: archive.sha256,
    manifestSha256: archive.manifestSha256,
    verifiedFiles: manifest.length
  };
}
(async () => {
  const folder = path.resolve(process.argv[2] || 'qa/package-smoke-5fe87d78/source/食刻2.0');
  const index = JSON.parse(fs.readFileSync('release/packages/package-index.json', 'utf8'));
  const sourceRoot = path.dirname(folder);
  const desktopRoot = path.join(path.dirname(sourceRoot), 'desktop');
  const extractedArchives = [
    verifyExtracted(
      sourceRoot,
      index.packages.find((p) => p.file.includes('源码与研究材料'))
    ),
    verifyExtracted(
      desktopRoot,
      index.packages.find((p) => p.file.includes('Windows桌面版'))
    )
  ];
  if (index.iteration === 'innovation-planner') {
    const wordRoot = path.join(path.dirname(sourceRoot), 'word');
    extractedArchives.push(
      verifyExtracted(
        wordRoot,
        index.packages.find((p) => p.file.includes('Word文章与指南'))
      )
    );
    for (const name of ['研究报告_公文格式.docx', '软件使用与学生研究指南.docx'])
      assert.equal(
        sha(fs.readFileSync(path.join(wordRoot, name))),
        sha(fs.readFileSync(path.join(folder, 'documents', name))),
        name + ' must match the source-package document'
      );
  }
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  const page = await browser.newPage({ acceptDownloads: true, viewport: { width: 1440, height: 1000 } });
  const errors = [],
    requests = [];
  page.on('pageerror', (error) => errors.push(String(error)));
  page.on('request', (request) => {
    if (/^https?:/.test(request.url())) requests.push(request.url());
  });
  try {
    await page.goto(pathToFileURL(path.join(folder, 'dist/index.html')).href);
    await page.waitForFunction(() => window.DiningLabSnapshot);
    const state = await page.evaluate(() => window.DiningLabSnapshot);
    assert.equal(state.build.id, index.build);
    assert.equal(state.config.students, 360);
    assert.equal(await page.locator('#scene3d canvas').count(), 1);
    // Capture the opening viewport before the export control scrolls the page.
    // A full-page capture after that scroll misplaces fixed navigation in the image.
    await page.screenshot({ path: 'qa/packaged-offline.png' });
    let threeDAnimationVerified = false;
    if (index.iteration === 'innovation-planner') {
      assert.equal(state.mode, '3d');
      const canvas = page.locator('#scene3d canvas'),
        beforeFrame = sha(await canvas.screenshot());
      await page.locator('#play').click();
      await page.waitForTimeout(900);
      const afterFrame = sha(await canvas.screenshot());
      await page.locator('#play').click();
      assert.ok((await page.evaluate(() => window.DiningLabSnapshot.time)) > state.time);
      assert.notEqual(afterFrame, beforeFrame);
      threeDAnimationVerified = true;
    }
    const downloadPromise = page.waitForEvent('download');
    await page.locator('#export-run').locator('xpath=ancestor::details[1]').locator('summary').click();
    await page.locator('#export-run').click();
    const download = await downloadPromise;
    const downloadPath = await download.path();
    const result = JSON.parse(fs.readFileSync(downloadPath, 'utf8'));
    assert.equal(result.build.id, index.build);
    assert.equal(result.result.students.length, 360);
    let innovation = {};
    if (index.iteration === 'innovation-planner') {
      // Exercise the files and numerical modules from this extracted ZIP.
      const E = require(path.join(folder, 'dist/school-engine.js'));
      const R = require(path.join(folder, 'dist/research.js'));
      const P = require(path.join(folder, 'dist/planner.js'));
      await page.locator('[data-tab="search"]').click();
      await page.locator('#planner-run').click();
      await page.waitForFunction(() => !window.DiningLabSnapshot.busy, null, { timeout: 120000 });
      const planned = await page.evaluate(() => window.DiningLabSnapshot.planner);
      assert.equal(planned.candidateCount, 126);
      assert.equal(await page.locator('#planner-timetable tbody tr').count(), 9);
      await page.locator('.planner-record>summary').click();
      const plannerDownload = page.waitForEvent('download');
      await page.locator('#planner-export').click();
      const experiment = JSON.parse(fs.readFileSync(await (await plannerDownload).path(), 'utf8'));
      assert.equal(experiment.schema, 'dining-planner/1');
      assert.equal(experiment.build.id, index.build);
      assert.equal(experiment.rows.length, 126);
      const selected = P.choose(
        experiment.rows,
        experiment.rows.find((x) => x.id === 'reference'),
        experiment.criteria
      );
      for (const role of ['balanced', 'efficiency', 'lowPeak'])
        assert.equal(selected[role].id, experiment.selection[role]);
      const row = experiment.verification.rows.find((x) => x.id === experiment.selection.balanced);
      const metrics = R.metrics(E.simulateSchool({ ...row.config, seed: experiment.verification.seeds[0] }));
      for (const key of Object.keys(metrics))
        assert.ok(Math.abs(metrics[key] - row.rounds[0][key]) < 1e-9, key);
      await page.locator('#planner-period-section>summary').click();
      await page.locator('#planner-period-run').click();
      await page.waitForFunction(() => !window.DiningLabSnapshot.busy, null, { timeout: 120000 });
      const periodDownload = page.waitForEvent('download');
      await page.locator('#planner-period-export').click();
      const period = JSON.parse(fs.readFileSync(await (await periodDownload).path(), 'utf8'));
      assert.equal(period.schema, 'dining-rotation/1');
      assert.equal(period.build.id, index.build);
      assert.equal(period.modes.length, 3);
      assert.ok(period.modes.every((x) => x.rounds.length === 30));
      const day = period.modes[2].rounds[0].days[0],
        daily = R.metrics(E.simulateSchool(day.config));
      for (const key of Object.keys(daily)) assert.ok(Math.abs(daily[key] - day.metrics[key]) < 1e-9, key);
      innovation = {
        plannerCandidateCount: 126,
        periodPolicies: 3,
        plannerExportVerified: true,
        periodExportVerified: true
      };
    }
    assert.deepEqual(errors, []);
    assert.deepEqual(requests, []);
    const desktop = JSON.parse(fs.readFileSync('qa/desktop-unpacked-test.json', 'utf8'));
    assert.equal(desktop.ok, true);
    if (index.iteration === 'innovation-planner') {
      assert.equal(desktop.capability.mode, '3d');
      assert.ok(desktop.capability.webgl && !desktop.capability.webgl.lost);
    }
    assert.equal(
      path.normalize(fileURLToPath(desktop.capability.origin)),
      path.join(desktopRoot, 'DiningLab', '_internal', 'dist', 'index.html')
    );
    const testLog = fs.readFileSync(path.join(folder, '..', 'unpacked-core-tests.log'), 'utf8');
    const testCount = Number(testLog.match(/tests (\d+)/)?.[1]);
    assert.ok(testCount > 0);
    assert.match(testLog, /fail 0\b/);
    assert.match(testLog, new RegExp('pass ' + testCount + '\\b'));
    const report = {
      at: new Date().toISOString(),
      build: index.build,
      extractedSource: folder,
      extractedArchives,
      offlineFileLaunch: true,
      webgl: true,
      exportPeople: 360,
      threeDAnimationVerified,
      ...innovation,
      externalRequests: requests,
      errors,
      desktopUnpackedStartup: desktop.ok,
      desktopExecutableSha256: sha(fs.readFileSync(path.join(desktopRoot, 'DiningLab', 'DiningLab.exe'))),
      desktopWebGLVerified:
        desktop.capability.mode === '3d' && !!desktop.capability.webgl && !desktop.capability.webgl.lost,
      sourceCoreTests: testCount
    };
    fs.writeFileSync('qa/package-smoke.json', JSON.stringify(report, null, 2));
    console.log(JSON.stringify(report));
  } finally {
    await browser.close();
  }
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
