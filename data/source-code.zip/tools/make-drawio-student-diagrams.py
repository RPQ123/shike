"""Editable report schematics; relationships from the student, not surveyed sizes.

Export these native diagrams with the draw.io desktop CLI, then inspect PNGs.
"""
from pathlib import Path
import json
import xml.etree.ElementTree as E

OUT=Path(__file__).resolve().parents[1]/'figures/student'
BLUE=('#dae8fc','#6c8ebf')
GREEN=('#d5e8d4','#82b366')
GRAY=('#f5f5f5','#666666')
INK='#263B3A'

class Drawing:
    def __init__(self,name,w,h):
        self.file=E.Element('mxfile',host='drawio',version='32.5.5')
        page=E.SubElement(self.file,'diagram',name=name,id=name)
        model=E.SubElement(page,'mxGraphModel',grid='1',gridSize='10',page='1',pageScale='1',pageWidth=str(w),pageHeight=str(h),background='#ffffff')
        self.root=E.SubElement(model,'root')
        E.SubElement(self.root,'mxCell',id='0')
        E.SubElement(self.root,'mxCell',id='1',parent='0')

    def box(self,id,text,x,y,w,h,colors=BLUE,parent='1',extra='',font=26):
        fill,stroke=colors
        style=f'rounded=1;arcSize=10;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};strokeWidth=1.5;fontColor={INK};fontFamily=Microsoft YaHei;fontSize={font};spacing=10;{extra}'
        cell=E.SubElement(self.root,'mxCell',id=id,value=text,style=style,vertex='1',parent=parent)
        E.SubElement(cell,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(h),attrib={'as':'geometry'})
        return id

    def text(self,id,text,x,y,w,h,font=25,parent='1'):
        return self.box(id,text,x,y,w,h,('none','none'),parent,'rounded=0;',font)

    def edge(self,id,source,target,start='1,0.5',end='0,0.5',double=False):
        sx,sy=start.split(',');tx,ty=end.split(',')
        style=f'edgeStyle=orthogonalEdgeStyle;rounded=1;orthogonalLoop=1;jettySize=auto;html=1;strokeColor=#407D6C;strokeWidth=2;endArrow=classic;endSize=10;exitX={sx};exitY={sy};entryX={tx};entryY={ty};'
        if double:style+='startArrow=classic;startSize=10;'
        cell=E.SubElement(self.root,'mxCell',id=id,value='',style=style,edge='1',parent='1',source=source,target=target)
        E.SubElement(cell,'mxGeometry',relative='1',attrib={'as':'geometry'})

    def save(self,stem):
        E.indent(self.file)
        E.ElementTree(self.file).write(OUT/(stem+'.drawio'),encoding='utf-8',xml_declaration=True)

# Repeated furniture is generated on a grid; only the three functional areas
# and the two entrances carry semantic layout information.
d=Drawing('食堂空间关系',1000,590)
d.text('rear','后端出入口',350,10,300,50,28)
d.text('front','前端出入口',350,510,300,50,28)
for side,x in [('left',50),('right',760)]:
    d.box(side,'',x,100,190,360,BLUE,extra='container=1;pointerEvents=0;')
    d.text(side+'title','窗口区',10,10,170,50,27,parent=side)
    for i in range(3):
        d.box(f'{side}-window-{i}','打饭窗口',20,80+i*90,150,60,BLUE,parent=side,font=23)
d.box('seating','',350,100,300,360,GREEN,extra='container=1;pointerEvents=0;')
d.text('seating-title','中央就餐区',10,10,280,50,27,parent='seating')
for row in range(3):
    for col in range(2):
        d.box(f'table-{row}-{col}','餐桌',30+col*130,90+row*80,110,50,GREEN,parent='seating',font=23)
d.edge('rear-seats','rear','seating','0.5,1','0.5,0',True)
d.edge('front-seats','seating','front','0.5,1','0.5,0',True)
d.edge('left-seats','left','seating')
d.edge('right-seats','right','seating','0,0.5','1,0.5')
d.text('note','空间关系示意；符号数量不代表实际窗口、餐桌数量',50,560,900,30,20)
d.save('11-hall-plan')

d=Drawing('就餐流程与时间记录',1000,350)
nodes=[('release','班级分批出发',30,30,BLUE),('arrival','到达食堂',380,30,BLUE),('queue','选窗排队',730,30,BLUE),('service','打饭取餐',730,210,GREEN),('dining','等座与用餐',380,210,GREEN),('return','返回教室',30,210,GREEN)]
for id,label,x,y,colors in nodes:d.box(id,label,x,y,240,80,colors,font=29)
d.edge('release-arrival','release','arrival')
d.edge('arrival-queue','arrival','queue')
d.edge('queue-service','queue','service','0.5,1','0.5,0')
d.edge('service-dining','service','dining','0,0.5','1,0.5')
d.edge('dining-return','dining','return','0,0.5','1,0.5')
d.save('12-meal-flow')

d=Drawing('预计取餐耗时比较',1000,450)
d.text('head-state','窗口状态',20,10,300,50,28)
d.text('head-time','预计取餐耗时',360,10,600,50,28)
d.text('a-label','甲窗口<br>空闲；平均打饭30秒',20,90,300,100,25)
d.text('b-label','乙窗口<br>服务中；平均打饭10秒',20,230,300,100,25)
d.box('a-own','本人打饭 30秒',360,110,540,60,GREEN,font=26)
d.box('b-current','5秒',360,250,90,60,BLUE,font=25)
d.box('b-own','本人打饭 10秒',450,250,180,60,GREEN,font=23)
d.text('a-total','30秒',900,110,90,60,25)
d.text('b-total','15秒',640,250,130,60,25)
d.box('legend-current','',170,350,30,20,BLUE)
d.text('legend-current-label','当前服务剩余时间',210,330,280,50,23)
d.box('legend-own','',520,350,30,20,GREEN)
d.text('legend-own-label','本人打饭时间',560,330,240,50,23)
d.text('decision','无其他等候者时：乙窗口预计取餐耗时为5＋10＝15秒',30,390,940,50,25)
d.save('13-window-choice')

(OUT/'figure-contract.json').write_text(json.dumps({'backend':'draw.io native XML','audience':'高中学生与竞赛评审','figures':[
 {'name':'11-hall-plan','source':'用户提供的两侧窗口、中央座位、前后出入口关系；非测绘图'},
 {'name':'12-meal-flow','source':'原800次计算所采用的就餐事件顺序'},
 {'name':'13-window-choice','source':'算术示例：甲30秒，乙5＋10＝15秒；无其他等候者'}
],'formats':['drawio','png','svg','pdf'],'colors':{'窗口及到达环节':BLUE,'就餐及后续环节':GREEN}},ensure_ascii=False,indent=2),encoding='utf-8')
print('Created three editable native draw.io diagrams.')
