const { chromium } = require('playwright');
const fs = require('node:fs');
(async () => {
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  try {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
    await page.goto('http://127.0.0.1:8769/');
    await page.waitForFunction(() => window.DiningLabSnapshot);
    const audit = [];
    for (const name of ['live', 'compare', 'search', 'evidence', 'learn']) {
      await page.locator('[data-tab="' + name + '"]').click();
      await page.screenshot({ path: 'qa/refresh-before-' + name + '.png', fullPage: true });
      audit.push(await page.evaluate(name => {
        const root = document.querySelector('#page-' + name);
        const leaves = [...root.querySelectorAll('*')].filter(e =>
          !e.children.length && e.textContent.trim() && e.getClientRects().length);
        return { page: name, textCharacters: root.innerText.length,
          smallTextLeaves: leaves.filter(e => parseFloat(getComputedStyle(e).fontSize) < 12).length,
          buttons: [...root.querySelectorAll('button')].filter(e => e.getClientRects().length).length };
      }, name));
    }
    fs.writeFileSync('qa/refresh-baseline.json', JSON.stringify({ at: new Date().toISOString(),
      viewport: { width: 1440, height: 1000 }, audit }, null, 2));
    console.log(JSON.stringify(audit));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
