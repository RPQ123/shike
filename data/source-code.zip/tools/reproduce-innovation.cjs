// Regenerate the complete study in a new QA folder, preserving the supplied records.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { spawnSync } = require('node:child_process');
const ROOT = path.resolve(__dirname, '..');
const sha = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
const load = (p) => JSON.parse(fs.readFileSync(p, 'utf8'));
const { sourceFile, sourceRoot } = require('./study-source.cjs');

function main() {
  const startedAt = new Date().toISOString();
  const qa = path.join(ROOT, 'qa');
  const target = path.resolve(
    ROOT,
    process.argv[2] || path.join('qa', 'reproduction-' + startedAt.replace(/\D/g, ''))
  );
  const relative = path.relative(qa, target);
  assert.ok(
    relative && relative !== '..' && !relative.startsWith('..' + path.sep) && !path.isAbsolute(relative),
    'Use a new subfolder inside this project qa directory'
  );
  assert.equal(fs.existsSync(target), false, 'The reproduction target must not already exist');
  const resultFile = 'data/innovation-study-results.json';
  const original = load(path.join(ROOT, resultFile));
  const bundle = sourceRoot(original.sourceHashes, ROOT);
  const sourceFiles = Object.keys(original.sourceHashes);
  assert.deepEqual(sourceFiles, [
    'dist/engine.js',
    'dist/school-engine.js',
    'dist/research.js',
    'dist/planner.js',
    'dist/rotation.js',
    'tools/run-innovation-study.cjs'
  ]);
  for (const file of sourceFiles)
    assert.equal(sha(fs.readFileSync(sourceFile(file, original.sourceHashes[file], bundle))), original.sourceHashes[file], file);
  for (const directory of ['data', 'dist', 'tools', 'research', 'qa'])
    fs.mkdirSync(path.join(target, directory), { recursive: true });
  for (const file of [
    ...sourceFiles,
    'research/innovation-protocol.json',
    'tools/audit-innovation-study.cjs',
    'tools/study-source.cjs'
  ])
    fs.copyFileSync(original.sourceHashes[file] ? sourceFile(file, original.sourceHashes[file], bundle) : path.join(ROOT,file), path.join(target, file));
  const generated = spawnSync(process.execPath, ['tools/run-innovation-study.cjs'], {
    cwd: target,
    encoding: 'utf8',
    maxBuffer: 4 * 1024 * 1024
  });
  fs.writeFileSync(path.join(target, 'generation.log'), generated.stdout + generated.stderr);
  assert.equal(generated.status, 0, generated.error?.message || generated.stderr);
  const regenerated = load(path.join(target, resultFile));
  // These four fields record when a run actually happened and must legitimately change.
  function numericalStudy(value) {
    delete value.startedAt;
    delete value.completedAt;
    delete value.verificationStartedAt;
    delete value.frozen.frozenAt;
    return value;
  }
  const originalNormalized = sha(JSON.stringify(numericalStudy(original)));
  const regeneratedNormalized = sha(JSON.stringify(numericalStudy(regenerated)));
  assert.equal(
    regeneratedNormalized,
    originalNormalized,
    'All study inputs, choices, individual rounds and summaries must match'
  );
  const ledgerFile = 'data/innovation-execution-ledger.json';
  const ledgerSha256 = sha(fs.readFileSync(path.join(ROOT, ledgerFile)));
  assert.equal(
    sha(fs.readFileSync(path.join(target, ledgerFile))),
    ledgerSha256,
    'The complete execution ledger must be byte-identical'
  );
  const a = load(path.join(ROOT, 'data/innovation-frozen-selection.json'));
  const b = load(path.join(target, 'data/innovation-frozen-selection.json'));
  delete a.frozenAt;
  delete b.frozenAt;
  assert.deepEqual(b, a);
  const audited = spawnSync(process.execPath, ['tools/audit-innovation-study.cjs'], {
    cwd: target,
    encoding: 'utf8',
    maxBuffer: 4 * 1024 * 1024
  });
  fs.writeFileSync(path.join(target, 'audit.log'), audited.stdout + audited.stderr);
  assert.equal(audited.status, 0, audited.stderr);
  const report = {
    passed: true,
    startedAt,
    completedAt: new Date().toISOString(),
    target,
    scope:
      'End-to-end generation from the supplied source and protocol in a fresh directory. Original research files are never overwritten; numerical records and the complete physical ledger are checked, with only four actual run timestamps excluded from study comparison.',
    sourceHashes: original.sourceHashes,
    normalizedStudySha256: originalNormalized,
    ledgerSha256,
    uniqueExecutions: regenerated.counts.uniqueExecutions,
    frozenSelection: regenerated.selection,
    timestampsExcluded: ['startedAt', 'completedAt', 'verificationStartedAt', 'frozen.frozenAt'],
    generatedAudit: load(path.join(target, 'qa/innovation-study-audit.json'))
  };
  const reportFile = path.join(target, 'reproduction-audit.json');
  fs.writeFileSync(reportFile, JSON.stringify(report, null, 2));
  console.log(
    JSON.stringify({
      passed: true,
      target,
      reportFile,
      uniqueExecutions: report.uniqueExecutions,
      normalizedStudySha256: originalNormalized,
      ledgerSha256
    })
  );
}
try {
  main();
} catch (error) {
  console.error(error);
  process.exitCode = 1;
}
