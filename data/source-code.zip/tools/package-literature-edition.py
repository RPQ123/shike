"""Issue the readable report revision without changing verified software bytes."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'release/packages'
DOCS=ROOT/'documents/literature-edition'
sha=lambda data:hashlib.sha256(data).hexdigest()
index=json.loads((OUT/'package-index-common.json').read_text('utf-8'))
render=json.loads((ROOT/'qa/literature-document-render.json').read_text('utf-8'))
assert [row['pages'] for row in render]==[15,2]
for row in render:
    assert sha((ROOT/row['file']).read_bytes())==row['pdfSha256']
assert json.loads((ROOT/'qa/literature-document-audit.json').read_text('utf-8'))['passed']

def previous(record):
    path=OUT/record['file']
    assert sha(path.read_bytes())==record['sha256']
    with ZipFile(path) as z:
        return {n:z.read(n) for n in z.namelist() if not n.endswith('/') and n!='文件校验清单.json'}

def package(name,files):
    path=OUT/name
    manifest={n:{'bytes':len(raw),'sha256':sha(raw)} for n,raw in sorted(files.items())}
    with ZipFile(path,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
        for n,raw in sorted(files.items()):z.writestr(n,raw)
        z.writestr('文件校验清单.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8'))
    with ZipFile(path) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(manifest)+1
        for n,m in manifest.items():assert sha(z.read(n))==m['sha256']
    return {'file':name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'entries':len(manifest)+1}

software=previous(index['packages'][0])
original_software={n:raw for n,raw in software.items() if n.startswith('DiningLab/')}
for p in DOCS.iterdir():
    if p.suffix in ['.pdf','.docx']:
        software[('PDF文档/' if p.suffix=='.pdf' else 'Word原稿/')+p.name]=p.read_bytes()
software['先读我.txt']=('''食刻2.3 软件与报告 文献研究完善版

完整解压后双击“启动软件.cmd”，或进入DiningLab文件夹打开DiningLab.exe。
请保留_internal文件夹。软件无需安装Python；Windows 10/11 64位需有Edge WebView2运行环境。

PDF文档中为15页研究报告和2页使用指南，Word原稿可编辑。
报告沿用范文七部分结构，补充四篇论文的方法与150次单项改变测试。
保留三张示意图和实际软件截图，说明排队、等座及年级轮换。
正文从每分钟接待人数、排队时间和总用时说明计算，全部结果来自保存的软件测试。
默认360人、6窗口、120座位为软件测试设置。布局按学生描述绘制，尺寸并非现场测量。
教育局公开的530人、580人为年度招生计划，不直接当作食堂人数。
研究报告第六部分说明已完成内容与下一步现场核对方法。

本次修订文档，软件与此前已检验的2.3版本逐字节相同。
全部窗口通用，学生选择预计能更早取到饭的窗口；两侧为窗口，中间为餐桌，前后可进出。
''').encode('utf-8-sig')
assert {n:raw for n,raw in software.items() if n.startswith('DiningLab/')}==original_software
main=package('食刻2.3_文献研究完善版_软件与报告.zip',software)

documents={p.name:p.read_bytes() for p in DOCS.iterdir() if p.suffix in ['.pdf','.docx']}
for p in (ROOT/'figures/student').iterdir():
    if p.suffix in ['.svg','.pdf','.png']:documents['示意图/'+p.name]=p.read_bytes()
small=package('校园食堂研究报告_文献研究完善版.zip',documents)

student_index=json.loads((OUT/'package-index-student.json').read_text('utf-8'))
source=previous(student_index['packages'][2])
prefix='食刻2.3/'
for relative in ['tools/report_common.py','tools/make-common-documents.py','tools/make-student-diagrams.py',
 'tools/render-student-pages.py','tools/audit-student-documents.py','tools/package-student-edition.py',
 'qa/literature-document-render.json','qa/literature-document-audit.json','qa/student-figure-source-audit.json','qa/student-visual-review.json',
 'qa/reference-writing-notes.md','tasks/student-report-revision.md',
 'tools/run-student-controls.cjs','tools/audit-student-controls.cjs','tools/package-literature-edition.py',
 'research/student-controls-protocol.json','data/student-controls-results.json',
 'data/student-controls-rounds.csv','data/student-controls-summary.csv',
 'research/canteen-related-literature-2026-10-19.json','research/canteen-related-literature-2026-10-19.ris',
 'research/binhe-public-facts-2026-10-19.json','qa/student-controls-audit.json',
 'qa/literature-visual-review.json','tasks/literature-research-update.md']:
    source[prefix+relative]=(ROOT/relative).read_bytes()
for p in DOCS.iterdir():
    if p.suffix in ['.pdf','.docx']:
        source[prefix+'documents/'+p.name]=p.read_bytes()
        source[prefix+p.relative_to(ROOT).as_posix()]=p.read_bytes()
for p in (ROOT/'figures/student').iterdir():
    if p.is_file():source[prefix+p.relative_to(ROOT).as_posix()]=p.read_bytes()
source[prefix+'README.md']=('''# 食刻2.3 文献研究完善版

完整解压后打开dist/index.html，可离线使用。Windows软件见独立成品包。
最新报告与指南见documents/literature-edition，根documents内同名文件亦为本次修订。
文稿遵循所提供范文的七部分结构，采用高中生可解释的算式，包含3张原创示意图和实际软件截图。

软件及原1430次研究数据沿用已经检验的2.3版本。新增5组、每组30次的窗口与座位对照测试。
逐次数据见data/student-controls-rounds.csv，均值见data/student-controls-summary.csv。
软件测试：node --test tests/*.test.cjs
2.3研究复算：node tools/audit-common-study.cjs --replay
新增研究复算：node tools/audit-student-controls.cjs --replay
重新生成新增研究：node tools/run-student-controls.cjs；该命令拒绝覆盖已有结果，请先复制整个文件夹。
生成Word：python tools/make-common-documents.py --output-dir documents/literature-edition --supplement data/student-controls-results.json
生成示意图：python tools/make-student-diagrams.py
Word需python-docx；示意图需Matplotlib和Microsoft YaHei字体。
绘图脚本可独立运行，示意图原稿同时保存在figures/student的SVG和PDF中。
PDF由Microsoft Word只读导出，已逐页检查。写作依据与审计记录见qa/reference-writing-notes.md及qa/literature-document-audit.json。

data/common-study-results.json为2.3研究，旧研究材料保留供追溯。
程序编写、资料整理和文字修改使用了AI辅助，学生实践与现场数据按实际记录。
''').encode('utf-8')
research=package('食刻2.3_文献研究完善版_源码与研究.zip',source)
receipt={'softwareVersion':'2.3.0','build':index['build'],'softwareBytesUnchanged':True,
 'earlierResearchDataUnchanged':True,'newExperimentExecutions':150,'documentPages':{'report':15,'guide':2},'packages':[main,small,research]}
(OUT/'package-index-literature.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=True,indent=2))
