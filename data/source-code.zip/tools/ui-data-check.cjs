// Exercise data round-trips through actual offline Chrome, including CSV downloads.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const E = require('../dist/school-engine.js');
const R = require('../dist/research.js');

(async () => {
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  const page = await browser.newPage({ acceptDownloads: true });
  const errors = [], external = [], checks = [];
  page.on('pageerror', e => errors.push(String(e)));
  page.on('request', r => { if (/^https?:/.test(r.url())) external.push(r.url()); });
  const snapshot = () => page.evaluate(() => window.DiningLabSnapshot);
  async function download(button, file) {
    if (!await page.locator(button).isVisible())
      await page.locator(button).locator('xpath=ancestor::details[1]').locator('summary').click();
    const pending = page.waitForEvent('download');
    await page.locator(button).click();
    await (await pending).saveAs(file);
    return fs.readFileSync(file, 'utf8');
  }
  try {
    await page.goto(pathToFileURL(path.resolve('dist/index.html')).href);
    await page.waitForFunction(() => window.DiningLabSnapshot);
    const initial = await snapshot();
    const raw = JSON.parse(await download('#export-run', 'qa/offline-run.json'));
    assert.equal(raw.schema, 'dining-run/2');
    assert.deepEqual(raw.config, initial.config);
    assert.equal(raw.result.students.length, 360);
    for (const key of ['meanWait', 'meanReadyToEndpoint'])
      assert.ok(Math.abs(raw.result.metrics[key] - E.simulateSchool(raw.config).metrics[key]) < 1e-9);
    checks.push('Offline file URL exports full reproducible event results');
    const csv = await download('#export-students', 'qa/offline-students.csv');
    const rows = csv.replace(/^\uFEFF/, '').split('\r\n').map(row => row.split(','));
    assert.equal(rows.length, 361);
    const waitIndex = rows[0].indexOf('排队_分钟');
    const totalIndex = rows[0].indexOf('完整用时_分钟');
    for (let i = 1; i < rows.length; i++) {
      assert.equal(Number(rows[i][waitIndex]), raw.result.students[i-1].wait);
      assert.equal(Number(rows[i][totalIndex]), raw.result.students[i-1].readyToEndpoint);
    }
    checks.push('CSV keeps full-precision per-person waiting and complete times');

    await page.locator('#parameters').click();
    await page.locator('.advanced-settings summary').click();
    await page.locator('[name="g1_walkMin"]').fill('3');
    await page.locator('[name="g1_walkMax"]').fill('5');
    await page.locator('[name="mealCV"]').fill('0.3');
    await page.getByRole('button', { name: '运行这个方案' }).click();
    const modified = (await snapshot()).config;
    assert.equal(modified.grades[1].walkMin, 3);
    assert.equal(modified.grades[1].walkMax, 5);
    assert.equal(modified.mealCV, .3);
    assert.equal(modified.grades[0].walkMin, initial.config.grades[0].walkMin);
    checks.push('Advanced settings change the intended grade and meal distribution');

    await page.locator('[data-tab="compare"]').click();
    await page.locator('#set-baseline').click();
    await page.getByRole('button', { name: '修改 B' }).click();
    await page.locator('[name="seats"]').fill('240');
    await page.getByRole('button', { name: '运行这个方案' }).click();
    await page.locator('#repeats').selectOption('10');
    await page.locator('#compare-run').click();
    await page.waitForFunction(() => !window.DiningLabSnapshot.busy);
    assert.match(await page.locator('#compare-output .decision-insight').innerText(), /座位.*(改变|变化|不同)|资源.*(改变|变化|不同)/);
    assert.equal((await snapshot()).comparison.decision.comparability.fixedResources, false);
    checks.push('A/B capacity warning includes changed seat resources');
    await page.locator('[data-tab="live"]').click();

    const nextDay = R.example();
    nextDay.grades[0].deadline = 900;
    nextDay.grades[0].latestReleaseTime = 800;
    nextDay.windowMeans = [10, 20, 30, 40, 50, 60];
    await page.locator('#file-input').setInputFiles({ name:'next-day.json', mimeType:'application/json', buffer:Buffer.from(JSON.stringify(R.session(nextDay))) });
    await page.waitForFunction(() => window.DiningLabSnapshot.config.grades[0].deadline === 900);
    await page.locator('#parameters').click();
    assert.match(await page.locator('[name="g0_deadline"]').locator('..').innerText(), /第 2 天/);
    await page.getByRole('button', { name:'运行这个方案' }).click();
    assert.deepEqual((await snapshot()).config, nextDay);
    checks.push('Imported next-day deadlines survive no-op form and are labelled as next day');

    const beforeBad = await snapshot();
    await page.locator('#file-input').setInputFiles({ name:'bad.json', mimeType:'application/json', buffer:Buffer.from('{invalid') });
    await page.locator('#message-dialog').waitFor({ state:'visible' });
    assert.equal(await page.locator('#message-title').innerText(), '导入失败');
    assert.deepEqual((await snapshot()).config, beforeBad.config);
    await page.locator('#message-close').click();
    checks.push('Broken import preserves the previous valid scenario');

    await page.locator('[data-tab="learn"]').click();
    await page.locator('#research-note').fill('自动测试记录，不是学生本人研究。');
    await page.locator('#save-note').click();
    await page.reload();
    await page.waitForFunction(() => window.DiningLabSnapshot);
    assert.equal(await page.locator('#research-note').inputValue(), '自动测试记录，不是学生本人研究。');
    checks.push('Local-file notes persist across a page reload in the same profile');
    assert.deepEqual(errors, []);
    assert.deepEqual(external, []);
    fs.writeFileSync('qa/ui-data-check.json', JSON.stringify({ at:new Date().toISOString(), build: initial.build, checks, errors, external },null,2));
    console.log(JSON.stringify({ passed:checks.length, errors }));
  } finally { await browser.close(); }
})().catch(e => { console.error(e); process.exitCode=1; });
