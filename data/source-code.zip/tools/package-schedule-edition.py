"""Freeze the reviewed report, runnable software and public download assets."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib, json, shutil, csv, io, argparse

root = Path(__file__).resolve().parents[1]
qa = root / 'qa'
out = root.parent / '【成品】提交材料'
docs = root / 'documents/schedule-edition'
packages = root / 'release/packages'
parser = argparse.ArgumentParser()
parser.add_argument('--edition-label', default='三种安排与推广版')
args = parser.parse_args()
assert args.edition_label and all(c not in args.edition_label for c in '/\\:*?"<>|')
sha = lambda raw: hashlib.sha256(raw).hexdigest()
build = json.loads((root / 'dist/build-info.js').read_text('utf-8').split('Object.freeze(', 1)[1].rsplit(');', 1)[0])
audit = json.loads((qa / 'schedule-document-audit.json').read_text('utf-8'))
visual = json.loads((qa / 'schedule-visual-review.json').read_text('utf-8'))
assert audit['passed'] and visual['passed']
assert visual['reportPdfSha256'] == sha((docs / '研究报告_公文格式.pdf').read_bytes())
for name in ['schedule-ui-audit.json', 'schedule-native-test.json']:
    check = json.loads((qa / name).read_text('utf-8'))
    assert check.get('passed', check.get('ok'))
    assert (check['build']['id'] if isinstance(check['build'], dict) else check['build']) == build['id']
for name, digest in build['files'].items():
    assert sha((root / 'dist' / name).read_bytes()) == digest
study = json.loads((root / 'data/schedule-study-results.json').read_text('utf-8'))
assert study['executions'] == 660 and study['selectedSeconds'] == 70

def archive(name, files):
    dest = packages / name
    manifest = {n: {'bytes': len(raw), 'sha256': sha(raw)} for n, raw in sorted(files.items())}
    # Identical repeated packaging is safe; previous editions use different names.
    if dest.exists():
        with ZipFile(dest) as z:
            assert all(z.read(n) == raw for n, raw in files.items())
            assert len(z.namelist()) == len(files) + 1
    else:
        with ZipFile(dest, 'x', ZIP_DEFLATED, compresslevel=6) as z:
            for n, raw in sorted(files.items()): z.writestr(n, raw)
            z.writestr('文件校验清单.json', json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf-8'))
    with ZipFile(dest) as z:
        assert z.testzip() is None
        assert all(sha(z.read(n)) == item['sha256'] for n, item in manifest.items())
    return {'file': str(dest), 'bytes': dest.stat().st_size, 'sha256': sha(dest.read_bytes()), 'entries': len(files) + 1}

names = [f'{stem}.{ext}' for stem in ['01-少年组作品申报书', '02-查新报告', '03-参赛学生诚信承诺书', '04-研究报告'] for ext in ['docx', 'pdf']]
names += ['05-原始实验记录.csv', '06-计算结果汇总.csv', '07-班级放行表.csv', '08-研究过程记录.docx', '08-研究过程记录.pdf', '09-软件使用指南.docx', '09-软件使用指南.pdf']
if (out / '00-文件说明.txt').exists(): names.append('00-文件说明.txt')
files = {n: (out / n).read_bytes() for n in names}
# The unnumbered PDF may be open in a user application; use the audited bytes.
files['04-研究报告.pdf'] = (docs / '研究报告_公文格式.pdf').read_bytes()
for p in sorted((out / '辅助图片').iterdir()):
    if p.suffix in ['.png', '.drawio', '.svg'] and not p.name.startswith('11-hall-plan'):
        files[p.relative_to(out).as_posix()] = p.read_bytes()
submission = archive(f'校园食堂研究_{args.edition_label}_提交材料.zip', files)

download = root / 'release/schedule-downloads'
download.mkdir(parents=True, exist_ok=True)
for p in sorted((root / 'data').glob('schedule-*')): shutil.copy2(p, download / p.name)
for source, name in [(docs / '研究报告_公文格式.pdf', 'report.pdf'), (docs / '研究报告_公文格式.docx', 'report.docx'),
                     (docs / '软件使用与学生研究指南.pdf', 'guide.pdf'), (root / 'tools/student_schedule.py', 'student_schedule.py')]:
    shutil.copy2(source, download / name)

def blank_csv(name, columns):
    stream = io.StringIO(newline='')
    csv.writer(stream).writerow(columns)
    (download / name).write_bytes(stream.getvalue().encode('utf-8-sig'))
blank_csv('observation-template.csv', ['日期', '安排方案', '年级', '班级', '就餐人数', '开放窗口数量', '可用座位数量', '允许出发时刻', '加入队伍时刻', '开始打饭时刻', '开始用餐时刻', '返回教室时刻', '备注'])
blank_csv('feedback-template.csv', ['日期', '安排方案', '年级（可空）', '等待时长感受（短/适中/长）', '排队时烦躁程度（低/中/高）', '就餐秩序感受（好/一般/差）', '改进建议（可空）'])
simple_index = '''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>研究资料</title><style>body{max-width:850px;margin:60px auto;padding:0 24px;background:#f6f7f1;color:#253f35;font:17px/1.9 system-ui}a{color:#147f6c}li{margin:14px 0}h1{line-height:1.3}</style><a href="../index.html">← 返回软件</a><h1>校园食堂方案研究资料</h1><p>三种安排比较 → 相邻组出发间隔比较 → 另一组条件复核。当前研究保存660次计算，示例中选择70秒。学校可填写自身参数重新比较。</p><ul>LINKS</ul><p>1610人为示例人数。排队时间与完整用时分别记录；示例中的平均完整用时增加3.53分钟。</p></html>'''
links = [('report.pdf', '研究报告 PDF'), ('report.docx', '研究报告 Word'), ('guide.pdf', '软件使用指南'), ('schedule-study-results.json', '完整研究结果 JSON'), ('schedule-study-rounds.csv', '660次原始计算记录 CSV'), ('schedule-study-summary.csv', '结果汇总 CSV'), ('schedule-study-timetable.csv', '33组班级放行表 CSV'), ('schedule-study-session.json', '推荐安排参数 JSON'), ('schedule-study-protocol.json', '计算协议 JSON'), ('student_schedule.py', 'Python放行表工具'), ('schedule-python-timetable.csv', 'Python核对结果'), ('observation-template.csv', '空白就餐记录表'), ('feedback-template.csv', '空白匿名反馈表')]
render = lambda pairs: simple_index.replace('LINKS', ''.join(f'<li><a href="{url}" download>{label}</a></li>' for url, label in pairs))
(download / 'index.html').write_text(render(links), encoding='utf-8')

desktop = root / 'release/desktop-schedules/DiningLab'
for name in [*build['files'], 'build-info.js']:
    assert (desktop / '_internal/dist' / name).read_bytes() == (root / 'dist' / name).read_bytes()
portable_files = [p for p in download.iterdir() if p.suffix != '.zip' and p.name != 'current-delivery.json']
for p in portable_files:
    (desktop / '_internal/dist/data').mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, desktop / '_internal/dist/data' / p.name)
software = {'DiningLab/' + p.relative_to(desktop).as_posix(): p.read_bytes() for p in desktop.rglob('*') if p.is_file() and (p.parent != desktop / '_internal/dist/data' or p in [desktop / '_internal/dist/data' / item.name for item in portable_files])}
for p in (root / 'dist').rglob('*'):
    if p.is_file(): software['离线网页/' + p.relative_to(root / 'dist').as_posix()] = p.read_bytes()
for p in portable_files: software['离线网页/data/' + p.name] = p.read_bytes()
software['启动软件.cmd'] = b'@echo off\r\nstart "" "%~dp0DiningLab\\DiningLab.exe"\r\n'
software['先读我.txt'] = '''校园食堂方案比较软件 2.5.0
完整解压后双击“启动软件.cmd”。请保留DiningLab内的_internal文件夹。
Windows 10/11 64位需有Edge WebView2运行环境。无需安装Python。
也可打开“离线网页/index.html”；网页与Windows使用同一套计算代码。
默认1610人为示例人数，70秒为本次研究选择结果。学校可调整人数、窗口、座位和时间。
软件按“选择方案→过程展示→结果展示”使用。在结果页展开“比较方案与出发间隔”，可进行多轮研究。
资料位于软件内“研究资料与下载”，包括研究报告、指南、660次记录、放行表及空白记录表。
完整用时包含出发前等待。减少排队不等于整次就餐更快。
'''.encode('utf-8-sig')
windows = archive(f'校园食堂研究_{args.edition_label}_Windows与离线网页.zip', software)

source = {}
for folder in ['dist', 'tests', 'desktop']:
    for p in (root / folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc': source[p.relative_to(root).as_posix()] = p.read_bytes()
for name in ['package.json', 'package-lock.json', 'SPEC-three-schedules.md', 'tools/run-schedule-study.cjs', 'tools/audit-schedule-study.cjs', 'tools/student_schedule.py', 'tools/report_schedules.py', 'tools/make-schedule-figures.py', 'tools/ui-schedule-check.cjs', 'tools/capture-schedule-interface.cjs', 'tools/stamp-build.cjs', 'tools/package-schedule-edition.py', 'research/schedule-background-evidence.json']:
    source[name] = (root / name).read_bytes()
# Include the original frozen sources and records required by the full core suite.
# Publisher full-text PDFs and personal submission templates stay outside this archive.
for folder in ['tools', 'data', 'research']:
    for p in (root / folder).rglob('*'):
        if p.is_file() and p.suffix in ['.py', '.js', '.cjs', '.json', '.csv', '.css', '.html', '.md', '.ps1', '.ts', '.tsx'] and '__pycache__' not in p.parts:
            source[p.relative_to(root).as_posix()] = p.read_bytes()
source['tasks/innovation-run-contract.json'] = (root / 'tasks/innovation-run-contract.json').read_bytes()
if (root / 'tasks/product-ui-spec.md').exists(): source['tasks/product-ui-spec.md'] = (root / 'tasks/product-ui-spec.md').read_bytes()
for name in ['schedule-data-audit.json', 'schedule-python-audit.json', 'schedule-ui-audit.json', 'schedule-native-test.json', 'schedule-document-audit.json', 'schedule-visual-review.json']:
    source['qa/' + name] = (qa / name).read_bytes()
for name in ['product-ui-audit.json','product-comparison-audit.json','product-code-review.json','product-visual-review.json','product-image-resolution.json','product-performance-before.json','polish-ui-audit.json','polish-visual-review.json','polish-image-resolution.json','polish-code-review.json','unified-forms-review.json']:
    if (qa / name).exists(): source['qa/' + name] = (qa / name).read_bytes()
for p in portable_files:
    if p.name != 'index.html': source['data/' + p.name] = p.read_bytes()
source['README.md'] = '''# 校园食堂方案比较软件 2.5.0

浏览器可直接打开dist/index.html，核心使用JavaScript。Python放行表工具仅用标准库。
界面按选择方案、过程展示、结果展示使用。三维建筑在dist/hall-design.js，人物在dist/dining-people.js，样式在dist/product.css。
学生位置和各阶段人数来自原仿真记录。输入模拟学生编号可定位并查看就餐轨迹。
Node.js运行：npm test；node tools/audit-schedule-study.cjs。
重做660次研究：node tools/run-schedule-study.cjs（会更新data/schedule-*研究记录）。
核对Python：python tools/student_schedule.py。
报告、协议与原始记录位于data。历史研究及冻结代码按原名称保存，与本次660次研究分别复核。
1610人为示例参数；各校修改人数、窗口、座位及时间后应重新比较。
'''.encode('utf-8')
sources = archive(f'校园食堂研究_{args.edition_label}_源码与研究记录.zip', source)

for receipt, name in [(submission, 'submission-materials.zip'), (windows, 'windows-software.zip'), (sources, 'source-code.zip')]:
    assert receipt['bytes'] < 25 * 1024 * 1024, (name, receipt['bytes'])
    shutil.copy2(receipt['file'], download / name)
current = {'version': '2.5.0', 'edition': args.edition_label, 'build': build['id'], 'executions': 660, 'selectedSeconds': 70,
           'reportPdfSha256': sha((download / 'report.pdf').read_bytes()), 'resultsSha256': sha((download / 'schedule-study-results.json').read_bytes()),
           'packages': [submission, windows, sources]}
# Public receipt contains no user filesystem paths.
public = {**current, 'packages': [{**p, 'file': Path(p['file']).name} for p in current['packages']]}
(download / 'current-delivery.json').write_text(json.dumps(public, ensure_ascii=False, indent=2), encoding='utf-8')
public_links = [('windows-software.zip', 'Windows软件与离线网页 ZIP'), ('submission-materials.zip', '提交材料 ZIP'), ('source-code.zip', '源码与研究记录 ZIP')] + links
(download / 'index.html').write_text(render(public_links) + '<details><summary>历史研究资料</summary><p><a href="all-research-data.zip">历史研究数据 ZIP</a>：原有800次与150次记录保留原参数及来源，与本次660次研究分别保存。</p></details>', encoding='utf-8')
(qa / 'schedule-package-audit.json').write_text(json.dumps({'passed': True, **current}, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'passed': True, **current}, ensure_ascii=False, indent=2))
