"""Package the 1610-person revision; retain every earlier delivered archive."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
root=Path(__file__).resolve().parents[1]
out=root/'release/packages';docs=root/'documents/problem-study'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
build=json.loads((root/'dist/build-info.js').read_text('utf-8').split('Object.freeze(',1)[1].rsplit(');',1)[0])
render=json.loads((root/'qa/problem-document-render.json').read_text('utf-8'))
assert [r['pages'] for r in render]==[13,2]
assert json.loads((root/'qa/problem-document-audit.json').read_text('utf-8'))['passed']
assert json.loads((root/'qa/problem-visual-review.json').read_text('utf-8'))['passed']
native=json.loads((root/'qa/binhe-native-test.json').read_text('utf-8'))
assert native['ok'] and native['build']['id']==build['id']
assert json.loads((root/'qa/binhe-ui.json').read_text('utf-8'))['passed']
assert json.loads((root/'qa/binhe-cohort-audit.json').read_text('utf-8'))['replayed']==800
for r in render:assert sha((root/r['file']).read_bytes())==r['pdfSha256']
for name,digest in build['files'].items():assert sha((root/'dist'/name).read_bytes())==digest

def package(name,files):
    path=out/name
    manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())}
    with ZipFile(path,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
        for n,b in sorted(files.items()):z.writestr(n,b)
        z.writestr('文件校验清单.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8'))
    with ZipFile(path) as z:
        assert z.testzip() is None
        for n,m in manifest.items():assert sha(z.read(n))==m['sha256']
    return {'file':name,'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'entries':len(manifest)+1}

desktop=root/'release/desktop-binhe/DiningLab'
for p in (root/'dist').rglob('*'):
    if p.is_file():assert p.read_bytes()==(desktop/'_internal/dist'/p.relative_to(root/'dist')).read_bytes()
software={'DiningLab/'+p.relative_to(desktop).as_posix():p.read_bytes() for p in desktop.rglob('*') if p.is_file()}
for p in docs.iterdir():
    if p.suffix in ['.pdf','.docx']:software[('PDF文档/' if p.suffix=='.pdf' else 'Word原稿/')+p.name]=p.read_bytes()
software['启动软件.cmd']=b'@echo off\r\nstart "" "%~dp0DiningLab\\DiningLab.exe"\r\n'
software['先读我.txt']='''食刻2.3.1 招生计划人数版

完整解压，双击“启动软件.cmd”，或打开DiningLab文件夹中的DiningLab.exe。
请保留_internal文件夹。无需安装Python；Windows 10/11 64位需有Edge WebView2运行环境。

人数按2026—2027学年对应入学年官方招生计划：高一580、高二530、高三500，共1610人，按全员参加同一餐计算。
16窗口、480座位、近似分组、放行时刻及用时均为可调整测试设置，不是学校设施和作息台账。
两侧窗口、中间座位、前后进出；所有窗口通用，选择预计取餐更快的窗口。
“恢复示例”返回招生计划人数场景。

PDF文档含13页研究报告、2页简明指南，Word原稿可编辑。
报告标题保留原名，正文研究滨河午餐安排；含3张示意图、1张结果图，使用800次计算记录。
现场数据与招生计划用途不同，后续可直接修改年级人数和其他设置检验。
旧版材料保留；本次表格和结论全部按新1610人实验更新。
'''.encode('utf-8-sig')
main=package('校园食堂错峰研究_报告与运行工具.zip',software)

small={p.name:p.read_bytes() for p in docs.iterdir() if p.suffix in ['.pdf','.docx']}
for p in (root/'figures/student').iterdir():
    if p.suffix in ['.png','.pdf','.svg']:small['示意图/'+p.name]=p.read_bytes()
for name in ['binhe-cohort-summary.csv','binhe-cohort-timetable.csv']:small['研究表格/'+name]=(root/'data'/name).read_bytes()
small['资料依据/学校公开信息.json']=(root/'research/binhe-public-facts-2026-10-19.json').read_bytes()
document=package('校园食堂错峰研究_文档与图表.zip',small)

old_index=json.loads((out/'package-index-student.json').read_text('utf-8'))
old=old_index['packages'][2];assert sha((out/old['file']).read_bytes())==old['sha256']
prefix='食刻2.3.1/'
with ZipFile(out/old['file']) as z:
    source={prefix+n.split('/',1)[1]:z.read(n) for n in z.namelist() if not n.endswith('/') and n.startswith('食刻2.3/') and n!='文件校验清单.json'}
for folder in ['dist','desktop','tests']:
    for p in (root/folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':source[prefix+p.relative_to(root).as_posix()]=p.read_bytes()
include=['package.json','package-lock.json','tools/make-common-documents.py','tools/report_common.py','tools/report_admission.py',
 'tools/render-student-pages.py','tools/render-admission-pdf.ps1','tools/audit-admission-documents.py','tools/run-binhe-cohort.cjs',
 'tools/audit-binhe-cohort.cjs','tools/export-binhe-tables.py','tools/ui-binhe-check.cjs','tools/package-admission-edition.py','tools/package-problem-study.py','tools/audit-problem-documents.py','tools/make-meal-results.py','qa/problem-prose-review.md','qa/meal-figure-collisions.json','tasks/problem-study-revision.md','research/meal-result-figure-contract.json',
 'tools/run-student-controls.cjs','tools/audit-student-controls.cjs','tools/audit-student-documents.py',
 'research/binhe-cohort-protocol.json','research/binhe-public-facts-2026-10-19.json',
 'research/canteen-related-literature-2026-10-19.json','research/canteen-related-literature-2026-10-19.ris',
 'research/student-controls-protocol.json','research/frozen-binhe-attempt1/binhe-cohort.js',
 'data/binhe-cohort-results.json','data/binhe-cohort-selection.json','data/binhe-cohort-session.json',
 'data/binhe-cohort-rounds.csv','data/binhe-cohort-summary.csv','data/binhe-cohort-timetable.csv',
 'data/binhe-cohort-attempt1-results.json','data/binhe-cohort-attempt1-selection.json','data/binhe-cohort-attempt1-session.json',
 'data/student-controls-results.json','data/student-controls-rounds.csv','data/student-controls-summary.csv',
 'qa/binhe-native-test.json','qa/binhe-ui.json','qa/binhe-cohort-audit.json','qa/binhe-core-tests.txt',
 'qa/problem-document-render.json','qa/problem-document-audit.json','qa/problem-visual-review.json','qa/artifact.md','qa/reference-writing-notes.md','PROVENANCE.txt','research/README-v2.2.md',
 'tasks/binhe-cohort-revision.md','tasks/literature-research-update.md','figures/14-binhe-admission-hall.png']
for name in include:source[prefix+name]=(root/name).read_bytes()
for p in (root/'figures/student').iterdir():
    if p.name.startswith('15-meal-arrangements'):source[prefix+p.relative_to(root).as_posix()]=p.read_bytes()
for p in docs.iterdir():
    if p.suffix in ['.pdf','.docx']:
        source[prefix+'documents/'+p.name]=p.read_bytes()
        source[prefix+p.relative_to(root).as_posix()]=p.read_bytes()
source[prefix+'README.md']=(root/'README.md').read_bytes()
research=package('校园食堂错峰研究_源码与研究记录.zip',source)
receipt={'version':'2.3.1','build':build['id'],'cohortCounts':[580,530,500],'students':1610,'executions':800,'reportPages':13,'guidePages':2,'packages':[main,document,research]}
(out/'package-index-problem-study.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=True,indent=2))
