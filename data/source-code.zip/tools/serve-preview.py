"""Loopback-only preview; production desktop and file:// usage remain offline.

Python 3.12's default queue of five connections can reject bursts from several
browser checks. Use a larger listen queue and keep logging out of PTY buffers.
"""
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PreviewServer(ThreadingHTTPServer):
    request_queue_size = 128


class PreviewHandler(SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store')
        super().end_headers()


if __name__ == '__main__':
    with PreviewServer(('127.0.0.1', 8769), partial(PreviewHandler, directory=str(ROOT / 'dist'))) as server:
        server.serve_forever()
