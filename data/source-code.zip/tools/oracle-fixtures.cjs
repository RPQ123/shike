const fs = require('node:fs');
const R = require('../dist/research.js');
const E = require('../dist/school-engine.js');
const fixtures = [];
for (const windows of [1, 3, 6]) for (const seats of [3, 20, 100]) for (const seed of [0, 7, 4294967295]) {
  const c = R.example();
  Object.assign(c, { windows, windowMeans: Array.from({length:windows},(_,i)=>10+i*3), windowOwners:null,
    strategy:'pooled', allocation:'shared', seats, seed, serviceZones:null, windowZones:null, gradeZoneWeights:null, seatPoolByZone:null });
  c.grades.forEach(g=>{g.students=10;g.classes=2;}); c.students=30;
  const result = E.simulateSchool(c);
  fixtures.push({ name:`w${windows}-s${seats}-r${seed}`, windows, seats, open_time:c.serviceStart*60, return_time:c.returnMinutes*60,
    people:result.students.map(s=>({id:s.id,ready:s.readyTime*60,arrival:s.arrival*60,service:result.effectiveWindowMeans.map(mean=>mean*s.serviceFactor),meal:c.mealMean*s.mealFactor*60})),
    expected:result.students.map(s=>({id:s.id,window:s.window,start:s.start*60,wait:s.wait*60,pickup:s.end*60,seat:s.seatId,sit:s.seatStart*60,seat_wait:s.seatWait*60,meal_end:s.mealEnd*60,finish:s.endpointTime*60,whole:s.readyToEndpoint*60})) });
}
fs.writeFileSync('qa/oracle-fixtures.json', JSON.stringify(fixtures));
console.log(JSON.stringify({fixtures:fixtures.length,people:fixtures.reduce((n,f)=>n+f.people.length,0)}));
