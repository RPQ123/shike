// A small one-factor study; the earlier reference and balanced plans remain unchanged.
const fs = require('node:fs'), crypto = require('node:crypto');
const E = require('../dist/school-engine'), R = require('../dist/research');
const sha = raw => crypto.createHash('sha256').update(raw).digest('hex');
const protocolPath = 'research/student-controls-protocol.json';
const protocolBytes = fs.readFileSync(protocolPath);
const protocol = JSON.parse(protocolBytes);
const baseBytes = fs.readFileSync(protocol.baseSource);
const previous = JSON.parse(baseBytes);
const output = 'data/student-controls-results.json';
if (fs.existsSync(output)) throw new Error('Preserve the completed experiment; choose a new output for a new protocol.');
const startedAt = new Date().toISOString();
const seeds = Array.from({length: protocol.repetitions}, (_, i) => protocol.seedStart + i);
const cases = protocol.cases.map(test => {
  const config = R.clone(previous.base);
  config.windows = test.windows;
  config.windowMeans = Array(test.windows).fill(config.serviceMean);
  config.windowOwners = Array(test.windows).fill(0);
  config.seats = test.seats;
  const normalized = E.normalizeSchoolConfig(config);
  const rounds = seeds.map(seed => ({seed, metrics: R.metrics(E.simulateSchool({...normalized, seed}))}));
  return {...test, config: normalized, rounds, summary: R.summarize(rounds.map(row => row.metrics))};
});
const files = ['dist/engine.js', 'dist/school-engine.js', 'dist/research.js', 'tools/run-student-controls.cjs'];
const result = {
  schema: 'student-controls/1', startedAt, completedAt: new Date().toISOString(),
  protocol, protocolSha256: sha(protocolBytes), baseSha256: sha(baseBytes),
  sourceHashes: Object.fromEntries(files.map(name => [name, sha(fs.readFileSync(name))])),
  executions: cases.length * seeds.length, cases
};
fs.writeFileSync(output, JSON.stringify(result, null, 2));
console.log(JSON.stringify({executions: result.executions, cases: cases.map(row => ({id: row.id, windows: row.windows, seats: row.seats, meanWait: row.summary.meanWait, seatWait: row.summary.seatWait, meanTotal: row.summary.meanTotal}))}));
