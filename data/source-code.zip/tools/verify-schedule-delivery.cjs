const {chromium}=require('playwright');
const fs=require('node:fs'),path=require('node:path'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),base=process.argv[2];
if(!base)throw new Error('Provide the exact published or extracted offline URL');
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const build=JSON.parse(fs.readFileSync(path.join(root,'dist/build-info.js'),'utf8').split('Object.freeze(')[1].split(');')[0]);
const offline=base.startsWith('file:'),name=offline?'offline':base.includes('github.io')?'github':'sites';
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome',...(offline?{}:{proxy:{server:'http://127.0.0.1:12000'}})});
 const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 try{
  await page.goto(base,{waitUntil:'networkidle',timeout:60000});await page.waitForFunction(()=>window.DiningLabSnapshot);
  const snap=()=>page.evaluate(()=>window.DiningLabSnapshot),first=await snap();
  assert.equal(first.build.id,build.id);assert.equal(first.config.students,1610);
  const native=JSON.parse(fs.readFileSync(path.join(root,'qa/schedule-extracted-native.json'),'utf8'));
  assert.ok(native.ok);for(const [key,value] of Object.entries(native.metrics))assert.ok(Math.abs(first.metrics[key]-value)<1e-9,key);
  let verifiedFiles=0;
  if(!offline){
   const local=path.join(root,'../sites/shike-canteen/dist');
   const files=[...Object.keys(build.files),'build-info.js',...fs.readdirSync(path.join(local,'data')).map(n=>'data/'+n)];
   for(let i=0;i<files.length;i+=5){
    const batch=files.slice(i,i+5),actual=await page.evaluate(async names=>Promise.all(names.map(async name=>{
     const response=await fetch(new URL(name,location.href)),bytes=await response.arrayBuffer();
     const digest=await crypto.subtle.digest('SHA-256',bytes);
     return {name,status:response.status,sha:Array.from(new Uint8Array(digest),x=>x.toString(16).padStart(2,'0')).join(''),html:name.endsWith('.html')?new TextDecoder().decode(bytes):null};
    })),batch);
    for(const r of actual){
     assert.equal(r.status,200,r.name);const expected=fs.readFileSync(path.join(local,r.name));
     if(r.sha!==sha(expected)&&r.html&&name==='sites'){
      const injection=r.html.match(/<script>\(function\(\)\{function c\(\)\{[\s\S]*?<\/script>(?=<\/body>)/);
      assert.ok(injection&&injection[0].includes('window.__CF$cv$params=')&&injection[0].includes('/cdn-cgi/challenge-platform/scripts/jsd/main.js'),'Only the observed Cloudflare challenge injection may differ');
      assert.equal(r.html.replace(injection[0],''),expected.toString('utf8'),r.name);
     }else assert.equal(r.sha,sha(expected),r.name);
     verifiedFiles++;
    }
   }
  }
  const canvas=page.locator('#scene3d canvas');assert.ok(await canvas.evaluate(c=>{const g=c.getContext('webgl2');return g&&!g.isContextLost()}));
  const before=await canvas.screenshot();await page.locator('#play').click();await page.waitForTimeout(500);await page.locator('#play').click();
  assert.ok((await snap()).time>first.time);assert.notDeepEqual(before,await canvas.screenshot());
  await page.locator('[data-tab=compare]').click();await page.locator('#study-run-three').click();
  await page.waitForFunction(()=>!DiningLabSnapshot.busy&&DiningLabSnapshot.scheduleStudy.initial,null,{timeout:120000});
  const saved=JSON.parse(fs.readFileSync(path.join(root,'data/schedule-study-results.json'),'utf8'));
  for(let i=0;i<3;i++)assert.ok(Math.abs((await snap()).scheduleStudy.initial.rows[i].summary.meanWait-saved.initial[i].summary.meanWait)<1e-10);
  await page.locator('#study-tab-gaps').click();await page.locator('#study-run-gaps').click();
  await page.waitForFunction(()=>!DiningLabSnapshot.busy&&DiningLabSnapshot.scheduleStudy.interval,null,{timeout:240000});
  const result=(await snap()).scheduleStudy.interval;assert.equal(result.selectedSeconds,70);assert.equal(result.rows.length,13);
  for(const row of result.rows)assert.ok(Math.abs(row.summary.meanWait-saved.intervals.find(x=>x.seconds===row.seconds).summary.meanWait)<1e-10);
  const event=page.waitForEvent('download');await page.locator('#study-timetable-export').click();
  assert.equal(fs.readFileSync(await(await event).path(),'utf8').trim().split(/\r?\n/).length,34);
  await page.locator('#study-gap-output [data-study-load=combined]').click();assert.equal((await snap()).tab,'live');
  await page.locator('#parameters').click();await page.getByRole('button',{name:'运行这个方案'}).click();
  if(!offline){
   const dataPage=await browser.newPage();await dataPage.goto(new URL('data/',base).href,{waitUntil:'networkidle',timeout:60000});
   assert.equal(await dataPage.locator('h1').innerText(),'校园食堂方案研究资料');
   const download=dataPage.waitForEvent('download');await dataPage.locator('a[href="submission-materials.zip"]').click();
   assert.equal(sha(fs.readFileSync(await(await download).path())),sha(fs.readFileSync(path.join(root,'release/schedule-downloads/submission-materials.zip'))));
   await dataPage.screenshot({path:path.join(root,'qa/schedule-'+name+'-downloads.png'),fullPage:true});await dataPage.close();
  }
  await page.setViewportSize({width:390,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
  await page.screenshot({path:path.join(root,'qa/schedule-'+name+'-final.png')});assert.deepEqual(errors,[]);
  const receipt={passed:true,url:base,build:build.id,verifiedFiles,defaultMatchesExtractedExe:true,threePlansMatchSavedStudy:true,intervals:13,selectedSeconds:70,timetableRows:33,webglAnimation:true,mobileNoOverflow:true,errors};
  fs.writeFileSync(path.join(root,'qa/schedule-'+name+'-delivery.json'),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
