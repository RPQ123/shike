# Optional local QA. Requires installed Microsoft Word; never saves over source DOCX.
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$wordApp = New-Object -ComObject Word.Application
$wordApp.Visible = $false
$wordApp.DisplayAlerts = 0
try {
    foreach ($pair in @(@('研究报告_公文格式.docx', 'report-render'), @('软件使用与学生研究指南.docx', 'guide-render'))) {
        $documentPath = Join-Path $projectRoot ('documents\' + $pair[0])
        $renderDirectory = Join-Path $projectRoot ('qa\' + $pair[1])
        New-Item -ItemType Directory -Path $renderDirectory -Force | Out-Null
        $pdfPath = Join-Path $renderDirectory 'current.pdf'
        $wordDoc = $wordApp.Documents.Open($documentPath, $false, $true)
        try {
            $wordDoc.Fields.Update() | Out-Null
            $wordDoc.ExportAsFixedFormat($pdfPath, 17)
            Write-Output $pdfPath
        } finally { $wordDoc.Close(0) }
    }
} finally { $wordApp.Quit() }
