const fs=require('node:fs'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const E=require('../dist/school-engine'),R=require('../dist/research');
const s=JSON.parse(fs.readFileSync('data/indoor-walking-results.json'));
for(const [file,hash] of Object.entries(s.sourceHashes))assert.equal(crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'),hash,file);
let replayed=0;
for(const row of s.rounds){
 const r=E.simulateSchool({...s.base,seed:row.seed,seats:row.seats,indoorWalkSpeed:row.speed});
 const metrics={...R.metrics(r),indoorWalk:r.metrics.meanIndoorWalk,peakWalking:Math.max(...r.diningTimeline.map(t=>t.walkingToSeat))};
 for(const [key,value] of Object.entries(metrics))assert.ok(Math.abs(value-row[key])<1e-9,row.id+':'+key);
 for(const p of r.students)assert.ok(Math.abs(p.seatStart-p.end-p.seatWait-p.indoorWalk)<1e-9);
 replayed++;
}
assert.equal(replayed,150);
const at=id=>s.summary.find(r=>r.id===id);
assert.ok(at('fast').indoorWalk<at('walking').indoorWalk&&at('walking').indoorWalk<at('slow').indoorWalk);
assert.ok(at('fewer-seats').seatWait>at('walking').seatWait);
assert.equal(at('legacy').meanWait,at('walking').meanWait);
const receipt={passed:true,replayed,checks:['exact source hashes','all 150 metric rows replayed','per-student time decomposition','speed sensitivity','seat capacity sensitivity','window queue unaffected']};
fs.writeFileSync('qa/indoor-data-audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
