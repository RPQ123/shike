from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'dist/index.html';s=p.read_text('utf-8')
if 'id="page-setup"' in s:
    raise SystemExit('Three-step migration already applied; edit the current UI files directly.')
start=s.index('    <aside class="rail">');end=s.index('    <div class="shell">',start)
s=s[:start]+'''    <aside class="rail">
      <a class="brand" href="#setup"><span class="brand-mark" aria-hidden="true">食</span><span>食刻</span></a>
      <nav aria-label="操作步骤" class="workflow-nav">
        <button data-tab="setup" class="nav active"><span>01</span>选择方案</button>
        <button data-tab="live" class="nav"><span>02</span>过程展示</button>
        <button data-tab="compare" class="nav"><span>03</span>结果展示</button>
      </nav>
      <details class="utility-menu"><summary>更多</summary><nav aria-label="工具与资料">
        <button data-tab="search" class="nav">自动排程</button>
        <button data-tab="evidence" class="nav">使用说明与资料</button>
        <button data-tab="learn" class="nav">研究笔记</button>
      </nav></details>
    </aside>
''' +s[end:]
s=s.replace('<main id="main">','''<main id="main">
        <section class="page" id="page-setup" aria-labelledby="setup-title">
          <div class="page-heading"><div><span class="step-eyebrow">第一步</span><h1 id="setup-title">选择就餐方案</h1><p>选择一种安排，按实际情况调整参数。</p></div><button id="setup-advanced" class="button">全部参数</button></div>
          <form id="setup-form">
            <fieldset class="preset-fieldset"><legend class="sr-only">就餐方案</legend><div class="preset-grid">
              <label class="preset-card"><input type="radio" name="preset" value="none"><span class="preset-number">01</span><strong>不实行错峰</strong><span>所有年级、班级同时出发</span></label>
              <label class="preset-card"><input type="radio" name="preset" value="grade"><span class="preset-number">02</span><strong>仅按年级错峰</strong><span>分年级出发，年级内同时出发</span></label>
              <label class="preset-card"><input type="radio" name="preset" value="combined" checked><span class="preset-number">03</span><strong>年级与班级结合错峰</strong><span>三个年级各出发一个班，依次轮换</span></label>
            </div></fieldset>
            <section class="panel setup-parameters"><div class="panel-heading"><h2>参数设置</h2><span id="setup-total">共1610人</span></div>
              <div class="setup-grades">
                <div><h3>高一</h3><label>人数<input id="setup-students-0" type="number" min="0" max="5000" step="1" required></label><label>班级数<input id="setup-classes-0" type="number" min="1" max="100" step="1" required></label></div>
                <div><h3>高二</h3><label>人数<input id="setup-students-1" type="number" min="0" max="5000" step="1" required></label><label>班级数<input id="setup-classes-1" type="number" min="1" max="100" step="1" required></label></div>
                <div><h3>高三</h3><label>人数<input id="setup-students-2" type="number" min="0" max="5000" step="1" required></label><label>班级数<input id="setup-classes-2" type="number" min="1" max="100" step="1" required></label></div>
              </div>
              <div class="setup-common">
                <label>开放窗口数量<input id="setup-windows" type="number" min="2" max="16" step="1" required></label>
                <label>可用座位数量<input id="setup-seats" type="number" min="2" max="5000" step="1" required></label>
                <label>平均打饭时间 / 秒<input id="setup-service" type="number" min="5" max="120" step="1" required></label>
                <label>允许开始出发的时刻<input id="setup-start" type="time" required></label>
                <label>返回教室的最晚时刻<input id="setup-deadline" type="time" required></label>
                <label id="setup-gap-label">相邻组出发间隔 / 秒<input id="setup-gap" type="number" min="0" max="600" step="1" required></label>
              </div>
              <details class="setup-order"><summary>年级顺序</summary><select id="setup-order" aria-label="年级顺序"><option value="2,1,0">高三 → 高二 → 高一</option><option value="2,0,1">高三 → 高一 → 高二</option><option value="1,2,0">高二 → 高三 → 高一</option><option value="1,0,2">高二 → 高一 → 高三</option><option value="0,2,1">高一 → 高三 → 高二</option><option value="0,1,2">高一 → 高二 → 高三</option></select></details>
            </section>
            <p id="setup-error" class="error" role="alert"></p>
            <div class="workflow-footer"><span class="example-label">当前为示例参数，可按学校实际修改</span><button class="button primary next-step" type="submit">查看就餐过程 <span aria-hidden="true">→</span></button></div>
          </form>
        </section>''')
s=s.replace('<h1 id="live-title">食堂仿真</h1>','<span class="step-eyebrow">第二步</span><h1 id="live-title">过程展示</h1>')
s=s.replace('<button id="parameters" class="button primary">设置方案</button>','<button id="parameters" class="button">调整参数</button><button id="live-next" class="button primary">查看结果 →</button>')
s=s.replace('开始一次比较 →','比较更多方案').replace('恢复示例','恢复示例参数')
s=s.replace('          <div class="kpi-grid" id="kpis"></div>','')
a=s.index('          <article class="panel chart-panel">');b=s.index('\n        </section>',a);chart=s[a:b];s=s[:a]+s[b:]
s=s.replace('<h1 id="compare-title">方案比较</h1>\n              <p>先比较三种安排，再选择合适的班组出发间隔。</p>','<span class="step-eyebrow">第三步</span><h1 id="compare-title">结果展示</h1><p id="result-scenario"></p>')
s=s.replace('<button id="export-compare" class="button" disabled>导出实验</button>','<button id="result-back" class="button">修改方案</button>')
s=s.replace('          <div id="schedule-study"></div>','''          <div class="kpi-grid" id="kpis"></div>
          <section class="panel result-overview"><h2>本次就餐结果</h2><div id="result-summary"></div><div id="result-grades"></div></section>
'''+chart+'''
          <details class="panel research-tools" id="research-tools"><summary>比较方案与出发间隔</summary><div id="schedule-study"></div></details>
          <button id="export-compare" class="button legacy-export" disabled>导出两方案实验</button>''')
s=s.replace('<link rel="stylesheet" href="schedule.css" />','<link rel="stylesheet" href="schedule.css" /><link rel="stylesheet" href="workflow.css" />')
s=s.replace('<script src="app.js"></script>','<script src="workflow-view.js"></script><script src="app.js"></script>')
p.write_text(s,'utf-8')
p=root/'dist/app.js';s=p.read_text('utf-8').replace("live: '食堂仿真',","setup: '选择方案',\n    live: '过程展示',").replace("compare: '方案比较',","compare: '结果展示',")
s=s.replace('let scheduleUI = null;','let scheduleUI = null;\n  let workflowUI = null;')
s=s.replace("    if (name === 'live')\n", "    if (name === 'compare') requestAnimationFrame(renderChart);\n    if (name === 'live')\n")
s=s.replace("    plannerUI?.onConfigChange();","    plannerUI?.onConfigChange();\n    workflowUI?.onConfigChange();")
s=s.replace("  run(state.config);\n  requestAnimationFrame(animate);", "  workflowUI = window.DiningWorkflow.mount({getConfig: () => state.config, getResult: () => state.result, run, tab, parameters, message});\n  run(state.config);\n  tab('setup');\n  requestAnimationFrame(animate);")
s=s.replace("if (state.tab === 'live') renderChart();","if (state.tab === 'compare') renderChart();")
s=s.replace("    tab('compare');\n    renderGuide();", "    tab('compare');\n    $('research-tools').open = true;\n    renderGuide();")
p.write_text(s,'utf-8')
p=root/'dist/schedule-view.js';s=p.read_text('utf-8').replace('返回目标时刻','返回教室的最晚时刻').replace('满足返回目标','按时返回').replace('晚于返回目标','超时返回').replace('当前没有满足返回目标的间隔','暂未找到能让所有学生按时返回教室的出发间隔').replace('当前没有按时返回的间隔','暂未找到能让所有学生按时返回教室的出发间隔').replace('返回目标</th>','是否按时返回</th>').replace('晚于目标','超时返回').replace('返回目标须','返回教室的最晚时刻须');p.write_text(s,'utf-8')
p=root/'dist/parameter-view.js';s=p.read_text('utf-8').replace('返程完成截止','返回教室的最晚时刻');p.write_text(s,'utf-8')
