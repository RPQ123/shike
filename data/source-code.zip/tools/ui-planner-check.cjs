const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const E = require('../dist/school-engine.js');
const R = require('../dist/research.js');
const P = require('../dist/planner.js');
(async () => {
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, acceptDownloads: true });
  const checks = [],
    errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  try {
    await page.goto('http://127.0.0.1:8769/');
    await page.waitForFunction(() => window.DiningLabSnapshot);
    await page.locator('[data-tab="search"]').click();
    assert.equal(await page.locator('#planner-run').isVisible(), true);
    assert.equal(await page.locator('#search-run').isVisible(), false);
    checks.push('Primary planner is visible; former grade-gap search remains in a closed optional section');
    await page.locator('#planner-run').click();
    await page.waitForFunction(() => !window.DiningLabSnapshot.busy, null, { timeout: 120000 });
    let s = await page.evaluate(() => window.DiningLabSnapshot);
    assert.equal(s.planner.candidateCount, 126);
    assert.equal(await page.locator('.planner-choice').count(), 3);
    assert.equal(await page.locator('#planner-timetable tbody tr').count(), 9);
    assert.equal(s.planner.verification.seeds.length, 30);
    assert.ok(s.planner.verification.seeds.every((x) => !s.planner.screeningSeeds.includes(x)));
    const originalMean=s.planner.verification.rows[0].rounds[0].meanTotal;
    await page.evaluate(()=>{const detached=window.DiningLabSnapshot;detached.planner.verification.rows[0].rounds[0].meanTotal=-12345;});
    assert.equal((await page.evaluate(()=>window.DiningLabSnapshot)).planner.verification.rows[0].rounds[0].meanTotal,originalMean);
    checks.push(
      '126 unique schedules produce three objective cards, nine-class timetable and 30 new verification seeds'
    );
    await page.locator('.planner-record>summary').click();
    const dp = page.waitForEvent('download');
    await page.locator('#planner-export').click();
    const data = JSON.parse(fs.readFileSync(await (await dp).path(), 'utf8'));
    assert.equal(data.schema, 'dining-planner/1');
    assert.equal(data.rows.length, 126);
    assert.deepEqual(
      P.choose(
        data.rows,
        data.rows.find((x) => x.id === 'reference'),
        data.criteria
      ).balanced.id,
      data.selection.balanced
    );
    const row = data.verification.rows.find((x) => x.id === data.selection.balanced);
    const actual = R.metrics(E.simulateSchool({ ...row.config, seed: data.verification.seeds[0] }));
    for(const key of Object.keys(actual))assert.ok(Number.isFinite(row.rounds[0][key])&&Math.abs(row.rounds[0][key]-actual[key])<1e-9,key);
    checks.push(
      'Downloaded full experiment reproduces selection and first held-out round independently in Node'
    );
    const csv = page.waitForEvent('download');
    await page.locator('#planner-csv').click();
    const text = fs.readFileSync(await (await csv).path(), 'utf8');
    assert.match(text, /班级/);
    assert.equal(text.trim().split(/\r?\n/).length, 10);
    checks.push('Timetable CSV contains the actual nine release batches');
    await page.locator('#planner-period-section>summary').click();
    await page.locator('#planner-period-run').click();
    await page.waitForFunction(() => !window.DiningLabSnapshot.busy, null, { timeout: 120000 });
    s = await page.evaluate(() => window.DiningLabSnapshot);
    assert.equal(s.planner.period.modes.length, 3);
    assert.equal(s.planner.period.repeats, 30);
    assert.equal(await page.locator('#planner-period-output tbody tr').count(), 3);
    checks.push('Three-meal fixed/cyclic/feedback comparison uses 30 paired periods');
    const periodDownload = page.waitForEvent('download');
    await page.locator('#planner-period-export').click();
    const periodData = JSON.parse(fs.readFileSync(await (await periodDownload).path(), 'utf8'));
    assert.equal(periodData.schema, 'dining-rotation/1');
    assert.equal(periodData.days, 3);
    const firstDay = periodData.modes[2].rounds[0].days[0];
    const expectedDay = R.metrics(E.simulateSchool(firstDay.config));
    for (const key of Object.keys(expectedDay))
      assert.ok(
        Number.isFinite(firstDay.metrics[key]) && Math.abs(firstDay.metrics[key] - expectedDay[key]) < 1e-9,
        key
      );
    checks.push('Period export retains raw causal histories and reproduces a real daily engine result');
    await page.locator('#planner-period-day').selectOption('1');
    await page.locator('#planner-period-load').click();
    await page.locator('[data-tab="search"]').click();
    await page.locator('.planner-choice[data-role="efficiency"]').click();
    assert.equal(await page.locator('#planner-load').isEnabled(), true);
    assert.equal(await page.locator('#planner-stale').isVisible(), false);
    await page.locator('.planner-choice[data-role="balanced"]').click();
    checks.push('After loading a generated later meal, switching goals retains valid timetable controls');
    await page.locator('#planner-load').click();
    s = await page.evaluate(() => window.DiningLabSnapshot);
    assert.equal(s.tab, 'live');
    assert.deepEqual(s.config.windowZones, row.config.windowZones);
    assert.deepEqual(
      s.config.grades.map((g) => [g.releaseTime, g.classInterval]),
      row.config.grades.map((g) => [g.releaseTime, g.classInterval])
    );
    await page.locator('[data-tab="search"]').click();
    assert.equal(await page.locator('#planner-stale').isVisible(), false);
    checks.push(
      'Loading a chosen timetable updates the real engine and does not invalidate its own saved result'
    );
    await page.locator('.planner-options>summary').click();
    await page.locator('#planner-mean').selectOption('0');
    assert.equal(await page.locator('#planner-stale').isVisible(), true);
    assert.equal(await page.locator('#planner-load').isEnabled(), false);
    assert.equal(await page.locator('#planner-export').isEnabled(), true);
    await page.locator('#planner-mean').selectOption('0.5');
    assert.equal(await page.locator('#planner-stale').isVisible(), false);
    assert.equal(await page.locator('#planner-load').isEnabled(), true);
    checks.push(
      'Changed selection preferences mark old recommendations stale; restoring the saved preference restores their applicability'
    );
    await page.locator('#planner-period-run').click();
    await page.waitForFunction(() => !window.DiningLabSnapshot.busy, null, { timeout: 120000 });
    await page.locator('#planner-days').selectOption('5');
    assert.equal(await page.locator('#planner-period-output tbody tr').count(), 0);
    assert.equal((await page.evaluate(() => window.DiningLabSnapshot)).planner.period, null);
    assert.match(await page.locator('#planner-period-output').innerText(), /餐次已改变/);
    checks.push(
      'Changing the observation length clears the former period table and its export, preventing a three-meal result from appearing under five meals'
    );
    assert.deepEqual(errors, []);
    fs.writeFileSync(
      'qa/ui-planner-check.json',
      JSON.stringify({ passed: true, at:new Date().toISOString(), build: s.build, checks, errors }, null, 2)
    );
    console.log(JSON.stringify({ passed: true, checks }));
  } catch (error) {
    await page.screenshot({ path: 'qa/ui-planner-failure.png', fullPage: true });
    fs.writeFileSync(
      'qa/ui-planner-failure.json',
      JSON.stringify({ checks, errors, error: String(error) }, null, 2)
    );
    throw error;
  } finally {
    await browser.close();
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
