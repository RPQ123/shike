"""Remove the retained template's identity and cached statistics from new work."""
from lxml import etree


def clean_template_metadata(document):
    package = document.part.package
    for rid, relation in list(package.rels.items()):
        if relation.reltype.endswith('/custom-properties'):
            del package.rels[rid]
        elif relation.reltype.endswith('/extended-properties'):
            # These are template counts, an old editor build ID and old editing time.
            root = etree.fromstring(relation.target_part.blob)
            for child in list(root):
                if etree.QName(child).localname in {
                    'Template', 'Pages', 'Words', 'Characters', 'Lines',
                    'Paragraphs', 'TotalTime', 'CharactersWithSpaces', 'Application'
                }:
                    root.remove(child)
            relation.target_part._blob = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
