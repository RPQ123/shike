"""Verify real WebView2 blob downloads using a test-only save-location substitute.

This does not test the appearance of the Windows SaveFileDialog. It exercises
the app's export buttons, WebView2 download transport and the resulting files.
Production launcher code keeps the normal save dialog unchanged.
"""
from pathlib import Path
from threading import Event
import csv
import json
import time
import traceback
import webview
from webview.platforms import edgechromium

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'qa/desktop-downloads'
OUT.mkdir(exist_ok=True)
finished=Event()
downloads=[]
result={'ok':False,'scope':'WebView2 real download with test-only chosen path; native save-dialog UI not tested'}

def chosen_path(self,sender,args):
    suggested=Path(str(args.ResultFilePath)).name
    destination=OUT/['run.json','students.csv','planner.json','timetable.csv'][len(downloads)]
    args.ResultFilePath=str(destination)
    args.Handled=True
    record={'suggestedName':suggested,'savedAs':destination.name,'state':'started','beganAt':time.time()}
    downloads.append(record)
    def changed(sender,event):
        record['state']=str(sender.State)
        record['stateAt']=time.time()
        if record['state'] in ['Completed','Interrupted']:
            finished.set()
    args.DownloadOperation.StateChanged+=changed

edgechromium.EdgeChrome.on_download_starting=chosen_path
webview.settings['ALLOW_DOWNLOADS']=True
webview.settings['REMOTE_DEBUGGING_PORT']=18887  # Isolated QA only; production keeps this disabled.
window=webview.create_window('DiningLab isolated download test',(ROOT/'dist/index.html').as_uri(),hidden=True)

def verify():
    try:
        assert window.events.loaded.wait(30),'WebView did not load'
        deadline=time.monotonic()+20
        while not window.evaluate_js('!!window.DiningLabSnapshot'):
            assert time.monotonic()<deadline,'app not ready'
            time.sleep(.1)
        deadline=time.monotonic()+90
        # tools/desktop-click-check.cjs drives trusted pointer clicks through CDP.
        while len(downloads)<4 or any(x['state']!='Completed' for x in downloads):
            assert time.monotonic()<deadline,'trusted-click downloads did not finish'
            time.sleep(.1)
        raw=json.loads((OUT/'run.json').read_text(encoding='utf8'))
        rows=list(csv.DictReader((OUT/'students.csv').read_text(encoding='utf-8-sig').splitlines()))
        assert raw['schema']=='dining-run/2'
        assert len(raw['result']['students'])==len(rows)==360
        assert abs(float(rows[0]['排队_分钟'])-raw['result']['students'][0]['wait'])<1e-12
        planner=json.loads((OUT/'planner.json').read_text(encoding='utf8'))
        timetable=list(csv.DictReader((OUT/'timetable.csv').read_text(encoding='utf-8-sig').splitlines()))
        assert planner['schema']=='dining-planner/1' and len(planner['rows'])==126
        assert len(timetable)==9 and sum(int(row['人数']) for row in timetable)==360
        result.update(ok=True,at=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),build=raw['build'],downloads=downloads,people=len(rows),plannerCandidates=126,timetableRows=9,plannerDownloadBytes=(OUT/'planner.json').stat().st_size)
    except Exception:
        result.update(error=traceback.format_exc(),downloads=downloads)
    finally:
        (ROOT/'qa/desktop-download-check.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
        window.destroy()

webview.start(verify,gui='edgechromium',private_mode=True,storage_path=str(OUT/'test-profile'))
print(json.dumps(result,ensure_ascii=False))
raise SystemExit(0 if result['ok'] else 1)
