// Offline new-workflow checks at workload, constraint and keyboard boundaries.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const {pathToFileURL}=require('node:url');
const R=require('../dist/research.js');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'}),page=await browser.newPage({viewport:{width:1280,height:900},acceptDownloads:true});
 page.setDefaultTimeout(10000);
 const checks=[],errors=[],external=[];page.on('pageerror',e=>errors.push(String(e)));page.on('request',r=>{if(/^https?:/.test(r.url()))external.push(r.url());});
 try{
  await page.goto(pathToFileURL(path.resolve('dist/index.html')).href+'?renderer=2d');await page.waitForFunction(()=>window.DiningLabSnapshot);
  const build=await page.evaluate(()=>window.DiningLabSnapshot.build);
  async function load(c){await page.locator('#file-input').setInputFiles({name:'scene.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(R.session(c)))});await page.waitForFunction(n=>window.DiningLabSnapshot.config.students===n,c.students);}
  const large=R.example();large.students=5000;large.grades.forEach((g,i)=>{g.students=[1667,1667,1666][i];g.classes=50;g.latestReleaseTime=null;});large.windows=16;large.windowMeans=Array(16).fill(20);large.windowZones=Array.from({length:16},(_,i)=>i<8?0:1);large.windowOwners=Array.from({length:16},(_,i)=>Math.min(2,Math.floor(i*3/16)));
  await load(large);await page.locator('[data-tab="search"]').click();await page.locator('#planner-run').click();
  assert.match(await page.locator('#message-body').innerText(),/计算量较大/);assert.equal(await page.evaluate(()=>window.DiningLabSnapshot.busy),false);await page.locator('#message-close').click();
  checks.push('5000-person fine joint search explains how to reduce its range before starting simulation');
  await page.locator('.planner-options>summary').click();await page.locator('#planner-slots').selectOption('coarse');await page.locator('#planner-reallocate').uncheck();
  await page.locator('#planner-run').click();await page.getByRole('button',{name:'取消本轮计算',exact:true}).click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy);
  assert.equal(await page.evaluate(()=>window.DiningLabSnapshot.planner),null);assert.match(await page.locator('#planner-output').innerText(),/已取消/);assert.equal(await page.locator('#parameters').isEnabled(),true);
  checks.push('Reduced maximum-size planner starts and cancels without a partial recommendation or locked controls');
  await page.locator('[data-tab="live"]').click();await page.locator('#example-reset').click();await page.locator('[data-tab="search"]').click();await page.locator('#planner-slots').selectOption('fine');await page.locator('#planner-reallocate').check();
  await page.locator('#planner-run').focus();await page.keyboard.press('Enter');await page.waitForFunction(()=>!window.DiningLabSnapshot.busy,null,{timeout:120000});
  await page.locator('.planner-choice[data-role="lowPeak"]').focus();await page.keyboard.press('Space');assert.equal(await page.locator('.planner-choice[data-role="lowPeak"]').getAttribute('aria-pressed'),'true');assert.match(await page.locator('.planner-choice[data-role="lowPeak"] .choice-main').innerText(),/人.*排队峰值/s);
  await page.locator('.planner-choice[data-role="balanced"]').focus();await page.keyboard.press('Enter');assert.equal(await page.locator('.planner-choice[data-role="balanced"]').getAttribute('aria-pressed'),'true');
  checks.push('Offline generation and objective cards work from Enter/Space, and primary units match each selected goal');
  const locked=R.example();locked.seed=4294967295;locked.grades.forEach(g=>g.releaseLocked=true);
  await load(locked);await page.locator('#planner-run').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy,null,{timeout:120000});
  let s=await page.evaluate(()=>window.DiningLabSnapshot.planner);assert.equal(s.candidateCount,1);assert.ok(Object.values(s.selection).every(id=>id==='reference'));assert.ok(s.screeningSeeds.every(n=>Number.isInteger(n)&&n>=0&&n<=4294967295));
  await page.locator('#planner-period-section>summary').click();assert.equal(await page.locator('#planner-period-run').isEnabled(),false);assert.match(await page.locator('#planner-period-output').innerText(),/原年级安排/);
  checks.push('Conflicting interleaving locks retain the valid original arrangement; unsigned seed wrap remains valid and rotation is not offered for an undefined class-slot plan');
  await page.locator('.planner-record>summary').click();const pending=page.waitForEvent('download');await page.locator('#planner-export').click();const saved=JSON.parse(fs.readFileSync(await(await pending).path(),'utf8'));assert.ok(saved.rejected.length>0);assert.ok(saved.rejected.every(x=>x.reason.length));
  checks.push('Unusable interleaving combinations retain their actual constraint reasons in the full export');
  const zero=R.example();zero.students=0;zero.grades.forEach(g=>g.students=0);await page.locator('#file-input').setInputFiles({name:'zero.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(R.session(zero)))});await page.locator('#message-dialog').waitFor({state:'visible'});assert.match(await page.locator('#message-body').innerText(),/就餐人数大于零/);assert.equal(await page.evaluate(()=>window.DiningLabSnapshot.config.students),360);assert.equal(await page.evaluate(()=>window.DiningLabSnapshot.busy),false);await page.locator('#message-close').click();
  checks.push('The workspace explains an unsupported empty-population import and retains the last valid scene');
  assert.deepEqual(errors,[]);assert.deepEqual(external,[]);
  fs.writeFileSync('qa/ui-planner-boundaries.json',JSON.stringify({passed:true,at:new Date().toISOString(),build,checks,errors,externalRequests:external},null,2));console.log(JSON.stringify({passed:true,checks,errors,externalRequests:external}));
 }catch(error){await page.screenshot({path:'qa/ui-planner-boundary-failure.png',fullPage:true});throw error;}
 finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
