// User-facing 3D replay acceptance: actual WebGL pixels, controls and event counts.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { pathToFileURL } = require('node:url');
const path = require('node:path');
const E = require('../dist/school-engine.js');
const hash = (bytes) => crypto.createHash('sha256').update(bytes).digest('hex');
(async () => {
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  const errors = [],
    checks = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  try {
    await page.goto(pathToFileURL(path.resolve('dist/index.html')).href);
    await page.waitForFunction(() => window.DiningLabSnapshot);
    const canvas = page.locator('#scene3d canvas');
    assert.equal(await canvas.count(), 1);
    const initial = await page.evaluate(() => window.DiningLabSnapshot);
    assert.equal(initial.mode, '3d');
    const gl = await canvas.evaluate((c) => {
      const context = c.getContext('webgl2') || c.getContext('webgl');
      return context
        ? { version: context.getParameter(context.VERSION), lost: context.isContextLost() }
        : null;
    });
    assert.ok(gl && !gl.lost);
    checks.push('Default scene is a live WebGL 3D canvas');
    const frame1 = await canvas.screenshot({ path: 'qa/animation-paused.png' });
    await page.waitForTimeout(400);
    const frame2 = await canvas.screenshot();
    assert.equal(hash(frame1), hash(frame2));
    assert.equal((await page.evaluate(() => window.DiningLabSnapshot)).time, initial.time);
    checks.push('Paused 3D scene and model time remain stable');
    await page.locator('#speed').selectOption('1');
    await page.locator('#play').click();
    const before = await page.evaluate(() => window.DiningLabSnapshot.time);
    const moving1 = await canvas.screenshot({ path: 'qa/animation-moving-01.png' });
    await page.waitForTimeout(1200);
    const moving2 = await canvas.screenshot({ path: 'qa/animation-moving-02.png' });
    const after = await page.evaluate(() => window.DiningLabSnapshot.time);
    assert.ok(after > before + 0.5 && after < before + 5);
    assert.notEqual(hash(moving1), hash(moving2));
    assert.equal(await page.locator('#play').getAttribute('aria-label'), '暂停回放');
    await page.locator('#play').click();
    const stopped = await page.evaluate(() => window.DiningLabSnapshot);
    await page.waitForTimeout(500);
    assert.equal((await page.evaluate(() => window.DiningLabSnapshot)).time, stopped.time);
    checks.push('Playing advances model time and changes 3D pixels; pausing stops time');
    const result = E.simulateSchool(stopped.config);
    function expectedCounts(time) {
      const s = E.snapshot(result, time);
      return [s.waiting, s.inService, s.seatWaiting, s.dining, s.returning, s.endpointCompleted];
    }
    const displayed = async () => (await page.locator('#live-counts').innerText()).match(/\d+/g).map(Number);
    assert.deepEqual(await displayed(), expectedCounts(stopped.time));
    checks.push('Live six-phase counts match the full-population event engine at the paused animation time');
    const cameraBefore = await canvas.screenshot();
    await page.getByRole('button', { name: '俯视', exact: true }).click();
    await page.waitForTimeout(700);
    const cameraAfter = await canvas.screenshot({ path: 'qa/animation-top.png' });
    assert.notEqual(hash(cameraBefore), hash(cameraAfter));
    const box = await canvas.boundingBox();
    await page.mouse.move(box.x + box.width * 0.5, box.y + box.height * 0.5);
    await page.mouse.down();
    await page.mouse.move(box.x + box.width * 0.62, box.y + box.height * 0.57, { steps: 12 });
    await page.mouse.up();
    await page.waitForTimeout(700);
    assert.notEqual(hash(cameraAfter), hash(await canvas.screenshot()));
    assert.equal((await page.evaluate(() => window.DiningLabSnapshot)).time, stopped.time);
    assert.deepEqual((await page.evaluate(() => window.DiningLabSnapshot)).metrics, initial.metrics);
    checks.push('Top camera and mouse orbit alter the real 3D view while retaining all numerical results');
    await page.locator('#timeline').focus();
    await page.keyboard.press('Home');
    assert.equal((await page.evaluate(() => window.DiningLabSnapshot)).time, 0);
    assert.deepEqual(await displayed(), expectedCounts(0));
    await page.keyboard.press('End');
    const end = await page.evaluate(() => window.DiningLabSnapshot.time);
    assert.deepEqual(await displayed(), expectedCounts(end));
    assert.equal((await displayed()).at(-1), 360);
    assert.equal(await page.locator('#play').getAttribute('aria-label'), '播放回放');
    checks.push('Timeline scrubbing pauses replay and reaches the real all-completed endpoint');
    await page.getByRole('button', { name: '立体', exact: true }).click();
    await page.locator('#peak').click();
    await page.locator('#speed').selectOption('0.5');
    await page.locator('#play').click();
    await page.waitForTimeout(600);
    await page.screenshot({ path: 'qa/innovation-3d-animation.png' });
    await page.locator('#play').click();
    assert.deepEqual(errors, []);
    const report = {
      at: new Date().toISOString(),
      build: initial.build,
      passed: true,
      webgl: gl,
      checks,
      motion: {
        before,
        after,
        elapsedModelMinutes: after - before,
        firstFrameSha256: hash(moving1),
        secondFrameSha256: hash(moving2)
      },
      errors,
      scope:
        'Real offline Chrome rendering and controls on this machine; 3D layout and avatar travel routes are illustrative, counts use all event records.'
    };
    fs.writeFileSync('qa/ui-3d-animation-check.json', JSON.stringify(report, null, 2));
    console.log(JSON.stringify({ passed: true, checks: checks.length, motion: report.motion, errors }));
  } finally {
    await browser.close();
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
