"""Package the verified desktop update without replacing an earlier delivery."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json,hashlib,shutil
root=Path(__file__).resolve().parents[1];out=root/'release/packages'
sha=lambda b:hashlib.sha256(b).hexdigest()
build=json.loads((root/'dist/build-info.js').read_text().split('Object.freeze(',1)[1].rsplit(');',1)[0])
assert json.loads((root/'qa/indoor-native-test.json').read_text())['build']['id']==build['id']
for name in ['indoor-native-test','indoor-ui-local','indoor-ui-live','indoor-data-audit','public-site-live']:
    receipt=json.loads((root/'qa'/f'{name}.json').read_text());assert receipt.get('ok',receipt.get('passed'))
    if 'build' in receipt:
        found=receipt['build'];assert (found['id'] if isinstance(found,dict) else found)==build['id']
for f in (root/'dist').rglob('*'):
    if f.is_file():assert f.read_bytes()==(root/'release/desktop-walking/DiningLab/_internal/dist'/f.relative_to(root/'dist')).read_bytes()
files={}
for f in (root/'release/desktop-walking/DiningLab').rglob('*'):
    if f.is_file():files['DiningLab/'+f.relative_to(root/'release/desktop-walking/DiningLab').as_posix()]=f.read_bytes()
for f in (root/'dist').rglob('*'):
    if f.is_file():files['离线网页版/'+f.relative_to(root/'dist').as_posix()]=f.read_bytes()
for name in ['indoor-walking-session.json','indoor-walking-results.json','indoor-walking-rounds.csv','indoor-walking-summary.csv']:
    files['研究数据/'+name]=(root/'data'/name).read_bytes()
files['研究数据/全部研究数据.zip']=(root.parent/'sites/shike-canteen/dist/data/all-research-data.zip').read_bytes()
files['启动软件.cmd']='@echo off\r\nstart "" "%~dp0DiningLab\\DiningLab.exe"\r\n'.encode('ascii')
files['使用说明.txt']='''食刻 2.4 · 端盘步行版

完整解压后双击“启动软件.cmd”，或打开DiningLab文件夹中的DiningLab.exe。
离线网页版直接打开index.html。Windows版与网页版使用同一套计算代码。

本版加入取餐后端盘行走、满座等候、座位预留、转弯和入座动作。
进入“食堂仿真”，拖动时间轴到11:54左右，再点击播放，可看到端盘行走。
选择“1倍速”可以仔细观察端盘、转弯和入座动作。
点击行走中的学生可查看路线。“设置方案”中可以调整端盘步行速度。
逐人记录CSV增加了端盘步行与离开等座区的时刻。

默认端盘速度为1.1米/秒，布局为示意。图形抽取部分学生展示，全体学生都参与计算。
本版150次步行对照计算单独保存；原800次方案研究按更新前模型保留。
'''.encode('utf-8-sig')
archive=out/'食刻2.4_端盘步行版_软件与数据.zip'
manifest={n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(files.items())}
with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
    for name,raw in sorted(files.items()):z.writestr(name,raw)
    z.writestr('文件校验清单.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8'))
with ZipFile(archive) as z:
    assert z.testzip() is None
    for name,record in manifest.items():assert sha(z.read(name))==record['sha256']
github=root.parent/'sites/github-shike'
assert (github/'README.md').is_file()
for f in (root.parent/'sites/shike-canteen/dist').rglob('*'):
    if f.is_file():
        target=github/f.relative_to(root.parent/'sites/shike-canteen/dist');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,target)
receipt={'passed':True,'build':build['id'],'file':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'entries':len(manifest)+1,'allRuntimeFilesMatch':True}
(root/'qa/indoor-package.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
