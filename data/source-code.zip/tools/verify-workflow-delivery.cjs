const {chromium}=require('playwright'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const root=path.resolve(__dirname,'..'),url=process.argv[2];if(!url)throw Error('Provide the published or extracted offline URL');
const sha=raw=>crypto.createHash('sha256').update(raw).digest('hex'),offline=url.startsWith('file:'),host=offline?'offline':url.includes('github.io')?'github':'sites';
const build=JSON.parse(fs.readFileSync(path.join(root,'dist/build-info.js'),'utf8').split('Object.freeze(')[1].split(');')[0]);
(async()=>{const browser=await chromium.launch({headless:true,channel:'chrome',...(offline?{}:{proxy:{server:'http://127.0.0.1:12000'}})});const page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});const errors=[];page.on('pageerror',e=>errors.push(e.message));
try {
 await page.goto(url,{waitUntil:'networkidle',timeout:60000});await page.waitForFunction(()=>window.DiningLabSnapshot);
 const s=await page.evaluate(()=>DiningLabSnapshot);assert.equal(s.build.id,build.id);assert.equal(s.tab,'setup');
 const native=JSON.parse(fs.readFileSync(path.join(root,'qa/schedule-native-test.json'),'utf8'));assert.ok(native.ok);assert.equal(native.build.id,build.id);assert.ok(Math.abs(native.metrics.meanWait-s.metrics.meanWait)<1e-10);
 let verifiedFiles=0;
 if(!offline) for(const file of [...Object.keys(build.files),'build-info.js']) {
  const actual=await page.evaluate(async file=>{const r=await fetch(new URL(file,location.href));return {status:r.status,raw:Array.from(new Uint8Array(await r.arrayBuffer()))}},file);assert.equal(actual.status,200,file);
  let raw=Buffer.from(actual.raw),expected=fs.readFileSync(path.join(root,'dist',file));
  if(file==='index.html'&&host==='sites'&&sha(raw)!==sha(expected)) {
    const html=raw.toString('utf8'),injection=html.match(/<script>\(function\(\)\{function c\(\)\{[\s\S]*?<\/script>(?=<\/body>)/);
    assert.ok(injection&&injection[0].includes('window.__CF$cv$params=')&&injection[0].includes('/cdn-cgi/challenge-platform/scripts/jsd/main.js'));raw=Buffer.from(html.replace(injection[0],''));
  }
  assert.equal(sha(raw),sha(expected),file);verifiedFiles++;
 }
 await page.locator('#setup-form button[type=submit]').click();assert.ok(await page.locator('#scene3d canvas').isVisible());
 const pixels=await page.locator('#scene3d canvas').screenshot();await page.locator('#play').click();await page.waitForTimeout(450);await page.locator('#play').click();assert.notDeepEqual(pixels,await page.locator('#scene3d canvas').screenshot());
 await page.locator('#live-next').click();assert.ok(await page.locator('#result-grades').isVisible());assert.equal(await page.locator('#study-run-three').isVisible(),false);
 await page.locator('#result-back').click();await page.locator('#setup-windows').fill('12');await page.locator('#setup-form button[type=submit]').click();assert.equal(await page.evaluate(()=>DiningLabSnapshot.config.windows),12);await page.locator('#live-next').click();assert.ok((await page.locator('#result-scenario').textContent()).includes('窗口数量：12个'));
 assert.ok(await page.locator('.chart-time-tick').count()>5);
 await page.locator('#queue-chart').focus();await page.keyboard.press('Home');assert.ok(await page.locator('.queue-tooltip').isVisible());await page.keyboard.press('Escape');
 const downloads=[],localDocuments=[];
 const data=await browser.newPage({acceptDownloads:true});await data.goto(new URL('data/index.html',url).href,{waitUntil:'networkidle',timeout:60000});
 for(const file of ['report.pdf','report.docx','guide.pdf',...(offline?[]:['submission-materials.zip','windows-software.zip','source-code.zip'])]) {
  if(offline) {const local=require('node:url').fileURLToPath(new URL('data/'+file,url));assert.equal(sha(fs.readFileSync(local)),sha(fs.readFileSync(path.join(root,'release/schedule-downloads',file))));localDocuments.push(file);continue;}
  const waiting=data.waitForEvent('download',{timeout:90000});await data.locator(`a[href="${file}"]`).click();const download=await waiting;assert.equal(await download.failure(),null);const actual=fs.readFileSync(await download.path());assert.equal(sha(actual),sha(fs.readFileSync(path.join(root,'release/schedule-downloads',file))),file);downloads.push(file);
 }
 await data.close();await page.setViewportSize({width:390,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);assert.deepEqual(errors,[]);
 const receipt={passed:true,url,build:build.id,verifiedFiles,threeStepFlow:true,real3DAnimation:true,parameterHandoff:true,matchesNative:true,downloads,localDocuments,mobileNoOverflow:true,errors};fs.writeFileSync(path.join(root,`qa/three-step-${host}-delivery.json`),JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
