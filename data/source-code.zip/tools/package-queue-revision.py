"""Package only the reviewed current submission, excluding earlier revisions."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,hashlib,shutil,argparse

root=Path(__file__).resolve().parents[1];out=root.parent/'【成品】提交材料';qa=root/'qa'
parser=argparse.ArgumentParser()
parser.add_argument('--archive-name',default='校园食堂研究_排队时间与图文修订版_提交材料.zip')
parser.add_argument('--receipt-prefix',default='queue')
args=parser.parse_args()
assert Path(args.archive_name).name==args.archive_name and args.archive_name.endswith('.zip')
sha=lambda raw:hashlib.sha256(raw).hexdigest()
audit=json.loads((qa/'queue-final-audit.json').read_text('utf-8'))
visual=json.loads((qa/'queue-visual-review.json').read_text('utf-8'))
assert audit['passed'] and visual['passed']
assert visual['reportPdfSha256']==audit['checks'][-1]['sha256']
# Preserve the earlier separately named PDF outside the current delivery folder.
old=out/'04-研究报告_语言修订.pdf'
if old.exists():
    dest=qa/'queue-focus-before-20261019'/old.name
    if not dest.exists():shutil.copy2(old,dest)
    assert old.read_bytes()==dest.read_bytes()
    try:old.unlink()
    except PermissionError:pass
names=[f'{stem}.{ext}' for stem in ['01-少年组作品申报书','02-查新报告','03-参赛学生诚信承诺书','04-研究报告'] for ext in ['docx','pdf']]
names+=['05-原始实验记录.csv','06-计算结果汇总.csv','07-班级放行表.csv','08-研究过程记录.docx']
names+=[p.relative_to(out).as_posix() for p in sorted((out/'辅助图片').iterdir()) if p.suffix in ['.png','.drawio','.svg']]
files={name:(out/name).read_bytes() for name in names}
files['04-研究报告.pdf']=Path(audit['checks'][-1]['pdf']).read_bytes()
assert len(files)==22
assert sha(files['04-研究报告.pdf'])==audit['checks'][-1]['sha256']
archive=root/'release/packages'/args.archive_name
with ZipFile(archive,'x',compression=ZIP_DEFLATED,compresslevel=6) as package:
    for name,raw in sorted(files.items()):package.writestr(name,raw)
with ZipFile(archive) as package:
    assert package.testzip() is None
    assert all(package.read(name)==raw for name,raw in files.items())
receipt={'passed':True,'file':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'files':{name:sha(raw) for name,raw in files.items()},'reportPages':audit['checks'][-1]['pages'],'selectedArrangement':'p210-s1-afixed','containsEarlierReport':False}
(qa/(args.receipt_prefix+'-package.json')).write_text(json.dumps(receipt,ensure_ascii=False,indent=2),encoding='utf-8')
final={**audit,'visualReview':visual,'reportPdf':Path(audit['checks'][-1]['delivered']).name,'reportInsideArchive':'04-研究报告.pdf','package':receipt['file']}
(qa/'submission-materials/final-audit.json').write_text(json.dumps(final,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'file':str(archive),'bytes':receipt['bytes'],'entries':len(files)},ensure_ascii=False))
