"""Retrieve public bibliographic/project metadata; keep failures, never invent fields."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.parse import quote, urlencode
import json

ROOT = Path(__file__).resolve().parents[1]
PAPERS = [
    '10.1057/jos.2012.20', '10.46354/i3m.2021.emss.037',
    '10.1109/WSC.2005.1574562', '10.21121/eab.20250207',
    '10.1287/opre.49.5.744.10606', '10.1002/sim.8086',
    '10.12677/csa.2026.169289', '10.1109/WSC.2016.7822088',
    '10.1111/j.1745-4506.1997.tb00316.x',
]
QUERIES = [
    'campus cafeteria discrete event simulation scheduling',
    'school foodservice scheduling simulation Nettles Gregoire',
    'Lam 2016 advanced tutorial input uncertainty robust analysis stochastic simulation',
    '食堂 排队 窗口 仿真',
]
REPOS = [
    'martokh/discrete-event-simulation', 'heyxingxing/canteen-sim',
    'doufutangvgood/canteen-seat-sim', 'keisanmono/bjtu-dining-sim',
    'jaamsim/jaamsim', 'djordon/queueing-tool',
    'DarwinRG/School-Cafeteria-Simulation', 'shamsadr/tableflow',
]


def fetch(url):
    request = Request(url, headers={'User-Agent': 'DiningLab-research-review/2.1', 'Accept': 'application/json'})
    with urlopen(request, timeout=15) as response:
        return json.load(response)


def article(item):
    return {key: item.get(key) for key in ['DOI', 'title', 'author', 'container-title',
        'published', 'volume', 'issue', 'page', 'URL', 'link', 'license', 'type']}


def retrieve(task):
    kind, value = task
    record = {'kind': kind, 'requested': value}
    try:
        if kind == 'doi':
            record['metadata'] = article(fetch('https://api.crossref.org/works/' + quote(value, safe=''))['message'])
        elif kind == 'discovery':
            url = 'https://api.crossref.org/works?' + urlencode({'query.bibliographic': value, 'rows': 8})
            record['results'] = [article(item) for item in fetch(url)['message']['items']]
        else:
            data = fetch('https://api.github.com/repos/' + value)
            record['metadata'] = {key: data.get(key) for key in ['full_name', 'html_url',
                'description', 'default_branch', 'license', 'archived', 'pushed_at']}
            commits = fetch('https://api.github.com/repos/' + value + '/commits?per_page=1')
            record['commit'] = commits[0]['sha']
            # File presence is not implied solely by the hosting service's license label.
            root = fetch('https://api.github.com/repos/' + value + '/contents?ref=' + record['commit'])
            record['rootFiles'] = [item['name'] for item in root]
    except Exception as error:
        record['error'] = str(error)
    return record


def main():
    tasks = [('doi', value) for value in PAPERS] + [('discovery', value) for value in QUERIES]
    tasks += [('repository', value) for value in REPOS]
    with ThreadPoolExecutor(max_workers=3) as executor:
        records = list(executor.map(retrieve, tasks))
    report = {'retrievedAt': datetime.now(timezone.utc).isoformat(),
        'purpose': 'Discovery and metadata verification only; original papers still require reading.',
        'records': records}
    (ROOT / 'research/decision-retrieval.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    for record in records:
        title = record.get('metadata', {}).get('title', [])
        print(json.dumps({'kind': record['kind'], 'requested': record['requested'],
            'title': title, 'results': len(record.get('results', [])),
            'commit': record.get('commit'), 'error': record.get('error')}, ensure_ascii=True))


if __name__ == '__main__':
    main()
