"""Build a source-traceable report from the user's retained public-document template.

The retained template is not modified. It supplies page geometry, type roles and footers.
Run with the bundled Python runtime. Render with Word and inspect all pages afterwards.
"""
from pathlib import Path
from copy import deepcopy
from datetime import datetime, timezone
import json
import hashlib
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from document_metadata import clean_template_metadata
from zipfile import ZipFile
from io import BytesIO
import argparse

ROOT=Path(__file__).resolve().parents[1]
TEMPLATE=ROOT/'documents/templates/公文模板.docx'
if not TEMPLATE.is_file(): TEMPLATE=ROOT.parent/'公文模板（先复制）.docx'
parser=argparse.ArgumentParser()
parser.add_argument('--output-dir',default='documents/common-windows')
parser.add_argument('--supplement',default=None,help='Optional saved student control study')
parser.add_argument('--cohort-study',default=None,help='Saved admission-plan-scale study')
parser.add_argument('--schedule-study',default=None,help='Saved generic three-schedule comparison')
args=parser.parse_args()
OUT=ROOT/args.output_dir;OUT.mkdir(parents=True,exist_ok=True)
SUPPLEMENT=json.loads((ROOT/args.supplement).read_text(encoding='utf8')) if args.supplement else None
INNOVATION=json.loads((ROOT/'data/common-study-results.json').read_text(encoding='utf8'))
COHORT=json.loads((ROOT/args.cohort_study).read_text(encoding='utf8')) if args.cohort_study else None
SCHEDULE=json.loads((ROOT/args.schedule_study).read_text(encoding='utf8')) if args.schedule_study else None
EXPECTED='ec93c69c2f33639421d1d89cf4fc1e1b0f926b6b1c9bee8ce3fda7167a523ae7'
assert hashlib.sha256(TEMPLATE.read_bytes()).hexdigest()==EXPECTED

def preserve_template_parts(path):
    # python-docx may serialize an equivalent XML declaration differently.
    # Restore the retained styles and page furniture byte for byte after authoring.
    with ZipFile(TEMPLATE) as original, ZipFile(path) as created:
        output=BytesIO()
        with ZipFile(output,'w') as final:
            for item in created.infolist():
                preserve=item.filename.startswith(('word/styles','word/theme/','word/footer','word/header','word/numbering'))
                final.writestr(item,original.read(item.filename) if preserve and item.filename in original.namelist() else created.read(item.filename))
    path.write_bytes(output.getvalue())

def new_document():
    doc=Document(TEMPLATE)
    compress=doc.settings.element.find(qn('w:doNotAutoCompressPictures'))
    if compress is None:
        compress=OxmlElement('w:doNotAutoCompressPictures');doc.settings.element.append(compress)
    compress.set(qn('w:val'),'true')
    roles={name:deepcopy(doc.paragraphs[index]._p) for name,index in [('title',0),('body',3),('h1',4),('h2',5)]}
    body=doc._element.body
    for child in list(body):
        if child.tag!=qn('w:sectPr'):body.remove(child)
    # The original notice's diagrams, hyperlink targets and custom data are not research content.
    for rid,rel in list(doc.part.rels.items()):
        if any(key in rel.reltype for key in ['diagram','hyperlink','customXml']):doc.part.drop_rel(rid)
    doc.core_properties.title='校园食堂错峰就餐与窗口分配仿真软件的设计与实现'
    doc.core_properties.subject='校园午餐错峰与班级出发安排研究' if COHORT else '通用窗口与班级错峰的模拟研究'
    doc.core_properties.author=''
    doc.core_properties.last_modified_by=''
    doc.core_properties.comments='AI辅助检索、开发和整理；协助说明见文末。'
    doc.core_properties.created=datetime.now(timezone.utc)
    doc.core_properties.modified=datetime.now(timezone.utc)
    return doc,roles

doc,roles=new_document()

def clear_paragraph_indents(p):
    """Override character-based and length-based indents on non-body content.

    Word gives firstLineChars precedence over firstLine. Setting only the
    python-docx first_line_indent property therefore leaves the template's
    two-character indent active.
    """
    props=p._p.get_or_add_pPr()
    ind=props.get_or_add_ind()
    ind.attrib.clear()
    for key in ['firstLine','firstLineChars','left','right','leftChars','rightChars','start','end']:
        ind.set(qn('w:'+key),'0')

def paragraph(text,role='body',size=None,align=None):
    proto=roles[role];p=doc.add_paragraph()
    p._p.insert(0,deepcopy(proto.find(qn('w:pPr'))))
    r=p.add_run(text)
    src=next(x for x in proto.findall(qn('w:r')) if x.find(qn('w:t')) is not None)
    r._r.insert(0,deepcopy(src.find(qn('w:rPr'))))
    if size:
        r.font.size=Pt(size);p.paragraph_format.line_spacing=Pt(size+8)
    if align is not None:
        p.alignment=align
        clear_paragraph_indents(p)
    if role=='title':clear_paragraph_indents(p)
    if role in ['h1','h2','title']:p.paragraph_format.keep_with_next=True
    p.paragraph_format.widow_control=True
    return p

def table(headers,rows,widths):
    t=doc.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    props=t._tbl.tblPr
    indent=OxmlElement('w:tblInd');indent.set(qn('w:w'),'0');indent.set(qn('w:type'),'dxa')
    props.insert_element_before(indent,'w:tblBorders','w:shd','w:tblLayout','w:tblCellMar','w:tblLook')
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        edge=OxmlElement('w:'+side);edge.set(qn('w:val'),'single');edge.set(qn('w:sz'),'4');edge.set(qn('w:color'),'D9D9D9');borders.append(edge)
    props.append(borders)
    for i,width in enumerate(widths):t.columns[i].width=Cm(width)
    for row_index,values in enumerate([headers]+rows):
        cells=t.rows[0].cells if row_index==0 else t.add_row().cells
        for i,value in enumerate(values):
            cell=cells[i];cell.width=Cm(widths[i]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cp=cell._tc.get_or_add_tcPr();m=OxmlElement('w:tcMar')
            for side,v in [('top',90),('bottom',90),('left',90),('right',90)]:
                e=OxmlElement('w:'+side);e.set(qn('w:w'),str(v));e.set(qn('w:type'),'dxa');m.append(e)
            cp.append(m)
            if row_index==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'EDF0EC');cp.append(shade)
            p=cell.paragraphs[0];p.paragraph_format.line_spacing=Pt(18);p.paragraph_format.space_after=Pt(2)
            clear_paragraph_indents(p)
            p.paragraph_format.keep_with_next=row_index<len(rows)
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT if i==0 else WD_ALIGN_PARAGRAPH.CENTER
            run=p.add_run(str(value));run.font.name='Times New Roman';run.font.size=Pt(12);run.font.color.rgb=RGBColor(0,0,0);run._r.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'仿宋')
            if row_index==0:run.bold=True
        trpr=t.rows[row_index]._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
    header=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(header)
    paragraph('',size=6).paragraph_format.keep_with_next=False
    return t

def figure(name,caption,width=15.2):
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
    clear_paragraph_indents(p)
    p.add_run().add_picture(str(ROOT/'figures'/name),width=Cm(width))
    paragraph(caption,size=12,align=WD_ALIGN_PARAGRAPH.CENTER)

if SCHEDULE:
    from report_schedules import write_report
    write_report(paragraph,table,figure,SCHEDULE)
elif COHORT:
    from report_admission import write_report
    write_report(paragraph,table,figure,COHORT)
else:
    from report_common import write_report
    write_report(paragraph,table,figure,INNOVATION,SUPPLEMENT)
clean_template_metadata(doc)
doc.save(OUT/'研究报告_公文格式.docx')
preserve_template_parts(OUT/'研究报告_公文格式.docx')
print(str(OUT/'研究报告_公文格式.docx'))
# Build the companion guide from the same retained page and type roles.
doc,roles=new_document()
from report_common import write_guide
def guide_page(title):
    paragraph(title,'h1')
if SCHEDULE:
    from report_schedules import write_guide as schedule_guide
    schedule_guide(paragraph,guide_page)
elif COHORT:
    from report_admission import write_guide as admission_guide
    admission_guide(paragraph,guide_page)
else:
    write_guide(paragraph,guide_page,with_controls=SUPPLEMENT is not None)
doc.core_properties.title='食堂仿真软件使用与研究指南'
clean_template_metadata(doc)
doc.save(OUT/'软件使用与学生研究指南.docx')
preserve_template_parts(OUT/'软件使用与学生研究指南.docx')
print(str(OUT/'软件使用与学生研究指南.docx'))
