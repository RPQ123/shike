const {chromium}=require('playwright'),fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 try{
  const page=await browser.newPage({viewport:{width:1440,height:1100},deviceScaleFactor:4});
  await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>!!window.DiningLabSnapshot);
  await page.locator('[data-tab=compare]').click();await page.locator('#research-tools > summary').click();
  await page.locator('#study-run-three').click();
  await page.waitForFunction(()=>!window.DiningLabSnapshot.busy&&!!window.DiningLabSnapshot.scheduleStudy.initial,null,{timeout:120000});
  const snapshot=await page.evaluate(()=>window.DiningLabSnapshot),saved=JSON.parse(fs.readFileSync('data/schedule-study-results.json','utf8'));
  snapshot.scheduleStudy.initial.rows.forEach((r,i)=>assert.ok(Math.abs(r.summary.meanWait-saved.initial[i].summary.meanWait)<1e-10));
  const chart=page.locator('#study-initial-output .study-bars');
  await chart.scrollIntoViewIfNeeded();
  const clip=await chart.evaluate(el=>{
   const b=el.getBBox(),rect=el.getBoundingClientRect(),scale=rect.width/el.viewBox.baseVal.width,pad=9;
   return {x:rect.x+scrollX+(b.x-pad)*scale,y:rect.y+scrollY+(b.y-pad)*scale,width:(b.width+2*pad)*scale,height:(b.height+2*pad)*scale};
  });
  await page.screenshot({path:'figures/student/23-software-comparison.png',clip,fullPage:true});
  // Export the exact rendered SVG with its computed typeface and colors.
  const svg=await chart.evaluate(el=>{
   const copy=el.cloneNode(true);copy.setAttribute('xmlns','http://www.w3.org/2000/svg');
   const b=el.getBBox();copy.setAttribute('viewBox',`${b.x-9} ${b.y-9} ${b.width+18} ${b.height+18}`);
   [el,...el.querySelectorAll('*')].forEach((node,i)=>{
    const target=[copy,...copy.querySelectorAll('*')][i],css=getComputedStyle(node);
    for(const key of ['font-family','font-size','font-weight','fill','color'])target.style.setProperty(key,css.getPropertyValue(key));
   });
   return new XMLSerializer().serializeToString(copy);
  });
  fs.writeFileSync('figures/student/23-software-comparison.svg',svg);
  await page.locator('#study-initial-output').screenshot({path:'qa/report-software-comparison-full.png'});
  const raw=fs.readFileSync('figures/student/23-software-comparison.png');
  const receipt={passed:true,build:snapshot.build.id,source:'Actual browser UI after 30 repetitions per arrangement',crop:'Comparison chart; full page retained in QA',means:snapshot.scheduleStudy.initial.rows.map(r=>r.summary.meanWait),matchesSavedStudy:true,deviceScaleFactor:4,pngSha256:crypto.createHash('sha256').update(raw).digest('hex')};
  fs.writeFileSync('qa/report-comparison-capture.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});


