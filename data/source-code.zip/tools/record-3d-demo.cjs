// Record the real offline application; no substituted frames or synthetic motion.
// API reference: https://playwright.dev/docs/videos
const { chromium } = require('playwright');
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { pathToFileURL } = require('node:url');
(async () => {
  fs.mkdirSync('qa/3d-demo', { recursive: true });
  fs.mkdirSync('release/demo', { recursive: true });
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  const context = await browser.newContext({
    viewport: { width: 1440, height: 1000 },
    recordVideo: { dir: 'qa/3d-demo', size: { width: 1440, height: 1000 } }
  });
  const page = await context.newPage(),
    video = page.video(),
    errors = [],
    stages = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  const startedAt = new Date().toISOString();
  async function record(label) {
    const state = await page.evaluate(() => window.DiningLabSnapshot);
    assert.equal(state.mode, '3d');
    stages.push({ label, modelTime: state.time, counts: await page.locator('#live-counts').innerText() });
    return state;
  }
  try {
    await page.goto(pathToFileURL(path.resolve('dist/index.html')).href);
    await page.waitForFunction(() => window.DiningLabSnapshot && document.querySelector('#scene3d canvas'));
    const initial = await record('Initial peak-queue view');
    await page.locator('#speed').selectOption('1');
    await page.locator('#play').click();
    await page.waitForTimeout(6000);
    await record('Six seconds at 60x');
    await page.getByRole('button', { name: '俯视', exact: true }).click();
    await page.waitForTimeout(2000);
    await record('Top camera with live playback');
    await page.locator('#speed').selectOption('3');
    await page.waitForTimeout(8000);
    await record('Eight seconds at 180x');
    await page.getByRole('button', { name: '立体', exact: true }).click();
    await page.waitForTimeout(2000);
    await page.locator('#play').click();
    const final = await record('Paused after the accelerated lunch process');
    await page.screenshot({ path: 'qa/innovation-demo-poster.png' });
    assert.ok(final.time > initial.time + 20);
    assert.deepEqual(errors, []);
    await context.close();
    const file = 'release/demo/3D就餐动画_实机演示.webm';
    await video.saveAs(file);
    fs.writeFileSync(
      'qa/innovation-3d-demo.json',
      JSON.stringify(
        {
          startedAt,
          completedAt: new Date().toISOString(),
          build: initial.build,
          file,
          stages,
          errors,
          scope:
            'Unmodified recording of the actual offline 3D application, including speed and camera controls. Numerical metrics are computed by the same event engine; no external school footage or measured floorplan is implied.'
        },
        null,
        2
      )
    );
    console.log(JSON.stringify({ file, stages: stages.length, errors }));
  } finally {
    await browser.close();
  }
})().catch((e) => {
  console.error(e);
  process.exitCode = 1;
});
