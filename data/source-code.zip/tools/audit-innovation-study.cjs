// Verify persisted choices, all summaries and causal histories; optional full ledger replay.
const fs=require('node:fs'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const {sourceFile,sourceRoot}=require('./study-source.cjs');
const hash=x=>crypto.createHash('sha256').update(typeof x==='string'||Buffer.isBuffer(x)?x:JSON.stringify(x)).digest('hex');
function audit(replay=false) {
 const started=Date.now(),s=JSON.parse(fs.readFileSync('data/innovation-study-results.json','utf8')),checks=[];
 const bundle=sourceRoot(s.sourceHashes),bound=file=>sourceFile(file,s.sourceHashes[file],bundle);
 const E=require(bound('dist/school-engine.js')),R=require(bound('dist/research.js')),P=require(bound('dist/planner.js')),T=require(bound('dist/rotation.js')),S=require(bound('tools/run-innovation-study.cjs'));
 const protocol=JSON.parse(fs.readFileSync('research/innovation-protocol.json','utf8'));
 assert.equal(hash(protocol),s.protocolSha256);
 for(const [file,sha] of Object.entries(s.sourceHashes))assert.equal(hash(fs.readFileSync(bound(file))),sha,file);
 assert.deepEqual(JSON.parse(fs.readFileSync('data/innovation-frozen-selection.json','utf8')),s.frozen);
 assert.ok(Date.parse(protocol.writtenAt)<Date.parse(s.startedAt));
 assert.ok(Date.parse(s.frozen.frozenAt)<=Date.parse(s.verificationStartedAt));
 checks.push('Protocol, algorithm sources and frozen choices match; protocol precedes execution, freeze precedes verification');
 const select=P.choose(s.screened,s.screened.find(x=>x.id==='reference'),protocol.criteria);
 assert.deepEqual(Object.fromEntries(['balanced','efficiency','lowPeak'].map(k=>[k,select[k].id])),s.selection);
 const old=P.choose(s.oldScreened,s.oldScreened.find(x=>x.id==='reference'),protocol.criteria).balanced;
 assert.deepEqual(old,s.frozen.oldPlan);
 for(const row of [...s.screened,...s.oldScreened,...s.singleMeal.flatMap(c=>c.rows)])assert.deepEqual(R.summarize(row.rounds),row.summary);
 checks.push('New and old methods reproduce the same declared selector; all single-meal summaries reproduce');
 const ledgerPath='data/innovation-execution-ledger.json',l=JSON.parse(fs.readFileSync(ledgerPath,'utf8')),byKey=new Map();
 assert.equal(hash(fs.readFileSync(ledgerPath)),s.counts.ledgerSha256);
 const near=(a,b,label)=>{assert.equal(typeof a,typeof b,label);if(typeof a==='number')assert.ok(Number.isFinite(a)&&Math.abs(a-b)<1e-9,label);else assert.deepEqual(a,b,label);};
 for(const row of l.rows){
  assert.equal(hash(P.configKey(row.config)),row.key);assert.equal(byKey.has(row.key),false);byKey.set(row.key,row);
  if(replay){const m=R.metrics(E.simulateSchool(row.config));for(const k of Object.keys(m))near(m[k],row.metrics[k],row.key+'/'+k);}
 }
 assert.equal(l.rows.length,s.counts.uniqueExecutions);
 const ranges=[new Set(s.screened[0].seeds),new Set(s.singleMeal[0].rows[0].seeds),new Set(Array.from({length:90},(_,i)=>protocol.periodSeeds.start+i)),new Set(Array.from({length:150},(_,i)=>protocol.fiveMealSeeds.start+i))];
 for(let i=0;i<ranges.length;i++)for(let j=i+1;j<ranges.length;j++)assert.ok([...ranges[i]].every(seed=>!ranges[j].has(seed)));
 checks.push('Every physical configuration including seed has one unique ledger key; all four seed families are disjoint');
 for(const context of [...s.periods,s.fiveMeal]) {
  for(const row of context.rows){
   for(const period of row.rounds){
    assert.deepEqual(T.summarize(period.days,period.days[0].config),period.summary);
    const prior=[];
    for(const day of period.days){
     const saved=byKey.get(hash(P.configKey(day.config)));assert.ok(saved,'Every period day in actual execution ledger');assert.deepEqual(saved.metrics,day.metrics);
     if(day.historyBefore){
      const expected=T.nextOrder(row.plan,prior,row.mode,day.config);
      assert.deepEqual(expected.order,day.order);assert.deepEqual(expected.historyTotals,day.historyBefore.totals);assert.equal(prior.length,day.historyBefore.meals);
     }
     prior.push(day);
    }
   }
   assert.deepEqual(R.summarize(row.rounds.map(r=>r.summary)),row.summary);
  }
  if(context.differences){
   const ref=context.rows.find(r=>r.id==='reference');
   for(const row of context.rows)assert.deepEqual(S.pairedPeriods(ref.rounds,row.rounds),context.differences[row.id]);
   const oracle=context.rows.find(r=>r.id==='hindsight');
   for(let i=0;i<oracle.rounds.length;i++)for(const id of ['joint-fixed','joint-cyclic','joint-feedback'])assert.ok(oracle.rounds[i].summary.periodWorstGrade<=context.rows.find(r=>r.id===id).rounds[i].summary.periodWorstGrade+1e-9);
  }
 }
 checks.push('Every day matches the ledger; complete period summaries and paired comparisons reproduce; feedback orders reproduce using only their prior history');
 checks.push('Three-meal future-known comparison bounds each feasible online sequence within the declared search space');
 if(replay)checks.push(`All ${l.rows.length} unique engine executions replay with identical complete metrics`);
 return {passed:true,at:new Date().toISOString(),sourceHashes:s.sourceHashes,uniqueExecutions:l.rows.length,replayed:replay?l.rows.length:0,seconds:(Date.now()-started)/1000,checks};
}
module.exports={audit};
if(require.main===module){const result=audit(process.argv.includes('--replay'));fs.writeFileSync('qa/innovation-study-audit.json',JSON.stringify(result,null,2));console.log(JSON.stringify(result));}
