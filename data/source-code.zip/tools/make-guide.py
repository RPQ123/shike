"""Create the student-facing guide using the retained document template."""
from copy import deepcopy
from pathlib import Path
from datetime import datetime, timezone
import hashlib
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from document_metadata import clean_template_metadata

ROOT = Path(__file__).resolve().parents[1]
template = ROOT / 'documents/templates/公文模板.docx'
if not template.is_file(): template = ROOT.parent / '公文模板（先复制）.docx'
assert hashlib.sha256(template.read_bytes()).hexdigest() == 'ec93c69c2f33639421d1d89cf4fc1e1b0f926b6b1c9bee8ce3fda7167a523ae7'
doc = Document(template)
roles = {name: deepcopy(doc.paragraphs[i]._p) for name, i in [('title',0),('body',3),('h1',4),('h2',5)]}
for child in list(doc._element.body):
    if child.tag != qn('w:sectPr'):
        doc._element.body.remove(child)
for rid, rel in list(doc.part.rels.items()):
    if any(key in rel.reltype for key in ['diagram','hyperlink','customXml']):
        doc.part.drop_rel(rid)
doc.core_properties.title = '食堂仿真软件使用与学生研究指南'
doc.core_properties.author = ''
doc.core_properties.last_modified_by = ''
doc.core_properties.comments = 'AI辅助整理的学习材料；本人研究记录由学生如实填写。'
doc.core_properties.created = datetime.now(timezone.utc)
doc.core_properties.modified = datetime.now(timezone.utc)

def p(text, role='body', size=None, align=None):
    proto=roles[role]
    paragraph=doc.add_paragraph()
    paragraph._p.insert(0,deepcopy(proto.find(qn('w:pPr'))))
    src=next(r for r in proto.findall(qn('w:r')) if r.find(qn('w:t')) is not None)
    run=paragraph.add_run(text)
    run._r.insert(0,deepcopy(src.find(qn('w:rPr'))))
    run.font.color.rgb=RGBColor(0,0,0)
    if size:
        run.font.size=Pt(size)
        paragraph.paragraph_format.line_spacing=Pt(size+8)
    if align is not None:
        paragraph.alignment=align
    paragraph.paragraph_format.widow_control=True
    if role!='body':
        paragraph.paragraph_format.keep_with_next=True
    return paragraph

def page(title):
    heading=p(title,'h1')
    heading.paragraph_format.page_break_before=True

from guide_innovation import write_guide
write_guide(p,page)
output=ROOT/'documents/软件使用与学生研究指南.docx'
clean_template_metadata(doc)
doc.save(output)
print(output)
