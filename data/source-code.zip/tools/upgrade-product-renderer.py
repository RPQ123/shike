from pathlib import Path
p=Path(__file__).resolve().parents[1]/'dist/canteen3d.js';s=p.read_text('utf-8')
if 'const Crowd=root.DiningPeople;' in s:raise SystemExit('Renderer upgrade already applied.')
a=s.index('  class Crowd {');b=s.index('  class View {',a);s=s[:a]+'  const Crowd=root.DiningPeople;\n'+s[b:]
s=s.replace('const g=new T.Group();g.name=\'Dining hall\';const b=layout.bounds,c=layout.floorCenter;','const g=new T.Group();g.name=\'Dining hall\';const b=layout.bounds,c=layout.floorCenter;\n    const polished=!!root.DiningHallDesign&&layout.twoSided;\n    if(polished)g.add(root.DiningHallDesign.build(layout));')
a=s.index('    box(g,[b.width+.4');b=s.index('    const slotStations=',a)
s=s[:a]+'    if(!polished) {\n'+s[a:b]+'    }\n'+s[b:]
a=s.index('      box(station,[2.16,.95');b=s.index('      const status=box',a)
s=s[:a]+'      if(!polished) {\n'+s[a:b]+'      } else if(!slot.open) return {group:station,open:false};\n'+s[b:]
# The original chef bodies belong outside the static conditional.
s=s.replace('      cylinder(station,.14,.42','      cylinder(station,.14,.42')
s=s.replace('    layout.tables.forEach(t=>table(g,t.position[0],t.position[2],t.zone,layout.zoned));','    if(!polished)layout.tables.forEach(t=>table(g,t.position[0],t.position[2],t.zone,layout.zoned));')
s=s.replace('this.scene.background=new T.Color(0xeef2e9);','this.scene.background=new T.Color(0xf1f0e9);')
s=s.replace('new T.HemisphereLight(0xfff9ef,0xb7c5ae,2.35)','new T.HemisphereLight(0xfff9ef,0xb5c1ad,1.65)')
s=s.replace('new T.DirectionalLight(0xfff1d2,3.2);this.sun.position.set(-18,35,17)','new T.DirectionalLight(0xfff1d8,3.1);this.sun.position.set(-18,35,-18)')
s=s.replace('this.renderer.toneMappingExposure=1.13','this.renderer.toneMappingExposure=.98')
s=s.replace("this.renderer.outputColorSpace=T.SRGBColorSpace;","this.renderer.outputColorSpace=T.SRGBColorSpace;\n      if(root.DiningHallDesign){this.environmentTarget=root.DiningHallDesign.environment(this.renderer);this.scene.environment=this.environmentTarget.texture;this.scene.environmentIntensity=.48;}")
s=s.replace("if(obj.material)(Array.isArray(obj.material)?obj.material:[obj.material]).forEach(m=>materials.add(m));","if(obj.material)(Array.isArray(obj.material)?obj.material:[obj.material]).forEach(m=>materials.add(m));")
s=s.replace('materials.forEach(m=>m.dispose());','const textures=new Set();materials.forEach(m=>{for(const value of Object.values(m))if(value?.isTexture)textures.add(value);m.dispose();});textures.forEach(t=>t.dispose());')
s=s.replace('perspective:new T.Vector3(.54,1.2,1.38)','perspective:new T.Vector3(.20,1.85,1.58)')
s=s.replace('b.minX-.3,b.maxX+.3','b.minX-2,b.maxX+2').replace('b.minZ-.4,b.maxZ+.4','b.minZ-1.7,b.maxZ+1.8').replace('[-.5,3.2]','[-.65,3.7]').replace('halfX/aspect)*1.1','halfX/aspect)*1.05')
s=s.replace('shadow.left=-extent;shadow.right=extent;shadow.top=extent;shadow.bottom=-extent','shadow.left=-extent*.72;shadow.right=extent*.72;shadow.top=extent*.72;shadow.bottom=-extent*.72')
s=s.replace('this.renderer.dispose();this.renderer.domElement.remove();','this.environmentTarget?.dispose();this.renderer.dispose();this.renderer.domElement.remove();')
p.write_text(s,'utf-8')
