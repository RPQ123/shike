const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{const browser=await chromium.launch({headless:true,channel:'chrome'}),page=await browser.newPage({viewport:{width:1440,height:1000},acceptDownloads:true});const errors=[];page.on('pageerror',e=>errors.push(e.message));
try {
 await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>DiningLabSnapshot);await page.locator('[data-tab=compare]').click();
 assert.equal(await page.locator('#export-compare').isVisible(),false);await page.locator('#legacy-comparison>summary').click();assert.ok(await page.locator('#export-compare').isVisible());
 await page.locator('#set-baseline').click();await page.locator('#repeats').selectOption('10');await page.locator('#compare-run').click();await page.waitForFunction(()=>!DiningLabSnapshot.busy&&DiningLabSnapshot.comparison,null,{timeout:90000});
 let s=await page.evaluate(()=>DiningLabSnapshot);assert.ok(Object.values(s.comparison.differences).every(x=>x.mean===0&&x.low===0&&x.high===0));
 const waiting=page.waitForEvent('download');await page.locator('#export-compare').click();const comparison=JSON.parse(fs.readFileSync(await(await waiting).path(),'utf8'));assert.equal(comparison.seeds.length,10);assert.deepEqual(comparison,s.comparison);
 await page.locator('#scenario-section>summary').click();await page.locator('#scenario-run').click();await page.waitForFunction(()=>!DiningLabSnapshot.busy&&DiningLabSnapshot.scenarioCheck,null,{timeout:90000});assert.equal((await page.evaluate(()=>DiningLabSnapshot)).scenarioCheck.cases.length,3);
 assert.deepEqual(errors,[]);const receipt={passed:true,build:s.build.id,pairedUnchangedPlansHaveZeroDifference:true,exportRepeats:10,sensitivityCases:3,errors};fs.writeFileSync('qa/product-comparison-audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
