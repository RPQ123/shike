"""Compare the independent Python scheduling implementation with JS results.

Random inputs are supplied by JS and are NOT independently validated here.
This check validates common-pool pickup, shared seating and elapsed-time arithmetic.
"""
import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'learning'))
from teaching_model import simulate

fixtures = json.loads(Path('qa/oracle-fixtures.json').read_text(encoding='utf8'))
maximum = 0
checks = 0
for case in fixtures:
    actual = simulate(case['people'], case['windows'], case['seats'], case['open_time'], case['return_time'])
    for a, b in zip(actual, case['expected']):
        for key, expected in b.items():
            residual = abs(a[key] - expected)
            maximum = max(maximum, residual)
            assert residual < 1e-7, (case['name'], a['id'], key, a[key], expected)
            checks += 1
report = {'fixtures':len(fixtures),'compared_fields':checks,'max_absolute_seconds':maximum,'scope':'one meal zone, pooled pickup, shared seats; random inputs supplied by JS','passed':True}
Path('qa/oracle-result.json').write_text(json.dumps(report, indent=2),encoding='utf8')
print(json.dumps(report))
