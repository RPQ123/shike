"""Extract the indexed source and desktop archives into a NEW bounded QA directory."""
from pathlib import Path
import json
import sys
from zipfile import ZipFile

root = Path(__file__).resolve().parents[1]
target = Path(sys.argv[1]).resolve()
assert target.is_relative_to((root/'qa').resolve()), 'QA extraction must remain inside this workspace qa folder'
assert not target.exists(), 'Use a fresh extraction directory'
index = json.loads((root/'release/packages/package-index.json').read_text(encoding='utf8'))
pairs=[('source','源码与研究材料'),('desktop','Windows桌面版')]
if index.get('iteration')=='innovation-planner': pairs.append(('word','Word文章与指南'))
for key, marker in pairs:
    destination = target/key
    destination.mkdir(parents=True)
    archive = next(p for p in index['packages'] if marker in p['file'])
    with ZipFile(root/'release/packages'/archive['file']) as z:
        assert z.testzip() is None
        for item in z.infolist():
            resolved = (destination/item.filename).resolve()
            assert resolved.is_relative_to(destination), 'Unsafe ZIP entry: '+item.filename
            assert (item.external_attr >> 16) & 0o170000 != 0o120000, 'Unexpected symlink'
        z.extractall(destination)
print(json.dumps({'build':index['build'],'target':str(target)},ensure_ascii=True))
