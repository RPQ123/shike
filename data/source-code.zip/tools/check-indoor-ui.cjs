const {chromium}=require('playwright'),fs=require('node:fs'),assert=require('node:assert/strict');
const E=require('../dist/school-engine'),Scene=require('../dist/scene-state');
const url=process.argv[2]||'http://127.0.0.1:8773/';
const receiptName=url.includes('github.io')?'github':url.includes('127.0.0.1')?'local':'live';
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'}),page=await browser.newPage({viewport:{width:1500,height:1000},acceptDownloads:true}),errors=[];
 page.on('pageerror',e=>errors.push(String(e)));
 try{
  await page.goto(url,{waitUntil:'networkidle'});await page.waitForFunction(()=>window.DiningLabSnapshot);
  const s=await page.evaluate(()=>DiningLabSnapshot);assert.equal(s.config.indoorWalkSpeed,1.1);
  const r=E.simulateSchool(s.config),layout=Scene.createLayoutForResult(r);
  let best=null;
  for(let t=34;t<55;t+=.1){const f=Scene.frame(r,t,layout),walkers=f.visibleDiningPeople.filter(p=>p.state==='walking-to-seat');if(!best||walkers.length>best.walkers.length)best={t,walkers,f};}
  const seek=async t=>{await page.locator('#timeline').evaluate((el,t)=>{el.value=t;el.dispatchEvent(new Event('input',{bubbles:true}))},t);await page.waitForTimeout(120);};
  await seek(best.t);
  assert.ok(best.walkers.length>0);
  assert.ok((await page.locator('#live-counts').innerText()).includes('端盘步行'));
  const canvas=page.locator('#scene3d canvas');assert.ok(await canvas.evaluate(c=>!!c.getContext('webgl2')));
  await page.screenshot({path:'qa/indoor-walking-'+receiptName+'.png'});
  const first=best.walkers[0],person=r.students[first.id];
  await seek(person.seatStart-.005);
  const entering=await page.evaluate(({r,t,id})=>CanteenSceneState.frame(r,t).diningPeople.find(p=>p.id===id),{r,t:person.seatStart-.005,id:person.id});
  assert.equal(entering.state,'sitting');assert.ok(entering.sitProgress>0&&entering.sitProgress<1);
  await seek(person.seatStart+.001);
  const seated=await page.evaluate(({r,t,id})=>CanteenSceneState.frame(r,t).diningPeople.find(p=>p.id===id),{r,t:person.seatStart+.001,id:person.id});assert.equal(seated.state,'dining');
  await seek(best.t);
  await page.locator('#speed').selectOption('0.016666666666666666');
  const before=await canvas.screenshot(),t0=await page.evaluate(()=>DiningLabSnapshot.time);await page.locator('#play').click();await page.waitForTimeout(750);await page.locator('#play').click();
  const dt=await page.evaluate(t=>DiningLabSnapshot.time-t,t0);assert.ok(dt>0&&dt<.06,'real-time playback');assert.notDeepEqual(await canvas.screenshot(),before);
  await page.locator('#export-run').locator('xpath=ancestor::details').locator('summary').click();
  const download=page.waitForEvent('download');await page.locator('#export-run').click();const exported=JSON.parse(fs.readFileSync(await(await download).path(),'utf8'));
  function same(a,b,at='students'){
   if(typeof a==='number'&&typeof b==='number'){assert.ok(Math.abs(a-b)<1e-9,at);return;}
   if(a&&b&&typeof a==='object'&&typeof b==='object'){assert.deepEqual(Object.keys(a),Object.keys(b),at);for(const key of Object.keys(a))same(a[key],b[key],at+'.'+key);return;}
   assert.equal(a,b,at);
  }
  same(exported.result.students,r.students);
  await page.locator('#parameters').click();await page.locator('[name=indoorWalkSpeed]').fill('.8');await page.getByRole('button',{name:'运行这个方案'}).click();assert.equal(await page.evaluate(()=>DiningLabSnapshot.config.indoorWalkSpeed),.8);
  assert.deepEqual(errors,[]);
  const receipt={passed:true,url,build:s.build.id,walkingFigures:best.walkers.length,walkingCount:best.f.counts.walkingToSeat,time:best.t,checks:['real WebGL','walking around tables','sitting transition','playing','exact per-student export','speed parameter'],errors};
  fs.writeFileSync('qa/indoor-ui-'+receiptName+'.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
