from pathlib import Path
from zipfile import ZipFile
from docx import Document
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH as A
from lxml import etree as E
import json,hashlib,re,unicodedata,csv,subprocess
import pypdfium2 as pdfium

r=Path(__file__).resolve().parents[1];q=r/'qa';folder=r/'documents/schedule-edition';out=r.parent/'【成品】提交材料'
s=json.loads((r/'data/schedule-study-results.json').read_text('utf-8'))
sha=lambda b:hashlib.sha256(b).hexdigest()
norm=lambda t:re.sub(r'\s+','',unicodedata.normalize('NFKC',t))
d=Document(folder/'研究报告_公文格式.docx');text='\n'.join(p.text for p in d.paragraphs)
assert d.paragraphs[0].text.replace('\n','')=='校园食堂错峰就餐与窗口分配仿真软件的设计与实现'
assert len(d.tables)==7 and len(d.inline_shapes)==8
for bad in ['滨河','铁一','招生计划','国内大部分','已开展走访','实测表明','已经在全国','需要强调的是','值得注意的是','并非','窗口配置']:
    assert bad not in text,bad
for word in ['七、总结','八、推广与使用方法','公开网页或Windows软件','烦躁感','匿名反馈','Python','JavaScript','for循环','if语句','共比较13个间隔','660次','平均完整用时增加'+format(s['verification'][2]['summary']['meanTotal']-s['verification'][1]['summary']['meanTotal'],'.2f')+'分钟']:
    assert word in text,word
assert not re.search(r'\d',next(p.text for p in d.paragraphs if p.text.startswith('摘要：')))
cells=lambda t:[[c.text for c in row.cells] for row in t.rows][1:]
fmt=lambda n:f'{n:.2f}'
def clock(t):
    n=round((680+t)*60);return f'{n//3600:02}:{n//60%60:02}:{n%60:02}'
assert cells(d.tables[2])==[[['不实行错峰','仅年级错峰','年级班级错峰'][i],fmt(row['summary']['meanWait']),fmt(row['summary']['meanTotal']),fmt(row['summary']['peakQueue'])] for i,row in enumerate(s['initial'])]
assert cells(d.tables[3])==[[str(row['seconds']),fmt(row['summary']['meanWait']),fmt(row['summary']['meanTotal']),clock(row['summary']['lastEndpointMax'])] for row in s['intervals']]
assert cells(d.tables[4])==[[['不实行错峰','仅年级错峰','年级班级错峰'][i],fmt(row['summary']['meanWait']),fmt(row['summary']['meanTotal']),clock(row['summary']['lastEndpointMax'])] for i,row in enumerate(s['verification'])]
assert cells(d.tables[5])==[[['高一','高二','高三'][i],*[fmt(row['summary'][f'grade{i}Wait']) for row in s['verification']]] for i in range(3)]
images=['12-meal-flow.png','22-software-setup.png','16-software-scene.png','13-window-choice.png','23-software-comparison.png','21-group-intervals.png','24-class-parameters.png','25-usage-results.png']
for shape,name in zip(d.inline_shapes,images):assert d.part.related_parts[shape._inline.graphic.graphicData.pic.blipFill.blip.embed].blob==(r/'figures/student'/name).read_bytes()
captions=[p for p in d.paragraphs if re.match(r'^[图表]\d+',p.text)]
for p in d.paragraphs+[p for t in d.tables for row in t.rows for c in row.cells for p in c.paragraphs]:
    checked=re.sub(r'^([图表]\d+) ',r'\1',p.text)
    assert not re.search(r'\d[ \t\u00a0\u3000]+|[ \t\u00a0\u3000]+\d',checked),p.text
    if p.text and not p._p.xpath('.//m:oMath'):
        assert p._p.get_or_add_pPr().find(qn('w:autoSpaceDN')).get(qn('w:val'))=='0'
assert 'AI' not in text
equations=[p for p in d.paragraphs if p._p.xpath('.//m:oMath') or (p.alignment==A.CENTER and '＝' in p.text)]
assert len(captions)==15 and len(equations)==3
assert all(re.match(r'^[图表]\d+ [^\s]',p.text) for p in captions)
for p in captions+equations+[p for t in d.tables for row in t.rows for c in row.cells for p in c.paragraphs]:
    ind=p._p.get_or_add_pPr().find(qn('w:ind'));assert ind is not None and all(v=='0' for v in ind.attrib.values()),p.text
for p in captions+equations:assert p.alignment==A.CENTER
assert not re.search(r'参考资料|参考文献|\[\d+\]|https?://|DOI：|查阅了|研究参考这些',text)
for t in d.tables:
    prior=t._tbl.getprevious()
    assert prior is not None and re.match(r'^表\d+', ''.join(prior.itertext())), '表题必须紧邻表格上方'
for shape in d.inline_shapes:
    parent=shape._inline.getparent()
    while parent.tag!=qn('w:p'):parent=parent.getparent()
    after=parent.getnext()
    assert after is not None and re.match(r'^图\d+', ''.join(after.itertext())), '图题必须紧邻图片下方'
assert next(p for p in d.paragraphs if p.text.startswith('高中午餐时间'))._p.get_or_add_pPr().find(qn('w:ind')).get(qn('w:firstLineChars'))=='200'
assert d.element.xpath('.//m:sSubSup')
code='\n'.join(p.text for p in d.paragraphs if p.text.startswith(('for round_index','    for position','        if round_index','            seconds','                       + position','            slots.append')))
compile(code,'report-code','exec');assert len(code.splitlines())==6

template=r/'documents/templates/公文模板.docx'
for path in folder.glob('*.docx'):
    with ZipFile(template) as original,ZipFile(path) as revised:
        for name in original.namelist():
            if name.startswith(('word/styles','word/theme/','word/header','word/footer','word/numbering')) and not name.endswith('/'):assert original.read(name)==revised.read(name)
for name in ['binhe-cohort-results.json','binhe-cohort-rounds.csv','binhe-cohort-summary.csv','indoor-walking-results.json','indoor-walking-rounds.csv']:
    assert (r/'data'/name).read_bytes()==subprocess.check_output(['git','show','HEAD:data/'+name],cwd=r)
for name,expected in json.loads((q/'submission-materials/original-template-hashes.json').read_text('utf-8')).items():assert sha((r.parent/name).read_bytes())==expected
receipt=json.loads((q/'submission-materials/build-receipt.json').read_text('utf-8'));assert receipt['introCharacters']<=410
for record in receipt['documents']:
    with ZipFile(record['source']) as original,ZipFile(out/record['file']) as revised:
        changed=[name for name in original.namelist() if original.read(name)!=revised.read(name)]
        extra=set(changed)-{'word/document.xml','docProps/core.xml'}
        if extra:
            # The process-record template is a report copy whose body is replaced.
            # Old image blobs may remain in the ZIP but must not be referenced.
            body=E.fromstring(revised.read('word/document.xml'))
            ids=set(body.xpath('//@r:embed | //@r:link | //@r:id',namespaces={'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}))
            rels=E.fromstring(revised.read('word/_rels/document.xml.rels'))
            used={'word/'+rel.get('Target','') for rel in rels if rel.get('Id') in ids}
            assert all(name.startswith('word/media/') and name not in used for name in extra),extra
assert (out/'04-研究报告.docx').read_bytes()==(folder/'研究报告_公文格式.docx').read_bytes()
for src,dst in [('schedule-study-rounds.csv','05-原始实验记录.csv'),('schedule-study-summary.csv','06-计算结果汇总.csv'),('schedule-study-timetable.csv','07-班级放行表.csv')]:assert (r/'data'/src).read_bytes()==(out/dst).read_bytes()

exports=json.loads((q/'queue-submission-render/export-receipt.json').read_text('utf-8-sig'))
exports.append({'source':str(folder/'软件使用与学生研究指南.docx'),'pdf':str(folder/'软件使用与学生研究指南.pdf'),'delivered':None})
checks=[]
for record in exports:
    source=Path(record['source']);doc=Document(source);pdf=pdfium.PdfDocument(record['pdf'])
    rendered='\n'.join(line for page in pdf for line in page.get_textpage().get_text_range().splitlines() if not re.fullmatch(r'\s*[-－–—]\s*\d+\s*[-－–—]\s*',line))
    paras=[p.text for p in doc.paragraphs]+[p.text for t in doc.tables for row in t.rows for c in row.cells for p in c.paragraphs]
    missing=[p for p in paras if norm(p) and norm(p) not in norm(rendered)]
    assert not missing,(source.name,missing[:3]);assert '\ufffd' not in rendered
    if record['delivered']:assert Path(record['pdf']).read_bytes()==Path(record['delivered']).read_bytes()
    if source.name.startswith('研究报告'):assert len(pdf[len(pdf)-1].get_textpage().get_text_range())>150
    if source.name.startswith(('01-','02-','08-')):
        target=q/'schedule-forms-render'/source.stem;target.mkdir(parents=True,exist_ok=True)
        for i,page in enumerate(pdf):page.render(scale=1.3).to_pil().save(target/f'page-{i+1:02}.png')
    checks.append({'file':str(source),'pdf':record['pdf'],'pages':len(pdf),'sha256':sha(Path(record['pdf']).read_bytes()),'paragraphsChecked':len(paras),'delivered':record['delivered']});pdf.close()
result={'passed':True,'tables':7,'figures':8,'captions':15,'equations':3,'pythonCodeLines':6,'executions':660,'selectedSeconds':70,'originalDataUnchanged':True,'originalTemplatesUnchanged':True,'bodyFirstLineCharacters':2,'captionLabelSpace':True,'checks':checks}
(q/'schedule-document-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=False))
