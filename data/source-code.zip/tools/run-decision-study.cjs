// Supplemental synthetic experiment; selection is frozen before new verification seeds.
const fs = require('node:fs');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const E = require('../dist/school-engine.js');
const R = require('../dist/research.js');
const D = require('../dist/decision-support.js');
const protocol = JSON.parse(fs.readFileSync('research/decision-protocol.json', 'utf8'));
const hash = (data) =>
  crypto
    .createHash('sha256')
    .update(typeof data === 'string' ? data : JSON.stringify(data))
    .digest('hex');
const seeds = (range) => Array.from({ length: range.count }, (_, i) => range.start + i);

function contexts(base) {
  const grid = D.planScenarios(base, base, { repeats: 10, seed: protocol.screeningSeeds.start }).accepted.map(
    (cell) => ({ id: cell.id, label: cell.label, group: 'grid', config: cell.configA })
  );
  const extra = protocol.additionalVerificationScenarios.map((def) => {
    const c = R.clone(base);
    if (def.id === 'walk-fixed')
      c.grades.forEach((g) => {
        g.walkMin = 3;
        g.walkMax = 3;
      });
    else if (def.id === 'walk-spread')
      c.grades.forEach((g) => {
        g.walkMin = 1;
        g.walkMax = 5;
      });
    else if (def.id === 'meal-fast') c.mealMean = 8;
    else if (def.id === 'meal-slow') c.mealMean = 12;
    else if (def.id === 'unequal-windows') c.windowMeans = [16, 20, 24, 16, 20, 24];
    else if (def.id === 'pooled') c.strategy = 'pooled';
    else if (def.id === 'unequal-grades') c.grades.forEach((g, i) => (g.students = [80, 120, 160][i]));
    else throw new Error('Unknown declared supplemental context: ' + def.id);
    return { id: def.id, label: def.label, group: 'additional', config: E.normalizeSchoolConfig(c) };
  });
  assert.equal(grid.length, 9);
  return [...grid, ...extra];
}
function policyConfig(input, policy) {
  const c = E.makeSchoolGapConfig(input, policy.gap);
  c.windowZones = c.windowZones.map((_, i) => (i < policy.aWindows ? 0 : 1));
  return E.normalizeSchoolConfig(c);
}
function select(rows, referenceId) {
  assert.ok(
    rows.some((row) => row.id === referenceId),
    'Reference must be included'
  );
  const scores = rows.map((row) => {
    const nominal = row.cases.find((cell) => cell.contextId === 's1-p0');
    assert.ok(nominal, 'Nominal case required');
    return {
      id: row.id,
      nominalMean: nominal.summary.meanTotal,
      worstMeanDelta: Math.max(...row.cases.map((cell) => cell.assessment.total.mean)),
      passes: row.cases.every((cell) => cell.assessment.guard === 'within')
    };
  });
  const byNominal = (a, b) => a.nominalMean - b.nominalMean || a.id.localeCompare(b.id);
  const eligible = scores.filter((row) => row.passes);
  assert.ok(eligible.length, 'Reference must pass its own zero-difference checks');
  return {
    nominal: scores.slice().sort(byNominal)[0].id,
    guarded: eligible.slice().sort((a, b) => a.worstMeanDelta - b.worstMeanDelta || byNominal(a, b))[0].id,
    eligibleIds: eligible.map((row) => row.id),
    scores
  };
}

function main() {
  const startedAt = new Date().toISOString(),
    base = R.example(),
    allContexts = contexts(base);
  const policies = R.candidates(base, { reallocate: true }).accepted;
  assert.equal(policies.length, 25);
  const referenceId = protocol.referenceId,
    referencePolicy = policies.find((row) => row.id === referenceId);
  assert.deepEqual(referencePolicy.config, base);
  const sourceFiles = [
    'dist/engine.js',
    'dist/school-engine.js',
    'dist/research.js',
    'dist/decision-support.js',
    'tools/run-decision-study.cjs'
  ];
  const sourceHashes = Object.fromEntries(
    sourceFiles.map((file) => [file, hash(fs.readFileSync(file, 'utf8'))])
  );
  const protocolSha256 = hash(protocol),
    screenSeeds = seeds(protocol.screeningSeeds),
    checkSeeds = seeds(protocol.verificationSeeds);
  assert.ok(screenSeeds.every((seed) => !checkSeeds.includes(seed)));
  const records = [];
  let executions = 0;
  function evaluate(context, policy, seedList, phase) {
    const config = policyConfig(context.config, policy);
    const rounds = seedList.map((seed) => {
      executions++;
      return { seed, ...R.metrics(E.simulateSchool({ ...config, seed })) };
    });
    const summary = R.summarize(rounds.map(({ seed, ...metrics }) => metrics));
    const row = {
      phase,
      contextId: context.id,
      policyId: policy.id,
      config,
      configSha256: hash(config),
      rounds,
      summary
    };
    records.push(row);
    return row;
  }
  const screened = policies.map((policy) => ({ id: policy.id, label: policy.label, cases: [] }));
  for (const context of allContexts.filter((row) => row.group === 'grid')) {
    const local = policies.map((policy) => evaluate(context, policy, screenSeeds, 'screening'));
    const reference = local.find((row) => row.policyId === referenceId);
    for (const row of local)
      screened
        .find((policy) => policy.id === row.policyId)
        .cases.push({
          contextId: context.id,
          summary: row.summary,
          assessment: D.assess(
            reference.config,
            row.config,
            reference.rounds,
            row.rounds,
            protocol.thresholdMinutes
          )
        });
    console.log('Screened ' + context.id);
  }
  const selection = select(screened, referenceId);
  const selectedIds = [...new Set([referenceId, selection.nominal, selection.guarded])];
  const frozen = {
    schema: 'dining-frozen-decision/1',
    protocolSha256,
    sourceHashes,
    nominal: selection.nominal,
    guarded: selection.guarded,
    referenceId,
    configHashes: Object.fromEntries(
      selectedIds.map((id) => [id, hash(policies.find((row) => row.id === id).config)])
    ),
    screeningSeeds: screenSeeds,
    verificationSeeds: checkSeeds
  };
  const freezePath = 'data/decision-frozen-selection.json';
  if (fs.existsSync(freezePath)) {
    const existing = JSON.parse(fs.readFileSync(freezePath, 'utf8'));
    const { frozenAt, ...previous } = existing;
    assert.deepEqual(
      previous,
      frozen,
      'Do not replace a frozen selection after verification; preserve history and define a new study'
    );
    frozen.frozenAt = frozenAt;
  } else {
    frozen.frozenAt = new Date().toISOString();
    fs.writeFileSync(freezePath, JSON.stringify(frozen, null, 2));
  }
  // No verification simulation occurs before the immutable selection above exists.
  const verificationStartedAt = new Date().toISOString(),
    verification = [];
  for (const context of allContexts) {
    const local = selectedIds.map((id) =>
      evaluate(
        context,
        policies.find((row) => row.id === id),
        checkSeeds,
        'verification'
      )
    );
    const reference = local.find((row) => row.policyId === referenceId);
    for (const row of local)
      verification.push({
        contextId: context.id,
        group: context.group,
        policyId: row.policyId,
        summary: row.summary,
        assessment: D.assess(
          reference.config,
          row.config,
          reference.rounds,
          row.rounds,
          protocol.thresholdMinutes
        )
      });
    console.log('Verified ' + context.id);
  }
  const screeningRuns = records
    .filter((row) => row.phase === 'screening')
    .reduce((n, row) => n + row.rounds.length, 0);
  const verificationRuns = records
    .filter((row) => row.phase === 'verification')
    .reduce((n, row) => n + row.rounds.length, 0);
  assert.equal(executions, screeningRuns + verificationRuns);
  assert.equal(screeningRuns, 25 * 9 * 10);
  assert.equal(verificationRuns, selectedIds.length * 16 * 30);
  const validationSummary = Object.fromEntries(
    selectedIds.map((id) => [id, D.summarizeScenarios(verification.filter((row) => row.policyId === id))])
  );
  const output = {
    schema: 'dining-decision-study/1',
    evidence: 'synthetic',
    startedAt,
    verificationStartedAt,
    finishedAt: new Date().toISOString(),
    modelVersion: E.VERSION,
    researchVersion: R.VERSION,
    decisionVersion: D.VERSION,
    protocol,
    protocolSha256,
    sourceHashes,
    contexts: allContexts,
    screened,
    selection,
    frozen,
    records,
    verification,
    counts: { screeningRuns, verificationRuns, uniqueExecutions: executions, selectedPolicies: selectedIds },
    validationSummary
  };
  fs.writeFileSync('data/decision-study-results.json', JSON.stringify(output));
  fs.writeFileSync(
    'data/decision-study-rounds.csv',
    R.csv(
      records.flatMap((row) =>
        row.rounds.map((round) => ({
          phase: row.phase,
          context: row.contextId,
          policy: row.policyId,
          ...round
        }))
      )
    )
  );
  fs.writeFileSync(
    'data/decision-study-summary.json',
    JSON.stringify(
      {
        startedAt,
        finishedAt: output.finishedAt,
        counts: output.counts,
        selection,
        validationSummary,
        nominalCase: verification.filter((row) => row.contextId === 's1-p0')
      },
      null,
      2
    )
  );
  console.log(
    JSON.stringify({
      counts: output.counts,
      nominal: selection.nominal,
      guarded: selection.guarded,
      validationSummary
    })
  );
}
module.exports = { contexts, policyConfig, select };
if (require.main === module) main();
