const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const E=require('../dist/school-engine.js'),R=require('../dist/research.js');
(async()=>{const browser=await chromium.launch({headless:true,channel:'chrome'}),page=await browser.newPage({viewport:{width:1440,height:1100},acceptDownloads:true});
const errors=[],external=[],checks=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(!r.url().startsWith('http://127.0.0.1:8771')&&!r.url().startsWith('data:')&&!r.url().startsWith('blob:'))external.push(r.url())});
const snap=()=>page.evaluate(()=>DiningLabSnapshot),seek=async t=>{await page.locator('#timeline').evaluate((el,t)=>{el.value=t;el.dispatchEvent(new Event('input',{bubbles:true}))},t);await page.waitForTimeout(40);};
async function checkCounts(result){const s=await snap(),actual=await page.locator('#live-counts>span').evaluateAll(els=>els.map(el=>parseInt(el.querySelector('b').textContent))),m=E.snapshot(result,s.time);assert.deepEqual(actual,[m.waiting,m.inService,m.walkingToSeat||0,m.seatWaiting,m.dining,m.returning,m.endpointCompleted]);}
try {
 await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);const first=await snap(),result=E.simulateSchool(first.config);assert.equal(first.tab,'setup');
 await page.keyboard.press('Tab');assert.equal(await page.locator(':focus').getAttribute('class'),'skip-link');
 await page.locator('#setup-advanced').click();assert.ok(await page.locator('dialog[open]').isVisible());await page.keyboard.press('Escape');assert.equal(await page.locator(':focus').getAttribute('id'),'setup-advanced');
 await page.locator('#setup-form button[type=submit]').click();await page.waitForTimeout(600);assert.equal((await snap()).mode,'3d');
 const canvas=page.locator('#scene3d canvas'),initialPixels=await canvas.screenshot();await page.waitForTimeout(250);assert.deepEqual(initialPixels,await canvas.screenshot());
 const record=result.students.find(s=>s.indoorWalk>0);
 for(const t of [0,record.arrival,(record.start+record.end)/2,(record.seatWalkStart+record.seatStart)/2,(record.seatStart+record.mealEnd)/2,(record.mealEnd+record.returnTime)/2,result.metrics.observationEnd]) {await seek(t);await checkCounts(result)}
 checks.push('Seven stage counts match the actual engine at arrival, serving, walking, dining, return and completion boundaries');
 await page.locator('#peak').click();await page.locator('#speed').selectOption('1');const before=(await snap()).time;await page.locator('#play').click();await page.waitForTimeout(550);await page.locator('#play').click();assert.ok((await snap()).time>before);await checkCounts(result);
 await page.locator('#selection-details>summary').click();await page.locator('#student-number').fill('1610');await page.locator('#student-locate-form button').click();await page.waitForTimeout(150);
 let s=await snap();assert.equal(s.rendering.pickedStudent,1609);assert.ok(s.rendering.journeySegments>5);assert.ok((await page.locator('#inspect-text').innerText()).includes('1610'));assert.deepEqual(s.metrics,first.metrics);await checkCounts(result);
 await page.screenshot({path:'qa/product-student-route.png',fullPage:true});checks.push('Student number lookup pins the correct identity, renders the recorded meal route and preserves numerical results');
 await page.locator('#scene3d').scrollIntoViewIfNeeded();const target=(await snap()).rendering.pickTargets[0],bounds=await canvas.boundingBox();await page.mouse.click(bounds.x+target.x,bounds.y+target.y);await page.waitForTimeout(100);assert.notEqual((await snap()).rendering.pickedStudent,null);assert.ok((await page.locator('#inspect-text').innerText()).includes('模拟学生'));
 await page.locator('button.scene-station-label').first().click();assert.ok((await page.locator('#inspect-text').innerText()).includes('号通用窗口'));assert.equal((await snap()).rendering.pickedStudent,null);
 const originalView=await canvas.screenshot();await page.getByRole('button',{name:'俯视',exact:true}).click();await page.waitForTimeout(350);assert.notDeepEqual(originalView,await canvas.screenshot());
 await canvas.focus();await page.keyboard.press('ArrowRight');await page.keyboard.press('+');await page.waitForTimeout(350);assert.deepEqual((await snap()).metrics,first.metrics);await page.getByRole('button',{name:'立体',exact:true}).click();
 await page.locator('#scene-expand').click();assert.ok(await page.locator('.scene-panel').evaluate(el=>el.classList.contains('scene-expanded')));const expanded=await page.locator('.scene-panel').boundingBox();assert.ok(expanded.x<=17&&expanded.y<=17&&expanded.width>=1400);await page.keyboard.press('Escape');assert.equal(await page.locator('.scene-panel').evaluate(el=>el.classList.contains('scene-expanded')),false);
 await page.locator('#view-2d').click();assert.ok(await page.locator('#scene2d').isVisible());await page.locator('#scene2d [data-window="0"]').click();assert.ok((await page.locator('#inspect-detail').innerText()).includes('实际平均服务'));await page.locator('#view-3d').click();assert.ok(await canvas.isVisible());
 checks.push('Actual canvas picking, window records, camera presets, keyboard rotation and zoom, enlarged scene, Escape and 2D/3D controls work');
 const memory=[];
 for(let i=0;i<5;i++){await page.locator('#parameters').click();await page.getByRole('button',{name:'运行这个方案'}).click();await page.waitForTimeout(90);memory.push((await snap()).rendering);}
 assert.ok(memory.every(x=>x.textures===memory[1].textures));assert.ok(memory.slice(1).every(x=>x.geometries===memory[1].geometries));checks.push('Repeated parameter runs release and recreate GPU resources without increasing live textures or geometries');
 // Same synthetic crowd and viewport as the saved baseline, with no animation seek.
 await page.locator('#peak').click();await page.locator('#play').click();const times=await page.evaluate(()=>new Promise(resolve=>{let n=0,last=performance.now(),values=[];function tick(t){values.push(t-last);last=t;if(++n<100)requestAnimationFrame(tick);else resolve(values.slice(4).sort((a,b)=>a-b))}requestAnimationFrame(tick)}));await page.locator('#play').click();
 const rendering=(await snap()).rendering,performanceResult={medianMs:times[Math.floor(times.length*.5)],p95Ms:times[Math.floor(times.length*.95)],rendering};assert.ok(rendering.drawCalls<400);assert.ok(performanceResult.medianMs<50);
 await page.locator('[data-tab=setup]').click();await page.locator('[name=preset][value=none]').check();await page.locator('#setup-windows').fill('2');await page.locator('#setup-seats').fill('80');await page.locator('#setup-form button[type=submit]').click();await page.locator('#peak').click();const crowded=E.simulateSchool((await snap()).config);await checkCounts(crowded);assert.equal(await page.locator('button.scene-station-label').count(),2);assert.ok((await snap()).rendering.visiblePeople<=560);await page.screenshot({path:'qa/product-heavy-queues.png',fullPage:true});
 checks.push('Long queues and reduced window/seat capacity keep real counts and a bounded visible crowd');
 await page.reload();await page.waitForFunction(()=>window.DiningLabSnapshot);
 for(const width of [1440,768,390,320]) {
  await page.setViewportSize({width,height:1000});
  for(const tab of ['setup','live','compare']){await page.locator(`[data-tab=${tab}]`).first().click();await page.waitForTimeout(250);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,tab+' '+width);await page.screenshot({path:`qa/product-${tab}-${width}.png`,fullPage:true});}
 }
 assert.deepEqual(errors,[]);assert.deepEqual(external,[]);const receipt={passed:true,build:first.build.id,checks,performance:performanceResult,resourceRuns:memory.map(x=>({geometries:x.geometries,textures:x.textures})),widths:[1440,768,390,320],errors,external};fs.writeFileSync('qa/product-ui-audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
