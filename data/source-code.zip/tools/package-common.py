"""Deliver 2.3 separately, retaining all previously issued artifacts."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib,json

ROOT=Path(__file__).resolve().parents[1]
sha=lambda data:hashlib.sha256(data).hexdigest()
OUT=ROOT/'release/packages'
DOCS=ROOT/'documents/common-windows'
BUILD=json.loads((ROOT/'dist/build-info.js').read_text('utf-8').split('Object.freeze(',1)[1].rsplit(');',1)[0])
README='''食刻2.3 通用窗口版

打开方式
先完整解压，再双击“启动软件.cmd”，或进入DiningLab目录双击DiningLab.exe。
必须保留_internal文件夹；无需安装Python。Windows 10/11 64位需要Microsoft Edge WebView2 Runtime。

本版修改
全部窗口均可服务所有学生，取消餐品与年级窗口限制。
依据前方队伍、平均打餐时间、已服务时长与本人打餐时间，选择预计最早完成取餐的窗口。
窗口布置在两侧，座位位于中间，前后均可进出。
三维场景拖动旋转、滚轮缩放，点击圆形播放按钮观看；点击“俯视”查看布局。
总人数过多时仍会排队，速度不同时队伍也不必一样长。

文档
PDF文档中为新版8页研究报告和3页使用指南，Word原稿可编辑。
默认360人、6窗、120座位和时长均为合成教学参数。
大体布局来自项目交流，尺寸与前后门使用比例是示意，不是校内实测。
新版固定实验为1430次仿真调用，原2.2版餐品分区结论不作为本版结果。
'''

def write_zip(path,files):
    if path.exists():raise FileExistsError(f'Leave previous delivery untouched: {path}')
    manifest={name:{'bytes':len(raw),'sha256':sha(raw)} for name,raw in sorted(files.items())}
    with ZipFile(path,'x',compression=ZIP_DEFLATED,compresslevel=6) as z:
        for name,raw in sorted(files.items()):z.writestr(name,raw)
        z.writestr('文件校验清单.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode('utf-8'))
    with ZipFile(path) as z:
        assert z.testzip() is None
        for name,meta in manifest.items():assert sha(z.read(name))==meta['sha256']
    return {'file':path.name,'bytes':path.stat().st_size,'sha256':sha(path.read_bytes()),'entries':len(manifest)+1}

software=ROOT/'release/desktop-common/DiningLab'
files={'DiningLab/'+p.relative_to(software).as_posix():p.read_bytes() for p in software.rglob('*') if p.is_file()}
for p in DOCS.iterdir():
    if p.suffix in ('.pdf','.docx'):files[('PDF文档/' if p.suffix=='.pdf' else 'Word原稿/')+p.name]=p.read_bytes()
files['先读我.txt']=README.encode('utf-8-sig')
files['启动软件.cmd']=b'@echo off\r\nstart "" "%~dp0DiningLab\\DiningLab.exe"\r\n'
desktop=write_zip(OUT/'食刻2.3_通用窗口双侧布局_软件与PDF.zip',files)

# Retain the existing source release's explicit public-evidence allowlist.
old=OUT/'食刻2.2_源码与研究材料.zip'
old_index=json.loads((OUT/'package-index.json').read_text('utf-8'))
assert sha(old.read_bytes())==old_index['packages'][1]['sha256']
source={}
with ZipFile(old) as z:
    for name in z.namelist():
        if name.endswith('/'):continue
        relative=name.split('/',1)[1] if name.startswith('食刻2.2/') else name
        if 'manifest' in relative.lower():continue
        current=ROOT/relative
        if relative.startswith('documents/') and Path(relative).name in [p.name for p in DOCS.iterdir()]:current=DOCS/Path(relative).name
        source['食刻2.3/'+relative]=current.read_bytes() if current.is_file() else z.read(name)
for folder in ['dist','desktop','tools','tests','learning','licenses','research/frozen-v2.2']:
    for p in (ROOT/folder).rglob('*'):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix not in ('.pyc',):source['食刻2.3/'+p.relative_to(ROOT).as_posix()]=p.read_bytes()
for relative in ['package.json','package-lock.json','research/common-window-protocol.json','data/common-study-results.json','data/common-frozen-selection.json','qa/common-ui.json','qa/common-native-test.json','qa/common-document-render.json','qa/common-study-audit.json','qa/common-historical-study-replay.json','figures/10-common-hall.png']:
    source['食刻2.3/'+relative]=(ROOT/relative).read_bytes()
for p in DOCS.iterdir():
    if p.suffix in ('.pdf','.docx'):source['食刻2.3/documents/'+p.name]=p.read_bytes()
source['食刻2.3/README.md']=('''# 食刻2.3 通用窗口版

完整解压后打开dist/index.html，可离线使用。全部窗口通用，按预计取餐完成最早分配。
Windows成品和PDF见独立使用包。

使用Node.js运行核心检查：`node --test tests/*.test.cjs`。
新版研究复算：`node tools/audit-common-study.cjs --replay`。
新版研究再生成：`node tools/run-common-study.cjs`，将重写本版data/common文件，请先备份。
新版文章生成：使用带python-docx的Python执行`python tools/make-common-documents.py`。
文档来自用户保留的公文模板，PDF用Microsoft Word只读导出并逐页检查。

data/common-study-results.json为2.3研究。其他旧研究数据与qa/innovation、decision记录为历史2.2及更早版本，不能作为2.3效果证明。
research/frozen-v2.2保留旧研究逐字节绑定的算法；tools/study-source.cjs仍要求哈希精确一致。
研究与开发有AI辅助，校内真实数据和学生贡献须据实记录。依赖许可保留在licenses。
''').encode('utf-8')
research=write_zip(OUT/'食刻2.3_通用窗口双侧布局_源码与研究.zip',source)
index={'version':'2.3.0','build':BUILD['id'],'packages':[desktop,research]}
(OUT/'package-index-common.json').write_text(json.dumps(index,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(index,ensure_ascii=True,indent=2))
