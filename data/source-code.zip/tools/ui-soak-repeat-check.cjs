// Reproduce the second-expander-toggle failure using the same routine as the soak.
const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
const {runIdenticalScenarios}=require('./soak-scenario-flow.cjs');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 const page=await browser.newPage();page.setDefaultTimeout(1800);
 const errors=[],checks=[];page.on('pageerror',e=>errors.push(String(e)));
 try {
  await page.goto('http://127.0.0.1:8769/');await page.waitForFunction(()=>window.DiningLabSnapshot);
  const build=await page.evaluate(()=>window.DiningLabSnapshot.build);
  await page.locator('#guided-compare').click();await page.locator('#repeats').selectOption('10');
  for(let iteration=1;iteration<=3;iteration++) {
   await page.locator('#compare-run').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy);
   await runIdenticalScenarios(page);
   assert.equal(await page.locator('#scenario-section').getAttribute('open')!==null,true);
   checks.push(`Comparison/scenarios iteration ${iteration}: nine zero-difference pairs; expander remains usable`);
  }
  await page.locator('#scenario-section>summary').click();
  await runIdenticalScenarios(page);
  checks.push('The same routine also reopens an explicitly collapsed section');
  assert.deepEqual(errors,[]);
  fs.writeFileSync('qa/ui-soak-repeat-check.json',JSON.stringify({at:new Date().toISOString(),build,checks,errors},null,2));
  console.log(JSON.stringify({checks:checks.length,errors}));
 } finally {await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
