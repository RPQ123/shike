// Render native XML through diagrams.net's official viewer engine, locally.
// No diagram content is sent to an external server.
const fs=require('node:fs'),path=require('node:path');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'..');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 const page=await browser.newPage({viewport:{width:2200,height:1400},deviceScaleFactor:2});
 const checks=[];
 try {
  for(const stem of ['11-hall-plan','12-meal-flow','13-window-choice']){
   await page.setContent('<!doctype html><html><head><meta charset="utf-8"></head><body style="margin:0;background:white"><div id="graph" style="width:1100px;height:700px"></div></body></html>');
   await page.addScriptTag({path:path.join(root,'qa/drawio-runtime/viewer-static.min.js')});
   const xml=fs.readFileSync(path.join(root,'figures/student',stem+'.drawio'),'utf8');
   const rendered=await page.evaluate(xml=>{
    const doc=mxUtils.parseXml(xml);
    const graph=new Graph(document.getElementById('graph'));
    graph.setEnabled(false);
    new mxCodec(doc).decode(doc.getElementsByTagName('mxGraphModel')[0],graph.getModel());
    graph.refresh();
    const svg=graph.getSvg('#ffffff',1,20);
    svg.setAttribute('content',xml);
    const paths=[...svg.querySelectorAll('path')].map(e=>e.getAttribute('d'));
    const labels=[...svg.querySelectorAll('foreignObject')].map(e=>({text:e.textContent,rect:{x:e.getAttribute('x'),y:e.getAttribute('y'),width:e.getAttribute('width'),height:e.getAttribute('height')}}));
    return {svg:new XMLSerializer().serializeToString(svg),paths,labels};
   },xml);
   fs.writeFileSync(path.join(root,'figures/student',stem+'.svg'),rendered.svg);
   await page.setContent('<!doctype html><html><body style="margin:0;background:white">'+rendered.svg+'</body></html>');
   await page.locator('svg').screenshot({path:path.join(root,'figures/student',stem+'.png')});
   const size=await page.locator('svg').boundingBox();
   await page.pdf({path:path.join(root,'figures/student',stem+'.pdf'),width:size.width+'px',height:size.height+'px',printBackground:true,margin:{top:0,bottom:0,left:0,right:0}});
   if(rendered.labels.length<5)throw Error('Missing labels in '+stem);
   checks.push({file:stem,paths:rendered.paths,labels:rendered.labels,renderer:'Official diagrams.net viewer-static, local Chromium'});
  }
 } finally {await browser.close();}
 fs.writeFileSync(path.join(root,'qa/drawio-render-geometry.json'),JSON.stringify(checks,null,2));
 console.log(JSON.stringify(checks.map(r=>({file:r.file,labels:r.labels.length,paths:r.paths.length}))));
})().catch(e=>{console.error(e);process.exitCode=1;});
