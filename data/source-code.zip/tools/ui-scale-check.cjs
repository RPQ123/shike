// Maximum supported synthetic population: inspect readability and measured responsiveness.
const { chromium } = require('playwright');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const R = require('../dist/research.js');
const E = require('../dist/school-engine.js');

(async () => {
  const browser = await chromium.launch({headless:true,channel:'chrome'});
  const page = await browser.newPage({viewport:{width:1440,height:1000}});
  const errors=[], records=[];
  page.on('pageerror',error=>errors.push(String(error)));
  try {
    await page.goto('http://127.0.0.1:8769/');
    await page.waitForFunction(()=>window.DiningLabSnapshot);
    const config=R.example();
    config.students=5000;
    config.grades.forEach((g,i)=>{g.students=i===2?1666:1667;g.classes=50;g.latestReleaseTime=null});
    config.windows=16;config.windowMeans=Array(16).fill(20);
    config.windowZones=Array.from({length:16},(_,i)=>i<8?0:1);
    config.windowOwners=Array.from({length:16},(_,i)=>Math.min(2,Math.floor(i*3/16)));
    const start=performance.now();
    await page.locator('#file-input').setInputFiles({name:'scale.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(R.session(config)))});
    await page.waitForFunction(()=>window.DiningLabSnapshot.config.students===5000);
    const importMs=performance.now()-start;
    assert.equal(await page.locator('button.scene-station-label').count(),16);
    const snapshot=await page.evaluate(()=>window.DiningLabSnapshot);
    const reference=E.simulateSchool(config);
    assert.ok(Math.abs(snapshot.metrics.meanTotal-R.metrics(reference).meanTotal)<1e-8);
    for(const details of [false,true]) {
    if(details) await page.locator('#scene-labels').click();
    for(const [width,height] of [[1440,1000],[1366,768],[1024,1000],[1000,680],[840,640],[768,1000],[360,1000]]){
      await page.setViewportSize({width,height});
      await page.waitForTimeout(200);
      const geometry=await page.evaluate(()=>({
        width:innerWidth,scroll:document.documentElement.scrollWidth,
        host:document.querySelector('#scene3d').getBoundingClientRect().toJSON(),
        badges:[...document.querySelectorAll('.scene-zone-banner > span')].map(e=>e.getBoundingClientRect().toJSON()),
        grades:[...document.querySelectorAll('.scene-grade-banner > span')].map(e=>e.getBoundingClientRect().toJSON()),
        labels:[...document.querySelectorAll('button.scene-station-label')].map(e=>({id:e.getAttribute('aria-label'),rect:e.getBoundingClientRect().toJSON()}))
      }));
      const collisions=[];
      for(let i=0;i<geometry.labels.length;i++)for(let j=i+1;j<geometry.labels.length;j++){
        const a=geometry.labels[i].rect,b=geometry.labels[j].rect;
        if(Math.min(a.right,b.right)-Math.max(a.left,b.left)>1 && Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top)>1)
          collisions.push([i+1,j+1]);
      }
      const bannerCollisions=geometry.labels.filter(({rect:r})=>geometry.badges.some(b=>Math.min(r.right,b.right)-Math.max(r.left,b.left)>1 && Math.min(r.bottom,b.bottom)-Math.max(r.top,b.top)>1)).map(x=>x.id);
      const gradeCollisions=geometry.labels.filter(({rect:r})=>geometry.grades.some(b=>Math.min(r.right,b.right)-Math.max(r.left,b.left)>1 && Math.min(r.bottom,b.bottom)-Math.max(r.top,b.top)>1)).map(x=>x.id);
      records.push({width,height,details,overflow:geometry.scroll-width,collisions,bannerCollisions,gradeCollisions,labelsOutside:geometry.labels.filter(({rect:r})=>r.left<geometry.host.left-1||r.right>geometry.host.right+1||r.top<geometry.host.top-1||r.bottom>geometry.host.bottom+1).map(x=>x.id)});
      await page.screenshot({path:`qa/ui-scale-${details?"zones-":""}${width}.png`,fullPage:true});
    }
    }
    await page.setViewportSize({width:1440,height:1000});
    await page.locator('#play').click();
    await page.waitForTimeout(1500);
    const pauseStart=performance.now();
    await page.locator('#play').click();
    const pauseClickMs=performance.now()-pauseStart;
    await page.locator('#view-2d').click();
    assert.equal(await page.locator('#scene2d [data-window]').count(),16);
    const last=page.locator('#scene2d [data-window="15"]');
    await last.click();
    assert.match(await page.locator('#inspect-text').innerText(),/16 号窗口/);
    assert.deepEqual(errors,[]);
    const audit={at:new Date().toISOString(),build:snapshot.build,syntheticPeople:5000,windows:16,importMs,pauseClickMs,records,errors,note:'One local Chrome measurement under concurrent test load; not a cross-device performance guarantee.'};
    fs.writeFileSync('qa/ui-scale-check.json',JSON.stringify(audit,null,2));
    console.log(JSON.stringify({importMs,pauseClickMs,records,errors}));
    assert.ok(records.every(r=>r.overflow<=1 && r.collisions.length===0 && r.bannerCollisions.length===0 && r.gradeCollisions.length===0 && r.labelsOutside.length===0),'Window labels must remain legible and inside the scene');
  }finally{await browser.close()}
})().catch(error=>{console.error(error);process.exitCode=1});
