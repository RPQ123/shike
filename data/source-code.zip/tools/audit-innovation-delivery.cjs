// Current iteration only: five real hours plus coherent research and extracted artifacts.
const fs = require('node:fs'),
  crypto = require('node:crypto'),
  assert = require('node:assert/strict');
const T = require('./innovation-time.cjs');
const load = (p) => JSON.parse(fs.readFileSync(p, 'utf8')),
  sha = (p) => crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
function main() {
  const final = process.argv.includes('--final'),
    packages = process.argv.includes('--packages');
  const contract = load('tasks/innovation-run-contract.json'),
    taskTime = final ? T.requireComplete(contract) : T.measure(contract),
    checks = [];
  const build = JSON.parse(
    fs.readFileSync('dist/build-info.js', 'utf8').match(/Object\.freeze\((.*)\);/s)[1]
  );
  for (const [p, h] of Object.entries(build.files)) {
    assert.equal(sha('dist/' + p), h, p);
    assert.equal(sha('release/desktop/DiningLab/_internal/dist/' + p), h, 'desktop/' + p);
  }
  assert.equal(sha('dist/build-info.js'), sha('release/desktop/DiningLab/_internal/dist/build-info.js'));
  const desktop = load('qa/innovation-desktop-build.json');
  assert.equal(desktop.build, build.id);
  assert.equal(desktop.exeSha256, sha('release/desktop/DiningLab/DiningLab.exe'));
  for (const [p, h] of Object.entries(desktop.sourceHashes)) assert.equal(sha(p), h, p);
  checks.push('All stamped offline files, compiled desktop resources and executable/source hashes match');
  const numerical = require('./audit-innovation-study.cjs').audit(false),
    replay = load('qa/innovation-study-audit.json');
  assert.equal(numerical.uniqueExecutions, 14370);
  assert.equal(replay.replayed, 14370);
  assert.equal(replay.passed, true);
  assert.deepEqual(replay.sourceHashes, numerical.sourceHashes);
  for (const file of ['data/study-results.json', 'data/decision-study-results.json'])
    for (const [p, h] of Object.entries(load(file).sourceHashes))
      assert.equal(sha(p), h, 'Retained study ' + p);
  checks.push(
    'New frozen choices, fourteen conditions, all causal histories and the unique ledger reproduce; retained studies keep their original source hashes'
  );
  const reproduction = load('qa/innovation-source-reproduction.json');
  assert.equal(reproduction.passed, true);
  assert.deepEqual(reproduction.sourceHashes, numerical.sourceHashes);
  assert.equal(reproduction.uniqueExecutions, 14370);
  assert.equal(reproduction.ledgerSha256, sha('data/innovation-execution-ledger.json'));
  const regeneratedStudy = load('data/innovation-study-results.json');
  delete regeneratedStudy.startedAt;
  delete regeneratedStudy.completedAt;
  delete regeneratedStudy.verificationStartedAt;
  delete regeneratedStudy.frozen.frozenAt;
  assert.equal(
    crypto.createHash('sha256').update(JSON.stringify(regeneratedStudy)).digest('hex'),
    reproduction.normalizedStudySha256
  );
  const materialReproduction = load('qa/innovation-materials-reproduction.json');
  assert.equal(materialReproduction.passed, true);
  for (const [p, h] of Object.entries(materialReproduction.sourceHashes)) assert.equal(sha(p), h, p);
  for (const fig of materialReproduction.figures) assert.equal(sha(fig.file), fig.sha256, fig.file);
  for (const doc of materialReproduction.documents) assert.equal(sha(doc.file), doc.originalSha256, doc.file);
  assert.equal(sha('figures/innovation-source-data.csv'), materialReproduction.sourceCsvSha256);
  checks.push(
    'Fresh-directory full study generation reproduces every numerical record and byte-identical physical ledger; independent figure and Word generation retains content'
  );
  const docs = load('qa/document-audit.json');
  assert.equal(docs.templateUnchanged, true);
  assert.ok(docs.combinedBytes < 6 * 1024 * 1024);
  for (const doc of docs.documents) assert.equal(sha('documents/' + doc.file), doc.sha256);
  const figures = load('qa/innovation-figure-audit.json');
  for (const fig of figures.figures) {
    assert.equal(sha('data/innovation-study-results.json'), fig.sourceSha256);
    for (const f of fig.files) assert.equal(sha(f.file), f.sha256);
  }
  for (const item of [figures.generator, figures.sourceData]) assert.equal(sha(item.file), item.sha256);
  assert.equal(docs.visualInspection.iteration, 'innovation-planner');
  checks.push(
    'Page-reviewed Word documents, four data figures, generator and source CSV match their exact reviewed bytes'
  );
  const demo = load('qa/innovation-3d-demo.json');
  assert.equal(demo.passed, true);
  assert.equal(demo.build.id, build.id);
  assert.deepEqual(demo.errors, []);
  for (const media of demo.media) assert.equal(sha(media.file), media.sha256, media.file);
  assert.ok(demo.mp4.durationSeconds >= 15 && demo.gifPreview.differentDecodedFrames >= 20);
  checks.push(
    'The real 3D recording and animated preview match the current build and their inspected media bytes'
  );
  const qaFiles = [
    'ui-check.json',
    'ui-data-check.json',
    'ui-keyboard-check.json',
    'ui-scale-check.json',
    'ui-decision-check.json',
    'ui-refresh-check.json',
    'ui-planner-check.json',
    'ui-planner-boundaries.json',
    'ui-innovation-layout.json',
    'ui-3d-animation-check.json',
    'desktop-click-check.json',
    'desktop-download-check.json'
  ];
  for (const file of qaFiles) {
    const q = load('qa/' + file);
    assert.equal(q.build.id, build.id, file);
    assert.deepEqual(q.errors || q.logs || [], [], file);
    assert.ok(Date.parse(q.at || q.time) >= Date.parse(build.createdAt), file + ' timestamp');
  }
  const exe = load('qa/desktop-exe-test.json');
  assert.equal(exe.ok, true);
  assert.equal(exe.capability.mode, '3d');
  assert.ok(exe.capability.webgl && !exe.capability.webgl.lost);
  assert.equal(exe.build.id, build.id);
  assert.equal(exe.plannerCandidates, 126);
  assert.equal(exe.periodPolicies, 3);
  assert.equal(exe.periodReplicates, 30);
  const native = load('qa/desktop-download-check.json');
  assert.equal(native.ok, true);
  assert.equal(native.downloads.length, 4);
  assert.equal(native.plannerCandidates, 126);
  assert.equal(native.timetableRows, 9);
  const animation = load('qa/ui-3d-animation-check.json');
  assert.equal(animation.passed, true);
  assert.equal(animation.webgl.lost, false);
  assert.ok(animation.motion.elapsedModelMinutes > 0);
  assert.notEqual(animation.motion.firstFrameSha256, animation.motion.secondFrameSha256);
  const core = fs.readFileSync('qa/innovation-core-tests.log', 'utf8'),
    count = Number(core.match(/tests (\d+)/)?.[1]);
  assert.ok(count >= 240);
  assert.match(core, /fail 0\b/);
  assert.match(core, new RegExp('pass ' + count + '\\b'));
  assert.match(fs.readFileSync('qa/innovation-learning-tests.log', 'utf8'), /Ran 5 tests[\s\S]*OK/);
  checks.push(
    'Current-build browser, keyboard, offline, 5000-person cancellation, native WebView2, four native downloads and all core/teaching checks passed'
  );
  const logfile = 'qa/soak-innovation-final.jsonl',
    events = fs.readFileSync(logfile, 'utf8').trim().split('\n').map(JSON.parse);
  const starts = events.filter((e) => e.event === 'start');
  assert.equal(starts.length, 1, 'Observations cannot be concatenated');
  const start = starts[0],
    cycles = events.filter((e) => e.event === 'cycle'),
    terminal = events.find((e) => e.event === 'complete');
  assert.equal(start.initial.build.id, build.id);
  assert.ok(Date.parse(start.at) >= Date.parse(build.createdAt));
  assert.ok(
    !events.some((e) => ['failure', 'stopped', 'pageerror', 'revision-stop'].includes(e.event)),
    'A final observation contains a failure or interruption'
  );
  assert.ok(cycles.every((e) => e.build === build.id && e.errors === 0));
  const heaps = cycles.flatMap((e) =>
    e.memory.filter((m) => m.name === 'JSHeapUsedSize').map((m) => m.value / 1048576)
  );
  const segment = {
    file: logfile,
    start: start.at,
    until: start.until,
    build: build.id,
    cycles: cycles.length,
    plannerCycles: cycles.filter((e) => e.planner).length,
    crossMealCycles: cycles.filter((e) => e.crossMeal).length,
    completionRecorded: !!terminal,
    failures: [],
    runtimeErrors: [],
    heapMiBRange: heaps.length ? [Math.min(...heaps), Math.max(...heaps)] : null
  };
  if (final) {
    assert.ok(terminal, 'Final observation has not ended');
    assert.ok(Date.parse(terminal.at) >= Date.parse(contract.earliestCompletion));
    assert.ok(Date.parse(terminal.at) >= Date.parse(start.until));
    assert.ok(terminal.elapsedSeconds >= 1800 && cycles.length >= 15);
    assert.equal(terminal.cycles, cycles.length);
    assert.equal(terminal.failures, 0);
    assert.deepEqual(terminal.errors, []);
    assert.ok(segment.plannerCycles >= 5 && segment.crossMealCycles >= 2);
    segment.observedMinutes = terminal.elapsedSeconds / 60;
    segment.terminal = terminal;
    fs.writeFileSync(
      'qa/innovation-reliability-summary.json',
      JSON.stringify(
        {
          build: build.id,
          taskTime,
          segments: [segment],
          scope:
            'This new five-hour task and one completed final-build interaction observation; no duration from earlier tasks or interrupted observations is added.'
        },
        null,
        2
      )
    );
    checks.push(
      'The new task exceeded five real hours; the uninterrupted final build crossed its deadline with actual repeated planner and cross-meal operations'
    );
  }
  if (packages) {
    const index = load('release/packages/package-index.json');
    assert.equal(index.build, build.id);
    assert.equal(index.iteration, 'innovation-planner');
    if (final) assert.equal(index.stage, 'final');
    for (const p of index.packages) assert.equal(sha('release/packages/' + p.file), p.sha256);
    const smoke = load('qa/package-smoke.json');
    assert.equal(smoke.build, build.id);
    assert.equal(smoke.sourceCoreTests, count);
    assert.equal(smoke.desktopUnpackedStartup, true);
    assert.equal(smoke.desktopExecutableSha256, desktop.exeSha256);
    assert.equal(smoke.desktopWebGLVerified, true);
    assert.equal(smoke.plannerCandidateCount, 126);
    assert.equal(smoke.periodPolicies, 3);
    assert.equal(smoke.plannerExportVerified, true);
    assert.equal(smoke.threeDAnimationVerified, true);
    assert.equal(smoke.periodExportVerified, true);
    assert.equal(smoke.extractedArchives.length, 3);
    for (const item of smoke.extractedArchives) {
      const p = index.packages.find((p) => p.file === item.file);
      assert.equal(item.sha256, p.sha256);
      assert.equal(item.manifestSha256, p.manifestSha256);
      assert.equal(item.verifiedFiles, p.entries);
    }
    checks.push(
      'Freshly extracted current ZIPs match manifests, actual EXE startup, offline planner/period exports and source checks'
    );
  }
  const result = {
    at: new Date().toISOString(),
    build: build.id,
    iteration: 'innovation-planner',
    status: final ? (packages ? 'final' : 'terminal-ready') : 'candidate',
    taskTime,
    coreTests: count,
    uniqueStudyExecutions: numerical.uniqueExecutions,
    documentBytes: docs.combinedBytes,
    checks,
    segments: [segment]
  };
  fs.writeFileSync('qa/innovation-delivery-audit.json', JSON.stringify(result, null, 2));
  console.log(
    JSON.stringify({
      build: build.id,
      status: result.status,
      checks: checks.length,
      elapsedMinutes: taskTime.elapsedSeconds / 60,
      cycles: cycles.length
    })
  );
}
try {
  main();
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
