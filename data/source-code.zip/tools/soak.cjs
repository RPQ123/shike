// Long-duration browser reliability check, isolated from the user's browser.
// Exercises replay, camera changes, two display modes, and model consistency.
// Each cycle records evidence; this is not a timer presented as development work.
const { chromium } = require('playwright');
const fs = require('node:fs');
const E = require('../dist/school-engine.js');
const R = require('../dist/research.js');
const {runIdenticalScenarios}=require('./soak-scenario-flow.cjs');
const started = Date.now();
const until = Date.parse(process.argv[2] || '');
if (!Number.isFinite(until) || until <= started) {
  console.error('Usage: node tools/soak.cjs <future ISO deadline> [logfile] [--interface]');
  console.error('An explicit future deadline is required; a zero-cycle run is not a reliability check.');
  process.exit(2);
}
const logfile = process.argv[3] || 'qa/soak-events.jsonl';
const interfaceChecks = process.argv.includes('--interface');
const decisionChecks = process.argv.includes('--decision');
const log = obj => fs.appendFileSync(logfile, JSON.stringify({ at: new Date().toISOString(), ...obj }) + '\n');
(async () => {
  const browser = await chromium.launch({ headless: true, channel: 'chrome' });
  const page = await browser.newPage({ viewport: { width: 1280, height: 900 } });
  const errors = []; page.on('pageerror', error => { errors.push(String(error)); log({ event: 'pageerror', error: String(error) }); });
  const cdp = await page.context().newCDPSession(page);
  await cdp.send('Performance.enable');
  await page.goto('http://127.0.0.1:8769/');
  await page.waitForFunction(() => window.DiningLabSnapshot);
  const initial=await page.evaluate(() => ({version:window.DiningLabSnapshot.version,build:window.DiningLabSnapshot.build,userAgent:navigator.userAgent}));
  log({ event: 'start', until: new Date(until).toISOString(), initial });
  let cycle = 0, failures = 0;
  while (Date.now() < until) {
    const cycleStart = Date.now(); cycle++;
    try {
      if (interfaceChecks) {
        if (cycle % 20 === 0) {
          await page.reload();
          await page.waitForFunction(() => window.DiningLabSnapshot);
          const build = await page.evaluate(() => window.DiningLabSnapshot.build.id);
          if (build !== initial.build.id) throw new Error('Build changed during frozen-build observation');
        }
        const sizes = [[1440,1000],[1366,768],[1024,900],[360,800]];
        const [width,height] = sizes[cycle % sizes.length];
        await page.setViewportSize({width,height});
      }
      await page.getByRole('button', { name: '恢复示例', exact: true }).click();
      await page.getByRole('button', { name: cycle % 4 ? '3D' : '2D', exact: true }).click();
      if (cycle % 4) await page.getByRole('button', { name: cycle % 2 ? '俯视' : '立体', exact: true }).click();
      await page.locator('#speed').selectOption('3');
      await page.getByRole('button', { name: '播放回放', exact: true }).click();
      await page.waitForTimeout(12000);
      const state = await page.evaluate(() => window.DiningLabSnapshot);
      const expected = R.metrics(E.simulateSchool(state.config));
      for (const key of Object.keys(expected)) {
        if (typeof expected[key] === 'number') {
          if (!Number.isFinite(expected[key]) || !Number.isFinite(state.metrics[key]) || Math.abs(expected[key] - state.metrics[key]) > 1e-8) throw new Error('metric drift: ' + key);
        } else if (expected[key] !== state.metrics[key]) throw new Error('metric drift: ' + key);
      }
      // Pause through UI before collecting a same-frame sample on the next check.
      const pause = page.getByRole('button', { name: '暂停回放', exact: true });
      if (await pause.count()) await pause.click();
      const paused = await page.evaluate(() => window.DiningLabSnapshot);
      const pausedPhase = E.snapshot(E.simulateSchool(paused.config), paused.time);
      const pausedValues = (await page.locator('#live-counts').innerText()).match(/\d+/g).map(Number);
      const pausedExpected = [pausedPhase.waiting, pausedPhase.inService, pausedPhase.seatWaiting, pausedPhase.dining, pausedPhase.returning, pausedPhase.endpointCompleted];
      if (JSON.stringify(pausedValues) !== JSON.stringify(pausedExpected)) throw new Error('replay phase mismatch');
      if (interfaceChecks) {
        await page.locator('#parameters').click();
        if (await page.locator('#parameter-form input:visible').count() !== 15) throw new Error('Common parameter fields changed');
        await page.keyboard.press('Escape');
        await page.locator('.file-menu').first().locator('summary').click();
        await page.keyboard.press('Escape');
        if (await page.locator('.file-menu[open]').count()) throw new Error('File menu did not close');
        if (cycle % 10 === 0 || (decisionChecks && cycle % 5 === 0)) {
          await page.locator('[data-tab="compare"]').click();
          await page.locator('#set-baseline').click();
          await page.locator('#repeats').selectOption('10');
          await page.locator('#compare-run').click();
          await page.waitForFunction(() => !window.DiningLabSnapshot.busy);
          const differences=await page.evaluate(()=>window.DiningLabSnapshot.comparison.differences);
          if (!Object.values(differences).every(d=>d.mean===0&&d.low===0&&d.high===0)) throw new Error('Identical A/B comparison drift');
          if (decisionChecks) {
            await runIdenticalScenarios(page);
          }
          await page.locator('[data-tab="live"]').click();
        }
      }
      const memory = (await cdp.send('Performance.getMetrics')).metrics.filter(m => ['JSHeapUsedSize','JSHeapTotalSize','Nodes','Documents','JSEventListeners'].includes(m.name));
      log({ event: 'cycle', cycle, elapsedSeconds: (Date.now()-started)/1000, mode: paused.mode, time: paused.time, counts: pausedValues, interfaceChecks, decisionChecks, memory, errors: errors.length });
      if (cycle % 15 === 0) await page.screenshot({ path: `qa/soak-${cycle}.png` });
    } catch (error) {
      failures++; log({ event: 'failure', cycle, error: String(error) });
      await page.screenshot({ path: `qa/soak-failure-${cycle}.png` }).catch(() => {});
      if (failures >= 3) throw error;
      await page.reload(); await page.waitForFunction(() => window.DiningLabSnapshot);
    }
    // Hold the same live page between repeated UI cycles to expose retained memory.
    const pauseMs = Math.min(120000 - (Date.now()-cycleStart), until-Date.now());
    if (pauseMs > 0) await new Promise(resolve => setTimeout(resolve, pauseMs));
  }
  log({ event: 'complete', cycles: cycle, failures, errors, elapsedSeconds: (Date.now()-started)/1000 });
  await browser.close();
  console.log(JSON.stringify({ cycles: cycle, failures, errors, elapsedSeconds: (Date.now()-started)/1000 }));
})().catch(error => { log({ event: 'stopped', error: String(error) }); console.error(error); process.exit(1); });

