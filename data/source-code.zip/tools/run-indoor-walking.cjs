// Paired numerical checks of the new stage; no field observations are created.
const fs=require('node:fs'),crypto=require('node:crypto');
const E=require('../dist/school-engine'),R=require('../dist/research'),B=require('../dist/binhe-cohort');
const startedAt=new Date().toISOString(),base=B.create(),rounds=[];
const cases=[['legacy',0,480],['walking',1.1,480],['slow',.8,480],['fast',1.6,480],['fewer-seats',1.1,320]];
for(let seed=81001;seed<=81030;seed++)for(const [id,speed,seats] of cases){
 const r=E.simulateSchool({...base,seed,seats,indoorWalkSpeed:speed});
 rounds.push({id,seed,speed,seats,...R.metrics(r),indoorWalk:r.metrics.meanIndoorWalk,peakWalking:Math.max(...r.diningTimeline.map(t=>t.walkingToSeat))});
}
const summary=cases.map(([id])=>({id,...R.summarize(rounds.filter(r=>r.id===id).map(({id,...r})=>r))}));
const sourceHashes={};
for(const file of ['dist/engine.js','dist/school-engine.js','dist/hall-walk.js','dist/research.js','dist/common-windows.js','dist/binhe-cohort.js','tools/run-indoor-walking.cjs'])sourceHashes[file]=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
const result={schema:'dining-indoor-walking/1',evidence:'synthetic',startedAt,completedAt:new Date().toISOString(),executions:rounds.length,description:'五组设置使用相同的30个随机种子；室内速度及通道尺寸为实验设置。步行含入座动作1秒。旧800次研究独立保留。',base,sourceHashes,summary,rounds};
fs.writeFileSync('data/indoor-walking-results.json',JSON.stringify(result,null,2));
fs.writeFileSync('data/indoor-walking-rounds.csv',R.csv(rounds));
fs.writeFileSync('data/indoor-walking-summary.csv',R.csv(summary));
fs.writeFileSync('data/indoor-walking-session.json',JSON.stringify(R.session(base),null,2));
console.log(JSON.stringify({executions:result.executions,summary:summary.map(s=>({id:s.id,walkSeconds:s.indoorWalk*60,meanTotal:s.meanTotal,seatWait:s.seatWait}))}));
