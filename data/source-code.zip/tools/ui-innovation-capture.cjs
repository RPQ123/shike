const {chromium}=require('playwright'),fs=require('node:fs'),assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),records=[],errors=[];
 page.on('pageerror',e=>errors.push(String(e)));
 try{
  await page.goto('http://127.0.0.1:8769/');await page.waitForFunction(()=>window.DiningLabSnapshot);
  async function capture(name,width){
   await page.setViewportSize({width,height:1000});await page.evaluate(()=>window.scrollTo(0,0));
   await page.screenshot({path:`qa/innovation-${name}-${width}.png`,fullPage:true,animations:'disabled'});
   const geometry=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,smallText:[...document.querySelectorAll('main p,main button,main summary,main th,main td,main small,main label')].filter(el=>el.getBoundingClientRect().height&&getComputedStyle(el).visibility!=='hidden'&&parseFloat(getComputedStyle(el).fontSize)<12).map(el=>({tag:el.tagName,text:el.textContent.slice(0,70),size:getComputedStyle(el).fontSize}))}));
   assert.ok(geometry.scroll<=geometry.width+1,`${name}/${width} overflow`);assert.deepEqual(geometry.smallText,[],`${name}/${width} small text`);
   records.push({name,width,...geometry});
  }
  for(const tab of ['live','compare','search','evidence','learn']){
   await page.locator(`[data-tab="${tab}"]`).click();
   for(const width of [320,768,1024,1440])await capture(tab,width);
  }
  await page.locator('[data-tab="search"]').click();await page.locator('#planner-run').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy,null,{timeout:120000});
  for(const width of [320,768,1024,1440])await capture('planner-result',width);
  await page.locator('#planner-period-section>summary').click();await page.locator('#planner-period-run').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy,null,{timeout:120000});
  for(const width of [320,768,1024,1440])await capture('period-result',width);
  await page.emulateMedia({reducedMotion:'reduce'});
  const motion=await page.locator('.planner-choice').first().evaluate(el=>({animation:getComputedStyle(el).animationDuration,transition:getComputedStyle(el).transitionDuration}));
  assert.ok(motion.animation.split(',').every(x=>parseFloat(x)<.001));
  assert.deepEqual(errors,[]);
  const result={passed:true,at:new Date().toISOString(),build:await page.evaluate(()=>window.DiningLabSnapshot.build),records,motion,errors};
  fs.writeFileSync('qa/ui-innovation-layout.json',JSON.stringify(result,null,2));console.log(JSON.stringify({passed:true,views:records.length,motion,errors}));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
