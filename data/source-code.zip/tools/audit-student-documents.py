"""Check readable report tables, arithmetic and retained template parts."""
from pathlib import Path
from zipfile import ZipFile
import hashlib,json,argparse
from docx import Document
from report_common import number

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--document-dir',default='documents/student-edition')
parser.add_argument('--supplement',default=None)
parser.add_argument('--prefix',default='student')
args=parser.parse_args()
sha=lambda raw:hashlib.sha256(raw).hexdigest()
study=json.loads((root/'data/common-study-results.json').read_text('utf-8'))
supplement=json.loads((root/args.supplement).read_text('utf-8')) if args.supplement else None
folder=root/args.document_dir
report=Document(folder/'研究报告_公文格式.docx')
text='\n'.join(p.text for p in report.paragraphs)
for word in ['边界条件','路由','冻结','独立种子','95%','P95','hindsight','14370','实测表明','已在学校应用','全国一等奖','tools/','data/']:
    assert word not in text,word
assert '并非学校现场统计' in text
assert '根据学生提供的信息' in text
assert '使用了AI辅助' in text
headings=[p.text for p in report.paragraphs if p.text in ['一、研究背景','二、研究目的','三、资料收集','四、具体想法','五、工作计划','六、具体实施计划','七、结论']]
assert headings==['一、研究背景','二、研究目的','三、资料收集','四、具体想法','五、工作计划','六、具体实施计划','七、结论']
assert len(report.inline_shapes)==4
for shape,name in zip(report.inline_shapes,['student/11-hall-plan.png','student/12-meal-flow.png','10-common-hall.png','student/13-window-choice.png']):
    image=report.part.related_parts[shape._inline.graphic.graphicData.pic.blipFill.blip.embed].blob
    assert image==(root/'figures'/name).read_bytes(),name
assert '（六）本项目的改进' in text
assert '记录几个窗口完成连续10人打饭所用的时间' in text
assert len(report.tables)==6
cells=lambda table:[[cell.text for cell in row.cells] for row in table.rows]
rows={row['id']:row['summary'] for row in study['contexts'][0]['rows']}
expected=[[{'reference':'原来的安排','efficiency':'用时最短','balanced':'均衡安排','lowPeak':'队伍更短'}[key],number(rows[key]['meanTotal']),number(rows[key]['meanWait']),number(rows[key]['peakQueue'],1)] for key in rows]
assert cells(report.tables[2])[1:]==expected
assert cells(report.tables[3])[1:]==[[['高一','高二','高三'][i],number(rows['reference'][f'grade{i}Total']),number(rows['balanced'][f'grade{i}Total'])] for i in range(3)]
if supplement:
    expected=[[str(row['windows']),str(row['seats']),number(row['summary']['meanWait']),number(row['summary']['seatWait']),number(row['summary']['meanTotal'])] for row in supplement['cases']]
    assert cells(report.tables[4])[1:]==expected
    assert '2025年为530人[10]，2026年为580人[1]' in text
    assert '不能直接作为每天的就餐人数' in text
    assert all(f'[{i}]' in text for i in range(1,11))
    base=next(row for row in supplement['cases'] if row['id']=='reference')['summary']
    added=next(row for row in supplement['cases'] if row['id']=='windows-8')['summary']
    assert abs((base['meanTotal']-added['meanTotal'])*60-48)<.5
    assert number(base['meanWait']-added['meanWait'])=='2.48'
    assert number(added['seatWait']-base['seatWait'])=='1.68'
    assert supplement['executions']==150
else:
    for index,context in enumerate(study['contexts']):
        actual=cells(report.tables[4])[index+1]
        assert actual[1:]==[number(context['rows'][0]['summary']['meanTotal']),number(next(row for row in context['rows'] if row['id']=='balanced')['summary']['meanTotal'])]
assert cells(report.tables[5])[1:]==[[{'fixed':'顺序保持不变','cyclic':'循环轮换','feedback':'参考前几餐用时'}[row['mode']],*[number(row['summary'][f'grade{i}Total']) for i in range(3)]] for row in study['period']]
plan=next(row for row in study['screened'] if row['id']==study['selection']['balanced'])['config']
for index,row in enumerate(cells(report.tables[1])[1:]):
    for grade in range(3):
        minute=680+plan['grades'][grade]['releaseTime']+index*plan['grades'][grade]['classInterval']
        assert row[grade+1]==f'{int(minute)//60:02}:{int(minute)%60:02}'
assert abs((rows['reference']['meanTotal']-rows['efficiency']['meanTotal'])*60-35)<.5
assert abs((rows['reference']['grade2Total']-rows['balanced']['grade2Total'])*60-401)<.5
assert abs((rows['balanced']['grade0Total']-rows['reference']['grade0Total'])*60-450)<.5
assert max(abs(context['fastestVersusShortest']['meanTotal']['mean'])*60 for context in study['contexts'])<1
with ZipFile(root/'release/packages/食刻2.3_通用窗口双侧布局_源码与研究.zip') as original:
    assert original.read('食刻2.3/data/common-study-results.json')==(root/'data/common-study-results.json').read_bytes()
template=root/'documents/templates/公文模板.docx'
assert sha(template.read_bytes())=='ec93c69c2f33639421d1d89cf4fc1e1b0f926b6b1c9bee8ce3fda7167a523ae7'
for docx in folder.glob('*.docx'):
    with ZipFile(template) as original,ZipFile(docx) as revised:
        for part in original.namelist():
            if not part.endswith('/') and part.startswith(('word/styles','word/theme/','word/footer','word/header','word/numbering')):
                assert original.read(part)==revised.read(part),part
result={'passed':True,'reportTables':6,'reportFigures':4,'sampleHeadingOrder':headings,'tableAndArithmeticChecks':'passed','oldStudyDataUnchanged':True,'preservedTemplateParts':'byte-identical','sources':[{'url':'https://edu.xa.gov.cn/web_files/edu/file/2026/07/16/202607161006095103689.pdf','supports':'Official school name only; page 2','checkedOn':'2026-10-19'},{'source':'User messages','supports':'Three-grade staggering and two-sided windows, central seats, front/rear access'},{'source':'data/common-study-results.json','supports':'All numerical findings and the class schedule; software test settings'},{'source':'qa/student-reference/metadata.json','supports':'Seven-part sample outline; the source sample is embedded as a long image and was read in ten segments'},{'source':'qa/award-reference/metadata.json','supports':'Writing reference only; eight scanned pages of the two award cases were read; no award status asserted for this project'}]}
if supplement:
    result['supplementExecutions']=150
    result['schoolFacts']='2025 admission plan 530; 2026 admission plan 580; not attendance counts. Current window/seat counts not established by public search.'
    result['sources'].append({'source':'research/canteen-related-literature-2026-10-19.json','supports':'Four method-related references and claim mapping; no claim of first invention of staggering or simulation.'})
(root/'qa'/(args.prefix+'-document-audit.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'passed':True,'tables':6,'arithmetic':'passed','template':'unchanged'},ensure_ascii=True))
