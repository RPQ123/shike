const fs=require('node:fs'),assert=require('node:assert/strict'),crypto=require('node:crypto');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex'),s=JSON.parse(fs.readFileSync('data/binhe-cohort-results.json'));
const {sourceRoot}=require('./study-source.cjs'),path=require('node:path'),bundle=sourceRoot(s.sourceHashes);
const bound=name=>require(path.join(bundle,'dist',name));
const E=bound('school-engine'),R=bound('research'),P=bound('planner'),T=bound('rotation'),B=bound('binhe-cohort');
for(const [file,hash] of Object.entries(s.sourceHashes))assert.equal(sha(fs.readFileSync(path.join(bundle,file))),hash,file);
assert.equal(sha(fs.readFileSync('research/binhe-cohort-protocol.json')),s.protocolSha256);
assert.deepEqual(s.base,B.create());assert.deepEqual(s.base.grades.map(g=>g.students),[580,530,500]);
assert.equal(s.base.students,1610);
const frozen=JSON.parse(fs.readFileSync('data/binhe-cohort-selection.json'));
assert.deepEqual(frozen,{frozenAt:s.frozenAt,selection:s.selection});
const chosen=P.choose(s.screened,s.screened.find(p=>p.id==='reference'),s.protocol.criteria);
assert.deepEqual(Object.fromEntries(Object.keys(s.selection).map(k=>[k,chosen[k].id])),s.selection);
assert.ok(Date.parse(s.frozenAt)<=Date.parse(s.completedAt));
let verified=0,replayed=0;const ids=r=>Array.from({length:r.count},(_,i)=>r.start+i);
function check(c,seeds,rounds,summary){
  assert.deepEqual(R.summarize(rounds),summary);
  for(const k of Object.keys(rounds[0]))assert.ok(Math.abs(summary[k]-rounds.reduce((a,r)=>a+r[k],0)/rounds.length)<1e-9,k);
  rounds.forEach((r,i)=>{
    verified++;assert.deepEqual([r.grade0Count,r.grade1Count,r.grade2Count],[580,530,500]);
    if(process.argv.includes('--replay')){
      const actual=R.metrics(E.simulateSchool({...c,seed:seeds[i]}));replayed++;
      for(const k of Object.keys(actual))assert.ok(Math.abs(actual[k]-r[k])<1e-9,k);
    }
  });
}
for(const p of s.screened)check(p.config,ids(s.protocol.screenSeeds),p.rounds,p.summary);
for(const p of s.contexts[0].rows)check(p.config,ids(s.protocol.verifySeeds),p.rounds,p.summary);
for(const p of s.cases){
  const expected=R.clone(s.base);expected.windows=p.windows;expected.windowMeans=Array(p.windows).fill(expected.serviceMean);expected.windowOwners=Array(p.windows).fill(0);expected.seats=p.seats;
  assert.deepEqual(p.config,E.normalizeSchoolConfig(expected));
  check(p.config,ids(s.protocol.controlSeeds),p.rounds,p.summary);
}
for(const p of s.period){
  assert.deepEqual(p.summary,R.summarize(p.rounds.map(r=>r.summary)));
  for(const r of p.rounds){assert.deepEqual(r.summary,T.summarize(r.days,r.days[0].config));for(const d of r.days)check(d.config,[d.seed],[d.metrics],R.summarize([d.metrics]));}
}
assert.equal(verified,s.executions);assert.equal(s.executions,800);
if(process.argv.includes('--replay'))assert.equal(replayed,800);
const receipt={passed:true,executions:s.executions,replayed,cohortCounts:[580,530,500],students:1610,candidates:s.screened.length,selection:s.selection};
fs.writeFileSync('qa/binhe-cohort-audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
