"""Queue waiting is the hero metric; complete duration is a numerical side column.

All 120 saved verification executions contribute. Whiskers denote the observed
minimum and maximum across 30 runs, not confidence intervals. This definition
remains in the report prose rather than as an explanatory sentence in the legend.
"""
from pathlib import Path
import json,csv,sys
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import transforms
import numpy as np

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'figures/student'
SCRIPTS=Path.home()/'.codex/skills/nature-figure/scripts'
sys.path.insert(0,str(SCRIPTS))
from audit_panel_alignment import require_matplotlib_panel_alignment
s=json.loads((ROOT/'data/binhe-cohort-results.json').read_text('utf-8'))
rows=s['contexts'][0]['rows']
assert [r['id'] for r in rows]==['reference','efficiency','balanced','lowPeak']
assert all(len(r['rounds'])==30 for r in rows)
plt.rcParams.update({'font.family':'FangSong','font.size':12,
 'svg.fonttype':'none','pdf.fonttype':42,'axes.unicode_minus':False,
 'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,
 'axes.edgecolor':'#B2C0C8','axes.linewidth':.8})
fig,ax=plt.subplots(figsize=(6.6,3.7))
fig.subplots_adjust(left=.19,right=.77,top=.80,bottom=.18)
labels=['参照安排','用时最短','均衡安排','短排队安排']
means=np.array([r['summary']['meanWait'] for r in rows])
lo=np.array([min(v['meanWait'] for v in r['rounds']) for r in rows])
hi=np.array([max(v['meanWait'] for v in r['rounds']) for r in rows])
y=np.arange(4)
ax.barh(y,means,height=.48,color=['#54799B','#A4B4BF','#A4B4BF','#188779'],edgecolor='none',zorder=2)
ax.errorbar(means,y,xerr=np.vstack([means-lo,hi-means]),fmt='none',ecolor='#354D5D',elinewidth=.8,capsize=2.5,zorder=3)
ax.set(yticks=y,yticklabels=labels,xlim=(0,18),xticks=[0,5,10,15],ylim=(-.65,3.65),xlabel='平均排队 / 分钟')
ax.invert_yaxis();ax.tick_params(axis='y',length=0,pad=10);ax.tick_params(axis='x',length=3,color='#A3B5BF')
ax.grid(False)
for t in ax.get_yticklabels():
    t.set_fontweight('bold');t.set_color('#243746')
    if t.get_text()=='短排队安排':t.set_color('#188779')
for i,value in enumerate(means):
    ax.text(hi[i]+.35,i,f'{value:.2f}',ha='left',va='center',fontsize=14,
            color='#188779' if i==3 else '#243746',fontweight='bold')
# The side column is text, not a second axes with a competing visual scale.
blend=transforms.blended_transform_factory(ax.transAxes,ax.transData)
for i,r in enumerate(rows):
    ax.text(1.20,i,f'{r["summary"]["meanTotal"]:.2f}',transform=blend,ha='center',va='center',
            color='#188779' if i==3 else '#536877',fontsize=13,fontweight='bold')
fig.text(.19,.91,'平均排队时间',ha='left',va='center',fontsize=15,fontweight='bold',color='#243746')
fig.text(.886,.91,'完整用时',ha='center',va='center',fontsize=13,fontweight='bold',color='#536877')
fig.text(.886,.845,'分钟',ha='center',va='center',fontsize=11,color='#536877')
stem=OUT/'15-meal-arrangements'
fig.canvas.draw()
require_matplotlib_panel_alignment(fig,json_out=str(stem.with_suffix('.alignment.json')),tolerance_pt=1.5,strict=True)
fig.savefig(stem.with_suffix('.png'),dpi=600,facecolor='white')
fig.savefig(stem.with_suffix('.pdf'),facecolor='white')
fig.savefig(stem.with_suffix('.svg'),facecolor='white')
svg=stem.with_suffix('.svg');svg.write_text('\n'.join(line.rstrip() for line in svg.read_text('utf-8').splitlines())+'\n',encoding='utf-8',newline='\n')
records=[]
for r,label in zip(rows,labels):
    for metric,name in [('meanWait','平均排队时间'),('meanTotal','平均完整用时')]:
        values=[v[metric] for v in r['rounds']]
        records.append({'安排':label,'指标':name,'次数':30,'平均_分钟':r['summary'][metric],'最小_分钟':min(values),'最大_分钟':max(values)})
with stem.with_suffix('.csv').open('w',encoding='utf-8-sig',newline='') as stream:
    w=csv.DictWriter(stream,fieldnames=list(records[0]),lineterminator='\n');w.writeheader();w.writerows(records)
contract={'claim':'四种复算安排中，短排队安排的平均排队时间最低；完整用时单列核对',
 'archetype':'single-axis quantitative comparison','backend':'Python / Matplotlib',
 'inputs':120,'groups':4,'executionsPerGroup':30,'exclusions':[],
 'center':'mean across all 30 executions','uncertainty':'minimum to maximum for meanWait',
 'auxiliaryColumn':'meanTotal across the same 30 executions; numerical text only',
 'style':'FangSong, restrained blue/teal, bold main labels and values',
 'sizeInches':[6.6,3.7],'reportWidthCm':15.2,'legend':'No explanatory legend sentences',
 'source':'data/binhe-cohort-results.json'}
(OUT/'15-meal-arrangements.contract.json').write_text(json.dumps(contract,ensure_ascii=False,indent=2),encoding='utf-8')
plt.close(fig)
print(json.dumps({'groups':4,'executions':120,'axes':1,'figure':stem.name}))
