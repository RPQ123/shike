const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'}),page=await browser.newPage({viewport:{width:1440,height:1100},deviceScaleFactor:2,acceptDownloads:true});
 const errors=[];page.on('pageerror',e=>errors.push(String(e)));const snap=()=>page.evaluate(()=>window.DiningLabSnapshot);
 try{
  await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);assert.equal((await snap()).config.students,1610);
  assert.ok(!(await page.locator('body').innerText()).includes('滨河'));await page.locator('[data-tab=compare]').click();await page.locator('#research-tools > summary').click();
  assert.equal(await page.locator('#legacy-comparison').count(),0);
  await page.locator('#study-run-three').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy&&window.DiningLabSnapshot.scheduleStudy.initial,null,{timeout:120000});
  let s=await snap();assert.equal(s.scheduleStudy.initial.rows.length,3);for(const row of s.scheduleStudy.initial.rows)assert.equal(row.rounds.length,30);
  const recorded=JSON.parse(fs.readFileSync('data/schedule-study-results.json','utf8'));
  for(let i=0;i<3;i++)assert.ok(Math.abs(s.scheduleStudy.initial.rows[i].summary.meanWait-recorded.initial[i].summary.meanWait)<1e-10);
  await page.locator('.study-setup').screenshot({path:'qa/schedule-research-setup.png'});
  await page.locator('#study-initial-output').screenshot({path:'figures/student/17-software-three-plans.png'});
  await page.locator('#schedule-study').screenshot({path:'qa/schedule-ui-first-stage.png'});
  await page.locator('#study-next').click();await page.locator('#study-run-gaps').click();
  await page.waitForFunction(()=>!window.DiningLabSnapshot.busy&&window.DiningLabSnapshot.scheduleStudy.interval,null,{timeout:240000});
  s=await snap();const study=s.scheduleStudy.interval;assert.equal(study.selectedSeconds,recorded.selectedSeconds);assert.equal(study.rows.length,13);assert.equal(study.verification.length,3);
  for(const row of study.rows){const expected=recorded.intervals.find(r=>r.seconds===row.seconds);assert.ok(Math.abs(row.summary.meanWait-expected.summary.meanWait)<1e-10)}
  await page.locator('#study-gap-output').screenshot({path:'qa/schedule-ui-second-stage.png'});
  await page.locator('.study-gap-chart').screenshot({path:'figures/student/18-software-gap-chart.png'});
  const download=page.waitForEvent('download');await page.locator('#study-gap-output [data-study-export]').click();const path=await(await download).path();const exported=JSON.parse(fs.readFileSync(path,'utf8'));assert.equal(exported.selectedSeconds,70);fs.writeFileSync('qa/schedule-ui-export.json',JSON.stringify(exported,null,2));
  const timetable=page.waitForEvent('download');await page.locator('#study-timetable-export').click();const csv=fs.readFileSync(await(await timetable).path(),'utf8');assert.equal(csv.trim().split(/\r?\n/).length,34);
  await page.locator('#study-gap-output [data-study-load=combined]').click();s=await snap();assert.equal(s.tab,'live');assert.equal(s.config.grades[0].classInterval,3.5);
  await page.getByRole('button',{name:'排队高峰',exact:true}).click();await page.waitForTimeout(300);await page.locator('#scene3d').screenshot({path:'qa/schedule-scene-regression.png'});
  await page.locator('#parameters').click();await page.locator('#parameter-dialog').screenshot({path:'figures/student/19-software-parameters.png'}).catch(async()=>page.locator('dialog[open]').screenshot({path:'figures/student/19-software-parameters.png'}));await page.getByRole('button',{name:'运行这个方案'}).click();
  await page.locator('[data-tab=compare]').click();await page.locator('#study-tab-three').click();await page.locator('#study-grade-gap').fill('9');await page.locator('#study-grade-gap').dispatchEvent('change');assert.ok(!(await page.locator('#study-stale').getAttribute('hidden')));assert.equal(await page.locator('#study-initial-output [data-study-load]').first().isDisabled(),true);
  const old=s.scheduleStudy.initial;await page.locator('#study-run-three').click();await page.locator('#study-cancel').click();await page.waitForFunction(()=>!window.DiningLabSnapshot.busy);assert.deepEqual((await snap()).scheduleStudy.initial.rows,old.rows);
  await page.setViewportSize({width:390,height:844});assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);await page.screenshot({path:'qa/schedule-ui-mobile.png',fullPage:true});
  assert.deepEqual(errors,[]);const receipt={passed:true,build:s.build.id,selectedSeconds:study.selectedSeconds,intervals:study.rows.length,threePlans:3,rounds:30,exactlyMatchesSavedStudy:true,cancelPreservesCompleteResult:true,staleExportsDisabled:true,timetableRows:33,errors};fs.writeFileSync('qa/schedule-ui-audit.json',JSON.stringify(receipt,null,2));console.log(JSON.stringify(receipt));
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
