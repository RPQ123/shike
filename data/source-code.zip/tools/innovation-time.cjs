const assert = require('node:assert/strict');
function measure(contract, now = Date.now()) {
  assert.equal(contract.task, 'innovation-planner-20261019');
  assert.equal(contract.startedAt, '2026-10-19T02:07:57+08:00');
  assert.equal(contract.minimumSeconds, 18000);
  const start = Date.parse(contract.startedAt),
    end = Date.parse(contract.earliestCompletion);
  assert.equal(end - start, contract.minimumSeconds * 1000, 'The declared five-hour interval must be exact');
  assert.ok(Number.isFinite(now) && now >= start, 'Current time must follow the new task start');
  return {
    taskStartedAt: contract.startedAt,
    earliestTaskCompletion: contract.earliestCompletion,
    checkedAt: new Date(now).toISOString(),
    elapsedSeconds: (now - start) / 1000,
    minimumSeconds: contract.minimumSeconds,
    complete: now >= end
  };
}
function requireComplete(contract, now = Date.now()) {
  const result = measure(contract, now);
  if (!result.complete)
    throw new RangeError(`本轮尚未达到五小时，最早完成时刻为${contract.earliestCompletion}`);
  return result;
}
module.exports = { measure, requireComplete };
