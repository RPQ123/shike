// Recompute all new trials and verify controlled changes rather than expected benefits.
const fs = require('node:fs'), assert = require('node:assert/strict'), crypto = require('node:crypto');
const E = require('../dist/school-engine'), R = require('../dist/research');
const sha = raw => crypto.createHash('sha256').update(raw).digest('hex');
const study = JSON.parse(fs.readFileSync('data/student-controls-results.json'));
assert.equal(sha(fs.readFileSync('research/student-controls-protocol.json')), study.protocolSha256);
assert.equal(sha(fs.readFileSync(study.protocol.baseSource)), study.baseSha256);
for (const [name, hash] of Object.entries(study.sourceHashes)) assert.equal(sha(fs.readFileSync(name)), hash, name);
assert.equal(study.executions, 150);
assert.equal(study.cases.length, 5);
const base = JSON.parse(fs.readFileSync(study.protocol.baseSource)).base;
let replayed = 0;
for (const row of study.cases) {
  assert.equal(row.rounds.length, 30);
  assert.equal(row.config.students, 360);
  assert.deepEqual(row.config.grades, base.grades);
  assert.equal(row.config.strategy, 'fastest');
  assert.equal(row.config.windows, row.windows);
  assert.equal(row.config.seats, row.seats);
  for (const key of Object.keys(base))
    if (!['windows', 'windowMeans', 'windowOwners', 'seats', 'seed'].includes(key))
      assert.deepEqual(row.config[key], base[key], `${row.id}:${key}`);
  const keys = Object.keys(row.rounds[0].metrics);
  for (const key of keys) {
    const mean = row.rounds.reduce((sum, run) => sum + run.metrics[key], 0) / row.rounds.length;
    assert.ok(Math.abs(mean - row.summary[key]) < 1e-9, `${row.id}:${key}:mean`);
  }
  for (let i=0; i<row.rounds.length; i++) {
    const run = row.rounds[i];
    assert.equal(run.seed, study.protocol.seedStart+i);
    assert.equal(run.metrics.grade0Count+run.metrics.grade1Count+run.metrics.grade2Count, 360);
    if (process.argv.includes('--replay')) {
      const actual = R.metrics(E.simulateSchool({...row.config, seed:run.seed}));
      for (const key of keys) assert.ok(Math.abs(actual[key] - run.metrics[key]) < 1e-9, `${row.id}:${key}:replay`);
      replayed++;
    }
  }
}
const result={passed:true, cases:5, executions:150, repetitionsPerCase:30, controlledSettingsVerified:true, replayed};
fs.writeFileSync('qa/student-controls-audit.json',JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
