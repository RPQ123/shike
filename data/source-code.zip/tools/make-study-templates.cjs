const fs = require('node:fs');
const path = require('node:path');
const R = require('../dist/research.js');
const E = require('../dist/school-engine.js');
fs.mkdirSync('scenarios', { recursive: true });
fs.mkdirSync('learning/templates', { recursive: true });

const scenarios = [
  ['01_三年级教学基准', '教学基准 · 合成参数', () => {}],
  ['02_座位较少', '60 座位 · 合成参数', c => { c.seats=60;c.serviceZones[0].seats=45;c.serviceZones[1].seats=15; }],
  ['03_座位较多', '240 座位 · 合成参数', c => { c.seats=240;c.serviceZones[0].seats=180;c.serviceZones[1].seats=60; }],
  ['04_两类套餐需求相近', '两类需求各半 · 合成参数', c => { c.gradeZoneWeights=[[.5,.5],[.5,.5],[.5,.5]]; }],
  ['05_锁定年级放行', '首班时刻锁定 · 合成参数', c => { c.grades.forEach(g=>g.releaseLocked=true); }],
  ['06_窗口速度不同', '窗口速度不同 · 合成参数', c => { c.windowMeans=[15,20,25,15,20,25]; }]
];
const index=[];
for (const [name,title,edit] of scenarios) {
  const config=R.example(); edit(config);
  config.sourceProfile.title=title;
  if (name.slice(0,2)!=='01') config.sourceProfile.status='modified';
  const file=name+'.json';
  fs.writeFileSync(path.join('scenarios',file),JSON.stringify(R.session(config),null,2));
  index.push({file,title,people:config.students,seed:config.seed,metrics:R.metrics(E.simulateSchool(config))});
}
fs.writeFileSync('scenarios/index.json',JSON.stringify({note:'目录索引，不能作为场景导入；仅01至06文件可导入。',scenarios:index},null,2));

const templates = {
  '01_观察场次.csv':['场次编号','日期','餐次','学段','观察地点代号','计时工具','观察起始时刻','观察结束时刻','供餐形式','实际开放窗口数','可用座位数_未知留空','记录者代号','学校允许情况','缺失或干扰说明'],
  '02_匿名个体事件.csv':['场次编号','匿名样本编号','年级','班级代号_可空','允许放行时刻','实际放行时刻','到达时刻','开始取餐时刻','取餐结束时刻','开始用餐时刻','结束用餐时刻','返程完成时刻','窗口代号','餐品类别代号','缺失原因','记录者代号'],
  '03_现场计数.csv':['场次编号','观察时刻','开放窗口数','取餐排队人数','正在取餐人数','等座人数','正在用餐人数','计数覆盖区域','计数方法','不确定或遮挡说明'],
  '04_本人研究日志.csv':['实际日期时间','研究问题','事前预测','本人实际操作','结果及解释','证据文件名','参考或协助来源','本次未解决问题','后续计划'],
  '05_配对实验计划.csv':['计划记录时间','研究问题','方案A文件','方案B文件','唯一拟改条件','实际其他改变','应保持不变的条件','种子起点','重复次数','筛选规则_如适用','独立验证种子_如适用','事前预测','完成后的结果文件']
};
for (const [name,columns] of Object.entries(templates)) {
  fs.writeFileSync(path.join('learning/templates',name),R.csv([Object.fromEntries(columns.map(c=>[c,'']))]));
}
console.log(JSON.stringify({scenarios:scenarios.length,blankTemplates:Object.keys(templates).length}));
