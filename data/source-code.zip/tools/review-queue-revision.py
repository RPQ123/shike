"""Verify the queue-focused recommendation, forms, source records and PDFs."""
from pathlib import Path
from zipfile import ZipFile
from docx import Document
from lxml import etree as E
from PIL import Image,ImageDraw
import pypdfium2 as pdfium
import hashlib,json,re,unicodedata,subprocess,csv

root=Path(__file__).resolve().parents[1];out=root.parent/'【成品】提交材料';qa=root/'qa'
sha=lambda b:hashlib.sha256(b).hexdigest()
norm=lambda s:re.sub(r'\s+','',unicodedata.normalize('NFKC',s))
folder=root/'documents/queue-focus-edition'
report=Document(folder/'研究报告_公文格式.docx')
text='\n'.join(p.text for p in report.paragraphs)
assert len(report.inline_shapes)==4 and len(report.tables)==6
for word in ['需要强调的是','值得注意的是','这并不意味着','不能简单地','并非','实测表明','已在学校应用','独立完成','完整用时更加接近','缩小年级用时差']:
    assert word not in text,word
assert '高一至高三年级学生的平均就餐排队时间' in text
assert '增加约70秒' in text and '使用了AI辅助' in text
assert not re.search(r'\d',next(p.text for p in report.paragraphs if p.text.startswith('摘要：')))
assert len(report.element.xpath('.//m:sSubSup'))==1
selection=json.loads((root/'research/queue-focus-selection.json').read_text('utf-8'))
assert sha((root/selection['source']).read_bytes())==selection['sourceSha256']
study=json.loads((root/selection['source']).read_text('utf-8'))
chosen=next(r for r in study['screened'] if r['id']==selection['selectedId'])
with (root/'data/queue-focus-timetable.csv').open(encoding='utf-8-sig') as stream:rows=list(csv.DictReader(stream))
assert len(rows)==len(chosen['batches'])==33
assert sum(int(r['人数']) for r in rows)==1610
for row,batch in zip(rows,chosen['batches']):
    sec=round((680+batch['release'])*60)
    assert row['出发时刻']==f'{sec//3600:02}:{sec//60%60:02}:{sec%60:02}'
    assert row['方案编号']==chosen['id'] and row['年级']==batch['gradeName']
    assert int(row['人数'])==batch['students']
for name,expected in json.loads((qa/'submission-materials/original-template-hashes.json').read_text('utf-8')).items():
    assert sha((root.parent/name).read_bytes())==expected,name
receipt=json.loads((qa/'submission-materials/build-receipt.json').read_text('utf-8'))
assert receipt['introCharacters']==len(''.join(receipt['intro']))<=410
for record in receipt['documents']:
    source=Path(record['source']);dest=out/record['file']
    with ZipFile(source) as original,ZipFile(dest) as revised:
        changed=[n for n in original.namelist() if original.read(n)!=revised.read(n)]
        assert set(changed)<= {'word/document.xml','docProps/core.xml'}
        ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        a=E.fromstring(original.read('word/document.xml')).find('.//w:sectPr',ns)
        b=E.fromstring(revised.read('word/document.xml')).find('.//w:sectPr',ns)
        assert E.tostring(a)==E.tostring(b)
assert (out/'03-参赛学生诚信承诺书.docx').read_bytes()==(qa/'queue-focus-before-20261019/03-参赛学生诚信承诺书.docx').read_bytes()
assert (out/'04-研究报告.docx').read_bytes()==(folder/'研究报告_公文格式.docx').read_bytes()
for original,target in [('binhe-cohort-rounds.csv','05-原始实验记录.csv'),('binhe-cohort-summary.csv','06-计算结果汇总.csv'),('queue-focus-timetable.csv','07-班级放行表.csv')]:
    raw=(root/'data'/original).read_bytes();assert raw==(out/target).read_bytes()
for name in ['binhe-cohort-rounds.csv','binhe-cohort-results.json','binhe-cohort-summary.csv','binhe-cohort-timetable.csv']:
    assert (root/'data'/name).read_bytes()==subprocess.check_output(['git','show','HEAD:data/'+name],cwd=root)
export=json.loads((qa/'queue-submission-render/export-receipt.json').read_text('utf-8-sig'))
checks=[]
for record in export:
    doc=Document(record['source']);source=Path(record['pdf'])
    pdf=pdfium.PdfDocument(source)
    rendered='\n'.join(line for page in pdf for line in page.get_textpage().get_text_range().splitlines() if not re.fullmatch(r'\s*[-－–—]\s*\d+\s*[-－–—]\s*',line))
    paragraphs=[p.text for p in doc.paragraphs]
    for t in doc.tables:
        for row in t.rows:
            for cell in row.cells:paragraphs.extend(p.text for p in cell.paragraphs)
    missing=[s for s in paragraphs if norm(s) and norm(s) not in norm(rendered)]
    assert not missing,(source.name,missing[:3])
    assert '\ufffd' not in rendered
    dest=Path(record['delivered']) if record['delivered'] else None
    if dest:assert source.read_bytes()==dest.read_bytes()
    if source.name.startswith('研究报告'):
        assert norm('3×2×1＝6') in norm(rendered)
        assert len(pdf[len(pdf)-1].get_textpage().get_text_range())>150,'Near-empty final page'
    else:
        target=qa/'queue-submission-render'/source.stem;target.mkdir(exist_ok=True)
        tiles=[]
        for i,page in enumerate(pdf):
            picture=page.render(scale=1.3).to_pil();picture.save(target/f'page-{i+1:02}.png')
            picture.thumbnail((300,440));tile=Image.new('RGB',(320,470),'#dddddd');tile.paste(picture,((320-picture.width)//2,10));ImageDraw.Draw(tile).text((10,450),str(i+1),fill='black');tiles.append(tile)
        sheet=Image.new('RGB',(1280,470*((len(tiles)+3)//4)),'white')
        for i,tile in enumerate(tiles):sheet.paste(tile,((i%4)*320,(i//4)*470))
        sheet.save(target/'contact.png')
    checks.append({'pdf':str(source),'pages':len(pdf),'sha256':sha(source.read_bytes()),'paragraphsChecked':len(paragraphs),'delivered':None if dest is None else str(dest)})
    pdf.close()
skills=[]
for name in ['anti-defensive-writing','drawio-skill','humanizer-zh']:
    skill=Path.home()/'.codex/skills'/name/'SKILL.md';assert skill.is_file()
    skills.append({'name':name,'file':str(skill),'sha256':sha(skill.read_bytes())})
result={'passed':True,'tables':6,'figures':4,'originalTemplatesUnchanged':True,'originalStudyDataUnchanged':True,'recommendation':selection,'nativePermutationEquation':True,'introCharacters':receipt['introCharacters'],'skills':skills,'renderer':'Word ExportAsFixedFormat / PDFium; draw.io official viewer / Chromium','checks':checks}
(qa/'queue-final-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result,ensure_ascii=False))
