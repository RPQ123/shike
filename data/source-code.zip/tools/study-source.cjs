// Historical experiments bind exact source bytes, independent of newer app versions.
const fs = require('node:fs'), path = require('node:path'), crypto = require('node:crypto');
function sourceFile(file, expected, root = process.cwd()) {
  for (const candidate of [path.join(root,file),path.join(root,'research/frozen-v2.2',file)]) {
    if(fs.existsSync(candidate) && crypto.createHash('sha256').update(fs.readFileSync(candidate)).digest('hex')===expected) return candidate;
  }
  throw new Error('Missing exact frozen study source: '+file+' expected '+expected);
}
function sourceRoot(hashes, root=process.cwd()) {
  const candidates=[root,path.join(root,'research/frozen-model-2.3.1'),path.join(root,'research/frozen-v2.2')];
  for(const candidate of candidates)if(Object.entries(hashes).every(([file,expected])=>{
    const filename=path.join(candidate,file);
    return fs.existsSync(filename)&&crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex')===expected;
  }))return candidate;
  throw new Error('Missing complete exact source bundle for historical study');
}
module.exports = {sourceFile,sourceRoot};
