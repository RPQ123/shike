const {chromium}=require('playwright');
(async()=>{const browser=await chromium.launch({headless:true,channel:'chrome'});try{
 const page=await browser.newPage({viewport:{width:610,height:1100},deviceScaleFactor:3});
 await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);
 await page.waitForTimeout(300);
 await page.locator('.setup-parameters').screenshot({path:'figures/student/22-software-setup.png'});
 await page.setViewportSize({width:840,height:1100});
 await page.locator('#setup-form button[type=submit]').click();
 await page.locator('#peak').click();await page.waitForTimeout(400);
 await page.locator('#scene3d').screenshot({path:'figures/student/16-software-scene.png'});
 await page.setViewportSize({width:1440,height:1150});await page.waitForTimeout(250);
 await page.locator('#page-live').screenshot({path:'qa/product-workspace-full.png'});
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
