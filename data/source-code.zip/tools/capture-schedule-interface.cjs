const {chromium}=require('playwright');
(async()=>{const browser=await chromium.launch({headless:true,channel:'chrome'});try{
 const page=await browser.newPage({viewport:{width:520,height:1000},deviceScaleFactor:3});
 await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);
 await page.locator('[data-tab=compare]').click();
 await page.locator('.study-setup').screenshot({path:'figures/student/22-software-setup.png'});
}finally{await browser.close()}})().catch(e=>{console.error(e);process.exitCode=1});
