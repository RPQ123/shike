const {chromium} = require('playwright');
const fs = require('node:fs');
const label = process.argv[2];
if (!label || !/^[a-z0-9-]+$/.test(label) || label === 'before') throw new Error('Provide a unique round label');
(async () => {
  const browser = await chromium.launch({headless:true,channel:'chrome'});
  let page;
  const errors=[],audit=[],network=[];
  try {
    page = await browser.newPage({viewport:{width:1440,height:1000}});
    page.on('pageerror',e=>errors.push(String(e)));
    page.on('requestfailed',r=>network.push({url:r.url(),error:r.failure()}));
    page.on('response',r=>{if(r.status()>=400)network.push({url:r.url(),status:r.status()})});
    await page.goto('http://127.0.0.1:8769/');
    await page.waitForFunction(()=>window.DiningLabSnapshot);
    const build=await page.evaluate(()=>window.DiningLabBuild);
    for(const width of [1440,768,360,320]) {
      await page.setViewportSize({width,height:1000});
      for(const name of ['live','compare','search','evidence','learn']) {
        await page.locator(`[data-tab="${name}"]`).click();
        await page.mouse.move(width-8, 8);
        await page.screenshot({path:`qa/refresh-${label}-${name}-${width}.png`,fullPage:true,animations:"disabled"});
        audit.push(await page.evaluate(({name,width})=>{
          const root=document.querySelector('#page-'+name);
          const leaves=[...root.querySelectorAll('*')].filter(e=>!e.children.length&&e.textContent.trim()&&e.getClientRects().length);
          return {page:name,width,textCharacters:root.innerText.length,smallTextLeaves:leaves.filter(e=>parseFloat(getComputedStyle(e).fontSize)<12).map(e=>({text:e.textContent.trim().slice(0,80),size:getComputedStyle(e).fontSize})),overflow:document.documentElement.scrollWidth-innerWidth};
        },{name,width}));
      }
    }
    fs.writeFileSync(`qa/refresh-${label}.json`,JSON.stringify({at:new Date().toISOString(),build,audit,errors},null,2));
    console.log(JSON.stringify({errors,audit}));
  }catch(error){
    const failure = {at:new Date().toISOString(),label,error:String(error),errors,network,audit};
    if(page) {
      failure.page = await page.evaluate(()=>({url:location.href,ready:document.readyState,build:window.DiningLabBuild,body:document.body.innerText.slice(0,2500)})).catch(()=>null);
      await page.screenshot({path:`qa/refresh-capture-failed-${Date.now()}.png`}).catch(()=>{});
    }
    fs.writeFileSync(`qa/refresh-capture-failed-${Date.now()}.json`,JSON.stringify(failure,null,2));
    throw error;
  }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
