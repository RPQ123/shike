// Investigate one initialization timeout observed while four QA processes ran.
const {chromium}=require('playwright');
const fs=require('node:fs');
(async()=>{
  const records=[];
  for(let batch=0;batch<3;batch++) {
    const group=await Promise.all(Array.from({length:4},async(_,index)=>{
      const started=performance.now(),errors=[],network=[];
      const browser=await chromium.launch({headless:true,channel:'chrome'});
      let page;
      try {
        page=await browser.newPage();
        page.on('pageerror',e=>errors.push(String(e)));
        page.on('requestfailed',r=>network.push({url:r.url(),failure:r.failure()}));
        await page.goto('http://127.0.0.1:8769/');
        await page.waitForFunction(()=>window.DiningLabSnapshot);
        const state=await page.evaluate(()=>window.DiningLabSnapshot);
        return {batch,index,ok:true,elapsedMs:performance.now()-started,build:state.build.id,mode:state.mode,errors,network};
      } catch(error) {
        return {batch,index,ok:false,error:String(error),elapsedMs:performance.now()-started,errors,network,
          page:await page?.evaluate(()=>({url:location.href,ready:document.readyState,text:document.body.innerText.slice(0,2000)})).catch(()=>null)};
      } finally {await browser.close();}
    }));
    records.push(...group);
  }
  fs.writeFileSync('qa/refresh-startup-load.json',JSON.stringify({at:new Date().toISOString(),records},null,2));
  console.log(JSON.stringify(records));
  if(records.some(r=>!r.ok||r.errors.length||r.network.length))process.exitCode=1;
})().catch(e=>{console.error(e);process.exitCode=1});
