"""Render the fixed innovation study without editing the recorded results."""
from pathlib import Path
import csv, hashlib, json, os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'data/innovation-study-results.json'
study=json.loads(SOURCE.read_text(encoding='utf-8'))
out=ROOT/'figures';qa=ROOT/'qa'
audit_path=os.environ.get('DINING_FIGURE_AUDIT_DIR')
render_only='--render-only' in sys.argv
if render_only:
 print('Render-only reproduction: external publication QA is not being rerun.',file=sys.stderr)
else:
 if not audit_path: raise RuntimeError('Set DINING_FIGURE_AUDIT_DIR for full figure QA, or use --render-only to reproduce the graphics without the external auditor')
 sys.path.insert(0,audit_path)
 from audit_panel_alignment import require_matplotlib_panel_alignment

plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Microsoft YaHei','Arial','DejaVu Sans'],'font.size':9,'axes.unicode_minus':False,
 'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,
 'axes.linewidth':.7,'xtick.color':'#5c574f','ytick.color':'#5c574f','legend.frameon':False})
COLORS=['#5288ab','#c87954','#b18a32'];MARKERS=['o','s','^']
LABELS={'reference':'原安排','window-only':'只调窗口','class-only':'只调班级','grade-gap-balanced':'旧方法重筛','joint-fixed':'联合 固定顺序','joint-cyclic':'联合 循环轮换','joint-feedback':'联合 用时补偿','hindsight':'已知未来回看'}
records=[];source_rows=[]

def save(fig,name):
 fig.canvas.draw()
 if not render_only:
  require_matplotlib_panel_alignment(fig,json_out=str(qa/(name+'-alignment.json')),tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
 files=[]
 fig.savefig(out/f'{name}.png',dpi=300,bbox_inches='tight',facecolor='white')
 fig.savefig(out/f'{name}.svg',bbox_inches='tight',facecolor='white')
 fig.savefig(out/f'{name}.pdf',bbox_inches='tight',facecolor='white')
 for suffix in ['png','svg','pdf']:
  path=out/(name+'.'+suffix)
  files.append({'file':path.relative_to(ROOT).as_posix(),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
 records.append({'name':name,'sourceSha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'files':files})
 plt.close(fig)

# 06: the actual nine-class schedule, not a decorative schematic.
plans=[study['singleMeal'][0]['rows'][0],next(r for r in study['singleMeal'][0]['rows'] if r['id']==study['selection']['balanced'])]
fig,axes=plt.subplots(2,1,figsize=(6.3,3.6),sharex=True,sharey=True)
for panel,(ax,plan,title) in enumerate(zip(axes,plans,['原安排','联合均衡安排'])):
 for grade in plan['config']['grades']:
  xs=[grade['releaseTime']+j*grade['classInterval'] for j in range(grade['classes'])]
  ax.plot(xs,[grade['id']]*len(xs),color=COLORS[grade['id']],linewidth=1.5,marker=MARKERS[grade['id']],markersize=7,zorder=3)
  for j,x in enumerate(xs):
   ax.annotate(str(j+1),(x,grade['id']),xytext=(0,9),textcoords='offset points',ha='center',fontsize=8)
   source_rows.append({'figure':'06','context':'base','policy':plan['id'],'metric':'class-release','grade':grade['id'],'class':j+1,'mean':x})
 ax.set_yticks([0,1,2],['高一','高二','高三']);ax.set_ylim(2.6,-.7)
 ax.set_title(chr(97+panel)+'  '+title,loc='left',fontsize=10,pad=9)
axes[-1].set_xlim(29.5,36.5);axes[-1].set_xticks(range(30,37));axes[-1].xaxis.set_major_formatter(FuncFormatter(lambda x,pos:f'11:{int(x)+20:02d}'))
axes[-1].set_xlabel('班级放行时刻；数字为教学班级序号')
fig.tight_layout(pad=1.1,h_pad=1.3)
save(fig,'06-class-timetable')

# 07: paired component comparison. No decoration derived from validation success.
context=study['periods'][0]
fig,ax=plt.subplots(figsize=(6.3,4.5))
for i,row in enumerate(context['rows']):
 effect=context['differences'][row['id']]['periodWorstGrade']
 color='#a44b32' if row['id']=='joint-feedback' else '#556f62' if row['id'].startswith('joint-') else '#8b877e'
 ax.errorbar(effect['mean'],i,xerr=[[effect['mean']-effect['low']],[effect['high']-effect['mean']]],fmt='D' if row['id']=='hindsight' else 'o',markersize=5.5,color=color,capsize=3,linewidth=1.2)
 ax.text(.98,i,f"{effect['mean']:+.2f}",transform=ax.get_yaxis_transform(),ha='right',va='center',fontsize=9)
 source_rows.append({'figure':'07','context':'base','policy':row['id'],'metric':'periodWorstGrade','mean':effect['mean'],'low':effect['low'],'high':effect['high'],'n':30})
ax.set_yticks(range(8),[LABELS[r['id']] for r in context['rows']]);ax.set_ylim(7.6,-.6)
ax.set_xlim(-10,2);ax.axvline(0,color='#b2aa9b',linewidth=.8,linestyle='--');ax.grid(axis='x',alpha=.13);ax.set_axisbelow(True)
ax.set_xlabel('相对原安排的周期最慢年级用时变化 / 分钟')
ax.set_title('班级交错与跨餐轮换的组件比较',loc='left',fontsize=11,pad=14)
fig.text(.98,.015,'30组三餐周期；点为配对均值，线为95%区间；菱形为已知未来的回看参照',ha='right',fontsize=8)
fig.tight_layout(rect=(0,.055,1,1))
save(fig,'07-component-comparison')

# 08: all declared contexts; benefit and cost panels have complementary roles.
fig,axes=plt.subplots(1,2,figsize=(7.1,5.6),sharey=True)
for ax,key,title in zip(axes,['periodWorstGrade','meanTotal'],['a  周期最慢年级变化','b  全体平均用时变化']):
 for i,case in enumerate(study['periods']):
  d=case['versusCyclic']['joint-feedback'][key]
  ax.errorbar(d['mean'],i,xerr=[[d['mean']-d['low']],[d['high']-d['mean']]],fmt='o',color='#a44b32' if case['contextId']=='walk-asymmetric' else '#557564',markersize=4.5,capsize=2.5,linewidth=1.1)
  source_rows.append({'figure':'08','context':case['contextId'],'policy':'feedback-minus-cyclic','metric':key,'mean':d['mean'],'low':d['low'],'high':d['high'],'n':30})
 ax.axvline(0,color='#b2aa9b',linestyle='--',linewidth=.8);ax.grid(axis='x',alpha=.13);ax.set_axisbelow(True);ax.set_title(title,loc='left',fontsize=10,pad=13);ax.set_xlabel('补偿 − 循环 / 分钟')
axes[0].set_yticks(range(14),[c['label'] for c in study['periods']]);axes[0].set_ylim(13.6,-.6)
axes[0].set_xlim(-1.05,.7);axes[1].set_xlim(-.35,.8)
fig.text(.98,.015,'每条件30组三餐周期；线为95%配对区间；全部14个预设条件均展示',ha='right',fontsize=8)
fig.tight_layout(rect=(0,.045,1,1),w_pad=2)
save(fig,'08-feedback-vs-cyclic')

# 09: each prefix is aggregated within a replicate before between-replicate CI.
fig,axes=plt.subplots(1,3,figsize=(7.1,3.2),sharey=True)
for panel,(ax,policy,title) in enumerate(zip(axes,['joint-fixed','joint-cyclic','joint-feedback'],['固定顺序','循环轮换','用时补偿'])):
 row=next(r for r in study['fiveMeal']['rows'] if r['id']==policy)
 for grade in range(3):
  means=[];lows=[];highs=[]
  for k in range(1,6):
   values=np.array([np.mean([d['metrics'][f'grade{grade}Total'] for d in r['days'][:k]]) for r in row['rounds']]);mean=float(values.mean());half=2.04523*float(values.std(ddof=1))/np.sqrt(30)
   means.append(mean);lows.append(mean-half);highs.append(mean+half)
   source_rows.append({'figure':'09','context':'base-five-meal','policy':policy,'metric':'prefixGradeTotal','grade':grade,'prefixMeals':k,'mean':mean,'low':mean-half,'high':mean+half,'n':30})
  ax.plot(range(1,6),means,color=COLORS[grade],marker=MARKERS[grade],markersize=4,linewidth=1.3,label=['高一','高二','高三'][grade]);ax.fill_between(range(1,6),lows,highs,color=COLORS[grade],alpha=.12,linewidth=0)
 ax.set_title(chr(97+panel)+'  '+title,loc='left',fontsize=10,pad=12);ax.set_xticks(range(1,6));ax.set_xlabel('累计餐次');ax.set_xlim(.8,5.2);ax.set_ylim(24.5,35.5);ax.grid(alpha=.12);ax.set_axisbelow(True)
axes[0].set_ylabel('截至本餐的年级平均用时 / 分钟')
handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,loc='lower center',ncol=3,bbox_to_anchor=(.5,.01),fontsize=8)
fig.tight_layout(rect=(0,.13,1,1),w_pad=1.3)
save(fig,'09-five-meal-prefix')

with (out/'innovation-source-data.csv').open('w',encoding='utf-8-sig',newline='') as file:
 fields=['figure','context','policy','metric','grade','class','prefixMeals','mean','low','high','n'];writer=csv.DictWriter(file,fieldnames=fields);writer.writeheader();writer.writerows(source_rows)
record={'backend':'Python/matplotlib','source':str(SOURCE.relative_to(ROOT)),'uniqueExecutions':study['counts']['uniqueExecutions'],'allContextsShown':14,'sourceRows':len(source_rows),'figures':records,
 'sourceData':{'file':'figures/innovation-source-data.csv','sha256':hashlib.sha256((out/'innovation-source-data.csv').read_bytes()).hexdigest()},
 'generator':{'file':'tools/make-innovation-figures.py','sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}}
if render_only:
 record['scope']='Graphics regenerated only; no new alignment, collision, text or visual-review certification.'
(qa/('innovation-figure-regeneration.json' if render_only else 'innovation-figure-audit.json')).write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'figures':[r['name'] for r in records],'sourceRows':len(source_rows)}))
