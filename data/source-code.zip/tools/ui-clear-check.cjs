const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'});
 const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 try {
  await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);
  for(const selector of ['#legacy-comparison','.library-button','.utility-menu','#save','#import','#file-input']) assert.equal(await page.locator(selector).count(),0,selector);
  assert.deepEqual(await page.locator('.workflow-nav button').allTextContents(),['01选择方案','02运行过程','03仿真结果']);
  const contrast=async selector=>page.locator(selector).first().evaluate(e=>{
   const c=getComputedStyle(e),rgb=c.color.match(/[\d.]+/g).slice(0,3).map(Number).map(v=>{v/=255;return v<=.04045?v/12.92:((v+.055)/1.055)**2.4;});
   return {ratio:1.05/(.2126*rgb[0]+.7152*rgb[1]+.0722*rgb[2]+.05),size:parseFloat(c.fontSize)};
  });
  for(const width of [1440,390,320]){
   await page.setViewportSize({width,height:1000});
   for(const tab of ['setup','live','compare']){
    await page.locator(`[data-tab=${tab}]`).click();
    await page.waitForTimeout(300);
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,`${tab} ${width}`);
    for(const icon of await page.locator('.page.active .ui-icon:visible').all()){
     const box=await icon.boundingBox();assert.ok(box.width<=40&&box.height<=40,'An icon must not inherit chart SVG sizing');
    }
    if(tab==='live'){
     for(const s of ['#scenario-name','#scenario-detail','.legend','#live-counts .count-content'])assert.ok((await contrast(s)).ratio>=4.5,s);
     assert.ok((await contrast('#live-counts b')).size>=26);assert.ok((await contrast('#clock')).size>=30);
    }
    if(tab==='compare'){
     assert.ok((await contrast('#kpis .kpi:first-child strong')).size>=48);
     assert.ok((await contrast('#kpis .label')).ratio>=4.5);
     assert.equal(await page.locator('#page-compare .file-menu').count(),1,'Result export stays available');
    }
    if(width!==320)await page.screenshot({path:`qa/clear-${tab}-${width}.png`,fullPage:true});
   }
  }
  assert.deepEqual(errors,[]);
  const receipt={passed:true,build:await page.evaluate(()=>DiningLabSnapshot.build.id),removedEntries:true,newStepNames:true,readableData:true,textContrastAtLeast4_5:true,iconsBounded:true,widths:[1440,390,320],errors};
  fs.writeFileSync('qa/clear-ui-audit.json',JSON.stringify(receipt,null,2));console.log(receipt);
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
