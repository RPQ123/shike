"""Keep Word's text and layout, restoring each PDF figure to its source pixels.

Word may downsample images even when document compression is disabled. Replace
only the six image XObjects, never rasterize pages or change textual content.
"""
from pathlib import Path
import argparse,hashlib,json,io,struct
import fitz
from PIL import Image
p=argparse.ArgumentParser();p.add_argument('--document-dir',default='documents/three-step-edition');a=p.parse_args()
root=Path(__file__).resolve().parents[1];pdf=root/a.document_dir/'研究报告_公文格式.pdf'
names=['12-meal-flow','22-software-setup','16-software-scene','13-window-choice','20-three-arrangements','21-group-intervals']
d=fitz.open(pdf);before=[page.get_text() for page in d];records=[]
found=[(page,page.get_images(full=True)) for page in d if page.get_images(full=True)]
assert len(found)==len(names),(len(found),len(names))
for (page,images),name in zip(found,names):
    old=images[0]
    source=root/'figures/student'/f'{name}.png';im=Image.open(source)
    # Reuse lossless PNG scanline filters. An unfiltered RGB stream makes a
    # detailed scene unnecessarily large even though the pixels are identical.
    rgb=Image.new('RGB',im.size,'white')
    if im.mode=='RGBA':rgb.paste(im,mask=im.getchannel('A'))
    else:rgb.paste(im.convert('RGB'))
    stream=io.BytesIO();rgb.save(stream,format='PNG',optimize=True)
    raw=stream.getvalue();offset=8;idat=[]
    while offset<len(raw):
        length=struct.unpack('>I',raw[offset:offset+4])[0];kind=raw[offset+4:offset+8]
        if kind==b'IDAT':idat.append(raw[offset+8:offset+8+length])
        offset+=length+12
    for old_image in images:
        xref=old_image[0]
        d.update_object(xref,f'<< /Type /XObject /Subtype /Image /Width {im.width} /Height {im.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 >>')
        d.update_stream(xref,b''.join(idat),compress=False)
        for key,value in {'Filter':'/FlateDecode','DecodeParms':f'<< /Predictor 15 /Colors 3 /BitsPerComponent 8 /Columns {im.width} >>'}.items():d.xref_set_key(xref,key,value)
        assert fitz.Pixmap(d,xref).samples==rgb.tobytes()
    records.append({'name':name,'page':page.number+1,'oldPixels':old[2:4],'sourcePixels':im.size,'sourceSha256':hashlib.sha256(source.read_bytes()).hexdigest()})
assert before==[page.get_text() for page in d]
tmp=pdf.with_suffix('.high-resolution.pdf');d.save(tmp,garbage=4,deflate=True);d.close();tmp.replace(pdf)
with fitz.open(pdf) as checked:
    assert [page.get_text() for page in checked]==before
    for record in records:
        page=checked[record['page']-1]
        assert any(tuple(x[2:4])==tuple(record['sourcePixels']) for x in page.get_images(full=True))
receipt={'passed':True,'textAndPageLayoutPreserved':True,'pdfSha256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'figures':records}
(root/'qa/three-step-image-resolution.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2),'utf-8')
print(json.dumps(receipt,ensure_ascii=False))
