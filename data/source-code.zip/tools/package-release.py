"""Create local deliverable ZIPs from explicit allowlists; exclude personal caches."""
from pathlib import Path
import hashlib
import json
import re
import sys
import zipfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'release' / 'packages'
OUT.mkdir(parents=True, exist_ok=True)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def files_under(folder, suffixes=None):
    return [p for p in sorted((ROOT / folder).rglob('*'))
            if p.is_file() and '__pycache__' not in p.parts
            and (suffixes is None or p.suffix in suffixes)]


def package(name, entries, extra):
    archive = OUT / name
    manifest = []
    names = set()
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for source, target in entries:
            assert target not in names and not target.startswith('/') and '..' not in Path(target).parts
            assert source.is_file(), source
            names.add(target)
            blob = source.read_bytes()
            z.writestr(target, blob)
            manifest.append({'file': target, 'bytes': len(blob), 'sha256': digest(blob)})
        for target, text in extra.items():
            assert target not in names
            blob = text.encode('utf8')
            z.writestr(target, blob)
            manifest.append({'file': target, 'bytes': len(blob), 'sha256': digest(blob)})
        manifest_blob = json.dumps(manifest, ensure_ascii=False, indent=2).encode('utf8')
        z.writestr('MANIFEST.json', manifest_blob)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for item in manifest:
            assert digest(z.read(item['file'])) == item['sha256']
    return {'file': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'manifestSha256': digest(manifest_blob), 'entries': len(manifest)}


def main():
    build = json.loads(re.search(r'Object\.freeze\((.*)\);', (ROOT/'dist/build-info.js').read_text(), re.S).group(1))
    final_requested = '--final' in sys.argv
    refresh = '--refresh' in sys.argv
    decision = '--decision' in sys.argv
    assert not (refresh and decision), 'Choose one iteration profile'
    label = '食刻2.1' if decision else '食刻2.0'
    final_evidence = []
    if final_requested:
        evidence_names = (['decision-reliability-summary.json', 'decision-final-review.md',
                           'soak-decision-final.jsonl'] if decision else [
            'refresh-reliability-summary.json', 'refresh-final-review.md',
            'soak-refresh-round1.jsonl', 'soak-refresh-final.jsonl'] if refresh else [
            'reliability-summary.json', 'final-review.md', 'soak-events.jsonl',
            'soak-current-build.jsonl', 'soak-release.jsonl', 'soak-final.jsonl'])
        final_evidence = [ROOT/'qa'/name for name in evidence_names]
        assert all(p.is_file() for p in final_evidence), 'Final review and terminal reliability evidence required'
        terminal = json.loads(final_evidence[0].read_text(encoding='utf8'))
        assert terminal['build'] == build['id'], 'Final evidence must match the current build'
        current = [s for s in terminal['segments'] if s['build'] == build['id']][-1]
        assert current['completionRecorded'] and not current['failures'] and not current['runtimeErrors']
        if decision:
            assert current['observedMinutes'] >= 30 and current['cycles'] >= 15
            assert current['terminal']['failures'] == 0 and not current['terminal']['errors']
        if refresh:
            assert terminal['taskStartedAt'] == '2026-10-18T13:42:06+08:00', 'Cannot reuse prior task timing'
            assert terminal['earliestTaskCompletion'] == '2026-10-18T16:42:06+08:00'
    for name, expected in build['files'].items():
        assert digest((ROOT/'dist'/name).read_bytes()) == expected, 'Stale build stamp: '+name
    desktop_root = ROOT/'release/desktop/DiningLab'
    for name, expected in build['files'].items():
        assert digest((desktop_root/'_internal/dist'/name).read_bytes()) == expected, 'Desktop needs rebuilding: '+name
    assert (desktop_root/'_internal/dist/build-info.js').read_bytes() == (ROOT/'dist/build-info.js').read_bytes()
    license_files = files_under('licenses')
    desktop_entries = [(p, 'DiningLab/'+p.relative_to(desktop_root).as_posix()) for p in sorted(desktop_root.rglob('*')) if p.is_file()]
    desktop_entries += [(p, 'DiningLab/licenses/'+p.name) for p in license_files]
    desktop_entries.append((ROOT/'PROVENANCE.txt', 'DiningLab/PROVENANCE.txt'))
    desktop_readme = ('食刻 · 校园食堂仿真实验室\n\n完整解压后双击DiningLab.exe，保留_internal文件夹。'
                      '程序使用本机WebView2 Runtime。所有默认数值为合成教学假设，不是滨河学校实测。'
                      '\n学习与研究文章、源码、场景和逐轮实验数据见配套“源码与研究材料”包。'
                      '\n首次先看默认场景，再保存方案A、只改一个条件、运行配对比较并导出记录。'
                      '\n若电脑缺少WebView2，可使用源码包dist/index.html离线运行。\n')
    reports = [package(label+'_Windows桌面版.zip', desktop_entries, {'DiningLab/先读我.txt':desktop_readme})]
    source_files = [ROOT/name for name in ['README.md','PROVENANCE.txt','package.json','package-lock.json','.gitattributes','.prettierrc.json']]
    for folder in ['dist','desktop','tests','tools','learning','scenarios','examples','data','figures','documents','licenses']:
        source_files += files_under(folder)
    research_names = ['evidence-register.json','experiment-protocol.json','retrieval-manifest.json','award-list-verification.json','规则与证据说明.md','获奖资料复核.md']
    if decision:
        research_names += [p.name for p in sorted((ROOT/'research').glob('decision-*.json'))]
        research_names += ['补充调研与适用边界.md']
        source_files += sorted(ROOT.glob('SPEC-*.md'))
        source_files += [ROOT/'CAPABILITY-MAP.md']
    source_files += [ROOT/'research'/name for name in research_names]
    source_files += files_under('research/reference-files')
    qa_names = ['code-review.md','artifact.md','document-render.json','document-audit.json','ui-check.json','ui-data-check.json','ui-keyboard-check.json','ui-interruption-check.json','ui-scale-check.json','stress-audit.json','oracle-result.json','desktop-exe-test.json','desktop-download-check.json','desktop-click-check.json']
    if refresh:
        qa_names += ['ui-refresh-check.json','refresh-form-baseline.json','refresh-baseline.json','refresh-final.json','guide-refresh-edit.json','refresh-code-review.md',
                     'refresh-startup-load-before.json','refresh-startup-load.json','refresh-startup-investigation.md','refresh-soak-input-check.json']
    if decision:
        qa_names += ['ui-refresh-check.json','refresh-form-baseline.json','ui-decision-check.json','refresh-decision-final.json','ui-soak-repeat-check.json',
                     'decision-soak-investigation.md','soak-decision-round1.jsonl','soak-decision-round2-failed.jsonl','decision-soak-repro-red.log',
                     'decision-document-visual-review.json','decision-writing-audit.md',
                     'decision-figure-audit.json','decision-figure-contract.md','decision-code-review.md',
                     'decision-core-tests.log','decision-learning-tests.log',
                     '04-grade-tradeoff-alignment.json','04-grade-tradeoff-collisions.json','04-grade-tradeoff-text.json',
                     '05-scenario-grade-effects-alignment.json','05-scenario-grade-effects-collisions.json','05-scenario-grade-effects-text.json']
    source_files += [ROOT/'qa'/name for name in qa_names]
    source_files += final_evidence
    entries = [(p, label+'/'+p.relative_to(ROOT).as_posix()) for p in sorted(set(source_files))]
    reports.append(package(label+'_源码与研究材料.zip', entries, {}))
    materials = [(p,p.name) for p in files_under('documents',{'.docx'})]
    reports.append(package(label+'_Word文章与指南.zip',materials,{'材料说明.txt':'这两份Word是研究报告和学习指南，包含AI辅助及合成实验说明。不是已完成的整套官方申报文件。区级通知的6MB限制包括全部申报PDF、Word与附件。学生实测、本人贡献、签字盖章和正式查新查重材料须按真实情况及学校要求办理。\n'}))
    result = {'build':build['id'],'iteration':'research-decision-support' if decision else 'interface-refresh' if refresh else 'original-rebuild','stage':'final' if final_requested else 'candidate','packages':reports,'documentBytes':sum(p.stat().st_size for p in files_under('documents',{'.docx'}))}
    (OUT/'package-index.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(result,ensure_ascii=True))


if __name__ == '__main__':
    main()
