from pathlib import Path
import json, urllib.request, hashlib, datetime, concurrent.futures
root=Path('research');root.mkdir(exist_ok=True)
urls={
 'school-2026-plan.pdf':'https://edu.xa.gov.cn/web_files/edu/file/2026/07/16/202607161006095103689.pdf',
 'Usluer-2025-campus-dining.pdf':'https://dergipark.org.tr/en/download/article-file/3704159',
 'Ivan-2021-class-scheduling.pdf':'https://www.cal-tek.eu/proceedings/i3m/2021/emss/037/pdf.pdf',
 'Curin-2005-campus-fast-food.pdf':'https://informs-sim.org/wsc05papers/331.pdf',
 'Perez-Riano-2007-cafeteria.pdf':'https://www.redalyc.org/pdf/1210/121014223002.pdf'
}
repos=['martokh/discrete-event-simulation','heyxingxing/canteen-sim','doufutangvgood/canteen-seat-sim','keisanmono/bjtu-dining-sim','jaamsim/jaamsim','djordon/queueing-tool']
for repo in repos:
 for part in ['', '/commits?per_page=1', '/license']:
  label={'':'metadata','/commits?per_page=1':'head','/license':'license'}[part]
  urls[repo.replace('/','_')+'-'+label+'.json']='https://api.github.com/repos/'+repo+part

def fetch(item):
 name,url=item
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'School-Dining-Research/2.0'})
  with urllib.request.urlopen(req, timeout=25) as response: data=response.read()
  (root/name).write_bytes(data)
  return {'file':name,'url':url,'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'status':'retrieved'}
 except Exception as exc: return {'file':name,'url':url,'status':'failed','reason':str(exc)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(fetch,urls.items()))
(root/'retrieval-manifest.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'retrieved':sum(r['status']=='retrieved' for r in results),'failed':[r for r in results if r['status']=='failed']},ensure_ascii=False))
