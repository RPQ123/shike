"""Editable lunch-study illustrations; furniture is symbolic, not surveyed.

Repeated furniture and icons are generated from grids, retaining editable shapes.
"""
from pathlib import Path
import json
import xml.etree.ElementTree as E

OUT=Path(__file__).resolve().parents[1]/'figures/student'
INK='#243746'; MUTED='#687C89'; TEAL='#188779'; BLUE='#54799B'
AMBER='#D5A055'; LINE='#C8D2D8'

class Drawing:
    def __init__(self,name,w,h):
        self.file=E.Element('mxfile',host='drawio',version='32.5.5')
        page=E.SubElement(self.file,'diagram',name=name,id=name)
        model=E.SubElement(page,'mxGraphModel',grid='1',gridSize='10',page='1',pageScale='1',pageWidth=str(w),pageHeight=str(h),background='#ffffff')
        self.root=E.SubElement(model,'root')
        E.SubElement(self.root,'mxCell',id='0');E.SubElement(self.root,'mxCell',id='1',parent='0')

    def shape(self,id,x,y,w,h,fill='none',stroke=LINE,extra='',parent='1',text='',font=27,bold=False):
        style=f'rounded=1;arcSize=10;whiteSpace=wrap;html=1;fillColor={fill};strokeColor={stroke};strokeWidth=1.5;fontColor={INK};fontFamily=FangSong;fontSize={font};fontStyle={1 if bold else 0};spacing=0;{extra}'
        cell=E.SubElement(self.root,'mxCell',id=id,value=text,style=style,vertex='1',parent=parent)
        E.SubElement(cell,'mxGeometry',x=str(x),y=str(y),width=str(w),height=str(h),attrib={'as':'geometry'})
        return id

    def text(self,id,text,x,y,w,h,font=27,bold=False,color=INK,parent='1'):
        return self.shape(id,x,y,w,h,'none','none',f'fontColor={color};rounded=0;',parent,text,font,bold)

    def group(self,id,x,y,w,h,parent='1'):
        return self.shape(id,x,y,w,h,'none','none','group;container=1;pointerEvents=0;',parent)

    def reparent(self,id,parent):
        cell=next(c for c in self.root if c.get('id')==id)
        owner=next(c for c in self.root if c.get('id')==parent)
        g=cell.find('mxGeometry');p=owner.find('mxGeometry')
        g.set('x',str(float(g.get('x'))-float(p.get('x'))))
        g.set('y',str(float(g.get('y'))-float(p.get('y'))))
        cell.set('parent',parent)

    def path(self,id,points,color=LINE,width=2,arrow=False,double=False,dashed=False):
        style=f'edgeStyle=none;rounded=1;orthogonalLoop=1;jettySize=auto;html=1;strokeColor={color};strokeWidth={width};endArrow={"classic" if arrow else "none"};endSize=10;'
        if double:style+='startArrow=classic;startSize=10;'
        if dashed:style+='dashed=1;dashPattern=5 4;'
        cell=E.SubElement(self.root,'mxCell',id=id,style=style,edge='1',parent='1')
        g=E.SubElement(cell,'mxGeometry',relative='1',attrib={'as':'geometry'})
        for key,p in [('sourcePoint',points[0]),('targetPoint',points[-1])]:
            E.SubElement(g,'mxPoint',x=str(p[0]),y=str(p[1]),attrib={'as':key})
        if len(points)>2:
            a=E.SubElement(g,'Array',attrib={'as':'points'})
            for x,y in points[1:-1]:E.SubElement(a,'mxPoint',x=str(x),y=str(y))

    def person(self,id,x,y,color=BLUE,s=1,parent='1'):
        self.group(id,x,y,30*s,50*s,parent)
        self.shape(id+'-head',8*s,0,14*s,14*s,color,'none','ellipse;',id)
        self.shape(id+'-body',3*s,18*s,24*s,30*s,color,'none','arcSize=35;',id)

    def counter(self,id,x,y,parent='1',w=90,h=60):
        self.group(id,x,y,w,h,parent)
        self.shape(id+'-body',0,0,w,h,'#E4ECF3','#8CA6BA','arcSize=8;container=1;pointerEvents=0;',id)
        self.shape(id+'-ledge',0,h-14,w,14,BLUE,'none','rounded=0;',id+'-body')
        for i in range(3):self.shape(id+f'-pan{i}',12+i*23,12,18,18,'#FDFCF8','#A5B4BF','ellipse;',id+'-body')

    def table(self,id,x,y,parent='1',s=1):
        self.group(id,x,y,110*s,80*s,parent)
        for i,xx in enumerate([18,65]):
            for j,yy in enumerate([0,60]):self.shape(id+f'-seat{i}{j}',xx*s,yy*s,27*s,18*s,'#D4DFDE','#B6C8C4','arcSize=30;',id)
        self.shape(id+'-top',0,22*s,110*s,36*s,'#E4D6BD','#BCAE94','arcSize=6;',id)

    def building(self,id,x,y):
        self.group(id,x,y,100,80)
        self.shape(id+'-body',10,10,80,70,'#E7EEF3',BLUE,'rounded=0;container=1;pointerEvents=0;',id)
        for i in range(3):
            for j in range(2):self.shape(id+f'-w{i}{j}',10+i*23,10+j*22,13,13,'#AEC2D2','none','rounded=0;',id+'-body')
        self.shape(id+'-door',33,55,16,15,BLUE,'none','rounded=0;',id+'-body')

    def tray(self,id,x,y):
        self.group(id,x,y,100,70)
        self.shape(id+'-base',0,10,100,60,'#E0EEEB','#83B3AA','arcSize=12;container=1;pointerEvents=0;',id)
        self.shape(id+'-plate',12,10,42,42,'#FFFFFF','#83B3AA','ellipse;container=1;pointerEvents=0;',id+'-base')
        self.shape(id+'-rice',9,9,24,24,'#EBE4D0','none','ellipse;',id+'-plate')
        for i in range(2):self.shape(id+f'-dish{i}',65,12+i*22,22,16,'#C4D9CF','none','arcSize=20;',id+'-base')

    def save(self,stem):
        E.indent(self.file)
        E.ElementTree(self.file).write(OUT/(stem+'.drawio'),encoding='utf-8',xml_declaration=True)

# Floor plan: counters on both sides, central tables, front/rear entrances.
d=Drawing('食堂布局与动线',1100,680)
d.text('rear','后端出入口',410,0,280,50,30,True)
d.text('front','前端出入口',410,560,280,50,30,True)
for name,points in [('wall-tl',[(50,550),(50,80),(480,80)]),('wall-tr',[(620,80),(1050,80),(1050,550)]),('wall-bl',[(50,550),(480,550)]),('wall-br',[(620,550),(1050,550)])]:d.path(name,points,'#A5B4BC',4)
d.shape('aisle',490,155,120,370,'#EFF3F4','none','rounded=0;')
d.text('left-title','取餐窗口',60,100,160,40,28,True)
d.text('right-title','取餐窗口',880,100,160,40,28,True)
d.text('seating-title','就餐区',390,105,320,40,28,True)
for side,x in [('left',95),('right',915)]:
    for i in range(4):d.counter(f'{side}-window-{i}',x,165+i*90,w=90,h=60)
for row in range(3):
    for col,x in enumerate([350,640]):d.table(f'table-{row}-{col}',x,175+row*115)
for i in range(4):d.person(f'waiting-{i}',205+i*30,450,'#C29C65',.62)
d.path('arrive-route',[(550,570),(550,505),(350,505),(350,465),(335,465)],BLUE,4,True)
d.path('seat-route',[(190,440),(320,440),(320,330),(340,330)],TEAL,4,True)
d.path('rear-entry',[(550,50),(550,90)],MUTED,2.5,True,True)
d.path('legend-arrival',[(170,635),(235,635)],BLUE,4,True)
d.text('legend-arrival-label','取餐路线',250,610,150,50,27,True)
d.path('legend-seat',[(470,635),(535,635)],TEAL,4,True)
d.text('legend-seat-label','入座路线',550,610,150,50,27,True)
d.person('legend-person',810,620,'#C29C65',.6)
d.text('legend-person-label','等候学生',850,610,150,50,27,True)
d.save('11-hall-plan')

# Left-to-right journey, with separate queue and complete-duration brackets.
d=Drawing('就餐流程与时间记录',1120,380)
xs=[70,260,450,640,830,1020]
labels=['等待出发','步行到达','选窗排队','开始打饭','等座用餐','返回教室']
for i,x in enumerate(xs):
    d.text(f'number-{i}',f'{i+1:02}',x-35,10,70,40,25,True,TEAL if i==2 else MUTED)
    d.shape(f'icon-bg-{i}',x-62,65,124,114,'#F4F8F7' if i==2 else '#F7F9FA','none','ellipse;container=1;pointerEvents=0;')
    d.text(f'label-{i}',labels[i],max(0,x-90),190,140 if i==0 else 180,50,29,True)
    if i<5:d.path(f'step-{i}',[(x+76,125),(xs[i+1]-76,125)],TEAL if i==2 else '#ADBCC6',3,True)
d.building('departure',20,85)
d.path('walk-floor',[(225,155),(300,155)],BLUE,3)
for i in range(3):d.person(f'walking-{i}',230+i*22,95+i%2*8,BLUE,.62)
for i in range(3):d.person(f'queue-{i}',410+i*25,100,TEAL,.75)
d.tray('meal-tray',590,90)
d.table('meal-table',780,88,s=.9)
d.building('return',970,85)
for id,parent in [('departure','icon-bg-0'),('meal-tray','icon-bg-3'),('meal-table','icon-bg-4'),('return','icon-bg-5')]:d.reparent(id,parent)
for i in range(3):
    d.reparent(f'walking-{i}','icon-bg-1');d.reparent(f'queue-{i}','icon-bg-2')
d.path('queue-bracket',[(450,255),(450,270),(640,270),(640,255)],TEAL,3)
d.text('queue-label','排队时间',445,276,200,45,28,True,TEAL)
d.path('complete-bracket',[(70,325),(70,340),(1020,340),(1020,325)],'#96A9B4',2)
d.text('complete-label','完整用时',450,342,190,35,26,True)
d.save('12-meal-flow')

# Identical time scales make the worked arithmetic comparison visible.
d=Drawing('窗口取餐耗时比较',1100,460)
d.text('axis-label','预计取餐耗时 / 秒',400,0,600,45,29,True)
for t in range(0,31,5):
    x=400+t*20
    d.path(f'grid-{t}',[(x,95),(x,350)],'#E0E7EA',1.2)
    d.text(f'tick-{t}',str(t),x-28,50,56,40,24,True)
for key,y,title,state,time in [('a',130,'甲窗口','空闲',30),('b',280,'乙窗口','服务中',10)]:
    d.counter(key+'-counter',25,y+5,w=90,h=60)
    d.text(key+'-title',title,140,y-5,210,40,31,True)
    d.text(key+'-state',f'{state} · 每份{time}秒',130,y+40,235,40,25)
d.shape('a-own',400,140,600,55,TEAL,'none','rounded=0;fontColor=#FFFFFF;',text='本人取餐',font=28,bold=True)
d.shape('b-current',400,290,100,55,AMBER,'none','rounded=0;',text='5秒',font=26,bold=True)
d.shape('b-own',500,290,200,55,TEAL,'none','rounded=0;fontColor=#FFFFFF;',text='本人取餐',font=28,bold=True)
d.text('a-total','30秒',930,200,120,45,32,True,TEAL)
d.text('b-total','15秒',650,350,120,45,32,True,TEAL)
d.shape('legend-previous',320,420,34,20,AMBER,'none','rounded=0;')
d.text('legend-previous-label','前序服务',370,403,160,50,27,True)
d.shape('legend-own',630,420,34,20,TEAL,'none','rounded=0;')
d.text('legend-own-label','本人取餐',680,403,160,50,27,True)
d.save('13-window-choice')

(OUT/'figure-contract.json').write_text(json.dumps({
 'backend':'draw.io native XML / official viewer','audience':'高中学生与竞赛评审',
 'font':'FangSong; bold labels and main values',
 'figures':[
  {'name':'11-hall-plan','claim':'两侧取餐、中央就餐、前后进出；路线指向窗口和座位','source':'用户提供的空间关系；家具符号及比例为绘图示意'},
  {'name':'12-meal-flow','claim':'就餐过程由左至右排列，标出排队与完整用时','source':'原800次研究模型的流程顺序；完整用时含出发前等待'},
  {'name':'13-window-choice','claim':'相同时间刻度下，乙15秒、甲30秒完成取餐','source':'r+(q+1)m算术例；无其他等候者'}],
 'legendStyle':'noun labels only; no explanatory sentences',
 'formats':['drawio','png','svg','pdf'],
 'colors':{'primary':TEAL,'arrival':BLUE,'waiting':AMBER,'text':INK}
},ensure_ascii=False,indent=2),encoding='utf-8')
print('Created three pictorial editable figures with FangSong typography.')
