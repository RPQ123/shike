// Deterministic structural stress checks; these are synthetic inputs, not calibration.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const E=require('../dist/school-engine.js');
const R=require('../dist/research.js');
let randomState=0x51824061;
const random=()=>{randomState=(Math.imul(randomState,1664525)+1013904223)>>>0;return randomState/4294967296};
const integer=(min,max)=>min+Math.floor(random()*(max-min+1));
const close=(a,b,label)=>assert.ok(Math.abs(a-b)<=1e-7*Math.max(1,Math.abs(a),Math.abs(b)),label);
const report={at:new Date().toISOString(),seed:0x51824061,scope:'pickup/seat scheduling, event ordering, conservation, time integrals; synthetic valid two-zone configurations',cases:[],failures:[]};
const started=performance.now();
for(let index=0;index<120;index++){
 const c=R.example();
 c.seed=integer(0,4294967295);c.windows=index%3===0?12:6;
 c.windowOwners=Array.from({length:c.windows},(_,i)=>i%3);
 c.windowZones=Array.from({length:c.windows},(_,i)=>Math.floor(i/3)%2);
 c.windowMeans=Array.from({length:c.windows},()=>integer(1,600));
 c.strategy=['shortest','workload','pooled','random'][index%4];
 c.allocation=['shared','dedicated','overflow'][Math.floor(index/4)%3];
 c.serviceCV=[0,.35,1][index%3];c.mealCV=[0,.2,1][Math.floor(index/3)%3];
 c.serviceStart=integer(0,60);c.serviceEnd=c.serviceStart+integer(1,100);
 c.seats=integer(2,300);c.serviceZones[0].seats=integer(1,c.seats-1);c.serviceZones[1].seats=c.seats-c.serviceZones[0].seats;
 c.seatPoolByZone=index%2?[0,0]:[0,1];c.seatWaitingCapacity=index%4===0?0:null;
 c.mealMean=integer(1,90);c.returnMinutes=integer(0,60);
 c.grades.forEach((g,i)=>{
  g.students=index%11===0&&i===0?0:integer(1,index%10===0?1600:180);
  g.classes=g.students?Math.min(g.students,integer(1,12)):0;
  g.readyTime=integer(0,20);g.releaseTime=g.readyTime+integer(0,20);
  g.latestReleaseTime=null;g.classInterval=random()*3;
  g.assemblyMax=random()*5;g.walkMin=random()*3;g.walkMax=g.walkMin+random()*10;
  g.deadline=integer(40,720);const share=random();c.gradeZoneWeights[i]=[share,1-share];
 });
 c.students=c.grades.reduce((sum,g)=>sum+g.students,0);
 c.serviceZones.forEach(z=>{z.walkExtra=random()*15;z.returnExtra=random()*15});
 const caseStart=performance.now();
 try{
  const r=E.simulateSchool(c),people=r.students;
  assert.equal(people.length,c.students);
  for(const s of people){
   const times=[s.readyTime,s.release,s.arrival,s.start,s.end,s.seatStart,s.mealEnd,s.endpointTime];
   assert.ok(times.every(Number.isFinite),'finite event times');
   for(let i=1;i<times.length;i++)assert.ok(times[i]>=times[i-1]-1e-8,'event order');
   close(s.wait,s.start-s.arrival,'queue difference');
   close(s.seatWait,s.seatStart-s.end,'seat difference');
   close(s.readyToEndpoint,s.endpointTime-s.readyTime,'whole time');
  }
  for(const [key,start,end] of [['window','start','end'],['seatId','seatStart','mealEnd']]){
   const resources=new Map();
   for(const s of people){if(!resources.has(s[key]))resources.set(s[key],[]);resources.get(s[key]).push(s)}
   for(const rows of resources.values()){
    rows.sort((a,b)=>a[start]-b[start]||a.id-b.id);
    for(let i=1;i<rows.length;i++)assert.ok(rows[i][start]>=rows[i-1][end]-1e-8,'resource must not overlap');
   }
  }
  const sum=key=>people.reduce((total,s)=>total+s[key],0);
  close(r.metrics.queueIntegral,sum('wait'),'queue area');
  close(r.metrics.seatQueueIntegral,sum('seatWait'),'seat queue area');
  close(r.metrics.seatOccupancyIntegral,sum('mealDuration'),'seat occupancy area');
  for(const time of [0,r.metrics.observationEnd,...Array.from({length:12},()=>random()*r.metrics.observationEnd)]){
   const s=E.snapshot(r,time);
   assert.equal(s.notArrived+s.waiting+s.inService+s.seatWaiting+s.dining+s.returning+s.returned,c.students,'population conservation');
   assert.ok(s.dining<=c.seats,'seat capacity');
   assert.ok(s.inService<=c.windows,'window capacity');
  }
  report.cases.push({index,seed:c.seed,people:c.students,windows:c.windows,seats:c.seats,strategy:c.strategy,allocation:c.allocation,sharedSeats:index%2===1,observationMinutes:r.metrics.observationEnd,milliseconds:performance.now()-caseStart});
 }catch(error){
  const failed={index,error:String(error),config:c};report.failures.push(failed);
  fs.writeFileSync(`qa/stress-failure-${index}.json`,JSON.stringify(failed,null,2));
 }
}
report.elapsedMilliseconds=performance.now()-started;
fs.writeFileSync('qa/stress-audit.json',JSON.stringify(report,null,2));
console.log(JSON.stringify({cases:report.cases.length,failures:report.failures.length,milliseconds:report.elapsedMilliseconds}));
if(report.failures.length)process.exitCode=1;
