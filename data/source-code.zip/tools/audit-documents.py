"""Check document provenance and bind the recorded page review to exact DOCX bytes."""
from pathlib import Path
from zipfile import ZipFile
import hashlib
import json
import xml.etree.ElementTree as ET
import sys

ROOT = Path(__file__).resolve().parents[1]
NS = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
sha = lambda b: hashlib.sha256(b).hexdigest()
template = ROOT / 'documents/templates/公文模板.docx'
if not template.is_file(): template = ROOT.parent / '公文模板（先复制）.docx'
assert sha(template.read_bytes()) == 'ec93c69c2f33639421d1d89cf4fc1e1b0f926b6b1c9bee8ce3fda7167a523ae7'
innovation = '--innovation' in sys.argv
review = json.loads((ROOT/'qa'/('innovation-document-visual-review.json' if innovation else 'decision-document-visual-review.json')).read_text(encoding='utf8'))
render = json.loads((ROOT/'qa/document-render.json').read_text(encoding='utf8'))
images = dict(zip(['word/media/image1.png','word/media/image2.png','word/media/image3.png','word/media/image4.png'],
                  ['06-class-timetable.png','07-component-comparison.png','08-feedback-vs-cyclic.png','09-five-meal-prefix.png'] if innovation else ['01-queue-vs-whole.png','02-flow-decomposition.png','04-grade-tradeoff.png','05-scenario-grade-effects.png']))
records = []
with ZipFile(template) as original:
    sect = ET.tostring(ET.fromstring(original.read('word/document.xml')).find('.//w:sectPr', NS))
    preserved = [n for n in original.namelist() if n.startswith(('word/styles','word/theme/','word/footer','word/header','word/fontTable','word/numbering')) and n.endswith('.xml')]
    for key, rendered in zip(['report','guide'], render):
        path = ROOT/'documents'/rendered['source']
        digest = sha(path.read_bytes())
        assert digest == rendered['sha256'] == review[key]['sha256']
        assert review[key]['pagesReviewed'] == list(range(1, rendered['pages']+1))
        assert all(n > 100 for n in rendered['pageCharacterCounts']), 'Unexpected empty or sparse page'
        with ZipFile(path) as z:
            xml = ET.fromstring(z.read('word/document.xml'))
            assert ET.tostring(xml.find('.//w:sectPr',NS)) == sect, 'Template page geometry changed'
            for name in preserved:
                # python-docx may rewrite an XML declaration in accessed headers/footers.
                # Compare the complete parsed tree so serialization alone is not a defect.
                assert ET.tostring(ET.fromstring(z.read(name))) == ET.tostring(ET.fromstring(original.read(name))), 'Unintended template change: '+name
            assert not any(n.startswith('customXml/') for n in z.namelist())
            core = ET.fromstring(z.read('docProps/core.xml'))
            assert not core.findtext('{http://purl.org/dc/elements/1.1/}creator')
            assert not core.findtext('{http://schemas.openxmlformats.org/package/2006/metadata/core-properties}lastModifiedBy')
            text = ''.join(xml.itertext())
            assert 'AI' in text and ('合成' in text or '模拟' in text)
            media = [n for n in z.namelist() if n.startswith('word/media/')]
            if key == 'report':
                assert set(media) == set(images)
                for name, source in images.items():
                    assert z.read(name) == (ROOT/'figures'/source).read_bytes()
            else:
                assert not media
            records.append({'file': path.name,'sha256':digest,'pages':rendered['pages'],
                            'bytes':path.stat().st_size,'mediaCount':len(media),
                            'customIdentityRemoved':True,'syntheticAndAIDisclosure':True})
result = {'templateUnchanged':True,'templatePartsPreserved':preserved,'documents':records,
          'combinedBytes':sum(r['bytes'] for r in records),'visualInspection':review,
          'reportImageSources':images}
(ROOT/'qa/document-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps({'documents':len(records),'pages':[r['pages'] for r in records],
                  'combinedBytes':result['combinedBytes'],'templatePartsPreserved':len(preserved)}))
