const fs=require('node:fs'),crypto=require('node:crypto');
const S=require('../dist/schedule-study'),B=require('../dist/binhe-cohort'),R=require('../dist/research');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const base=B.create();base.grades.forEach(g=>{g.latestReleaseTime=100;g.deadline=100});
base.sourceProfile={id:'generic-school-1610',title:'高中就餐示例 · 1610人',asOf:'2026-10-19',status:'research-assumptions',observedSchoolData:false};
const protocol={schema:'dining-three-schedules-protocol/1',createdAt:new Date().toISOString(),evidence:'synthetic',base,
  options:{order:[2,1,0],gradeGapMinutes:10,slotSeconds:60},coarseGaps:[0,15,30,45,60,75,90,105,120],
  refinement:'Around the feasible coarse winner, test its +/-5 and +/-10 seconds not already tested, bounded by 0..600. If a feasible winner reaches the maximum coarse gap, extend by 15/30 seconds before refinement.',
  selection:'Among rows whose latest individual return in every screening round is <=13:00, minimize mean queue time, then mean complete time, then slot seconds. Preserve unconstrained minimum separately.',
  seeds:{initial:Array.from({length:30},(_,i)=>93001+i),screening:Array.from({length:30},(_,i)=>94001+i),verification:Array.from({length:30},(_,i)=>95001+i),gradeCheck:Array.from({length:30},(_,i)=>96001+i)},
  gradeGapCheck:[5,10,15],returnTarget:100,commonReady:30,
  numericMeaning:'Minutes after 11:20; 11:50 common allowed start, 13:00 example return target. 1610 people and capacities are scenario parameters, not field observations.'};
fs.writeFileSync('data/schedule-study-protocol.json',JSON.stringify(protocol,null,2));
const executions=[];
function evaluate(stage,id,label,config,seeds,seconds=null){
  const result=S.evaluate(config,seeds),row={id,label,seconds,...result};
  result.rounds.forEach(r=>executions.push({stage,id,seconds:seconds??'',...r}));
  console.log(JSON.stringify({stage,id,wait:row.summary.meanWait,lastMax:row.summary.lastEndpointMax}));return row;
}
const initial=S.three(base,protocol.options).map(p=>evaluate('initial',p.id,p.label,p.config,protocol.seeds.initial));
const gapRows=[];
function gap(seconds){if(!gapRows.some(r=>r.seconds===seconds))gapRows.push(evaluate('interval','gap-'+seconds,seconds+'秒',S.makeConfig(base,'combined',{...protocol.options,slotSeconds:seconds}),protocol.seeds.screening,seconds));}
protocol.coarseGaps.forEach(gap);
let winner=S.select(gapRows,protocol.returnTarget);
if(winner&&winner.seconds===Math.max(...protocol.coarseGaps)){gap(winner.seconds+15);gap(winner.seconds+30);winner=S.select(gapRows,protocol.returnTarget)}
if(winner)for(const offset of [-10,-5,5,10]){const sec=winner.seconds+offset;if(sec>=0&&sec<=600)gap(sec)}
gapRows.sort((a,b)=>a.seconds-b.seconds);winner=S.select(gapRows,protocol.returnTarget);
const finalOptions={...protocol.options,slotSeconds:winner?.seconds??protocol.options.slotSeconds};
const verification=S.three(base,finalOptions).map(p=>evaluate('verification',p.id,p.label,p.config,protocol.seeds.verification));
const gradeCheck=protocol.gradeGapCheck.map(minutes=>evaluate('grade-gap','grade-'+minutes,minutes+'分钟',S.makeConfig(base,'grade',{...protocol.options,gradeGapMinutes:minutes}),protocol.seeds.gradeCheck));
const sourceHashes={};for(const name of ['dist/engine.js','dist/school-engine.js','dist/hall-walk.js','dist/schedule-study.js','dist/research.js','tools/run-schedule-study.cjs'])sourceHashes[name]=sha(fs.readFileSync(name));
const result={schema:'dining-three-schedules/1',evidence:'synthetic',completedAt:new Date().toISOString(),protocol,protocolSha256:sha(fs.readFileSync('data/schedule-study-protocol.json')),sourceHashes,executions:executions.length,initial,intervals:gapRows,selectedSeconds:winner?.seconds??null,unconstrainedBest:gapRows.slice().sort((a,b)=>a.summary.meanWait-b.summary.meanWait)[0].seconds,verification,gradeCheck};
fs.writeFileSync('data/schedule-study-results.json',JSON.stringify(result,null,2));
fs.writeFileSync('data/schedule-study-rounds.csv',R.csv(executions));
fs.writeFileSync('data/schedule-study-summary.csv',R.csv([...initial.map(r=>({stage:'initial',id:r.id,seconds:'',...r.summary})),...gapRows.map(r=>({stage:'interval',id:r.id,seconds:r.seconds,...r.summary})),...verification.map(r=>({stage:'verification',id:r.id,seconds:r.id==='combined'?finalOptions.slotSeconds:'',...r.summary})),...gradeCheck.map(r=>({stage:'grade-gap',id:r.id,seconds:'',...r.summary}))]));
const selected=verification.find(r=>r.id==='combined');
fs.writeFileSync('data/schedule-study-session.json',JSON.stringify(R.session(selected.config),null,2));
const P=require('../dist/planner');
fs.writeFileSync('data/schedule-study-timetable.csv',R.csv(P.timetable(selected.config).map(r=>({方案:'年级与班级结合错峰',相邻组间隔秒:finalOptions.slotSeconds,年级:r.gradeName,班序:r.classIndex+1,人数:r.students,出发时刻:R.clockLabel(r.release)}))));
console.log(JSON.stringify({complete:true,executions:result.executions,selectedSeconds:result.selectedSeconds,verification:verification.map(r=>({id:r.id,wait:r.summary.meanWait,total:r.summary.meanTotal,last:r.summary.lastEndpoint,lastMax:r.summary.lastEndpointMax}))}));
