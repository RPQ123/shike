"""Measure the hidden QA host's scheduling, without changing production behavior."""
from pathlib import Path
import json,time,webview
ROOT=Path(__file__).resolve().parents[1]
window=webview.create_window('Hidden planner timing diagnostic',(ROOT/'dist/index.html').as_uri(),hidden=True)
result={'samples':[]}
def diagnose():
 try:
  assert window.events.loaded.wait(30)
  deadline=time.monotonic()+20
  while not window.evaluate_js('!!window.DiningLabSnapshot'):
   assert time.monotonic()<deadline
   time.sleep(.1)
  result['environment']=window.evaluate_js('({visibility:document.visibilityState,hidden:document.hidden,userAgent:navigator.userAgent,build:window.DiningLabSnapshot.build.id})')
  start=time.monotonic()
  window.evaluate_js("document.querySelector('[data-tab=search]').click();document.getElementById('planner-run').click()")
  while time.monotonic()-start<18:
   sample=window.evaluate_js("({busy:window.DiningLabSnapshot.busy,progress:document.getElementById('planner-progress')?.value,max:document.getElementById('planner-progress')?.max,error:document.getElementById('message-body').textContent,candidates:window.DiningLabSnapshot.planner?.candidateCount})")
   result['samples'].append({'seconds':time.monotonic()-start,**sample})
   if not sample['busy']:break
   time.sleep(1)
 finally:
  (ROOT/'qa/webview-planner-diagnosis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
  window.destroy()
webview.start(diagnose,gui='edgechromium',private_mode=True,storage_path=str(ROOT/'qa/webview-diagnosis-profile'))
print(json.dumps(result,ensure_ascii=True))
