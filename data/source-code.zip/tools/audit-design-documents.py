"""Bind the admission-scale report to actual calculations and retained template."""
from pathlib import Path
from zipfile import ZipFile
import json,hashlib,csv,re,argparse
from docx import Document
from report_common import number as f
from report_admission import clock
root=Path(__file__).resolve().parents[1]
s=json.loads((root/'data/binhe-cohort-results.json').read_text('utf-8'))
parser=argparse.ArgumentParser()
parser.add_argument('--document-dir',default='documents/design-edition')
parser.add_argument('--prefix',default='design')
args=parser.parse_args()
folder=root/args.document_dir
report=Document(folder/'研究报告_公文格式.docx')
text='\n'.join(p.text for p in report.paragraphs)
assert len(report.tables)==6 and len(report.inline_shapes)==4
assert all(t in text for t in ['高一580人','高二530人','高三500人','共1610人','共800次','人数采用教育局公布的高中招生计划','表2的参数设置','使用了AI辅助'])
assert all(t not in text for t in ['全国一等奖','实测表明','已在学校应用','边界条件','P95','95%','路由','独立种子'])
headings=['一、研究背景','二、研究目的','三、资料收集','四、具体想法','五、工作计划','六、具体实施计划','七、结论']
assert [p.text for p in report.paragraphs if p.text in headings]==headings
assert report.paragraphs[0].text.replace('\n','')=='校园食堂错峰就餐与窗口分配仿真软件的设计与实现'
assert all(word not in text for word in ['Windows','封装','按钮','界面操作','软件的价值','作为高中生','制作一套'])
background=text.split('一、研究背景',1)[1].split('二、研究目的',1)[0]
assert all(word in background for word in ['年级错峰','两侧','座位','前后','班级出发间隔'])
assert '评价学生就餐方案的关键，是看学生的平均就餐排队时间是否缩短' in background
assert '窗口配置' not in text and '评价午餐安排' not in text
assert text.count('滨河')==1
abstract=next(p.text for p in report.paragraphs if p.text.startswith('摘要：'))
assert not re.search(r'[0-9０-９]',abstract)
assert abstract.startswith('摘要：本研究设计了一套')
assert all(word in abstract for word in ['班级放行表','开放窗口数量和可用座位数量的建议','使用仿真软件比较','高一至高三年级学生的平均就餐排队时间'])
assert all(word not in abstract for word in ['仿真结果支持','滨河','招生计划','Usluer','Kambli'])
assert all(word not in text for word in ['需要强调的是','值得注意的是','这并不意味着','不能简单地','并非','不是对学校现行作息的转录','不能保证','不能只','不代表','Usluer','Kambli','SimPy','Three.js','Ege Academic','Hospitality and Tourism'])
purpose=text.split('二、研究目的',1)[1].split('三、资料收集',1)[0]
assert '各班出发的顺序和间隔' in purpose and '校园就餐方案' in purpose and '设计' in purpose and '制作' not in purpose
assert '窗口数、座位数及各环节用时采用表2的参数设置' in text
conclusion=text.split('七、结论',1)[1].split('参考资料',1)[0]
assert all(word in conclusion for word in ['班级交错出发','开放窗口数量和可用座位数量','课表','平均排队时间'])
assert all(word not in conclusion for word in ['软件功能','设计了一套','完成了软件','三维界面'])
for shape,name in zip(report.inline_shapes,['student/11-hall-plan.png','student/12-meal-flow.png','student/13-window-choice.png','student/15-meal-arrangements.png']):
    assert report.part.related_parts[shape._inline.graphic.graphicData.pic.blipFill.blip.embed].blob==(root/'figures'/name).read_bytes()
cells=lambda t:[[c.text for c in r.cells] for r in t.rows][1:]
assert cells(report.tables[0])==[['高一','2026','580'],['高二','2025','530'],['高三','2024','500'],['合计','—','1610']]
plan=next(r for r in s['screened'] if r['id']==s['selection']['lowPeak'])
assert cells(report.tables[2])==[[g['name'],str(g['classes']),clock(g['releaseTime']),clock(g['releaseTime']+(g['classes']-1)*g['classInterval'])] for g in plan['config']['grades']]
rows={r['id']:r['summary'] for r in s['contexts'][0]['rows']}
names={'reference':'参照安排','efficiency':'用时最短','balanced':'均衡安排','lowPeak':'短排队安排'}
assert cells(report.tables[3])==[[names[k],f(r['meanWait']),f(r['meanTotal']),f(r['peakQueue'],1)] for k,r in rows.items()]
assert cells(report.tables[4])==[[['高一','高二','高三'][i],f(rows['reference'][f'grade{i}Wait']),f(rows['lowPeak'][f'grade{i}Wait'])] for i in range(3)]
assert cells(report.tables[5])==[[str(r['windows']),str(r['seats']),f(r['summary']['meanWait']),f(r['summary']['seatWait']),f(r['summary']['meanTotal'])] for r in s['cases']]
assert rows['lowPeak']['meanWait']==min(r['meanWait'] for r in rows.values())
assert all(rows['lowPeak'][f'grade{i}Wait']<rows['reference'][f'grade{i}Wait'] for i in range(3))
assert '完整用时更加接近' not in text and '缩小年级用时差' not in text
assert len(report.element.xpath('.//m:sSubSup'))==1
with (root/'data/binhe-cohort-rounds.csv').open(encoding='utf-8-sig') as stream:
    csvrows=list(csv.DictReader(stream));assert len(csvrows)==800
    assert all([int(float(r[k])) for k in ['高一人数','高二人数','高三人数']]==[580,530,500] for r in csvrows)
guide='\n'.join(p.text for p in Document(folder/'软件使用与学生研究指南.docx').paragraphs)
assert '1610' in guide and '360' not in guide and '报告表6' in guide
template=root/'documents/templates/公文模板.docx'
assert hashlib.sha256(template.read_bytes()).hexdigest()=='ec93c69c2f33639421d1d89cf4fc1e1b0f926b6b1c9bee8ce3fda7167a523ae7'
for path in folder.glob('*.docx'):
    with ZipFile(template) as original,ZipFile(path) as revised:
        for name in original.namelist():
            if not name.endswith('/') and name.startswith(('word/styles','word/theme/','word/footer','word/header','word/numbering')):assert original.read(name)==revised.read(name),name
result={'passed':True,'tables':6,'figures':4,'executions':800,'cohortCounts':[580,530,500],'students':1610,'csvRows':800,'templateParts':'byte-identical','negativeFindingsPreserved':['average total time increases about 70 seconds under the selected short-queue arrangement'],'figureBytes':'exact match to current PNG files','focus':'Design a lunch scheduling plan and use software to compare and refine it','titlePreserved':True,'abstractContainsNoSpecificNumbers':True,'schoolNameMentions':1,'researchReferences':'three verified Chinese papers','sourceAndSettingsNotes':'concentrated in section three'}
(root/'qa'/f'{args.prefix}-document-audit.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(result))
