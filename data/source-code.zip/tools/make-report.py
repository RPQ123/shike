"""Build a source-traceable report from the user's retained public-document template.

The retained template is not modified. It supplies page geometry, type roles and footers.
Run with the bundled Python runtime. Render with Word and inspect all pages afterwards.
"""
from pathlib import Path
from copy import deepcopy
from datetime import datetime, timezone
import json
import hashlib
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from document_metadata import clean_template_metadata

ROOT=Path(__file__).resolve().parents[1]
TEMPLATE=ROOT/'documents/templates/公文模板.docx'
if not TEMPLATE.is_file(): TEMPLATE=ROOT.parent/'公文模板（先复制）.docx'
OUT=ROOT/'documents';OUT.mkdir(exist_ok=True)
INNOVATION=json.loads((ROOT/'data/innovation-study-results.json').read_text(encoding='utf8'))
EXPECTED='ec93c69c2f33639421d1d89cf4fc1e1b0f926b6b1c9bee8ce3fda7167a523ae7'
assert hashlib.sha256(TEMPLATE.read_bytes()).hexdigest()==EXPECTED

def new_document():
    doc=Document(TEMPLATE)
    roles={name:deepcopy(doc.paragraphs[index]._p) for name,index in [('title',0),('body',3),('h1',4),('h2',5)]}
    body=doc._element.body
    for child in list(body):
        if child.tag!=qn('w:sectPr'):body.remove(child)
    # The original notice's diagrams, hyperlink targets and custom data are not research content.
    for rid,rel in list(doc.part.rels.items()):
        if any(key in rel.reltype for key in ['diagram','hyperlink','customXml']):doc.part.drop_rel(rid)
    doc.core_properties.title='校园食堂错峰就餐与窗口分配仿真软件的设计与实现'
    doc.core_properties.subject='班级交错与跨餐轮换的合成仿真研究'
    doc.core_properties.author=''
    doc.core_properties.last_modified_by=''
    doc.core_properties.comments='AI辅助检索、开发和整理；协助说明见文末。'
    doc.core_properties.created=datetime.now(timezone.utc)
    doc.core_properties.modified=datetime.now(timezone.utc)
    return doc,roles

doc,roles=new_document()

def paragraph(text,role='body',size=None,align=None):
    proto=roles[role];p=doc.add_paragraph()
    p._p.insert(0,deepcopy(proto.find(qn('w:pPr'))))
    r=p.add_run(text)
    src=next(x for x in proto.findall(qn('w:r')) if x.find(qn('w:t')) is not None)
    r._r.insert(0,deepcopy(src.find(qn('w:rPr'))))
    if size:
        r.font.size=Pt(size);p.paragraph_format.line_spacing=Pt(size+8)
    if align is not None:p.alignment=align;p.paragraph_format.first_line_indent=Pt(0)
    if role in ['h1','h2','title']:p.paragraph_format.keep_with_next=True
    p.paragraph_format.widow_control=True
    return p

def table(headers,rows,widths):
    t=doc.add_table(rows=1,cols=len(headers));t.alignment=WD_TABLE_ALIGNMENT.CENTER;t.autofit=False
    props=t._tbl.tblPr
    borders=OxmlElement('w:tblBorders')
    for side in ['top','left','bottom','right','insideH','insideV']:
        edge=OxmlElement('w:'+side);edge.set(qn('w:val'),'single');edge.set(qn('w:sz'),'4');edge.set(qn('w:color'),'D9D9D9');borders.append(edge)
    props.append(borders)
    for i,width in enumerate(widths):t.columns[i].width=Cm(width)
    for row_index,values in enumerate([headers]+rows):
        cells=t.rows[0].cells if row_index==0 else t.add_row().cells
        for i,value in enumerate(values):
            cell=cells[i];cell.width=Cm(widths[i]);cell.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            cp=cell._tc.get_or_add_tcPr();m=OxmlElement('w:tcMar')
            for side,v in [('top',90),('bottom',90),('left',90),('right',90)]:
                e=OxmlElement('w:'+side);e.set(qn('w:w'),str(v));e.set(qn('w:type'),'dxa');m.append(e)
            cp.append(m)
            if row_index==0:
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'EDF0EC');cp.append(shade)
            p=cell.paragraphs[0];p.paragraph_format.line_spacing=Pt(18);p.paragraph_format.space_after=Pt(2)
            p.paragraph_format.keep_with_next=row_index<len(rows)
            p.alignment=WD_ALIGN_PARAGRAPH.LEFT if i==0 else WD_ALIGN_PARAGRAPH.CENTER
            run=p.add_run(str(value));run.font.name='Times New Roman';run.font.size=Pt(12);run.font.color.rgb=RGBColor(0,0,0);run._r.get_or_add_rPr().rFonts.set(qn('w:eastAsia'),'仿宋')
            if row_index==0:run.bold=True
        trpr=t.rows[row_index]._tr.get_or_add_trPr();cant=OxmlElement('w:cantSplit');trpr.append(cant)
    header=OxmlElement('w:tblHeader');t.rows[0]._tr.get_or_add_trPr().append(header)
    paragraph('',size=6)
    return t

def figure(name,caption,width=15.2):
    p=doc.add_paragraph();p.alignment=WD_ALIGN_PARAGRAPH.CENTER;p.paragraph_format.keep_with_next=True
    p.add_run().add_picture(str(ROOT/'figures'/name),width=Cm(width))
    paragraph(caption,size=12,align=WD_ALIGN_PARAGRAPH.CENTER)

from report_innovation import write_report
write_report(paragraph,table,figure,INNOVATION)
clean_template_metadata(doc)
doc.save(OUT/'研究报告_公文格式.docx')
print(json.dumps({'file':str(OUT/'研究报告_公文格式.docx'),'bytes':(OUT/'研究报告_公文格式.docx').stat().st_size,'paragraphs':len(doc.paragraphs)},ensure_ascii=False))
