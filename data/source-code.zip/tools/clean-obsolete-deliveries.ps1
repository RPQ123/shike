param([switch]$Execute)
$ErrorActionPreference = 'Stop'
$project = (Resolve-Path -LiteralPath (Split-Path -Parent $PSScriptRoot)).Path
$workspace = (Resolve-Path -LiteralPath (Split-Path -Parent $project)).Path
$targets = [System.Collections.Generic.List[string]]::new()
function Add-Target([string]$path) {
    if (Test-Path -LiteralPath $path) { $targets.Add((Resolve-Path -LiteralPath $path).Path) }
}
# Obsolete published copies, not original source repositories or handoff archives.
Add-Target (Join-Path $workspace '食堂仿真_完整交付.zip')
Add-Target (Join-Path $workspace '食堂仿真_交付')
foreach ($name in @('04-研究报告_v2.pdf','04-研究报告_视觉精修与交互修正版.docx','04-研究报告_视觉精修与交互修正版.pdf')) {
    Add-Target (Join-Path $workspace ('【成品】提交材料/' + $name))
}
foreach ($p in Get-ChildItem -LiteralPath (Join-Path $project 'release/packages') -File) {
    if ($p.Name -notlike '校园食堂研究_统一提交版_*') { Add-Target $p.FullName }
}
foreach ($name in @('candidates','demo','desktop','desktop-binhe','desktop-common','desktop-walking','history')) {
    Add-Target (Join-Path $project ('release/' + $name))
}
# Keep the current document directories required by authoring scripts.
foreach ($p in Get-ChildItem -LiteralPath (Join-Path $project 'documents') -Directory) {
    if ($p.Name -notin @('polish-edition','schedule-edition','queue-focus-edition','design-edition','templates')) { Add-Target $p.FullName }
}
foreach ($p in Get-ChildItem -LiteralPath (Join-Path $project 'qa') -Directory) {
    if ($p.Name -like '*before*' -or $p.Name -like 'package-smoke*' -or $p.Name -like '*-extracted' -or
        $p.Name -like 'public-site-stage*' -or $p.Name -like '*-site-sdk-stage*' -or
        $p.Name -like '*incomplete-packages' -or $p.Name -like 'materials-reproduction*' -or
        $p.Name -in @('desktop-downloads','desktop-test-profile','3d-demo') -or
        ($p.Name -like '*-render' -and $p.Name -notin @('polish-doc-render','schedule-forms-render','queue-submission-render','template-render'))) {
        Add-Target $p.FullName
    }
}
foreach ($p in Get-ChildItem -LiteralPath (Join-Path $project 'qa') -File -Filter '*.tar.gz') { Add-Target $p.FullName }
$rows = @()
foreach ($path in ($targets | Sort-Object -Unique)) {
    # Check the resolved absolute path before any recursive deletion.
    if (-not $path.StartsWith($workspace + [IO.Path]::DirectorySeparatorChar, [StringComparison]::OrdinalIgnoreCase) -or $path -eq $project) {
        throw "Refusing target outside the intended workspace: $path"
    }
    $item = Get-Item -LiteralPath $path -Force
    if ($item.Attributes -band [IO.FileAttributes]::ReparsePoint) { throw "Refusing linked target: $path" }
    $files = if ($item.PSIsContainer) { @(Get-ChildItem -LiteralPath $path -File -Recurse -Force) } else { @($item) }
    $rows += [pscustomobject]@{ path=$path; files=$files.Count; bytes=[long](($files | Measure-Object Length -Sum).Sum) }
}
$receipt = [ordered]@{ executed=[bool]$Execute; targets=$rows; files=($rows | Measure-Object files -Sum).Sum; bytes=($rows | Measure-Object bytes -Sum).Sum; removed=@(); failures=@() }
if ($Execute) {
    $packageReceipt = Get-Content -LiteralPath (Join-Path $project 'qa/schedule-package-audit.json') -Raw | ConvertFrom-Json
    if (-not $packageReceipt.passed -or $packageReceipt.edition -ne '统一提交版') { throw 'The updated delivery must pass before cleanup.' }
    foreach ($row in $rows) {
        try {
            Remove-Item -LiteralPath $row.path -Recurse -Force
            $receipt.removed += $row
        } catch {
            $receipt.failures += [pscustomobject]@{path=$row.path;error=$_.Exception.Message}
        }
    }
}
$receipt | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $project 'qa/cleanup-deliveries.json') -Encoding utf8
[pscustomobject]@{executed=[bool]$Execute;targets=$rows.Count;files=$receipt.files;gigabytes=[Math]::Round($receipt.bytes/1GB,2);failures=$receipt.failures.Count}
