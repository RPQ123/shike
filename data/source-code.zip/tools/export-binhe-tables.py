"""Export all 800 executions and the 33-group timetable to ordinary CSV."""
from pathlib import Path
import json,csv
root=Path(__file__).resolve().parents[1]
s=json.loads((root/'data/binhe-cohort-results.json').read_text('utf-8'))
records=[]
def add(phase,label,seed,r):
    records.append({'阶段':phase,'安排':label,'随机数':seed,'高一人数':r['grade0Count'],'高二人数':r['grade1Count'],'高三人数':r['grade2Count'],'平均排队_分钟':r['meanWait'],'平均等座_分钟':r['seatWait'],'平均总用时_分钟':r['meanTotal'],'高一总用时_分钟':r['grade0Total'],'高二总用时_分钟':r['grade1Total'],'高三总用时_分钟':r['grade2Total'],'排队最多人数':r['peakQueue']})
for phase,items,seedkey in [('初选',s['screened'],'screenSeeds'),('复查',s['contexts'][0]['rows'],'verifySeeds'),('单项改变',s['cases'],'controlSeeds')]:
    for item in items:
        for i,r in enumerate(item['rounds']):add(phase,item['id'],s['protocol'][seedkey]['start']+i,r)
for mode in s['period']:
    for i,period in enumerate(mode['rounds']):
        for j,day in enumerate(period['days']):add('三餐比较',f'{mode["mode"]}-第{i+1}组-第{j+1}餐',day['seed'],day['metrics'])
assert len(records)==800
def write(name,rows):
    with (root/'data'/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
write('binhe-cohort-rounds.csv',records)
summary=[]
for phase,items in [('放行安排',s['contexts'][0]['rows']),('单项改变',s['cases']),('三餐比较',s['period'])]:
    for item in items:
        r=item['summary'];summary.append({'阶段':phase,'安排':item.get('id',item.get('mode')),'平均排队_分钟':r['meanWait'],'平均等座_分钟':r['seatWait'],'平均总用时_分钟':r['meanTotal'],**{f'高{i+1}总用时_分钟':r[f'grade{i}Total'] for i in range(3)}})
write('binhe-cohort-summary.csv',summary)
plan=next(r for r in s['screened'] if r['id']==s['selection']['balanced'])
timetable=[]
for row in plan['batches']:
    seconds=round((680+row['release'])*60)
    timetable.append({'年级':row['gradeName'],'组号':row['classIndex']+1,'本组人数':row['students'],'出发时刻':f'{seconds//3600:02}:{seconds//60%60:02}:{seconds%60:02}'})
assert len(timetable)==33 and sum(r['本组人数'] for r in timetable)==1610
write('binhe-cohort-timetable.csv',timetable)
print(json.dumps({'executions':len(records),'summaries':len(summary),'timetableGroups':len(timetable)}))
