const {chromium}=require('playwright'),assert=require('node:assert/strict'),fs=require('node:fs');
(async()=>{
 const browser=await chromium.launch({headless:true,channel:'chrome'}),page=await browser.newPage({viewport:{width:1440,height:900}});
 const errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{
  await page.goto('http://127.0.0.1:8771/');await page.waitForFunction(()=>window.DiningLabSnapshot);
  await page.locator('#setup-form button[type=submit]').click();await page.locator('#peak').click();
  const canvas=page.locator('#scene3d canvas');await canvas.scrollIntoViewIfNeeded();await page.waitForTimeout(300);
  const snap=()=>page.evaluate(()=>DiningLabSnapshot);
  const bounds=await canvas.boundingBox(),targets=(await snap()).rendering.pickTargets;
  const target=targets.find(t=>t.legX>150&&t.legX<bounds.width-150);
  assert.ok(target);
  // A fresh selection must hit the visible lower leg, not only the head.
  await page.mouse.click(bounds.x+target.legX,bounds.y+target.legY);
  await page.waitForTimeout(100);
  assert.equal((await snap()).rendering.pickedStudent,target.id,'clicking a visible leg must select that student');
  assert.ok((await snap()).rendering.journeySegments>0);
  assert.ok((await page.locator('#inspect-text').innerText()).includes(String(target.id+1)));
  // Holding a click briefly while playback runs must select the pressed student.
  await page.locator('#speed').selectOption('1');await page.locator('#play').click();
  await canvas.scrollIntoViewIfNeeded();
  const moving=(await snap()).rendering.pickTargets.find(t=>t.x>150&&t.x<bounds.width-150);
  const actual=await canvas.boundingBox();
  await page.mouse.move(actual.x+moving.x,actual.y+moving.y);await page.mouse.down();await page.waitForTimeout(220);await page.mouse.up();await page.waitForTimeout(150);
  assert.equal((await snap()).rendering.pickedStudent,moving.id);
  assert.equal(await page.locator('#play').getAttribute('aria-label'),'播放回放');
  // Dragging the camera must never be interpreted as clicking a person.
  await page.mouse.move(actual.x+moving.x,actual.y+moving.y);await page.mouse.down();await page.mouse.move(actual.x+moving.x+45,actual.y+moving.y+20,{steps:6});await page.mouse.up();
  assert.equal((await snap()).rendering.pickedStudent,moving.id);
  for(const [width,height] of [[1440,900],[1920,1080],[390,844]]){
   await page.setViewportSize({width,height});await page.locator('[data-camera=perspective]').click();await page.locator('#peak').click();await page.waitForTimeout(300);
   await page.evaluate(()=>scrollTo(0,0));
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false);
   assert.equal(await page.locator('.scene-station-label:visible').count(),16);
   await page.screenshot({path:`qa/polish-live-${width}.png`,fullPage:true});
  }
  assert.deepEqual(errors,[]);
  const receipt={passed:true,build:(await snap()).build.id,fullBodyPicking:true,playingPointerDownIdentity:true,selectionPausesPlayback:true,dragDoesNotSelect:true,all16Labels:true,widths:[1440,1920,390],errors};
  fs.writeFileSync('qa/polish-ui-audit.json',JSON.stringify(receipt,null,2));console.log(receipt);
 }finally{await browser.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
