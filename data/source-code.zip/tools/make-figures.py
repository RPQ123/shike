from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm

root=Path(__file__).resolve().parents[1]
data=json.loads((root/'data/study-results.json').read_text(encoding='utf8'))
out=root/'figures';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'Microsoft YaHei','font.size':10,'axes.unicode_minus':False,'axes.spines.top':False,'axes.spines.right':False,'axes.labelcolor':'#263c34','xtick.color':'#4f6057','ytick.color':'#4f6057','svg.fonttype':'none'})
names={'sync':'同步放行 / 3:3','gap2':'间隔2分 / 3:3','gap4':'间隔4分 / 3:3','twoThirdsA':'间隔2分 / 4:2','fiveSixthsA':'间隔2分 / 5:1','pooled':'间隔2分 / 公共队列'}
primary=[r for r in data['results'] if r['context']=='primary']

def save(fig,name):
    fig.savefig(out/(name+'.png'),dpi=260,bbox_inches='tight',facecolor='white')
    fig.savefig(out/(name+'.svg'),bbox_inches='tight',facecolor='white')
    plt.close(fig)

fig,ax=plt.subplots(figsize=(6.2,3.9));y=np.arange(len(primary))
for offset,key,label,color in [(-.18,'meanWait','平均取餐排队','#348971'),(.18,'meanTotal','平均完整用时','#b29b6b')]:
    values=[r['summary'][key] for r in primary]
    bars=ax.barh(y+offset,values,height=.32,label=label,color=color)
    ax.bar_label(bars,labels=[f'{v:.2f}' for v in values],padding=3,fontsize=8)
ax.set_yticks(y,[names[r['policy']] for r in primary]);ax.invert_yaxis();ax.set_xlim(0,34);ax.set_xlabel('分钟；每种方案30个配对随机种子');ax.legend(loc='lower center',bbox_to_anchor=(.5,1.01),ncol=2,frameon=False,fontsize=9);ax.grid(axis='x',alpha=.15);ax.set_axisbelow(True);fig.tight_layout();save(fig,'01-queue-vs-whole')

fig,ax=plt.subplots(figsize=(6.2,3.9));y=np.arange(len(primary));left=np.zeros(len(primary))
parts=[('releaseDelay','放行延后','#b99f71'),('walking','集合与步行','#cbd4c5'),('queue','取餐排队','#32836b'),('service','服务','#647876'),('seatWait','等座','#cc845f'),('meal','用餐','#9bb7aa'),('return','返程','#708eac')]
for key,label,color in parts:
    values=np.array([np.mean([r['flow'][key] for r in row['rounds']]) for row in primary]);ax.barh(y,values,left=left,height=.65,label=label,color=color);left+=values
ax.set_yticks(y,[names[r['policy']] for r in primary]);ax.invert_yaxis();ax.set_xlim(0,32);ax.set_xlabel('从允许放行到返回终点的平均用时 / 分钟');ax.legend(ncol=4,loc='upper center',bbox_to_anchor=(.47,-.19),frameon=False,fontsize=8);ax.grid(axis='x',alpha=.13);ax.set_axisbelow(True);fig.tight_layout();save(fig,'02-flow-decomposition')

contexts=data['contexts'];rows=[]
for context in contexts:
    local={r['policy']:r['summary'] for r in data['results'] if r['context']==context['id']}
    rows.append([local['twoThirdsA'][k]-local['gap2'][k] for k in ['meanWait','seatWait','meanTotal']])
array=np.array(rows)
fig,ax=plt.subplots(figsize=(6.2,5.8));cmap=LinearSegmentedColormap.from_list('changes',['#348971','#ffffff','#c98157']);im=ax.imshow(array,cmap=cmap,norm=TwoSlopeNorm(vmin=-4.5,vcenter=0,vmax=4.5),aspect='auto')
ax.set_yticks(np.arange(len(contexts)),[r['label'] for r in contexts]);ax.set_xticks([0,1,2],['排队变化','等座变化','完整用时变化'])
for i in range(len(contexts)):
    for j in range(3):ax.text(j,i,f'{array[i,j]:+.2f}',ha='center',va='center',color='#173c31' if abs(array[i,j])<3.3 else 'white',fontsize=10)
ax.tick_params(length=0);ax.set_title('窗口向 A 类套餐倾斜：相对均分窗口的变化',fontsize=11,pad=14,color='black');ax.set_xlabel('单位：分钟；负值为缩短，正值为增加',labelpad=12)
fig.colorbar(im,ax=ax,shrink=.8,pad=.035,label='分钟');fig.tight_layout();save(fig,'03-sensitivity')
print(json.dumps({'figures':[p.name for p in out.glob('*.png')],'source':'data/study-results.json'},ensure_ascii=False))
