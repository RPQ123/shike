// Audit relationships among saved artifacts. Does not manufacture a final completion claim.
const fs=require('node:fs'),crypto=require('node:crypto'),assert=require('node:assert/strict');
const R=require('../dist/research.js');
const load=file=>JSON.parse(fs.readFileSync(file,'utf8'));
const sha=value=>crypto.createHash('sha256').update(value).digest('hex');
const checks=[];
const finalRequested=process.argv.includes('--final');
const refresh=process.argv.includes('--refresh');
const startedAt=refresh?'2026-10-18T13:42:06+08:00':'2026-10-18T05:55:05+08:00';
const minimumHours=refresh?3:5;
const earliestCompletion=refresh?'2026-10-18T16:42:06+08:00':'2026-10-18T10:55:05+08:00';
const evidencePrefix=refresh?'refresh-':'';
const study=load('data/study-results.json');
for(const [file,hash] of Object.entries(study.sourceHashes))assert.equal(sha(fs.readFileSync(file)),hash,file);
assert.equal(sha(JSON.stringify(load('research/experiment-protocol.json'))),study.protocolSha256);
checks.push('Recorded study source and protocol hashes match current files');
let mainRuns=0;
for(const row of study.results){
 assert.equal(sha(JSON.stringify(row.config)),row.configSha256);
 const expected=R.summarize(row.rounds.map(({seed,flow,grades,warnings,...metrics})=>metrics));
 for(const key of Object.keys(expected))assert.ok(Math.abs(expected[key]-row.summary[key])<1e-9,`${row.context}/${row.policy}/${key}`);
 assert.deepEqual(row.rounds.map(x=>x.seed),Array.from({length:30},(_,i)=>710001+i));
 mainRuns+=row.rounds.length;
}
assert.equal(mainRuns,1980);
assert.deepEqual(load('data/frozen-selection.json'),study.candidateSearch.selection);
checks.push('All 66 scenario-policy summaries recompute from saved rounds; frozen selection agrees');
const build=JSON.parse(fs.readFileSync('dist/build-info.js','utf8').match(/Object\.freeze\((.*)\);/s)[1]);
for(const [file,hash] of Object.entries(build.files)){
 assert.equal(sha(fs.readFileSync('dist/'+file)),hash,file);
 assert.equal(sha(fs.readFileSync('release/desktop/DiningLab/_internal/dist/'+file)),hash,'desktop/'+file);
}
checks.push('Desktop resources and current offline build are byte-identical');
const documents=load('qa/document-audit.json');
for(const item of documents.documents)assert.equal(sha(fs.readFileSync('documents/'+item.file)),item.sha256);
assert.equal(documents.templateUnchanged,true);
checks.push('Reviewed Word files retain their audited hashes');
const packages=load('release/packages/package-index.json');
assert.equal(packages.build,build.id);
for(const item of packages.packages)assert.equal(sha(fs.readFileSync('release/packages/'+item.file)),item.sha256);
assert.equal(load('qa/package-smoke.json').build,build.id);
checks.push('Candidate package hashes and unpacked launch evidence match the software build');
const logs=refresh?['qa/soak-refresh-round1.jsonl','qa/soak-refresh-final.jsonl']:['qa/soak-events.jsonl','qa/soak-current-build.jsonl','qa/soak-release.jsonl','qa/soak-final.jsonl'];
const segments=[];
for(const file of logs){
 let segment;
 for(const line of fs.readFileSync(file,'utf8').trim().split('\n')){
  const row=JSON.parse(line);
  if(row.event==='start'){
   segment={file,start:row.at,build:row.initial?.build?.id||'not stamped in early run',cycles:0,failures:[],runtimeErrors:[],lastEvent:row.at,completionRecorded:false,heaps:[]};segments.push(segment);
  }
  if(!segment)throw Error('Log missing start event: '+file);
  segment.lastEvent=row.at;
  if(row.event==='cycle'){
   segment.cycles++;
   const heap=row.memory?.find(x=>x.name==='JSHeapUsedSize')?.value;
   if(Number.isFinite(heap))segment.heaps.push(heap);
  }
  if(row.event==='failure'||row.event==='stopped')segment.failures.push(row);
  if(row.event==='pageerror')segment.runtimeErrors.push(row);
  if(row.event==='user-duration-change')segment.interruption=row.reason;
  if(row.event==='complete'){
   segment.completionRecorded=true;segment.elapsedSeconds=row.elapsedSeconds;
   segment.terminal={at:row.at,cycles:row.cycles,failures:row.failures,errors:row.errors};
  }
 }
}
for(const segment of segments){
 segment.observedMinutes=(Date.parse(segment.lastEvent)-Date.parse(segment.start))/60000;
 segment.heapMiBRange=segment.heaps.length?[Math.min(...segment.heaps)/1048576,Math.max(...segment.heaps)/1048576]:null;
 delete segment.heaps;
}
const latest=segments.filter(x=>x.build===build.id).at(-1);
assert.ok(latest,'Current software must have a version-identified reliability run');
const durationMinutes=(Date.now()-Date.parse(startedAt))/60000;
const activeSegments=logs.map(file=>segments.filter(segment=>segment.file===file).at(-1));
const reliabilityPassed=activeSegments.every(segment=>
 segment.completionRecorded && segment.failures.length===0 && segment.runtimeErrors.length===0 &&
 segment.terminal?.failures===0 && Array.isArray(segment.terminal?.errors) && segment.terminal.errors.length===0 &&
 segment.cycles>0 && segment.terminal.cycles===segment.cycles &&
 Date.parse(segment.start)>=Date.parse(startedAt) &&
 Date.parse(segment.terminal.at)>=Date.parse(refresh?startedAt:earliestCompletion) && Date.parse(segment.terminal.at)<=Date.now()
);
if(finalRequested){
 assert.ok(durationMinutes>=minimumHours*60,`The user-approved ${minimumHours}-hour duration has not elapsed`);
 assert.ok(reliabilityPassed,'All retained browser runs must finish with matching zero-error terminal records');
 assert.ok(latest.completionRecorded,'The current build must have a completed reliability record');
 assert.ok(Date.parse(latest.terminal.at)>=Date.parse(earliestCompletion),'Final-build observation must continue through the task deadline');
 const smoke=load('qa/package-smoke.json');
 assert.equal(smoke.extractedArchives?.length,2,'Final smoke check must verify both extracted archives');
 for(const archive of smoke.extractedArchives){
  const current=packages.packages.find(item=>item.file===archive.file);
  assert.equal(archive.sha256,current.sha256,'Smoke evidence must match this archive');
  assert.equal(archive.manifestSha256,current.manifestSha256);
  assert.equal(archive.verifiedFiles,current.entries);
 }
 checks.push(`${minimumHours}-hour task duration reached; retained browser runs completed without recorded failures`);
 // Deterministic terminal evidence is safe to include in the archive; the separate
 // delivery audit contains archive hashes and must not be embedded in its own ZIP.
 fs.writeFileSync(`qa/${evidencePrefix}reliability-summary.json`,JSON.stringify({
  build:build.id,taskStartedAt:startedAt,earliestTaskCompletion:earliestCompletion,
  latestBrowserCompletedAt:latest.terminal.at,segments,
  scope:`Total task development and observation lasted at least ${minimumHours} hours. Browser runs may overlap and cover different builds; their durations are not added or represented as ${minimumHours} hours of one final-build browser. Memory ranges are observations, not proof that no leak can exist.`
 },null,2));
}
const report={at:new Date().toISOString(),build:build.id,checks,mainRuns,screeningRuns:250,verificationRuns:60,documentsBytes:documents.combinedBytes,startedAt,minimumHours,durationMinutes,minimumDurationReached:durationMinutes>=minimumHours*60,reliabilityPassed,segments,status:finalRequested?'Final artifact-consistency and duration gates passed; manual QA scope is recorded separately':'Candidate verified; final duration and human completion audit remain required'};
fs.writeFileSync(`qa/${evidencePrefix}delivery-audit.json`,JSON.stringify(report,null,2));
console.log(JSON.stringify({build:build.id,checks:checks.length,durationMinutes,segments:segments.map(({file,build,cycles,failures,runtimeErrors,completionRecorded,heapMiBRange})=>({file,build,cycles,failures:failures.length,runtimeErrors:runtimeErrors.length,completionRecorded,heapMiBRange}))}));
