// A fresh study for the universal-window product; old study files are never overwritten.
const fs=require('node:fs'),crypto=require('node:crypto');
const E=require('../dist/school-engine'),R=require('../dist/research'),P=require('../dist/planner'),T=require('../dist/rotation'),C=require('../dist/common-windows');
const protocol=JSON.parse(fs.readFileSync('research/common-window-protocol.json','utf8'));
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const sourceFiles=['dist/engine.js','dist/school-engine.js','dist/research.js','dist/planner.js','dist/rotation.js','dist/common-windows.js','tools/run-common-study.cjs'];
const seeds=range=>Array.from({length:range.count},(_,i)=>range.start+i);
const base=C.normalize(R.example()),set=P.candidates(base,{slots:protocol.slots,reallocate:false});
let executions=0;
const evaluate=(config,ids)=>{
  const rounds=ids.map(seed=>{executions++;return R.metrics(E.simulateSchool({...config,seed}));});
  return {rounds,summary:R.summarize(rounds)};
};
const startedAt=new Date().toISOString();
const rows=set.accepted.map(p=>({...p,...evaluate(p.config,seeds(protocol.screenSeeds))}));
const chosen=P.choose(rows,rows.find(r=>r.id==='reference'),protocol.criteria);
const selection=Object.fromEntries(['efficiency','balanced','lowPeak'].map(k=>[k,chosen[k].id]));
const frozenAt=new Date().toISOString();
fs.writeFileSync('data/common-frozen-selection.json',JSON.stringify({frozenAt,selection,screeningSeeds:seeds(protocol.screenSeeds)},null,2));
const contexts=protocol.contexts.map(id=>{
  const config=R.clone(base);
  if(id==='unequal-speed')config.windowMeans=[15,20,25,15,20,25];
  if(id==='seats-60')config.seats=60;
  if(id==='service-30'){config.serviceMean=30;config.windowMeans=Array(6).fill(30);}
  if(id==='students-1200'){config.students=1200;config.grades.forEach(g=>g.students=400);}
  if(id==='windows-16-students-2400'){
    config.windows=16;config.windowMeans=Array(16).fill(20);config.windowOwners=Array(16).fill(0);
    config.students=2400;config.grades.forEach(g=>g.students=800);
  }
  const plans=[{id:'reference',config},...Object.keys(selection).map(role=>{
    const plan=chosen[role],c=R.clone(config);c.grades=R.clone(plan.config.grades).map((g,i)=>({...g,students:config.grades[i].students}));
    return {id:role,config:E.normalizeSchoolConfig(c)};
  })];
  const verification=plans.map(p=>({...p,...evaluate(p.config,seeds(protocol.verifySeeds))}));
  const shortest=evaluate({...config,strategy:'shortest'},seeds(protocol.verifySeeds));
  const paired=(a,b)=>Object.fromEntries(['meanTotal','meanWait','worstGrade','peakQueue','seatWait'].map(k=>[k,R.paired(a.rounds.map(r=>r[k]),b.rounds.map(r=>r[k]))]));
  return {id,rows:verification,shortest,fastestVersusShortest:paired(shortest,verification[0]),differences:Object.fromEntries(verification.slice(1).map(p=>[p.id,paired(verification[0],p)]))};
});
const period=protocol.periodModes.map(mode=>{
  const rounds=Array.from({length:30},(_,i)=>T.runPeriod(chosen.balanced,{mode,seeds:[0,1,2].map(d=>protocol.periodSeeds.start+i*3+d),evaluate:c=>{executions++;return R.metrics(E.simulateSchool(c));}}));
  return {mode,rounds,summary:R.summarize(rounds.map(r=>r.summary))};
});
const result={schema:'common-window-study/1',startedAt,frozenAt,completedAt:new Date().toISOString(),protocol,protocolSha256:sha(JSON.stringify(protocol)),sourceHashes:Object.fromEntries(sourceFiles.map(f=>[f,sha(fs.readFileSync(f))])),executions,base,selection,screened:rows,contexts,period};
fs.writeFileSync('data/common-study-results.json',JSON.stringify(result,null,2));
console.log(JSON.stringify({executions,candidates:rows.length,selection,base:contexts[0].rows.map(r=>({id:r.id,summary:r.summary})),period:period.map(r=>({mode:r.mode,summary:r.summary}))}));
