// Independent admission-scale experiment. Never overwrite completed datasets.
const fs=require('node:fs'),crypto=require('node:crypto');
const E=require('../dist/school-engine'),R=require('../dist/research'),P=require('../dist/planner'),T=require('../dist/rotation'),B=require('../dist/binhe-cohort');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const protocolBytes=fs.readFileSync('research/binhe-cohort-protocol.json'),protocol=JSON.parse(protocolBytes);
const output='data/binhe-cohort-results.json',freeze='data/binhe-cohort-selection.json';
if(fs.existsSync(output)||fs.existsSync(freeze))throw new Error('Copy the project before a new run; completed records are retained.');
const ids=r=>Array.from({length:r.count},(_,i)=>r.start+i),base=B.create();
const startedAt=new Date().toISOString();let executions=0;
const evaluate=(config,seeds)=>{const rounds=seeds.map(seed=>{executions++;return R.metrics(E.simulateSchool({...config,seed}));});return {rounds,summary:R.summarize(rounds)};};
const screened=P.candidates(base,{slots:protocol.slots,reallocate:false}).accepted.map(p=>({...p,...evaluate(p.config,ids(protocol.screenSeeds))}));
const chosen=P.choose(screened,screened.find(p=>p.id==='reference'),protocol.criteria);
const selection=Object.fromEntries(['efficiency','balanced','lowPeak'].map(k=>[k,chosen[k].id]));
const frozenAt=new Date().toISOString();
fs.writeFileSync(freeze,JSON.stringify({frozenAt,selection},null,2));
const contexts=[{id:'admission-plan-1610',rows:[{id:'reference',config:base},...Object.keys(selection).map(id=>({id,config:chosen[id].config}))].map(p=>({...p,...evaluate(p.config,ids(protocol.verifySeeds))}))}];
const cases=protocol.cases.map(test=>{
  const c=R.clone(base);c.windows=test.windows;c.windowMeans=Array(c.windows).fill(c.serviceMean);c.windowOwners=Array(c.windows).fill(0);c.seats=test.seats;
  const config=E.normalizeSchoolConfig(c);return {...test,config,...evaluate(config,ids(protocol.controlSeeds))};
});
const period=protocol.periodModes.map(mode=>{
  const rounds=Array.from({length:30},(_,i)=>T.runPeriod(chosen.balanced,{mode,seeds:[0,1,2].map(d=>protocol.periodSeeds.start+i*3+d),evaluate:c=>{executions++;return R.metrics(E.simulateSchool(c));}}));
  return {mode,rounds,summary:R.summarize(rounds.map(r=>r.summary))};
});
const files=['dist/engine.js','dist/school-engine.js','dist/research.js','dist/planner.js','dist/rotation.js','dist/common-windows.js','dist/binhe-cohort.js','tools/run-binhe-cohort.cjs'];
const result={schema:protocol.schema,startedAt,frozenAt,completedAt:new Date().toISOString(),protocol,protocolSha256:sha(protocolBytes),sourceHashes:Object.fromEntries(files.map(f=>[f,sha(fs.readFileSync(f))])),base,selection,screened,contexts,cases,period,executions};
fs.writeFileSync(output,JSON.stringify(result,null,2));
fs.writeFileSync('data/binhe-cohort-session.json',JSON.stringify(R.session(base),null,2));
console.log(JSON.stringify({executions,selection,rows:contexts[0].rows.map(r=>({id:r.id,summary:r.summary})),cases:cases.map(r=>({id:r.id,summary:r.summary})),period:period.map(p=>({mode:p.mode,summary:p.summary}))}));
