# 食刻 校园食堂仿真实验室

《校园食堂错峰就餐与窗口分配仿真软件的设计与实现》2.2版。把错峰安排细化到班级，生成放行表，并比较固定、循环、历史用时补偿三种跨餐顺序。

面向高二学生理解、操作和复核。应用背景为西安铁一中滨河高级中学，默认360人、6窗、120座是合成教学场景。学校当前规则与参数待实际核实；参考基础和AI协助范围见PROVENANCE.txt。

## 开始使用

- **Windows**：完整解压Windows包，双击 `DiningLab/DiningLab.exe`，保留 `_internal` 文件夹。使用本机Microsoft Edge WebView2 Runtime。
- **离线网页**：用Chrome或Edge打开 `dist/index.html`。计算和图形依赖都在本地；查阅外部资料时才联网。没有WebGL时切换二维，指标保持同一来源。

先在“方案筛选”点击“生成放行方案”，选择均衡、效率或低峰目标，查看班级放行表，再载入仿真。放行表可导出CSV，全部候选和30轮独立复核可在“计算记录”中导出。

主展示默认使用3D。点击回放区的播放按钮，观看学生到达、排队、取餐、入座和离开的动态过程；可以暂停、调整倍速、拖动时间，或拖动场景旋转视角。换一个放行方案后仍使用同一套3D回放和事件数据。

展开“连续几餐，怎样轮换更均衡”，比较三餐或五餐。周期结果和每日结果分别查看；可载入第一组实验的某一餐回放，完整30组通过JSON导出保存。操作与手算说明见 `documents/软件使用与学生研究指南.docx`。

## 2.2的主要内容

| 能力 | 实际实现 |
| --- | --- |
| 班级排程 | 年级顺序、相邻班级槽、窗口餐品配比联合枚举，默认126个唯一安排 |
| 可行性 | 保留最早放行、首班锁定、末班限制和餐品兼容 |
| 三种目标 | 均衡优先最慢年级，效率优先全体平均，低峰优先排队峰值 |
| 跨餐轮换 | 固定、简单循环、依据此前完整用时补偿的可解释规则 |
| 输出 | 逐班时刻表、CSV、配置和种子、逐轮复核、逐餐历史 |
| 界面 | 暖灰表面、陶土色主要操作和轻动效；支持系统减少动态效果 |

原有A/B配对比较、逐年级解释、参数情景检查、逐人事件导出和研究笔记继续可用。旧年级间隔筛选保留在排程页的折叠区域。

## 本轮研究结果

新协议在正式运行前保存，已有378次开发探索单列。新旧两种搜索采用相同均衡目标，固定选择后开展14种预设条件、30组三餐周期和额外30组五餐周期。实际唯一物理执行 **14370次**，不把重复政策身份或重放检查增加为研究样本。

- 基准单餐复核，均衡选择使最慢年级平均完整用时从38.34分降至32.74分，排队峰值约少21人；全体平均差值区间包含零。
- 单餐均衡调整了年级先后，高一由21.63分变为32.67分，高三由38.34分变为29.87分，需要同时看各年级。
- 基准三餐中，补偿相对联合固定使周期最慢年级再减少约1.93分。与简单循环相比，多数条件差异不明确；步行距离不同时出现均衡改善与效率代价。
- 另一个五餐批次中，补偿的周期最慢年级约30.09分，循环约30.28分；完整区间、逐餐结果和未来已知的回看参照见报告及源数据。

这些是所设模型的实验结果。文章集中报告方法、取舍和条件，后续以学校实际规则与独立观察检验。

## 文件对应关系

| 目录 | 内容 |
| --- | --- |
| `dist/` | 可直接离线打开的完整应用 |
| `desktop/` | Windows外壳、图标与构建配置 |
| `scenarios/` | 可导入工作台的合成场景和本轮固定研究安排 |
| `documents/` | 公文式研究报告、六页学生指南及复现用模板 |
| `data/` | 原研究、2.1补充研究、2.2冻结选择与唯一执行台账 |
| `figures/` | 从数据生成的PNG、可编辑SVG、PDF及源CSV |
| `research/` | 规则资料、论文与项目核查、阅读范围、实验协议 |
| `learning/` | Python教学模型、手算练习和空白研究记录 |
| `tests/`、`tools/` | 计算验证、复现、图表、文稿和浏览器检查 |
| `qa/` | 绑定版本的开发与成品验收记录 |

`examples/`为保留的v1.5模型示例，其格式不同于工作台场景。界面导入使用 `scenarios/` 中的文件。

## 复现实验

应用本身不用安装开发依赖。开发检查需要Node.js和Python，在项目目录执行：

```powershell
npm ci --ignore-scripts
npm test
python -m unittest discover -s tests -p "test_*.py"
node tools/audit-innovation-study.cjs --replay
```

`--replay`逐项重算14370个已有物理输入，正常约需一至数分钟，取决于电脑。执行 `node tools/reproduce-innovation.cjs` 则在一个全新的qa子目录从协议开始完整生成，核对选择、所有逐轮结果及整个执行台账，保留原数据。底层生成入口 `node tools/run-innovation-study.cjs` 会重写当前目录的研究输出及生成时刻，修改研究前先另存旧协议和数据。

筛选种子2310001—2310010，单餐复核2320001—2320030，三餐2330001—2330090，五餐2340001—2340150。界面从当前种子派生临时实验，选择结果可能与文章固定批次不同。

图表用Python/matplotlib生成；依赖见 `tools/requirements-research.txt`。执行 `python tools/make-innovation-figures.py --render-only` 可直接从已有结果重建四张图和源CSV，不需要安装Codex技能；此模式另存重建记录，不覆盖原有质量审查记录。开发时完整多面板对齐检查需将 `DINING_FIGURE_AUDIT_DIR` 指向nature-figure技能的scripts目录。正文图06—09保留逐条件及逐前缀源CSV。

Word由 `python tools/make-report.py` 与 `python tools/make-guide.py` 生成，优先使用随研究材料保留的 `documents/templates/公文模板.docx`，校验其哈希。模板原有授权不因收入本地复现材料而改变。Word只读渲染与逐页检查工具另附，生成后仍需重新审校。

安装研究依赖后，`python tools/reproduce-materials.py` 会在新目录重建四图和两份Word，逐项核对原文件，保留已交付文稿。两种复现入口都把新验收记录写到各自新目录的 `reproduction-audit.json`，保留包内原记录。其检查排除实际生成日期的正常变化，正文、图像和模板内容仍须一致。

旧研究分别由 `tools/run-study.cjs`、`tools/run-decision-study.cjs` 重现，实际2290次和3210次，保留各自的协议、源哈希和结果。旧数值模型和旧研究模块版本保持原值；具体应用文件由 `dist/build-info.js` 的内容哈希标识。

## 浏览器和桌面检查

```powershell
python tools/serve-preview.py
```

在另一终端运行 `node tools/ui-planner-check.cjs` 或 `node tools/ui-innovation-capture.cjs`。`ui-data-check.cjs`直接验证本地文件的离线导出。长时新流程检查为 `soak-innovation.cjs <未来ISO截止时刻> <新的JSONL路径>`，每轮实际操作回放、排程或轮换，记录构建和内存。

Windows构建使用 `desktop/requirements.txt` 指定的pywebview/PyInstaller，先建立虚拟环境，再执行：

```powershell
python -m PyInstaller --noconfirm --distpath release/desktop --workpath build/desktop desktop/DiningLab.spec
```

EXE的 `--self-test <结果JSON绝对路径>` 会隐藏启动真实WebView2，执行默认数值、126候选、九班表、三种轮换及载入检查。源码与Windows包使用同一套离线文件。

## 记录与出处

原参考包提供事件引擎和三维基础，本轮由AI辅助检索、开发、实验及文章整理；学生实际研究日志按本人完成的工作填写。研究台账保存每个来源的读取范围和采用内容，UI参考用户提供的Open Claude UI，保留MIT许可；Three.js许可在vendor和licenses中。

申报规则、学校名称来源和历史报道集中在 `research/规则与证据说明.md`。研究报告和指南与正式申报表分开，学校报送及材料大小按当届通知办理。
