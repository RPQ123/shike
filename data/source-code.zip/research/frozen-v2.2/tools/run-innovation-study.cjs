// Frozen-choice synthetic comparison. Run from repository root; no browser/UI data used.
const fs = require('node:fs'),
  crypto = require('node:crypto'),
  assert = require('node:assert/strict');
const E = require('../dist/school-engine.js'),
  R = require('../dist/research.js'),
  P = require('../dist/planner.js'),
  T = require('../dist/rotation.js');
const protocol = JSON.parse(fs.readFileSync('research/innovation-protocol.json', 'utf8'));
const hash = (x) =>
  crypto
    .createHash('sha256')
    .update(typeof x === 'string' || Buffer.isBuffer(x) ? x : JSON.stringify(x))
    .digest('hex');
const range = (d) => Array.from({ length: d.count }, (_, i) => d.start + i);
function contexts(base) {
  return protocol.contexts.map((def) => {
    const c = R.clone(base);
    const share = (p) => (c.gradeZoneWeights = c.grades.map(() => [p, 1 - p]));
    if (def.id === 'seats-60') {
      c.seats = 60;
      c.serviceZones.forEach((z, i) => (z.seats = [45, 15][i]));
    } else if (def.id === 'seats-240') {
      c.seats = 240;
      c.serviceZones.forEach((z, i) => (z.seats = [180, 60][i]));
    } else if (def.id.startsWith('service-')) {
      const v = Number(def.id.split('-')[1]);
      c.serviceMean = v;
      c.windowMeans = c.windowMeans.map(() => v);
    } else if (def.id === 'share-55') share(0.55);
    else if (def.id === 'share-90') share(0.9);
    else if (def.id === 'unequal-grades') c.grades.forEach((g, i) => (g.students = [80, 120, 160][i]));
    else if (def.id === 'unequal-windows') c.windowMeans = [12, 16, 20, 20, 24, 28];
    else if (def.id === 'walk-spread')
      c.grades.forEach((g) => {
        g.walkMin = 1;
        g.walkMax = 5;
      });
    else if (def.id === 'walk-asymmetric')
      c.grades.forEach((g, i) => {
        g.walkMin = [1, 2, 4][i];
        g.walkMax = [2, 4, 6][i];
      });
    else if (def.id === 'pooled') c.strategy = 'pooled';
    else if (def.id === 'meal-20') c.mealMean = 20;
    else assert.ok(['base', 'menu-shift'].includes(def.id), 'Unknown declared context');
    return { ...def, config: E.normalizeSchoolConfig(c) };
  });
}
function dayInputs(plan, context, days) {
  return Array.from({ length: days }, (_, i) => {
    const c = R.clone(plan.config);
    if (context.id === 'menu-shift') {
      const p = [0.75, 0.55, 0.9][i % 3];
      c.gradeZoneWeights = c.grades.map(() => [p, 1 - p]);
    }
    return E.normalizeSchoolConfig(c);
  });
}
function policyPlans(input, jointSelection, oldSelection) {
  const joint = P.makePlan(input, {
    order: jointSelection.order,
    slot: jointSelection.slot,
    aWindows: jointSelection.aWindows
  });
  const classOnly = P.makePlan(input, { order: jointSelection.order, slot: jointSelection.slot });
  const win = R.clone(input);
  win.windowZones = joint.config.windowZones.slice();
  const old = E.makeSchoolGapConfig(input, oldSelection.gap);
  old.windowZones = old.windowZones.map((_, i) => (i < oldSelection.aWindows ? 0 : 1));
  return [
    { id: 'reference', mode: 'fixed', plan: P.reference(input) },
    { id: 'window-only', mode: 'fixed', plan: P.reference(E.normalizeSchoolConfig(win)) },
    { id: 'class-only', mode: 'fixed', plan: classOnly },
    { id: 'grade-gap-balanced', mode: 'fixed', plan: P.reference(E.normalizeSchoolConfig(old)) },
    ...['fixed', 'cyclic', 'feedback'].map((mode) => ({ id: 'joint-' + mode, mode, plan: joint }))
  ];
}
function hindsight(plan, seeds, inputs, evaluate) {
  const possible = seeds.map((seed, i) =>
    T.orders(plan, inputs[i] ?? plan.config).map((p) => {
      const config = E.normalizeSchoolConfig({ ...p.config, seed });
      return {
        day: i + 1,
        seed,
        order: p.order,
        config,
        metrics: evaluate(config),
        decisionReason: '回看参照：已知未来全部餐次结果'
      };
    })
  );
  assert.ok(
    possible.every((a) => a.length),
    'No feasible order in hindsight benchmark'
  );
  let best = null,
    sequences = 0;
  function visit(days) {
    if (days.length < seeds.length) {
      for (const day of possible[days.length]) visit([...days, day]);
      return;
    }
    sequences++;
    const summary = T.summarize(days, plan.config),
      id = days.map((d) => d.order.join('')).join('-');
    const score = [summary.periodWorstGrade, summary.meanTotal, summary.periodGradeGap];
    let better = !best;
    if (best)
      for (let i = 0; i < score.length; i++)
        if (Math.abs(score[i] - best.score[i]) > 1e-9) {
          better = score[i] < best.score[i];
          break;
        }
    if (best && score.every((v, i) => Math.abs(v - best.score[i]) <= 1e-9)) better = id < best.id;
    if (better) best = { id, score, days: days.slice(), summary };
  }
  visit([]);
  return { kind: 'future-known-benchmark', mode: 'hindsight', seeds: seeds.slice(), sequences, ...best };
}
function pairedPeriods(a, b) {
  const keys = [
    'meanTotal',
    'periodWorstGrade',
    'periodGradeGap',
    'meanDailyWorstGrade',
    'peakQueue',
    'onTime'
  ];
  return Object.fromEntries(
    keys.map((key) => [
      key,
      {
        ...R.paired(
          a.map((r) => r.summary[key]),
          b.map((r) => r.summary[key])
        ),
        unit: key === 'peakQueue' ? 'people' : key === 'onTime' ? 'proportion' : 'minutes'
      }
    ])
  );
}
function main() {
  assert.notEqual(protocol.writtenAt, 'pending-before-execution');
  const startedAt = new Date().toISOString(),
    base = R.example(),
    cs = contexts(base),
    screenSeeds = range(protocol.screeningSeeds),
    verifySeeds = range(protocol.verificationSeeds);
  const sourceFiles = [
    'dist/engine.js',
    'dist/school-engine.js',
    'dist/research.js',
    'dist/planner.js',
    'dist/rotation.js',
    'tools/run-innovation-study.cjs'
  ];
  const sourceHashes = Object.fromEntries(sourceFiles.map((f) => [f, hash(fs.readFileSync(f))]));
  const cache = new Map(),
    ledger = [];
  function evaluate(config, use) {
    const canonical = P.configKey(config),
      key = hash(canonical);
    if (!cache.has(key)) {
      const record = {
        key,
        config: E.normalizeSchoolConfig(config),
        firstUse: use,
        metrics: R.metrics(E.simulateSchool(config))
      };
      cache.set(key, record);
      ledger.push(record);
    }
    return cache.get(key).metrics;
  }
  function evalRows(plans, seeds, phase, context) {
    return plans.map((p) => {
      const rounds = seeds.map((seed) => evaluate({ ...p.config, seed }, `${phase}/${context}/${p.id}`));
      return { ...p, seeds: seeds.slice(), rounds, summary: R.summarize(rounds) };
    });
  }
  const candidates = P.candidates(base),
    screened = evalRows(candidates.accepted, screenSeeds, 'screening', 'base');
  const reference = screened.find((x) => x.id === 'reference'),
    selection = P.choose(screened, reference, protocol.criteria);
  const oldPlans = R.candidates(base, { reallocate: true }).accepted.map((p) => ({
    ...p,
    id: p.gap === 2 && p.aWindows === 3 ? 'reference' : p.id
  }));
  const oldScreened = evalRows(oldPlans, screenSeeds, 'screening-old', 'base');
  const oldChoice = P.choose(
    oldScreened,
    oldScreened.find((x) => x.id === 'reference'),
    protocol.criteria
  ).balanced;
  const selected = Object.fromEntries(
    ['balanced', 'efficiency', 'lowPeak'].map((role) => [role, selection[role].id])
  );
  const frozen = {
    schema: 'dining-innovation-frozen/1',
    frozenAt: new Date().toISOString(),
    sourceHashes,
    protocolSha256: hash(protocol),
    selected,
    jointPlan: selection.balanced,
    oldPlan: oldChoice,
    screeningExecutions: ledger.length
  };
  fs.writeFileSync('data/innovation-frozen-selection.json', JSON.stringify(frozen, null, 2));
  const verificationStartedAt = new Date().toISOString();
  const singleMeal = [];
  const distinct = [...new Set(['reference', ...Object.values(selected)])];
  for (const context of cs) {
    const plans = distinct.map((id) => {
      const p = screened.find((r) => r.id === id);
      return id === 'reference'
        ? P.reference(context.config)
        : P.makePlan(context.config, { order: p.order, slot: p.slot, aWindows: p.aWindows });
    });
    const rows = evalRows(plans, verifySeeds, 'verification-single', context.id),
      ref = rows.find((x) => x.id === 'reference');
    singleMeal.push({
      contextId: context.id,
      label: context.label,
      rows,
      differences: Object.fromEntries(
        rows.map((row) => [
          row.id,
          Object.fromEntries(
            [
              'meanTotal',
              'worstGrade',
              'peakQueue',
              'meanWait',
              'onTime',
              ...P.activeGrades(context.config).map((id) => 'grade' + id + 'Total')
            ].map((k) => [
              k,
              {
                ...R.paired(
                  ref.rounds.map((x) => x[k]),
                  row.rounds.map((x) => x[k])
                ),
                unit: k === 'peakQueue' ? 'people' : k === 'onTime' ? 'proportion' : 'minutes'
              }
            ])
          )
        ])
      )
    });
  }
  const periods = [];
  for (const context of cs) {
    const plans = policyPlans(context.config, selection.balanced, oldChoice),
      policyRows = plans.map((p) => ({ ...p, rounds: [] }));
    const oracle = { id: 'hindsight', mode: 'future-known-benchmark', rounds: [] };
    for (let rep = 0; rep < protocol.periodSeeds.repeats; rep++) {
      const seeds = Array.from(
        { length: protocol.periodSeeds.days },
        (_, i) => protocol.periodSeeds.start + rep * protocol.periodSeeds.days + i
      );
      for (const row of policyRows)
        row.rounds.push(
          T.runPeriod(row.plan, {
            mode: row.mode,
            seeds,
            dayInputs: dayInputs(row.plan, context, seeds.length),
            evaluate: (c) => evaluate(c, `verification-period/${context.id}/${row.id}/${rep}`)
          })
        );
      const joint = plans.find((p) => p.id === 'joint-fixed').plan;
      oracle.rounds.push(
        hindsight(joint, seeds, dayInputs(joint, context, seeds.length), (c) =>
          evaluate(c, `hindsight/${context.id}/${rep}`)
        )
      );
    }
    const rows = [...policyRows, oracle];
    for (const row of rows) row.summary = R.summarize(row.rounds.map((r) => r.summary));
    const ref = rows.find((r) => r.id === 'reference'),
      fixed = rows.find((r) => r.id === 'joint-fixed'),
      cyclic = rows.find((r) => r.id === 'joint-cyclic');
    periods.push({
      contextId: context.id,
      label: context.label,
      rows,
      differences: Object.fromEntries(rows.map((row) => [row.id, pairedPeriods(ref.rounds, row.rounds)])),
      versusJointFixed: Object.fromEntries(
        rows.map((row) => [row.id, pairedPeriods(fixed.rounds, row.rounds)])
      ),
      versusCyclic: Object.fromEntries(rows.map((row) => [row.id, pairedPeriods(cyclic.rounds, row.rounds)]))
    });
    console.log(
      JSON.stringify({
        context: context.id,
        uniqueExecutions: ledger.length,
        periods: rows.map((r) => ({
          id: r.id,
          periodWorst: r.summary.periodWorstGrade,
          gap: r.summary.periodGradeGap,
          mean: r.summary.meanTotal
        }))
      })
    );
  }
  const fiveMeal = {
    contextId: 'base',
    days: protocol.fiveMealSeeds.days,
    rows: policyPlans(base, selection.balanced, oldChoice).map((p) => ({ ...p, rounds: [] }))
  };
  for (let rep = 0; rep < protocol.fiveMealSeeds.repeats; rep++) {
    const seeds = Array.from(
      { length: protocol.fiveMealSeeds.days },
      (_, i) => protocol.fiveMealSeeds.start + rep * protocol.fiveMealSeeds.days + i
    );
    for (const row of fiveMeal.rows)
      row.rounds.push(
        T.runPeriod(row.plan, {
          mode: row.mode,
          seeds,
          evaluate: (c) => evaluate(c, `five-meal/${row.id}/${rep}`)
        })
      );
  }
  for (const row of fiveMeal.rows) row.summary = R.summarize(row.rounds.map((r) => r.summary));
  const ledgerPath = 'data/innovation-execution-ledger.json';
  fs.writeFileSync(
    ledgerPath,
    JSON.stringify({ schema: 'dining-execution-ledger/1', sourceHashes, rows: ledger }, null, 2)
  );
  const counts = {
    uniqueExecutions: ledger.length,
    screeningExecutions: frozen.screeningExecutions,
    singleMealRows: singleMeal.reduce((n, c) => n + c.rows.length * verifySeeds.length, 0),
    periodRoleRuns: periods.reduce(
      (n, c) => n + c.rows.length * protocol.periodSeeds.repeats * protocol.periodSeeds.days,
      0
    ),
    fiveMealRoleRuns: fiveMeal.rows.length * protocol.fiveMealSeeds.repeats * protocol.fiveMealSeeds.days,
    ledgerSha256: hash(fs.readFileSync(ledgerPath))
  };
  const result = {
    schema: 'dining-innovation-study/1',
    dataNature: 'synthetic',
    startedAt,
    completedAt: new Date().toISOString(),
    verificationStartedAt,
    protocol,
    protocolSha256: hash(protocol),
    sourceHashes,
    frozen,
    screened,
    oldScreened,
    selection: selected,
    singleMeal,
    periods,
    fiveMeal,
    counts
  };
  fs.writeFileSync('data/innovation-study-results.json', JSON.stringify(result, null, 2));
  console.log(JSON.stringify({ selection: selected, oldChoice: oldChoice.id, counts }));
}
module.exports = { contexts, dayInputs, policyPlans, hindsight, pairedPeriods };
if (require.main === module) main();
