"""Windows shell for the same offline research app. No Python API is exposed.

Keep the executable with its _internal directory. Numerical work stays in the
audited JavaScript model, so desktop and browser versions share one codebase.
"""
from pathlib import Path
import argparse
import ctypes
import json
import os
import sys
import time
import traceback


def main():
    parser = argparse.ArgumentParser(description="食刻 · 校园食堂仿真实验室")
    parser.add_argument("--self-test", type=Path, help="Hidden WebView2 smoke test result")
    args = parser.parse_args()
    root = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))
    page = root / "dist" / "index.html"
    if not page.is_file():
        raise FileNotFoundError("缺少界面资源，请完整解压软件文件夹后运行。")
    profile = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "DiningLab" / "WebView2"
    if args.self_test:
        profile = args.self_test.resolve().parent / "desktop-test-profile"
    profile.mkdir(parents=True, exist_ok=True)

    import webview
    webview.settings["ALLOW_DOWNLOADS"] = True
    webview.settings["OPEN_EXTERNAL_LINKS_IN_BROWSER"] = True
    webview.settings["OPEN_DEVTOOLS_IN_DEBUG"] = False
    window = webview.create_window(
        "食刻 · 校园食堂仿真实验室", page.as_uri(),
        width=1440, height=960, min_size=(840, 640),
        hidden=bool(args.self_test), background_color="#f6f5ef",
        text_select=True, zoomable=True,
    )
    test_state = {"ok": False, "reason": "Window closed before verification"}

    def verify():
        try:
            if not window.events.loaded.wait(50):
                raise TimeoutError("WebView2 did not load within 50 seconds")
            deadline = time.monotonic() + 20
            snapshot = None
            while time.monotonic() < deadline:
                snapshot = window.evaluate_js("window.DiningLabSnapshot || null")
                if snapshot:
                    break
                time.sleep(.2)
            if not snapshot:
                raise RuntimeError("Research app did not initialize")
            assert snapshot['tab'] == 'setup'
            window.evaluate_js("document.querySelector('#setup-form button[type=submit]').click()")
            assert window.evaluate_js("DiningLabSnapshot.tab") == 'live'
            assert snapshot["config"]["students"] == 1610
            assert [g['students'] for g in snapshot['config']['grades']] == [580, 530, 500]
            assert snapshot["config"]["strategy"] == "fastest"
            assert snapshot["config"]["serviceZones"] is None
            assert snapshot["config"]["indoorWalkSpeed"] == 1.1
            journey = window.evaluate_js("(()=>{const E=CanteenSim,r=E.simulateSchool(DiningLabSnapshot.config),s=r.students.slice().sort((a,b)=>a.end-b.end)[0],f=CanteenSceneState.frame(r,(s.seatWalkStart+s.seatStart)/2);return {people:r.students.length,walkers:f.counts.walkingToSeat,visible:f.visibleDiningPeople.some(p=>p.id===s.id&&p.state==='walking-to-seat'),duration:s.indoorWalk,ordered:s.end<=s.seatWalkStart&&s.seatWalkStart<s.seatStart&&s.seatStart<s.mealEnd}})()")
            assert journey['people'] == 1610 and journey['walkers'] > 0 and journey['visible']
            assert journey['duration'] > 0 and journey['ordered']
            assert snapshot["metrics"]["meanWait"] < 1
            assert all(abs(g["classInterval"] - 3.5) < 1e-8 for g in snapshot["config"]["grades"])
            capability = window.evaluate_js("({userAgent:navigator.userAgent, canvas:!!document.querySelector('#scene3d canvas'), mode:window.DiningLabSnapshot.mode, webgl:(()=>{const canvas=document.querySelector('#scene3d canvas');const gl=canvas&&(canvas.getContext('webgl2')||canvas.getContext('webgl'));return gl?{version:gl.getParameter(gl.VERSION),lost:gl.isContextLost()}:null})(), origin:location.href})")
            assert capability['mode'] == '3d' and capability['canvas']
            assert capability['webgl'] and not capability['webgl']['lost']
            window.evaluate_js("localStorage.setItem('dining-desktop-smoke','verified')")
            assert window.evaluate_js("localStorage.getItem('dining-desktop-smoke')") == "verified"
            window.evaluate_js("localStorage.removeItem('dining-desktop-smoke')")
            simplified = window.evaluate_js("({removed:!document.querySelector('#legacy-comparison,.library-button,.utility-menu,#save,#import'),steps:Array.from(document.querySelectorAll('.workflow-nav button')).map(e=>e.textContent.trim())})")
            assert simplified['removed']
            assert simplified['steps'][1].endswith('运行过程') and simplified['steps'][2].endswith('仿真结果')
            window.evaluate_js("document.getElementById('view-2d').click()")
            assert window.evaluate_js("DiningLabSnapshot.mode") == '2d'
            window.evaluate_js("document.getElementById('view-3d').click()")
            assert window.evaluate_js("DiningLabSnapshot.mode") == '3d'
            window.evaluate_js("document.querySelector('[data-tab=compare]').click();document.getElementById('research-tools').open=true;document.getElementById('study-run-three').click()")
            deadline = time.monotonic() + 120
            while time.monotonic() < deadline:
                stage_one = window.evaluate_js("({busy:DiningLabSnapshot.busy,ready:!!DiningLabSnapshot.scheduleStudy.initial})")
                if not stage_one['busy'] and stage_one['ready']:
                    break
                time.sleep(.3)
            assert stage_one['ready'] and not stage_one['busy']
            window.evaluate_js("document.getElementById('study-tab-gaps').click();document.getElementById('study-run-gaps').click()")
            deadline = time.monotonic() + 240
            while time.monotonic() < deadline:
                new_study = window.evaluate_js("(()=>{const s=DiningLabSnapshot;return {busy:s.busy,selected:s.scheduleStudy.interval?.selectedSeconds,intervals:s.scheduleStudy.interval?.rows.length}})()")
                if not new_study['busy'] and new_study.get('selected') is not None:
                    break
                time.sleep(.3)
            assert new_study['selected'] == 70 and new_study['intervals'] == 13
            test_state.clear()
            test_state.update(ok=True, metrics=snapshot["metrics"], capability=capability,
                              build=snapshot['build'], simplifiedUI=simplified, viewSwitching=True,
                              indoorWalking=journey, threeSchedules=stage_one, intervalStudy=new_study)
        except Exception:
            test_state.update(ok=False, reason=traceback.format_exc())
        finally:
            args.self_test.parent.mkdir(parents=True, exist_ok=True)
            args.self_test.write_text(json.dumps(test_state, ensure_ascii=False, indent=2), encoding="utf-8")
            window.destroy()

    webview.start(verify if args.self_test else None, gui="edgechromium",
                  private_mode=False, storage_path=str(profile), debug=False)
    return 0 if not args.self_test or test_state["ok"] else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        error = "启动失败：" + str(exc) + "\n\n请确认已完整解压，并安装 Microsoft Edge WebView2 Runtime。也可打开离线网页版的 index.html。"
        if "--self-test" in sys.argv:
            print(error, file=sys.stderr)
        else:
            ctypes.windll.user32.MessageBoxW(0, error, "食刻 · 启动检查", 0x10)
        raise SystemExit(1)
