@echo off
start "" "%~dp0DiningLab\DiningLab.exe"
